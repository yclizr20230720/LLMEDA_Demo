Here's the complete breakdown of every file in the project, grouped by responsibility:

---

## Infrastructure (root level)

**`docker-compose.yml`** — Orchestrates four services: PostgreSQL 15 (data warehouse), Redis 7 (cache + rate limiting), the Flask backend, and the Vite frontend. Includes health checks so the backend waits for the database to be ready before starting.

---

## Backend (`backend/`)

### Entry & Config
**`run.py`** — Flask application entry point. Boots the app via `socketio.run()` for WebSocket support. Registers three CLI commands: `flask init-db` (create all tables), `flask seed-db` (populate demo data), `flask drop-db` (destructive wipe with confirmation).

**`config/settings.py`** — Three configuration classes (`DevelopmentConfig`, `ProductionConfig`, `TestingConfig`) controlling database URL, Redis URL, JWT expiry, CORS origins, rate limit settings, and FAB metadata. Loaded at startup by the app factory.

**`backend/.env`** — Runtime secrets: `DATABASE_URL`, `REDIS_URL`, `JWT_SECRET_KEY`, `SECRET_KEY`, `FAB_ID`, `PROCESS_NODE`. Never committed to version control.

**`requirements.txt`** — 33 packages including Flask, SQLAlchemy, Flask-JWT-Extended, Flask-Caching (Redis), Flask-Limiter, flask-socketio, psycopg2, pandas, numpy, scipy, scikit-learn, argon2-cffi.

**`Dockerfile`** — Python 3.11-slim image. Installs libpq-dev for PostgreSQL, copies requirements first for layer caching, then copies app source.

---

### App Factory (`app/__init__.py`)
The Flask application factory. Initialises all extensions in order (SQLAlchemy → Migrate → JWT → Cache → Limiter → CORS → SocketIO), then registers all 11 route blueprints, global error handlers, and WebSocket event handlers.

---

### Middleware
**`middleware/request_id.py`** — Injects a unique `X-Request-ID` header on every request (reads from incoming header or generates a UUID). Also adds `X-Powered-By: SEMFAB-IQ/1.0` on every response. Stored in Flask `g` for audit logging.

**`middleware/audit.py`** — Logs every API request after it completes: method, path, status code, duration in milliseconds, and request ID. Only fires for paths starting with `/api/`.

---

### Utils
**`utils/response.py`** — Three response envelope helpers used by every route: `success(data, meta)`, `error(code, message, details, status_code)`, and `paginated(data, total, page, per_page)`. All include a `trace_id` (UUID) and `timestamp` in every response.

**`utils/errors.py`** — Flask error handler registration for HTTP 400, 401, 403, 404, 405, 422, 429, and 500. All return the standard JSON envelope from `response.py` rather than Flask's default HTML error pages.

**`utils/websocket.py`** — Socket.IO event handlers: `connect` (sends FAB status), `subscribe`/`unsubscribe` (room join/leave for selective broadcasts), `disconnect`, and `ping`/`pong` for keepalive.

---

### Models (`app/models/`)
All models inherit `TimestampMixin` from `base.py` which adds `created_at`, `updated_at`, and safe-cast helpers `_f()` (float) and `_d()` (ISO date string). Every model implements `to_dict()` returning only JSON-serialisable types.

**`base.py`** — `TimestampMixin` with `created_at`, `updated_at`, `_f()`, `_d()`.

**`user.py`** — Authentication model (`auth_users` table). Argon2id password hashing with fallback to SHA-256+salt when argon2-cffi isn't available. Account lockout after 5 failed attempts (15-minute lock). Tracks `last_login`, `login_count`, `failed_logins`, `locked_until`.

**`lot.py`** — `Lot` model (SCD-2 capable with `is_current`, `effective_from`, `effective_to`). Stores lot type, product, priority, hold code/reason, SYL/SBL limits, wafer count. `Wafer` model stores per-slot disposition, CP yield, die counts.

**`equipment.py`** — `Equipment` with health scoring (four components: Z-score 35%, GOF 30%, CV stability 20%, volume 15%). `composite_health` property recomputes live from stored components. `Chamber` stores per-chamber health and PM history.

**`wat.py`** — Four tables: `WATParameter` (parameter catalogue), `WATSpec` (USL/LSL/SPC limits per product × parameter × conditions), `WATResult` (individual site measurements with outlier flags), `WATLotSummary` (pre-aggregated statistics per lot × wafer × parameter including Cp/Cpk/Cpm).

**`cp.py`** — `CPDieResult` (per-die hard/soft bin, X/Y coordinates, touch-down, spatial cluster flag) and `CPWaferSummary` (gross/net/first-pass yield, bin counts JSON, site yields JSON, pattern classification, all MRB flag columns: `syl_flag`, `sbl_flag`, `wafer_pattern_flag`, `wafer_cluster_flag`, `mrb_required`, `mrb_result`).

**`spc.py`** — Four tables: `SPCConfig` (per-parameter control limits, sigma, 8 WE rules bitmask `enabled_rules`, virtual metrology fields), `SPCMeasurement` (individual measurements with `violation_rule_1` through `violation_rule_8` as separate booleans for fast querying), `SPCViolation` (triggered violations with acknowledgement and resolution fields), `SPCCapability` (period-aggregated Cp/Cpk/Pp/Ppk by equipment and period).

**`fdc.py`** — Four tables: `FDCSensor` (sensor catalogue per equipment), `FDCIndicator` (statistical features extracted from sensor traces, with Cp/Cpk and alarm rates), `FDCTraceRun` (per-run record with four anomaly sub-scores: interval, PM drift, amplitude, shape, plus composite), `FDCPMEvent` (maintenance events with pre/post health scores and qualification result).

**`defect.py`** — `DefectResult` (individual defect with ADC classification, kill probability, SEM review flag) and `DefectWaferSummary` (aggregated density, killer count, pattern class, suspected equipment hypothesis).

---

### Services (`app/services/`)

**`spc_engine.py`** (425 lines) — The statistical engine. Eight individual Western Electric rule functions (`rule_1` through `rule_8`), each returning a list of violating point indices. `check_all_rules()` runs all enabled rules via bitmask and returns per-rule results plus a unified violation index set. `estimate_sigma_rbar()` uses the Rbar/d2 method (moving range for IMR charts, subgroup ranges for Xbar charts) with the D2 constants table. `compute_capability()` produces the full Cp/Cpk/Cpm/Cpl/Cpu/Pp/Ppk suite plus Shapiro-Wilk normality test and distribution percentiles. `one_way_anova()` computes SS/MS/F-statistic/p-value/η²/ω² with full group statistics. `pearson_correlation()` returns Pearson + Spearman + OLS regression (slope, intercept, R², adjusted R², F-statistic).

**`data_generator.py`** (809 lines) — Complete demo data seeder. `seed_users()` creates 6 users with roles. `seed_equipment()` creates 12 equipment + 24 chambers with realistic health scores. `seed_wat_params()` creates 10 WAT parameters with specs for 3 products. `seed_lots_and_results(n=50)` generates 50 lots × 25 wafers × 9 sites × 10 parameters ≈ 112,500 WAT results, plus CP wafer summaries with realistic yield distributions (lots 18 and 32 are excursion lots with BVJ degradation). `seed_spc()` creates 6 SPC configs with 90 measurements each, injecting Rule 1 excursions at points 40–44, Rule 2 at 60–68, Rule 5 at 75–77. `seed_fdc()` creates 13 sensors, 6 indicators, 150 trace runs with PM_DRIFT anomaly cluster at runs 65–75 and AMPLITUDE cluster at 110–115. `seed_defects()` creates defect data for 10 lots.

---

### Routes (`app/routes/`)

**`health.py`** — `GET /health` (pings DB and Redis, returns service status). `GET /api/v1/version`.

**`auth.py`** — JWT authentication: `POST /login` (with lockout logic, JWT claims injection), `POST /refresh`, `GET /me`, `POST /logout`, `POST /change-password`, `GET /users` (manager/admin only).

**`yield_routes.py`** (299 lines) — Seven endpoints: `/kpi` (fab-level aggregate), `/trend` (daily P10/P50/P90 bands using `percentile_cont`), `/summary` (paginated lot score card), `/wafer-gallery`, `/bin-pareto` (with cumulative %), `/excursions`, `/lot/<lot_id>`, `/products`.

**`wat_routes.py`** (459 lines) — Eight endpoints: `/parameters`, `/specs`, `/distribution` (histogram + KDE + capability + equipment breakdown), `/trend` (lot-sequence with group-by option), `/correlation-matrix` (full Pearson matrix), `/correlation-scatter`, `/anova` (one-way with η²), `/site-map`, `/equipment-health` (Z-score + CV composite scoring).

**`cp_routes.py`** (292 lines) — Seven endpoints: `/bin-map` (columnar xs/ys/bins/passes), `/wafer-summary`, `/mrb-review` (all flag columns), `/die-result/<sk>`, `/touchdown-summary`, `/site-yield`, `/pattern-gallery` (with example wafers), `/lot-compare`.

**`spc_routes.py`** (353 lines) — Eight endpoints: `/configs`, `/chart` (with live rule recomputation and 1σ/2σ zone bands), `/violations` (filterable + paginated), `/capability`, `/check-rules` (POST arbitrary array), `/violations/<sk>/acknowledge`, `/configs/<id>` (PUT), `/annotations` (POST), `/dashboard-summary`.

**`fdc_routes.py`** (309 lines) — Seven endpoints: `/trace-runs` (filterable by equipment, anomaly class, score), `/anomaly-summary` (per-equipment rates and sub-scores), `/pm-events`, `/sensors`, `/indicators`, `/qualification-compare`, `/alarm-drill-down` (sensor breakdown + class distribution), `/trend` (daily anomaly rate).

**`equipment_routes.py`** — Five endpoints: `GET /` (list with health tier counts), `GET /<id>` (with chambers), `GET /<id>/health-history`, `GET /<id>/chambers`, `GET /pm-schedule` (overdue + due within 14 days).

**`defect_routes.py`** — Five endpoints: `/summary` (paginated), `/pareto` (with cumulative % and killer %), `/wafer-map` (columnar XY + class + killer + size), `/classify` (POST human review override), `/pattern-analysis`.

**`mrb_routes.py`** — Three endpoints: `/review` (wafers awaiting decision), `/decision` (POST: GoodWafer/BadWafer/ScrapWafer), `/consolidation` (all flag columns report).

**`alarm_routes.py`** (212 lines) — Three endpoints: `/active` (aggregates SPC violations + FDC anomaly runs + yield excursions into unified alarm list with severity), `/<id>/acknowledge`, `/history` (filterable by source: SPC/FDC/YIELD).

---

## Frontend (`frontend/`)

### Config
**`package.json`** — React 18, React Router 6, TanStack Query 5, Axios, Zustand, Recharts, Framer Motion, Socket.IO client, date-fns, clsx. Dev: Vite 5, TypeScript 5, Tailwind CSS 3.

**`vite.config.ts`** — Path alias `@/` → `src/`. Dev server proxy for `/api` → backend. Host `0.0.0.0` for Docker.

**`tsconfig.json`** — Strict TypeScript, `moduleResolution: bundler`, path aliases matching Vite config.

**`tailwind.config.js`** — Extended color palette: `void` (#060A12), `surface` (#0B1120), `elevated`, `card`, plus `teal`, `violet`, `amber`, `coral`, `sky`, `lime`, `pass`, `warn`, `fail`. Custom font families: `display` (Space Grotesk), `body` (Inter), `mono` (JetBrains Mono).

**`index.html`** — Loads Space Grotesk + Inter + JetBrains Mono from Google Fonts. Single `<div id="root">`.

**`Dockerfile.dev`** — Node 20 Alpine. Installs npm packages, starts `vite --host 0.0.0.0`.

---

### `src/`

**`main.tsx`** — Creates `QueryClient` (staleTime 30s, retry 2, no refetch on window focus), wraps app in `BrowserRouter` and `QueryClientProvider`.

**`App.tsx`** — Route definitions. `ProtectedRoute` wrapper checks `isAuthenticated` from authStore and redirects to `/login`. Five protected routes: `/` (YMS), `/wat`, `/cp`, `/spc`, `/fdc`.

**`styles/globals.css`** — CSS custom properties for all design tokens. Utility classes: `.panel`, `.panel-header`, `.panel-body`, `.kpi-card`, `.data-table` (with `th` and `td` rules), `.badge` variants (pass/warn/coral/violet/teal/sky/amber), `.cell-pass/warn/fail`, `@keyframes fadeIn` and `pulse-badge`, `.animate-fade-in`, `.animate-pulse-red`. Global scrollbar styling. Recharts tooltip overrides.

**`types/index.ts`** — Full TypeScript interfaces for every domain entity: `User`, `Equipment`, `Chamber`, `YieldKPI`, `YieldTrendPoint`, `LotSummary`, `WATParameter`, `WATDistribution`, `WATTrendRow`, `CPBinMap`, `CPWaferSummary`, `SPCConfig`, `SPCMeasurement`, `SPCCapabilityResult`, `FDCTraceRun`, `FDCSensor`, `FDCIndicator`, `Alarm`, `ApiResponse<T>`, `PaginatedResponse<T>`.

---

### `api/`
**`client.ts`** — Axios instance with 30s timeout. Request interceptor attaches `Authorization: Bearer` from localStorage. Response interceptor handles 401 by queueing concurrent requests, refreshing the token once, replaying the queue on success, or redirecting to `/login` on failure.

**`endpoints.ts`** — Typed function wrappers for every API endpoint: `authApi`, `yieldApi`, `watApi`, `cpApi`, `spcApi`, `fdcApi`, `equipmentApi`, `alarmApi`, `defectApi`. All functions accept typed parameters and return typed Axios promises.

---

### `store/`
**`authStore.ts`** — Zustand with `persist` middleware. Stores `user`, `accessToken`, `refreshToken`, `isAuthenticated`. `setAuth()` writes tokens to localStorage. `logout()` clears both store and localStorage.

**`fabStore.ts`** — Real-time FAB state: `activeAlarms[]`, `criticalCount`, `equipmentStatusMap`. Updated by WebSocket events and alarm polling. `setAlarms()` also recomputes `criticalCount`.

**`uiStore.ts`** — UI state: `sidebarCollapsed`, `activeModule`, `commandPaletteOpen`. `toggleSidebar()` is the main action used by the sidebar collapse button.

---

### `hooks/`
**`useWebSocket.ts`** — Connects to Socket.IO with JWT auth. Subscribes to `fab-global` room on connect. Handles `alarm` events (calls `addAlarm`) and `equipment_status` events (calls `setEquipmentStatus`). Implements exponential backoff reconnection via `reconnectionDelay: min(1000 × 2^retryCount, 30000)`.

**`useWaferRenderer.ts`** — Canvas ImageData bitmap renderer. Single O(n) pass over all die coordinates. Uses circular clip (wafer boundary) to exclude corner dies. Colour-codes by bin number using a `BIN_COLORS` map. Draws wafer ring and flat-zone indicator in a second pass. Triggered by `useEffect` on coordinate array changes.

---

### `components/layout/`
**`AppShell.tsx`** — Root layout component. Calls `useWebSocket()` to start the Socket.IO connection. Renders `<Sidebar>` + vertical flex column containing `<TopBar>` + `<main>` with `<Outlet>`.

**`Sidebar.tsx`** — Collapsible navigation with five module entries (YMS/WAT/CP/SPC/FDC), each with icon, label, abbreviation, and module-specific accent colour. Active link highlighted with coloured left border and tinted background. Shows critical alarm count badge at the bottom. Width transitions between 200px (expanded) and 56px (collapsed) via CSS transition.

**`TopBar.tsx`** — Live clock (1s interval), FAB ONLINE green pulse indicator, critical alarm badge (with `animate-pulse-red` class), user dropdown (avatar initials, name, role, sign-out button). Polls `alarmApi.active()` every 30s via TanStack Query and writes to `fabStore`.

---

### `pages/`

**`LoginPage.tsx`** (184 lines) — Animated particle canvas background (80 particles, RAF loop, teal alpha). Four quick-fill demo user buttons. Username + password form with teal focus border animation. Error display and loading state. Calls `authApi.login()` and dispatches `setAuth()` on success.

**`yms/YMSDashboard.tsx`** (356 lines) — Five components: `KPIStrip` (5 metric cards), `YieldTrendChart` (Recharts AreaChart with P10/P90 gradient band, P50 line, SYL/SBL reference lines), `LotScoreCard` (sortable table with colour-coded yield cells and SYL/SBL/MRB flag columns), `AlarmFeed` (severity-coloured alarm cards with left-border accent), `BinParetoMini` (horizontal BarChart with per-bin colours and cumulative label). Product selector and days (7/14/30/60) controls.

**`wat/WATAnalytics.tsx`** (630 lines) — Five tabs. **Distribution**: histogram + KDE ComposedChart, USL/LSL/mean reference lines, normality badge, 8-stat grid, equipment breakdown cards, SVG CpkGauge with needle + zone markers, Cp/Cpk/Cpm/Ppk progress bars, spec limits panel. **Trend**: LineChart with custom dot renderer (red = Cpk < 1.0, amber = < 1.33, green = ≥ 1.33), equipment filter, sortable trend table. **Correlation**: interactive Pearson heatmap (click cell → scatter), colour scale (teal positive, coral negative), OLS scatter chart with r/p/R²/n stats. **ANOVA**: factor toggle (equipment/chamber/recipe), F-stat/p-value/η²/ω² stat cards with significance badge, group stats table. **Equipment Health**: tier summary cards, health score progress bar table.

**`cp/CPAnalytics.tsx`** (584 lines) — Four tabs. **Bin Map**: Canvas ImageData wafer (via `useWaferRenderer`), 25-wafer gallery grid with colour-coded SVG rings, aggregate bin pareto BarChart, selected wafer detail panel. **MRB Review**: 6-stat summary strip, full MRB table with all flag columns (SYL/SBL/pattern/cluster/partial/MRB result). **Site Yield**: wafer selector, 9-cell 3×3 grid heatmap with temperature colour scale (red→green), gradient scale bar. **Pattern Gallery**: pattern cards with icon, count, avg/min yield, example lot list.

**`spc/SPCMonitor.tsx`** (506 lines) — Config selector dropdown, days control. Rule toggle buttons (bitmask — clicking bit-XORs the `enabled_rules` integer). Rule summary bar (8 count badges, coloured by rule, filled when triggered). Custom Recharts dot renderer (violation dots show rule-colour ring). ComposedChart with UCL/CL/LCL reference lines and ±1σ/±2σ zone lines, USL/LSL when available, VM prediction band when present. Capability sidebar with mini CPK gauge ring, Cp/Cpk/Cpm/Pp/Ppk/n/mean grid. Unacknowledged violations table with `ACK` button (calls `spcApi.acknowledge()`).

**`fdc/FDCEngine.tsx`** (618 lines) — Equipment selector. Three tabs. **Sensor Qualification**: sigma limit slider (3–9), sensor pass-rate bar list, FDC indicator table (feature type, alarm mode, Cp/Cpk, runs/alarms/rate), PM event timeline with health improvement. **Trace Run Review**: daily anomaly rate BarChart (colour by rate threshold), anomaly-only toggle, run table with composite score colouring; selected run panel with 5-axis RadarChart (Interval/PM Drift/Amplitude/Shape/Composite), four `ScoreRing` SVGs. **Alarm Drill-Down**: fleet anomaly rate horizontal BarChart, anomaly class distribution bar chart, sensor alarm breakdown list with count + rate + progress bars.