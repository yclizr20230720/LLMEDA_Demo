// ── Auth ─────────────────────────────────────────────────────────────────────
export interface User {
  username: string; email: string; full_name: string;
  role: string; department?: string; fab_id: string;
  is_active: boolean; last_login?: string; login_count: number;
}

// ── Equipment ────────────────────────────────────────────────────────────────
export interface Equipment {
  equipment_id: string; equipment_name: string; equipment_type: string;
  equipment_subtype?: string; oem_vendor?: string; oem_model?: string;
  fab_id: string; bay_id?: string; area_id?: string;
  chamber_count: number; is_multi_chamber: boolean; wafer_size_mm: number;
  equipment_status: string; is_golden_tool: boolean;
  health_score: number; health_tier: 'HEALTHY' | 'WATCH' | 'DEGRADED' | 'CRITICAL';
  z_score_component?: number; gof_component?: number;
  cv_stability_component?: number; volume_component?: number;
  last_pm_date?: string; next_pm_date?: string;
  pm_interval_days?: number; run_since_pm?: number;
  chambers?: Chamber[];
}

export interface Chamber {
  equipment_id: string; chamber_id: string; chamber_name?: string;
  chamber_type?: string; chamber_status: string;
  health_score?: number; last_pm_date?: string;
  run_since_pm: number; is_reference_chamber: boolean;
}

// ── Yield ─────────────────────────────────────────────────────────────────────
export interface YieldKPI {
  avg_yield_pct: number; min_yield_pct: number; max_yield_pct: number;
  std_yield_pct: number; wafer_count: number; lot_count: number;
  total_pass_die: number; total_die: number; fab_yield_pct: number;
  syl_wafer_count: number; sbl_wafer_count: number; period_days: number;
}

export interface YieldTrendPoint {
  date: string; mean: number; min: number; max: number;
  std: number; p10: number; p50: number; p90: number; n: number;
}

export interface LotSummary {
  lot_id: string; product_id: string; process_node: string;
  tester_id?: string; avg_yield: number; avg_first_pass?: number;
  avg_retest_rate?: number; avg_uph?: number;
  total_die: number; total_pass: number; wafer_count: number;
  any_syl: boolean; any_sbl: boolean; any_mrb: boolean;
  last_test_date: string;
}

// ── WAT ───────────────────────────────────────────────────────────────────────
export interface WATParameter {
  parameter_id: string; parameter_name: string; parameter_group: string;
  device_type?: string; mos_type?: string; unit?: string;
  is_spc_monitored?: boolean; criticality_rank?: number;
  layer_name?: string; process_module?: string; count?: number;
}

export interface WATDistribution {
  parameter_id: string; n: number; usl?: number; lsl?: number; target?: number;
  histogram: { counts: number[]; edges: number[] };
  kde?: { x: number[]; y: number[] };
  capability: {
    mean: number; median: number; std_within: number; std_overall: number;
    min: number; max: number; p5?: number; p25?: number; p75?: number; p95?: number;
    skewness?: number; kurtosis?: number;
    cp?: number; cpk?: number; cpm?: number; cpl?: number; cpu?: number;
    pp?: number; ppk?: number; shapiro_wilk_p?: number; is_normal?: boolean;
  };
  outliers: { mad: number; grubbs: number };
  equipment_breakdown: Record<string, { n: number; mean: number; std: number }>;
}

export interface WATTrendRow {
  lot_id: string; wafer_id: string; parameter_id: string;
  mean_value: number; std_dev: number; cp?: number; cpk?: number;
  event_date: string; equipment_id?: string;
}

// ── CP ────────────────────────────────────────────────────────────────────────
export interface CPBinMap {
  lot_id: string; wafer_id: string;
  xs: number[]; ys: number[]; bins: number[]; passes: boolean[];
  die_count: number; pass_count: number; fail_count: number;
  gross_yield_pct: number; bin_counts: Record<string, number>;
}

export interface CPWaferSummary {
  lot_id: string; wafer_id: string; slot_number: number;
  program_id?: string; tester_id?: string; step_id?: string;
  total_die?: number; pass_die?: number; fail_die?: number;
  gross_yield_pct?: number; net_yield_pct?: number; first_pass_yield?: number;
  retest_count?: number; offline_retest_rate?: number; good_part_uph?: number;
  avg_sites?: number;
  bin_counts_json?: string; site_yields_json?: string;
  pattern_class_generic?: string; pattern_confidence?: number;
  edge_yield_pct?: number; center_yield_pct?: number;
  is_partial_wafer: boolean; syl_flag: boolean; sbl_flag: boolean;
  wafer_pattern_flag?: boolean; wafer_cluster_flag?: boolean;
  mrb_required?: boolean; mrb_result?: string;
  event_date: string;
}

// ── SPC ───────────────────────────────────────────────────────────────────────
export interface SPCConfig {
  config_id: string; parameter_id: string; parameter_source: string;
  parameter_desc?: string; equipment_id?: string; chamber_id?: string;
  chart_type: string; subgroup_size: number;
  ucl?: number; cl?: number; lcl?: number;
  ucl_2sigma?: number; lcl_2sigma?: number;
  ucl_1sigma?: number; lcl_1sigma?: number;
  sigma_estimate?: number; usl?: number; lsl?: number; target?: number;
  enabled_rules: number; alarm_mode: string; alarm_severity: string;
  is_active: boolean;
}

export interface SPCMeasurement {
  measurement_sk: number; config_id: string; parameter_id: string;
  lot_id?: string; wafer_id?: string; equipment_id?: string;
  subgroup_index?: number; measured_value: number;
  moving_range?: number; sigma_score?: number;
  ucl_at_time?: number; cl_at_time?: number; lcl_at_time?: number;
  violation_rule_1: boolean; violation_rule_2: boolean; violation_rule_3: boolean;
  violation_rule_4: boolean; violation_rule_5: boolean; violation_rule_6: boolean;
  violation_rule_7: boolean; violation_rule_8: boolean;
  any_violation: boolean; violation_rules_list?: string;
  alarm_triggered: boolean; alarm_severity?: string;
  is_virtual?: boolean; vm_predicted_value?: number;
  vm_ci_lower?: number; vm_ci_upper?: number;
  measurement_time: string; event_date: string;
}

export interface SPCCapabilityResult {
  n: number; mean: number; median: number;
  std_within: number; std_overall: number;
  min: number; max: number; p5?: number; p95?: number;
  skewness?: number; kurtosis?: number;
  usl: number; lsl: number; target?: number;
  cp?: number; cpk?: number; cpm?: number; cpl?: number; cpu?: number;
  pp?: number; ppk?: number;
  shapiro_wilk_p?: number; is_normal?: boolean;
}

// ── FDC ───────────────────────────────────────────────────────────────────────
export interface FDCTraceRun {
  run_id: string; lot_id?: string; wafer_id?: string;
  equipment_id: string; chamber_id?: string;
  recipe_id?: string; step_id?: string;
  run_start_time: string; run_end_time?: string; run_duration_sec?: number;
  run_result: string; alarm_count: number; alarm_sensor_list?: string;
  interval_anomaly_score?: number; pm_anomaly_score?: number;
  amplitude_anomaly_score?: number; shape_anomaly_score?: number;
  composite_anomaly_score?: number; anomaly_class?: string;
  is_anomaly: boolean; is_post_pm: boolean; is_qualification_run?: boolean;
  qual_match_score?: number; event_date: string;
}

export interface FDCSensor {
  equipment_id: string; sensor_alias: string; sensor_full_name?: string;
  sensor_type?: string; measurement_units?: string;
  module_id?: string; sampling_rate_hz?: number;
  is_fdc_monitored: boolean; baseline_sigma_limit?: number;
}

export interface FDCIndicator {
  indicator_id: string; indicator_name?: string;
  equipment_id: string; recipe_id?: string; sensor_alias?: string;
  feature_type?: string; alarm_mode: string;
  ucl?: number; lcl?: number; cl?: number;
  ca?: number; cp?: number; cpk?: number;
  total_runs: number; total_alarms: number; alarm_rate_pct?: number;
}

// ── Alarms ────────────────────────────────────────────────────────────────────
export interface Alarm {
  alarm_id: string; source: 'SPC' | 'FDC' | 'YIELD';
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR';
  title: string; message: string;
  entity_id?: string; equipment_id?: string; lot_id?: string;
  timestamp?: string; acknowledged: boolean;
}

// ── API Response Envelope ─────────────────────────────────────────────────────
export interface ApiResponse<T = unknown> {
  status: 'success' | 'error'; data: T;
  meta: Record<string, unknown>;
  errors: { code: string; message: string }[];
  trace_id: string; timestamp: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  meta: { total: number; page: number; per_page: number; pages: number };
}
