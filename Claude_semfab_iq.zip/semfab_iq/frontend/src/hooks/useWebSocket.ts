import { useEffect, useRef } from 'react'
import { io, Socket } from 'socket.io-client'
import { useFabStore } from '@/store/fabStore'
import type { Alarm } from '@/types'

const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:5000'

export function useWebSocket() {
  const socketRef = useRef<Socket | null>(null)
  const { addAlarm, setEquipmentStatus } = useFabStore()
  const retryRef = useRef(0)

  useEffect(() => {
    const token = localStorage.getItem('access_token')
    if (!token) return

    const connect = () => {
      const socket = io(WS_URL, {
        auth: { token },
        reconnection: true,
        reconnectionDelay: Math.min(1000 * 2 ** retryRef.current, 30000),
        transports: ['websocket', 'polling'],
      })

      socket.on('connect', () => {
        retryRef.current = 0
        socket.emit('subscribe', { room: 'fab-global' })
      })

      socket.on('alarm', (alarm: Alarm) => addAlarm(alarm))
      socket.on('equipment_status', ({ equipment_id, status }: { equipment_id: string; status: string }) => {
        setEquipmentStatus(equipment_id, status)
      })
      socket.on('disconnect', () => { retryRef.current += 1 })
      socketRef.current = socket
    }

    connect()
    return () => { socketRef.current?.disconnect() }
  }, [])

  return socketRef
}
