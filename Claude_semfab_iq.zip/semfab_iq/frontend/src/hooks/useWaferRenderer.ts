import { RefObject, useEffect } from 'react'

const BIN_COLORS: Record<number, [number, number, number]> = {
  1:  [16, 185, 129],   // pass — emerald
  8:  [56, 189, 248],   // bin 8 — sky
  14: [139, 92, 246],   // bin 14 — violet
  9:  [245, 158, 11],   // bin 9 — amber
  12: [239, 68, 68],    // bin 12 — red
  6:  [132, 204, 16],   // bin 6 — lime
  4:  [236, 72, 153],   // bin 4 — pink
  0:  [71, 85, 105],    // untested — slate
}
const DEFAULT_COLOR: [number, number, number] = [100, 116, 139]

export function useWaferRenderer(
  canvasRef: RefObject<HTMLCanvasElement>,
  xs: number[],
  ys: number[],
  bins: number[],
  _passes: boolean[],
  colorOverride?: Record<number, [number, number, number]>
) {
  const palette = colorOverride || BIN_COLORS

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !xs.length) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const W = canvas.width, H = canvas.height
    const minX = Math.min(...xs), maxX = Math.max(...xs)
    const minY = Math.min(...ys), maxY = Math.max(...ys)
    const rangeX = maxX - minX + 1, rangeY = maxY - minY + 1
    const cellW = W / rangeX, cellH = H / rangeY
    const cellSize = Math.min(cellW, cellH)
    const padX = (W - cellSize * rangeX) / 2
    const padY = (H - cellSize * rangeY) / 2

    // ImageData bitmap approach — O(n) single pass
    const imgData = ctx.createImageData(W, H)
    const buf = imgData.data

    // Fill void
    for (let i = 0; i < buf.length; i += 4) {
      buf[i] = 6; buf[i+1] = 10; buf[i+2] = 18; buf[i+3] = 255
    }

    // Draw circular wafer boundary
    const cx = W / 2, cy = H / 2
    const radius = Math.min(W, H) / 2 - 2

    for (let idx = 0; idx < xs.length; idx++) {
      const bin = bins[idx]
      const [r, g, b] = palette[bin] || DEFAULT_COLOR
      const px = padX + (xs[idx] - minX) * cellSize
      const py = padY + (ys[idx] - minY) * cellSize
      const pw = Math.max(1, Math.floor(cellSize) - 1)
      const ph = Math.max(1, Math.floor(cellSize) - 1)

      for (let dy = 0; dy < ph; dy++) {
        for (let dx = 0; dx < pw; dx++) {
          const pixX = Math.floor(px) + dx
          const pixY = Math.floor(py) + dy
          if (pixX < 0 || pixX >= W || pixY < 0 || pixY >= H) continue
          // Clip to circle
          const dist = Math.hypot(pixX - cx, pixY - cy)
          if (dist > radius) continue
          const i = (pixY * W + pixX) * 4
          buf[i] = r; buf[i+1] = g; buf[i+2] = b; buf[i+3] = 255
        }
      }
    }

    ctx.putImageData(imgData, 0, 0)

    // Draw wafer ring
    ctx.beginPath()
    ctx.arc(cx, cy, radius, 0, Math.PI * 2)
    ctx.strokeStyle = 'rgba(255,255,255,0.15)'
    ctx.lineWidth = 1.5
    ctx.stroke()

    // Flat zone (bottom)
    ctx.beginPath()
    ctx.moveTo(cx - radius * 0.35, cy + radius)
    ctx.lineTo(cx + radius * 0.35, cy + radius)
    ctx.strokeStyle = 'rgba(255,255,255,0.3)'
    ctx.lineWidth = 2
    ctx.stroke()

  }, [xs, ys, bins, canvasRef])
}
