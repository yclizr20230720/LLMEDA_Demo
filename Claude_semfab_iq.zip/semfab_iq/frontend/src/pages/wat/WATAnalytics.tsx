import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ReferenceLine, ResponsiveContainer, Cell, ComposedChart } from 'recharts'
import { watApi } from '@/api/endpoints'
import type { WATDistribution, WATTrendRow, WATParameter } from '@/types'
import { clsx } from 'clsx'

const PARAMS = ['IDSAT_N','IDSAT_P','VTN','VTP','IOFF_N','BVJ','REXT','GATOX_THK','NRES','CFMOM14']
const FACTORS = ['equipment_id','chamber_id','recipe_id']

// ─── CPK Gauge SVG ────────────────────────────────────────────────────────────
function CpkGauge({ cpk, label='Cpk' }: { cpk: number; label?: string }) {
  const pct = Math.min(1, Math.max(0, cpk / 2.0))
  const angle = pct * 180 - 90
  const rad = angle * Math.PI / 180
  const nx = 70 + 56 * Math.cos(rad)
  const ny = 70 + 56 * Math.sin(rad)
  const color = cpk >= 1.67 ? '#10B981' : cpk >= 1.33 ? '#F59E0B' : '#EF4444'
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center' }}>
      <svg width={140} height={84} viewBox="0 0 140 84">
        <path d="M14 70 A56 56 0 0 1 126 70" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={10} strokeLinecap="round"/>
        {/* Zones */}
        {[1.0, 1.33, 1.67].map((v,i) => {
          const a = ((v/2)*180-90)*Math.PI/180
          return <line key={i} x1={70+46*Math.cos(a)} y1={70+46*Math.sin(a)} x2={70+66*Math.cos(a)} y2={70+66*Math.sin(a)} stroke="rgba(255,255,255,0.15)" strokeWidth={1}/>
        })}
        <path d={`M14 70 A56 56 0 0 1 ${nx} ${ny}`} fill="none" stroke={color} strokeWidth={10} strokeLinecap="round"/>
        <line x1={70} y1={70} x2={nx} y2={ny} stroke="white" strokeWidth={2} strokeLinecap="round" opacity={0.6}/>
        <circle cx={70} cy={70} r={4} fill={color}/>
        <text x={70} y={60} textAnchor="middle" fill={color} fontSize={16} fontFamily="JetBrains Mono" fontWeight="700">{cpk.toFixed(3)}</text>
        <text x={70} y={75} textAnchor="middle" fill="#475569" fontSize={8}>{label}</text>
      </svg>
      <div style={{ fontSize:9, color:'var(--text-muted)', marginTop:-4 }}>
        {cpk>=1.67?'Six Sigma':cpk>=1.33?'Acceptable':'Incapable'}
      </div>
    </div>
  )
}

// ─── Distribution Tab ─────────────────────────────────────────────────────────
function DistributionTab({ param, lotId }: { param: string; lotId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['wat-dist', param, lotId],
    queryFn: () => watApi.distribution(param, lotId || undefined),
    enabled: !!param,
  })
  const dist = data?.data?.data as WATDistribution | undefined
  const cap = dist?.capability

  const histData = useMemo(() => {
    if (!dist?.histogram) return []
    const { counts, edges } = dist.histogram
    return counts.map((count, i) => ({
      x: ((edges[i] + edges[i+1]) / 2), count,
      label: edges[i].toFixed(5),
    }))
  }, [dist])

  if (isLoading) return <div style={{ height:240, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>Computing distribution…</div>
  if (!dist) return <div style={{ height:240, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>Select a parameter</div>

  const capColor = (v?: number) => !v ? '' : v >= 1.67 ? '#10B981' : v >= 1.33 ? '#F59E0B' : '#EF4444'
  const f = (v?: number | null, d=6) => v != null ? v.toFixed(d) : '—'

  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 220px', gap:16 }}>
      {/* Histogram */}
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span className={`badge ${dist.capability?.is_normal ? 'badge-pass' : 'badge-coral'}`}>
            {dist.capability?.is_normal ? 'Normal' : 'Non-Normal'}
          </span>
          <span style={{ fontSize:10, color:'var(--text-muted)', fontFamily:'JetBrains Mono' }}>
            SW p = {f(dist.capability?.shapiro_wilk_p, 4)}
          </span>
          <span style={{ fontSize:10, color:'var(--text-muted)', marginLeft:'auto' }}>
            N = {dist.n.toLocaleString()}
          </span>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <ComposedChart data={histData} margin={{ top:4, right:8, bottom:0, left:-10 }}>
            <defs>
              <linearGradient id="histG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.85}/>
                <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0.25}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
            <XAxis dataKey="x" tick={{ fill:'#475569', fontSize:8 }} tickFormatter={v => (+v).toFixed(4)}/>
            <YAxis tick={{ fill:'#475569', fontSize:8 }}/>
            <Tooltip contentStyle={{ background:'#0F1626', border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, fontSize:10 }}/>
            {dist.usl != null && <ReferenceLine x={dist.usl} stroke="rgba(255,79,106,0.7)" strokeDasharray="4 3" label={{ value:'USL', fill:'#FF4F6A', fontSize:8 }}/>}
            {dist.lsl != null && <ReferenceLine x={dist.lsl} stroke="rgba(255,79,106,0.7)" strokeDasharray="4 3" label={{ value:'LSL', fill:'#FF4F6A', fontSize:8 }}/>}
            {cap?.mean != null && <ReferenceLine x={cap.mean} stroke="rgba(0,229,196,0.7)" strokeWidth={1.5} label={{ value:'μ', fill:'#00E5C4', fontSize:8 }}/>}
            <Bar dataKey="count" fill="url(#histG)" radius={[3,3,0,0]}/>
          </ComposedChart>
        </ResponsiveContainer>
        {/* Stat grid */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:6 }}>
          {[
            { l:'Mean',     v:f(cap?.mean) },
            { l:'Median',   v:f(cap?.median) },
            { l:'Std Dev',  v:f(cap?.std_within) },
            { l:'Range',    v:cap ? f(cap.max - cap.min, 5) : '—' },
            { l:'P5',       v:f(cap?.p5) },
            { l:'P95',      v:f(cap?.p95) },
            { l:'Skewness', v:f(cap?.skewness, 4) },
            { l:'Kurtosis', v:f(cap?.kurtosis, 4) },
          ].map(s => (
            <div key={s.l} style={{ background:'var(--elevated)', border:'1px solid var(--border)', borderRadius:6, padding:'6px 8px' }}>
              <div style={{ fontSize:8, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em' }}>{s.l}</div>
              <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--text-secondary)', marginTop:2 }}>{s.v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Equipment breakdown */}
      <div>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:8, textTransform:'uppercase', letterSpacing:'0.06em', fontFamily:'JetBrains Mono' }}>
          Equipment Breakdown
        </div>
        {Object.entries(dist.equipment_breakdown || {}).map(([eid, stats]) => (
          <div key={eid} style={{ padding:'8px 10px', background:'var(--elevated)',
            border:'1px solid var(--border)', borderRadius:8, marginBottom:6 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
              <span style={{ fontSize:11, fontFamily:'JetBrains Mono', color:'var(--teal)', fontWeight:600 }}>{eid}</span>
              <span style={{ fontSize:10, color:'var(--text-muted)' }}>N={stats.n}</span>
            </div>
            <div style={{ display:'flex', gap:12, fontSize:10 }}>
              <span>μ <span style={{ fontFamily:'JetBrains Mono', color:'var(--text-secondary)' }}>{stats.mean.toFixed(5)}</span></span>
              <span>σ <span style={{ fontFamily:'JetBrains Mono', color:'var(--text-secondary)' }}>{stats.std.toFixed(5)}</span></span>
            </div>
          </div>
        ))}
        {Object.keys(dist.equipment_breakdown || {}).length === 0 && (
          <div style={{ color:'var(--text-muted)', fontSize:11 }}>No equipment breakdown data</div>
        )}
      </div>

      {/* Capability panel */}
      <div>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:10, textTransform:'uppercase', letterSpacing:'0.06em', fontFamily:'JetBrains Mono' }}>
          Capability
        </div>
        {cap?.cpk != null && <CpkGauge cpk={cap.cpk} />}
        <div style={{ marginTop:10 }}>
          {[
            { k:'Cp',  v:cap?.cp }, { k:'Cpk', v:cap?.cpk },
            { k:'Cpm', v:cap?.cpm }, { k:'Ppk', v:cap?.ppk },
          ].map(({ k, v }) => v != null && (
            <div key={k} style={{ marginBottom:6 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                <span style={{ fontSize:10, fontFamily:'JetBrains Mono', color:'var(--text-secondary)' }}>{k}</span>
                <span style={{ fontSize:12, fontWeight:700, fontFamily:'JetBrains Mono', color:capColor(v) }}>{v.toFixed(3)}</span>
              </div>
              <div style={{ height:4, background:'var(--elevated)', borderRadius:2, overflow:'hidden' }}>
                <div style={{ height:'100%', width:`${Math.min(100, (v/2)*100)}%`,
                  background:capColor(v), borderRadius:2, transition:'width .5s' }}/>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop:12, borderTop:'1px solid var(--border)', paddingTop:10 }}>
          {[
            { l:'USL', v:f(dist.usl), c:'var(--coral)' },
            { l:'LSL', v:f(dist.lsl), c:'var(--coral)' },
            { l:'Target', v:f(dist.target), c:'var(--text-muted)' },
          ].map(item => (
            <div key={item.l} style={{ display:'flex', justifyContent:'space-between', marginBottom:4, fontSize:10 }}>
              <span style={{ color:'var(--text-muted)' }}>{item.l}</span>
              <span style={{ fontFamily:'JetBrains Mono', color:item.c }}>{item.v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Trend Tab ────────────────────────────────────────────────────────────────
function TrendTab({ param, days }: { param: string; days: number }) {
  const [equipment, setEquipment] = useState('')
  const { data, isLoading } = useQuery({
    queryKey: ['wat-trend', param, equipment, days],
    queryFn: () => watApi.trend(param, equipment || undefined, days),
    enabled: !!param,
  })
  const rows: WATTrendRow[] = data?.data?.data || []
  const allEquip = [...new Set(rows.map(r => r.equipment_id).filter(Boolean))] as string[]
  const filtered = equipment ? rows.filter(r => r.equipment_id === equipment) : rows
  const usl = rows[0] ? undefined : undefined // no USL in summary; shown from distribution

  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr', gap:12 }}>
      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <span style={{ fontSize:10, color:'var(--text-muted)' }}>Equipment:</span>
        <select value={equipment} onChange={e => setEquipment(e.target.value)}
          style={{ background:'var(--elevated)', border:'1px solid var(--border)', color:'var(--text-secondary)',
            borderRadius:8, padding:'4px 10px', fontSize:11, fontFamily:'JetBrains Mono' }}>
          <option value="">All</option>
          {allEquip.map(e => <option key={e}>{e}</option>)}
        </select>
        <span style={{ fontSize:10, color:'var(--text-muted)', marginLeft:'auto' }}>{filtered.length} data points</span>
      </div>
      {isLoading ? (
        <div style={{ height:200, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>Loading…</div>
      ) : (
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={filtered} margin={{ top:4, right:12, bottom:0, left:-10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
            <XAxis dataKey="lot_id" tick={{ fill:'#475569', fontSize:8 }} interval="preserveStartEnd"/>
            <YAxis tick={{ fill:'#475569', fontSize:9 }}/>
            <Tooltip contentStyle={{ background:'#0F1626', border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, fontSize:11 }}
              formatter={(v: number) => [v?.toFixed(6), param]}/>
            <Line type="monotone" dataKey="mean_value" stroke="var(--teal)" strokeWidth={2}
              dot={(p) => {
                const cpk = p.payload?.cpk as number | undefined
                const color = !cpk ? '#00E5C4' : cpk < 1.0 ? '#EF4444' : cpk < 1.33 ? '#F59E0B' : '#00E5C4'
                return <circle key={p.key} cx={p.cx} cy={p.cy} r={cpk != null && cpk < 1.0 ? 5 : 3} fill={color}/>
              }}
            />
          </LineChart>
        </ResponsiveContainer>
      )}

      {/* Trend table */}
      <div style={{ maxHeight:200, overflowY:'auto' }}>
        <table className="data-table">
          <thead><tr><th>Lot ID</th><th className="text-right">Mean</th><th className="text-right">Std</th><th className="text-right">Cp</th><th className="text-right">Cpk</th><th>Equipment</th><th>Date</th></tr></thead>
          <tbody>
            {filtered.slice(0, 30).map(r => (
              <tr key={r.lot_id+r.wafer_id}>
                <td style={{ color:'var(--teal)', fontFamily:'JetBrains Mono', fontSize:10 }}>{r.lot_id}</td>
                <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{r.mean_value?.toFixed(6)}</td>
                <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{r.std_dev?.toFixed(6)}</td>
                <td style={{ textAlign:'right' }}>
                  <span style={{ fontFamily:'JetBrains Mono', fontSize:10, color:r.cp!=null&&r.cp<1.0?'var(--fail)':r.cp!=null&&r.cp<1.33?'var(--warn)':'var(--pass)' }}>
                    {r.cp?.toFixed(3) ?? '—'}
                  </span>
                </td>
                <td style={{ textAlign:'right' }}>
                  <span style={{ fontFamily:'JetBrains Mono', fontSize:10, color:r.cpk!=null&&r.cpk<1.0?'var(--fail)':r.cpk!=null&&r.cpk<1.33?'var(--warn)':'var(--pass)' }}>
                    {r.cpk?.toFixed(3) ?? '—'}
                  </span>
                </td>
                <td style={{ color:'var(--text-muted)', fontSize:10 }}>{r.equipment_id}</td>
                <td style={{ color:'var(--text-muted)', fontSize:9, fontFamily:'JetBrains Mono' }}>{r.event_date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Correlation Tab ──────────────────────────────────────────────────────────
function CorrelationTab({ product }: { product: string }) {
  const [xParam, setXParam] = useState('IDSAT_N')
  const [yParam, setYParam] = useState('VTN')
  const { data: matrixData } = useQuery({
    queryKey: ['wat-corr-matrix', product],
    queryFn: () => watApi.correlationMatrix(product, 30),
  })
  const { data: scatterData } = useQuery({
    queryKey: ['wat-scatter', xParam, yParam],
    queryFn: () => watApi.correlationScatter(xParam, yParam, 30),
    enabled: !!xParam && !!yParam && xParam !== yParam,
  })

  const matrix = matrixData?.data?.data as { params: string[]; r_matrix: (number|null)[][]; p_matrix: (number|null)[][]; lot_count: number } | undefined
  const params = matrix?.params || PARAMS
  const rMat = matrix?.r_matrix || []
  const pMat = matrix?.p_matrix || []

  const scatter = scatterData?.data?.data as { scatter: { lot_id:string; x:number; y:number }[]; correlation: { pearson_r:number; pearson_p:number; ols_slope:number; ols_intercept:number; ols_r_squared:number } } | undefined

  const cellBg = (r: number|null, p: number|null) => {
    if (r == null) return 'rgba(255,255,255,0.03)'
    if (p != null && p > 0.05) return 'rgba(255,255,255,0.025)'
    const abs = Math.abs(r)
    return r > 0 ? `rgba(0,229,196,${abs*0.8})` : `rgba(255,79,106,${abs*0.8})`
  }

  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 280px', gap:16 }}>
      <div>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:6, fontFamily:'JetBrains Mono' }}>
          Pearson Correlation Matrix · {matrix?.lot_count || 0} lots · Click cell to scatter plot
        </div>
        <div style={{ overflowX:'auto' }}>
          {/* Header row */}
          <div style={{ display:'flex', marginLeft:90 }}>
            {params.map(p => (
              <div key={p} style={{ width:52, fontSize:8, color:'var(--text-muted)',
                textAlign:'center', writingMode:'vertical-rl', transform:'rotate(180deg)',
                height:60, display:'flex', alignItems:'center', justifyContent:'center', padding:'0 4px' }}>
                {p}
              </div>
            ))}
          </div>
          {params.map((p1, i) => (
            <div key={p1} style={{ display:'flex', alignItems:'center', marginBottom:1 }}>
              <div style={{ width:90, fontSize:9, fontFamily:'JetBrains Mono', color:'var(--text-secondary)',
                textAlign:'right', paddingRight:8, flexShrink:0 }}>{p1}</div>
              {params.map((p2, j) => {
                const r = rMat[i]?.[j] ?? null
                const p = pMat[i]?.[j] ?? null
                const isSelected = (p2 === xParam && p1 === yParam) || (p1 === xParam && p2 === yParam)
                return (
                  <div key={p2}
                    onClick={() => { if (i !== j) { setXParam(p2); setYParam(p1) } }}
                    title={r != null ? `r=${r.toFixed(3)}, p=${p?.toFixed(4)}` : '—'}
                    style={{
                      width:52, height:32, display:'flex', alignItems:'center', justifyContent:'center',
                      background: isSelected ? 'rgba(245,158,11,0.3)' : cellBg(r, p),
                      cursor: i !== j ? 'pointer' : 'default',
                      fontSize:9, fontFamily:'JetBrains Mono', fontWeight:700,
                      color: r != null && i !== j ? (Math.abs(r) > 0.5 ? '#fff' : 'rgba(255,255,255,0.5)') : 'transparent',
                      transition:'all .12s',
                      outline: isSelected ? '2px solid var(--amber)' : 'none',
                    }}
                  >
                    {r != null && i !== j ? r.toFixed(2) : i === j ? '1.00' : '—'}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
        <div style={{ display:'flex', gap:12, marginTop:8, fontSize:9, color:'var(--text-muted)', alignItems:'center' }}>
          <div style={{ width:14, height:10, borderRadius:2, background:'rgba(255,79,106,0.8)' }}/>Strong negative
          <div style={{ width:14, height:10, borderRadius:2, background:'rgba(255,255,255,0.05)' }}/>No correlation
          <div style={{ width:14, height:10, borderRadius:2, background:'rgba(0,229,196,0.8)' }}/>Strong positive
        </div>
      </div>

      {/* Scatter panel */}
      <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:10, padding:14 }}>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:8, fontFamily:'JetBrains Mono' }}>
          <span style={{ color:'var(--violet)' }}>{yParam}</span> vs <span style={{ color:'var(--teal)' }}>{xParam}</span>
        </div>
        <div style={{ display:'flex', gap:6, marginBottom:10 }}>
          {[xParam, yParam].map((p, idx) => (
            <select key={idx} value={p}
              onChange={e => idx === 0 ? setXParam(e.target.value) : setYParam(e.target.value)}
              style={{ flex:1, background:'var(--elevated)', border:'1px solid var(--border)',
                color:'var(--text-secondary)', borderRadius:6, padding:'4px 6px', fontSize:10, fontFamily:'JetBrains Mono' }}>
              {PARAMS.map(p2 => <option key={p2}>{p2}</option>)}
            </select>
          ))}
        </div>
        {scatter ? (
          <>
            <ResponsiveContainer width="100%" height={140}>
              <ComposedChart data={scatter.scatter} margin={{ top:4, right:8, bottom:0, left:-15 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
                <XAxis dataKey="x" tick={{ fill:'#475569', fontSize:8 }} tickFormatter={v => (+v).toFixed(4)} name={xParam}/>
                <YAxis tick={{ fill:'#475569', fontSize:8 }} tickFormatter={v => (+v).toFixed(4)} name={yParam}/>
                <Tooltip contentStyle={{ background:'#0F1626', border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, fontSize:10 }}
                  formatter={(v: number, n: string) => [v?.toFixed(6), n]}/>
                {/* Regression line as a Line on computed points */}
                <Line type="linear" dataKey="y" stroke="none" dot={(p) => (
                  <circle key={p.key} cx={p.cx} cy={p.cy} r={3} fill="rgba(0,229,196,0.7)" stroke="rgba(0,229,196,0.3)" strokeWidth={0.5}/>
                )}/>
              </ComposedChart>
            </ResponsiveContainer>
            <div style={{ marginTop:10, display:'grid', gridTemplateColumns:'1fr 1fr', gap:4, fontSize:10 }}>
              {[
                { l:'r', v:scatter.correlation.pearson_r?.toFixed(4) },
                { l:'p', v:scatter.correlation.pearson_p?.toFixed(6) },
                { l:'R²', v:scatter.correlation.ols_r_squared?.toFixed(4) },
                { l:'n', v:scatter.scatter.length },
              ].map(s => (
                <div key={s.l} style={{ display:'flex', justifyContent:'space-between', padding:'3px 6px',
                  background:'var(--elevated)', borderRadius:4 }}>
                  <span style={{ color:'var(--text-muted)' }}>{s.l}</span>
                  <span style={{ fontFamily:'JetBrains Mono', color:'var(--text-secondary)' }}>{s.v}</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div style={{ height:140, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:11 }}>Click a heatmap cell</div>
        )}
      </div>
    </div>
  )
}

// ─── ANOVA Tab ────────────────────────────────────────────────────────────────
function AnovaTab({ param, days }: { param: string; days: number }) {
  const [factor, setFactor] = useState('equipment_id')
  const { data, isLoading } = useQuery({
    queryKey: ['wat-anova', param, factor, days],
    queryFn: () => watApi.anova(param, factor, days),
    enabled: !!param,
  })
  const res = data?.data?.data as {
    f_statistic:number; p_value:number; eta_squared:number; omega_squared:number;
    ss_between:number; ss_within:number; ss_total:number;
    df_between:number; df_within:number; is_significant:boolean;
    grand_n:number; grand_mean:number; k_groups:number;
    group_stats: Record<string, { n:number; mean:number; std:number; min:number; max:number }>;
  } | undefined

  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
      <div>
        <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:12 }}>
          <span style={{ fontSize:10, color:'var(--text-muted)' }}>Factor:</span>
          {FACTORS.map(f => (
            <button key={f} onClick={() => setFactor(f)}
              style={{ padding:'4px 10px', fontSize:10, fontFamily:'JetBrains Mono',
                background: factor===f ? 'rgba(0,229,196,0.1)' : 'transparent',
                border:`1px solid ${factor===f ? 'rgba(0,229,196,0.4)' : 'var(--border)'}`,
                color: factor===f ? 'var(--teal)' : 'var(--text-muted)',
                borderRadius:6, cursor:'pointer' }}>
              {f.replace('_id','')}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div style={{ height:180, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>Computing ANOVA…</div>
        ) : res ? (
          <>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:12 }}>
              {[
                { l:'F-Statistic', v:res.f_statistic.toFixed(4), c: res.is_significant?'var(--coral)':'var(--text-secondary)' },
                { l:'p-value', v:res.p_value.toExponential(3), c: res.p_value<0.001?'var(--coral)':res.p_value<0.05?'var(--amber)':'var(--pass)' },
                { l:'Eta²', v:(res.eta_squared*100).toFixed(1)+'%', c: res.eta_squared>0.3?'var(--coral)':res.eta_squared>0.1?'var(--amber)':'var(--pass)' },
                { l:'Omega²', v:(res.omega_squared*100).toFixed(1)+'%', c:'var(--text-secondary)' },
                { l:'Groups k', v:res.k_groups, c:'var(--text-secondary)' },
                { l:'N total', v:res.grand_n, c:'var(--text-secondary)' },
              ].map(s => (
                <div key={s.l} style={{ background:'var(--elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'8px 10px' }}>
                  <div style={{ fontSize:9, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em' }}>{s.l}</div>
                  <div style={{ fontSize:14, fontWeight:700, fontFamily:'JetBrains Mono', color:s.c, marginTop:3 }}>{s.v}</div>
                </div>
              ))}
            </div>
            <div style={{ display:'flex', gap:4, alignItems:'center' }}>
              <span className={`badge ${res.is_significant ? 'badge-coral' : 'badge-pass'}`}>
                {res.is_significant ? 'SIGNIFICANT' : 'NOT SIGNIFICANT'}
              </span>
              <span style={{ fontSize:10, color:'var(--text-muted)' }}>
                Factor explains {(res.eta_squared*100).toFixed(1)}% of variance
              </span>
            </div>
          </>
        ) : (
          <div style={{ color:'var(--text-muted)', fontSize:12 }}>Select a parameter and factor</div>
        )}
      </div>

      {/* Group stats */}
      <div>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:8, textTransform:'uppercase', letterSpacing:'0.06em', fontFamily:'JetBrains Mono' }}>
          Group Statistics
        </div>
        {res ? (
          <table className="data-table">
            <thead><tr><th>{factor.replace('_id','')}</th><th className="text-right">N</th><th className="text-right">Mean</th><th className="text-right">Std</th><th className="text-right">Min</th><th className="text-right">Max</th></tr></thead>
            <tbody>
              {Object.entries(res.group_stats).map(([name, stats]) => (
                <tr key={name}>
                  <td style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--teal)' }}>{name}</td>
                  <td style={{ textAlign:'right' }}>{stats.n}</td>
                  <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{stats.mean.toFixed(5)}</td>
                  <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{stats.std.toFixed(5)}</td>
                  <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{stats.min.toFixed(5)}</td>
                  <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{stats.max.toFixed(5)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div style={{ color:'var(--text-muted)', fontSize:11 }}>Run ANOVA to see group breakdown</div>
        )}
      </div>
    </div>
  )
}

// ─── Equipment Health Tab ─────────────────────────────────────────────────────
function EquipmentHealthTab({ days }: { days: number }) {
  const { data, isLoading } = useQuery({
    queryKey: ['wat-equip-health', days],
    queryFn: () => watApi.equipmentHealth(days),
  })
  const equipList = (data?.data?.data || []) as { equipment_id:string; health_score:number; health_tier:string; z_score_mean:number; cv_ratio_mean:number; n_measurements:number }[]
  const tierColor = (t: string) => ({ HEALTHY:'#10B981', WATCH:'#F59E0B', DEGRADED:'#F97316', CRITICAL:'#EF4444' }[t] || '#64748B')

  if (isLoading) return <div style={{ height:200, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>Loading…</div>

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:6 }}>
        {['HEALTHY','WATCH','DEGRADED','CRITICAL'].map(tier => {
          const cnt = equipList.filter(e => e.health_tier === tier).length
          return (
            <div key={tier} style={{ background:'var(--elevated)', border:`1px solid ${tierColor(tier)}30`,
              borderRadius:8, padding:'8px 12px', textAlign:'center' }}>
              <div style={{ fontSize:20, fontWeight:700, color:tierColor(tier), fontFamily:'Space Grotesk' }}>{cnt}</div>
              <div style={{ fontSize:9, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em', marginTop:2 }}>{tier}</div>
            </div>
          )
        })}
      </div>
      <table className="data-table">
        <thead>
          <tr>
            <th>Equipment</th><th className="text-right">Health</th><th>Tier</th>
            <th className="text-right">Z-Score Avg</th><th className="text-right">CV Ratio</th>
            <th className="text-right">N Measurements</th>
          </tr>
        </thead>
        <tbody>
          {equipList.map(e => (
            <tr key={e.equipment_id}>
              <td style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--teal)' }}>{e.equipment_id}</td>
              <td style={{ textAlign:'right' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'flex-end' }}>
                  <div style={{ width:50, height:4, background:'var(--elevated)', borderRadius:2, overflow:'hidden' }}>
                    <div style={{ height:'100%', width:`${e.health_score}%`, background:tierColor(e.health_tier), borderRadius:2 }}/>
                  </div>
                  <span style={{ fontFamily:'JetBrains Mono', fontSize:11, fontWeight:700, color:tierColor(e.health_tier) }}>
                    {e.health_score?.toFixed(1)}
                  </span>
                </div>
              </td>
              <td>
                <span className="badge" style={{ background:`${tierColor(e.health_tier)}20`,
                  color:tierColor(e.health_tier), borderColor:`${tierColor(e.health_tier)}40`, fontSize:9 }}>
                  {e.health_tier}
                </span>
              </td>
              <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{e.z_score_mean?.toFixed(4)}</td>
              <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{e.cv_ratio_mean?.toFixed(4)}</td>
              <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:10 }}>{e.n_measurements?.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
const TABS = [
  { id:'distribution', label:'📊 Distribution' },
  { id:'trend',        label:'📈 Trend' },
  { id:'correlation',  label:'🔗 Correlation' },
  { id:'anova',        label:'🧮 ANOVA' },
  { id:'equipment',    label:'🔧 Equipment Health' },
]

export function WATAnalytics() {
  const [tab, setTab] = useState('distribution')
  const [param, setParam] = useState('IDSAT_N')
  const [lotId, setLotId] = useState('')
  const [product, setProduct] = useState('PROD_N5_001')
  const [days, setDays] = useState(30)

  return (
    <div style={{ animation:'fadeIn .25s ease' }}>
      <div className="panel">
        {/* Header */}
        <div className="panel-header">
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:2, height:14, borderRadius:2, background:'var(--violet)' }}/>
            <span style={{ fontFamily:'Space Grotesk', fontWeight:600, fontSize:14 }}>WAT Analytics Workbench</span>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <select value={param} onChange={e => setParam(e.target.value)}
              style={{ background:'var(--elevated)', border:'1px solid var(--border)',
                color:'var(--teal)', borderRadius:8, padding:'5px 10px', fontSize:11,
                fontFamily:'JetBrains Mono', cursor:'pointer' }}>
              {PARAMS.map(p => <option key={p}>{p}</option>)}
            </select>
            <input value={lotId} onChange={e => setLotId(e.target.value)} placeholder="Lot filter…"
              style={{ width:120, background:'var(--elevated)', border:'1px solid var(--border)',
                color:'var(--text-secondary)', borderRadius:8, padding:'5px 10px', fontSize:11,
                fontFamily:'JetBrains Mono', outline:'none' }}/>
            <select value={product} onChange={e => setProduct(e.target.value)}
              style={{ background:'var(--elevated)', border:'1px solid var(--border)',
                color:'var(--text-muted)', borderRadius:8, padding:'5px 10px', fontSize:10,
                fontFamily:'JetBrains Mono', cursor:'pointer' }}>
              {['PROD_N5_001','PROD_N5_002','PROD_N3_001'].map(p => <option key={p}>{p}</option>)}
            </select>
            {[14, 30, 60, 90].map(d => (
              <button key={d} onClick={() => setDays(d)}
                style={{ padding:'5px 10px', fontSize:10, fontFamily:'JetBrains Mono',
                  background: days===d ? 'rgba(139,92,246,0.1)' : 'transparent',
                  border:`1px solid ${days===d ? 'rgba(139,92,246,0.4)' : 'var(--border)'}`,
                  color: days===d ? 'var(--violet)' : 'var(--text-muted)',
                  borderRadius:6, cursor:'pointer' }}>{d}d</button>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', gap:2, padding:'10px 18px 0', borderBottom:'1px solid var(--border)' }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{
                padding:'8px 14px', fontSize:11, fontWeight:500, background:'none', border:'none',
                cursor:'pointer', color: tab===t.id ? 'var(--teal)' : 'var(--text-muted)',
                borderBottom: tab===t.id ? '2px solid var(--teal)' : '2px solid transparent',
                borderRadius:'6px 6px 0 0', transition:'all .15s',
              }}>{t.label}</button>
          ))}
        </div>

        {/* Content */}
        <div className="panel-body" style={{ paddingTop:16 }}>
          {tab === 'distribution' && <DistributionTab param={param} lotId={lotId}/>}
          {tab === 'trend'        && <TrendTab param={param} days={days}/>}
          {tab === 'correlation'  && <CorrelationTab product={product}/>}
          {tab === 'anova'        && <AnovaTab param={param} days={days}/>}
          {tab === 'equipment'    && <EquipmentHealthTab days={days}/>}
        </div>
      </div>
    </div>
  )
}
