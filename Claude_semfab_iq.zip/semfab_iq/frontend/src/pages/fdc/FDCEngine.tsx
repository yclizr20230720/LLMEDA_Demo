import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
} from 'recharts'
import { fdcApi } from '@/api/endpoints'
import type { FDCTraceRun, FDCIndicator } from '@/types'

// ─── Anomaly Score Ring ───────────────────────────────────────────────────────
function ScoreRing({ score, label, color }: { score: number; color: string; label: string }) {
  const r = 22, circ = 2 * Math.PI * r
  const dash = circ * Math.min(1, Math.max(0, score))
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <svg width={58} height={58} viewBox="0 0 58 58">
        <circle cx={29} cy={29} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={5} />
        <circle cx={29} cy={29} r={r} fill="none" stroke={color} strokeWidth={5}
          strokeDasharray={`${dash} ${circ}`}
          strokeLinecap="round" transform="rotate(-90 29 29)" />
        <text x={29} y={33} textAnchor="middle" fill={color}
          fontSize={11} fontFamily="JetBrains Mono" fontWeight="700">
          {(score * 100).toFixed(0)}
        </text>
      </svg>
      <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase',
        letterSpacing: '0.05em', textAlign: 'center', lineHeight: 1.2 }}>{label}</div>
    </div>
  )
}

// ─── Equipment selector ───────────────────────────────────────────────────────
const EQUIPMENT_IDS = ['CVD-01', 'CVD-02', 'CVD-03', 'ETCH-01', 'ETCH-02', 'CMP-01']

// ─── Tab 1: Sensor Qualification ─────────────────────────────────────────────
function SensorQualificationTab({ equipmentId }: { equipmentId: string }) {
  const [sigmaLimit, setSigmaLimit] = useState(6)

  const { data: sensorsData } = useQuery({
    queryKey: ['fdc-sensors', equipmentId],
    queryFn: () => fdcApi.sensors(equipmentId),
    enabled: !!equipmentId,
  })
  const { data: indicatorsData } = useQuery({
    queryKey: ['fdc-indicators', equipmentId],
    queryFn: () => fdcApi.indicators(equipmentId),
    enabled: !!equipmentId,
  })
  const { data: pmData } = useQuery({
    queryKey: ['fdc-pm', equipmentId],
    queryFn: () => fdcApi.pmEvents(equipmentId, 90),
    enabled: !!equipmentId,
  })

  const sensors = sensorsData?.data?.data || []
  const indicators: FDCIndicator[] = indicatorsData?.data?.data || []
  const pmEvents = pmData?.data?.data || []

  // Pass rate bar helper
  const passRateColor = (r: number) => r >= 99 ? 'var(--pass)' : r >= 95 ? 'var(--warn)' : 'var(--fail)'

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
      {/* Sensor list */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase',
            letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
            Monitored Sensors ({sensors.length})
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10 }}>
            <span style={{ color: 'var(--text-muted)' }}>σ limit:</span>
            <input type="range" min={3} max={9} step={0.5} value={sigmaLimit}
              onChange={e => setSigmaLimit(+e.target.value)}
              style={{ width: 80, accentColor: 'var(--teal)' }} />
            <span style={{ fontFamily: 'JetBrains Mono', color: 'var(--teal)', minWidth: 20 }}>{sigmaLimit}</span>
          </div>
        </div>
        <div style={{ maxHeight: 380, overflowY: 'auto' }}>
          {sensors.length === 0 ? (
            <div style={{ color: 'var(--text-muted)', fontSize: 11, textAlign: 'center', padding: 40 }}>
              Select equipment to view sensors
            </div>
          ) : sensors.map((s: any, i: number) => {
            // Simulate a pass rate for demo
            const passRate = 95 + Math.sin(i * 2.3) * 4
            return (
              <div key={s.sensor_alias} style={{ padding: '8px 10px', marginBottom: 5,
                background: 'var(--elevated)', border: '1px solid var(--border)', borderRadius: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)',
                      fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden',
                      textOverflow: 'ellipsis', maxWidth: 200 }}>
                      {s.sensor_alias}
                    </div>
                    <div style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 2 }}>
                      {s.sensor_type} · {s.measurement_units} · {s.sampling_rate_hz}Hz
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 13, fontWeight: 700, fontFamily: 'JetBrains Mono',
                      color: passRateColor(passRate) }}>
                      {passRate.toFixed(1)}%
                    </div>
                    <div style={{ fontSize: 8, color: 'var(--text-muted)' }}>pass rate</div>
                  </div>
                </div>
                {/* Pass-rate bar */}
                <div style={{ height: 3, background: 'var(--card)', borderRadius: 2, marginTop: 6, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${passRate}%`,
                    background: passRateColor(passRate), borderRadius: 2, transition: 'width .5s' }} />
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Indicator table + PM events */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase',
            letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
            FDC Indicators ({indicators.length})
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr><th>Indicator</th><th>Type</th><th>Alarm Mode</th>
                  <th className="text-right">Cp</th><th className="text-right">Cpk</th>
                  <th className="text-right">Runs</th><th className="text-right">Alarms</th>
                  <th className="text-right">Rate%</th>
                </tr>
              </thead>
              <tbody>
                {indicators.length === 0 && (
                  <tr><td colSpan={8} style={{ textAlign: 'center', padding: '20px', color: 'var(--text-muted)', fontSize: 11 }}>
                    No indicators for this equipment
                  </td></tr>
                )}
                {indicators.slice(0, 12).map((ind: FDCIndicator) => (
                  <tr key={ind.indicator_id}>
                    <td style={{ fontFamily: 'JetBrains Mono', fontSize: 9, color: 'var(--sky)',
                      maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {ind.indicator_name || ind.indicator_id}
                    </td>
                    <td><span className="badge badge-violet" style={{ fontSize: 8 }}>{ind.feature_type}</span></td>
                    <td>
                      <span className={`badge ${ind.alarm_mode === 'NoSPC' ? 'badge-teal' : 'badge-amber'}`}
                        style={{ fontSize: 8 }}>
                        {ind.alarm_mode}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10,
                      color: ind.cp != null ? (ind.cp >= 1.33 ? 'var(--pass)' : 'var(--warn)') : 'var(--text-muted)' }}>
                      {ind.cp?.toFixed(2) ?? '—'}
                    </td>
                    <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10,
                      color: ind.cpk != null ? (ind.cpk >= 1.33 ? 'var(--pass)' : 'var(--warn)') : 'var(--text-muted)' }}>
                      {ind.cpk?.toFixed(2) ?? '—'}
                    </td>
                    <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10 }}>{ind.total_runs}</td>
                    <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10,
                      color: ind.total_alarms > 0 ? 'var(--coral)' : 'var(--text-muted)' }}>
                      {ind.total_alarms}
                    </td>
                    <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10,
                      color: (ind.alarm_rate_pct ?? 0) > 2 ? 'var(--amber)' : 'var(--text-muted)' }}>
                      {ind.alarm_rate_pct?.toFixed(2) ?? '0.00'}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* PM Events */}
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase',
            letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
            PM History (90 days)
          </div>
          {(pmEvents as any[]).map((pm: any) => (
            <div key={pm.pm_sk} style={{ padding: '8px 12px', marginBottom: 6,
              background: 'var(--elevated)', border: '1px solid var(--border)', borderRadius: 8,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 600 }}>
                  {pm.pm_type} · {pm.pm_subtype}
                </div>
                <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2, fontFamily: 'JetBrains Mono' }}>
                  {pm.event_date} · {pm.pm_duration_hr?.toFixed(1)}h · by {pm.performed_by}
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 12, fontWeight: 700, fontFamily: 'JetBrains Mono',
                  color: 'var(--pass)' }}>
                  +{pm.health_improvement?.toFixed(1)}
                </div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)' }}>health gain</div>
              </div>
              {pm.qualification_passed != null && (
                <span className={`badge ${pm.qualification_passed ? 'badge-pass' : 'badge-coral'}`}
                  style={{ marginLeft: 10 }}>
                  QUAL {pm.qualification_passed ? 'PASS' : 'FAIL'}
                </span>
              )}
            </div>
          ))}
          {(pmEvents as any[]).length === 0 && (
            <div style={{ color: 'var(--text-muted)', fontSize: 11, textAlign: 'center', padding: 20 }}>No PM events found</div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Tab 2: Trace Run Review ──────────────────────────────────────────────────
function TraceRunTab({ equipmentId }: { equipmentId: string }) {
  const [anomalyOnly, setAnomalyOnly] = useState(false)
  const [minScore, setMinScore] = useState(0)
  const [selectedRun, setSelectedRun] = useState<FDCTraceRun | null>(null)

  const { data } = useQuery({
    queryKey: ['fdc-trace-runs', equipmentId, anomalyOnly, minScore],
    queryFn: () => fdcApi.traceRuns({
      equipment_id: equipmentId || undefined,
      is_anomaly: anomalyOnly ? true : undefined,
      days: 21, page: 1,
    }),
  })
  const { data: trendData } = useQuery({
    queryKey: ['fdc-trend', equipmentId],
    queryFn: () => fdcApi.trend(equipmentId || undefined, 21),
  })

  const runs: FDCTraceRun[] = data?.data?.data || []
  const trend = trendData?.data?.data || []

  const scoreColor = (s: number) => s > 0.7 ? '#EF4444' : s > 0.4 ? '#F59E0B' : '#10B981'
  const anomalyClassBadge = (cls?: string) => {
    const map: Record<string, string> = { PM_DRIFT: 'badge-amber', AMPLITUDE: 'badge-coral', NORMAL: 'badge-pass' }
    return map[cls || 'NORMAL'] || 'badge-teal'
  }

  const radarData = selectedRun ? [
    { axis: 'Interval', value: (selectedRun.interval_anomaly_score ?? 0) * 100 },
    { axis: 'PM Drift', value: (selectedRun.pm_anomaly_score ?? 0) * 100 },
    { axis: 'Amplitude', value: (selectedRun.amplitude_anomaly_score ?? 0) * 100 },
    { axis: 'Shape', value: (selectedRun.shape_anomaly_score ?? 0) * 100 },
    { axis: 'Composite', value: (selectedRun.composite_anomaly_score ?? 0) * 100 },
  ] : []

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 20 }}>
      <div>
        {/* Daily trend chart */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 6,
            textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
            Daily Anomaly Rate (21 days)
          </div>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart data={trend as any[]} margin={{ top: 4, right: 8, bottom: 0, left: -15 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 8 }}
                tickFormatter={d => (d as string).slice(5)} interval={3} />
              <YAxis tick={{ fill: '#475569', fontSize: 8 }} tickFormatter={v => `${v.toFixed(0)}%`} />
              <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 10 }}
                formatter={(v: number) => [`${v.toFixed(1)}%`, 'Anomaly Rate']} />
              <Bar dataKey="anomaly_rate_pct" radius={[3, 3, 0, 0]}>
                {(trend as any[]).map((d: any, i: number) => (
                  <Cell key={i} fill={d.anomaly_rate_pct > 30 ? '#EF4444' : d.anomaly_rate_pct > 10 ? '#F59E0B' : '#10B981'} />
                ))}
              </Bar>
              <ReferenceLine y={20} stroke="rgba(245,158,11,0.5)" strokeDasharray="4 3"
                label={{ value: '20%', fill: '#F59E0B', fontSize: 8 }} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <button onClick={() => setAnomalyOnly(!anomalyOnly)}
            style={{ padding: '4px 10px', fontSize: 10, fontFamily: 'JetBrains Mono',
              background: anomalyOnly ? 'rgba(255,79,106,0.1)' : 'transparent',
              border: `1px solid ${anomalyOnly ? 'rgba(255,79,106,0.4)' : 'var(--border)'}`,
              color: anomalyOnly ? 'var(--coral)' : 'var(--text-muted)',
              borderRadius: 6, cursor: 'pointer' }}>
            Anomalies Only
          </button>
          <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
            {runs.length} runs · {runs.filter(r => r.is_anomaly).length} anomalies
          </span>
        </div>

        {/* Run table */}
        <div style={{ maxHeight: 320, overflowY: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Run ID</th><th>Equipment</th><th>Chamber</th>
                <th>Recipe</th><th className="text-right">Duration</th>
                <th className="text-right">Composite Score</th>
                <th>Class</th><th>Result</th><th>Date</th>
              </tr>
            </thead>
            <tbody>
              {runs.map(r => (
                <tr key={r.run_id}
                  onClick={() => setSelectedRun(r)}
                  style={{ cursor: 'pointer',
                    background: selectedRun?.run_id === r.run_id ? 'rgba(0,229,196,0.05)' : undefined }}
                >
                  <td style={{ fontFamily: 'JetBrains Mono', fontSize: 9, color: 'var(--sky)' }}>
                    {r.run_id.slice(-8)}
                  </td>
                  <td style={{ fontSize: 10, fontFamily: 'JetBrains Mono', color: 'var(--teal)' }}>{r.equipment_id}</td>
                  <td style={{ fontSize: 10, color: 'var(--text-muted)' }}>{r.chamber_id}</td>
                  <td style={{ fontSize: 9, color: 'var(--text-muted)', maxWidth: 100,
                    overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.recipe_id}</td>
                  <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10 }}>
                    {r.run_duration_sec?.toFixed(1)}s
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <span style={{ fontFamily: 'JetBrains Mono', fontSize: 12, fontWeight: 700,
                      color: scoreColor(r.composite_anomaly_score ?? 0) }}>
                      {((r.composite_anomaly_score ?? 0) * 100).toFixed(0)}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${anomalyClassBadge(r.anomaly_class)}`} style={{ fontSize: 9 }}>
                      {r.anomaly_class || 'NORMAL'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${r.run_result === 'PASS' ? 'badge-pass' : 'badge-coral'}`} style={{ fontSize: 9 }}>
                      {r.run_result}
                    </span>
                  </td>
                  <td style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>
                    {r.event_date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Run detail panel */}
      <div style={{ background: 'var(--elevated)', border: '1px solid var(--border)', borderRadius: 10, padding: 14 }}>
        {selectedRun ? (
          <>
            <div style={{ fontSize: 11, fontWeight: 600, fontFamily: 'Space Grotesk',
              color: 'var(--text-primary)', marginBottom: 10 }}>
              Run Detail
            </div>
            <div style={{ marginBottom: 14 }}>
              {[
                { l: 'Run ID', v: selectedRun.run_id.slice(-8) },
                { l: 'Equipment', v: selectedRun.equipment_id },
                { l: 'Chamber', v: selectedRun.chamber_id },
                { l: 'Lot', v: selectedRun.lot_id },
                { l: 'Wafer', v: selectedRun.wafer_id?.slice(-5) },
                { l: 'Alarms', v: String(selectedRun.alarm_count) },
                { l: 'Post-PM', v: selectedRun.is_post_pm ? 'Yes' : 'No' },
                { l: 'Date', v: selectedRun.event_date },
              ].map(s => (
                <div key={s.l} style={{ display: 'flex', justifyContent: 'space-between',
                  padding: '4px 0', fontSize: 10,
                  borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <span style={{ color: 'var(--text-muted)' }}>{s.l}</span>
                  <span style={{ fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)' }}>{s.v ?? '—'}</span>
                </div>
              ))}
            </div>

            {/* 5-axis radar chart */}
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 6,
              textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
              Anomaly Sub-Scores
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <RadarChart data={radarData} margin={{ top: 0, right: 12, bottom: 0, left: 12 }}>
                <PolarGrid stroke="rgba(255,255,255,0.08)" />
                <PolarAngleAxis dataKey="axis" tick={{ fill: '#64748B', fontSize: 8 }} />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#475569', fontSize: 7 }} tickCount={3} />
                <Radar name="Score" dataKey="value"
                  stroke={selectedRun.is_anomaly ? '#EF4444' : '#00E5C4'}
                  fill={selectedRun.is_anomaly ? '#EF444422' : '#00E5C422'}
                  strokeWidth={1.5} />
              </RadarChart>
            </ResponsiveContainer>

            {/* Score rings */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, marginTop: 6 }}>
              <ScoreRing score={selectedRun.composite_anomaly_score ?? 0} label="Composite"
                color={scoreColor(selectedRun.composite_anomaly_score ?? 0)} />
              <ScoreRing score={selectedRun.pm_anomaly_score ?? 0} label="PM Drift" color="#F59E0B" />
              <ScoreRing score={selectedRun.amplitude_anomaly_score ?? 0} label="Amplitude" color="#EF4444" />
              <ScoreRing score={selectedRun.shape_anomaly_score ?? 0} label="Shape" color="#8B5CF6" />
            </div>
          </>
        ) : (
          <div style={{ height: '100%', display: 'flex', alignItems: 'center',
            justifyContent: 'center', color: 'var(--text-muted)', fontSize: 11, textAlign: 'center', padding: 20 }}>
            Click a run to see detail & anomaly scores
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Tab 3: Alarm Drill-Down ──────────────────────────────────────────────────
function AlarmDrillDownTab({ equipmentId }: { equipmentId: string }) {
  const [days, setDays] = useState(7)
  const { data: summaryData } = useQuery({
    queryKey: ['fdc-anomaly-summary', days],
    queryFn: () => fdcApi.anomalySummary(days),
  })
  const { data: drillData } = useQuery({
    queryKey: ['fdc-drill-down', equipmentId, days],
    queryFn: () => fdcApi.alarmDrillDown(equipmentId, days),
    enabled: !!equipmentId,
  })

  const summary = summaryData?.data?.data || []
  const drill = drillData?.data?.data as {
    total_alarm_runs: number;
    sensor_breakdown: { sensor_alias: string; alarm_count: number; alarm_rate_pct: number }[];
    anomaly_class_distribution: Record<string, number>;
  } | undefined

  const classDist = drill ? Object.entries(drill.anomaly_class_distribution).map(([cls, count]) => ({ cls, count })) : []
  const maxCount = classDist.reduce((m, d) => Math.max(m, d.count), 0)
  const classColors: Record<string, string> = { PM_DRIFT: '#F59E0B', AMPLITUDE: '#EF4444', NORMAL: '#10B981' }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
      {/* Left: Fleet summary + class distribution */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase',
            letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>Fleet Anomaly Rates</div>
          <div style={{ display: 'flex', gap: 6, marginLeft: 'auto' }}>
            {[3, 7, 14].map(d => (
              <button key={d} onClick={() => setDays(d)}
                style={{ padding: '3px 8px', fontSize: 9, fontFamily: 'JetBrains Mono',
                  background: days === d ? 'rgba(255,79,106,0.1)' : 'transparent',
                  border: `1px solid ${days === d ? 'rgba(255,79,106,0.35)' : 'var(--border)'}`,
                  color: days === d ? 'var(--coral)' : 'var(--text-muted)',
                  borderRadius: 5, cursor: 'pointer' }}>{d}d</button>
            ))}
          </div>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={summary as any[]} layout="vertical" margin={{ left: 10, right: 60, top: 4, bottom: 4 }}>
            <XAxis type="number" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v.toFixed(0)}%`} />
            <YAxis dataKey="equipment_id" type="category" tick={{ fill: '#94A3B8', fontSize: 10, fontFamily: 'JetBrains Mono' }} width={58} />
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
            <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 10 }}
              formatter={(v: number) => [`${v.toFixed(2)}%`, 'Anomaly Rate']} />
            <Bar dataKey="anomaly_rate_pct" radius={[0, 3, 3, 0]}
              label={{ position: 'right', fill: '#64748B', fontSize: 9, formatter: (v: number) => `${v.toFixed(1)}%` }}>
              {(summary as any[]).map((_: any, i: number) => {
                const rate = _?.anomaly_rate_pct ?? 0
                return <Cell key={i} fill={rate > 30 ? '#EF4444' : rate > 10 ? '#F59E0B' : '#10B981'} />
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        {/* Class distribution */}
        {classDist.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 8,
              textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
              Anomaly Class — {equipmentId}
            </div>
            {classDist.map(({ cls, count }) => (
              <div key={cls} style={{ marginBottom: 6 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3, fontSize: 10 }}>
                  <span style={{ color: classColors[cls] || 'var(--text-secondary)', fontFamily: 'JetBrains Mono' }}>{cls}</span>
                  <span style={{ color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>{count}</span>
                </div>
                <div style={{ height: 5, background: 'var(--elevated)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${count / maxCount * 100}%`,
                    background: classColors[cls] || 'var(--teal)', borderRadius: 3, transition: 'width .5s' }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Right: Sensor breakdown for selected equipment */}
      <div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 8,
          textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
          Sensor Alarm Breakdown — {equipmentId}
          {drill && <span style={{ color: 'var(--coral)', marginLeft: 8 }}>
            {drill.total_alarm_runs} alarm runs
          </span>}
        </div>

        {!equipmentId ? (
          <div style={{ color: 'var(--text-muted)', fontSize: 11, textAlign: 'center', padding: 40 }}>
            Select an equipment above
          </div>
        ) : !drill || (drill.sensor_breakdown || []).length === 0 ? (
          <div style={{ color: 'var(--text-muted)', fontSize: 11, textAlign: 'center', padding: 40 }}>
            No sensor alarm data for this period
          </div>
        ) : (
          <div>
            {(drill.sensor_breakdown || []).slice(0, 12).map((s, i) => (
              <div key={s.sensor_alias} style={{ padding: '8px 10px', marginBottom: 5,
                background: 'var(--elevated)', border: '1px solid var(--border)', borderRadius: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 10, fontFamily: 'JetBrains Mono', color: 'var(--sky)',
                      fontWeight: 600 }}>
                      {i + 1}. {s.sensor_alias}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'JetBrains Mono',
                        color: s.alarm_count > 5 ? 'var(--coral)' : 'var(--amber)' }}>
                        {s.alarm_count}
                      </div>
                      <div style={{ fontSize: 8, color: 'var(--text-muted)' }}>alarms</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: 13, fontWeight: 700, fontFamily: 'JetBrains Mono',
                        color: s.alarm_rate_pct > 30 ? 'var(--coral)' : 'var(--amber)' }}>
                        {s.alarm_rate_pct.toFixed(1)}%
                      </div>
                      <div style={{ fontSize: 8, color: 'var(--text-muted)' }}>rate</div>
                    </div>
                  </div>
                </div>
                <div style={{ height: 3, background: 'var(--card)', borderRadius: 2, marginTop: 6, overflow: 'hidden' }}>
                  <div style={{ height: '100%',
                    width: `${Math.min(100, s.alarm_rate_pct)}%`,
                    background: s.alarm_rate_pct > 30 ? '#EF4444' : '#F59E0B',
                    borderRadius: 2, transition: 'width .5s' }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'sensors', label: '⚙ Sensor Qualification' },
  { id: 'runs',    label: '📡 Trace Run Review' },
  { id: 'alarms',  label: '🔔 Alarm Drill-Down' },
]

export function FDCEngine() {
  const [tab, setTab] = useState('sensors')
  const [equipmentId, setEquipmentId] = useState('CVD-01')

  return (
    <div style={{ animation: 'fadeIn .25s ease' }}>
      <div className="panel">
        {/* Header */}
        <div className="panel-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 2, height: 14, borderRadius: 2, background: 'var(--coral)' }} />
            <span style={{ fontFamily: 'Space Grotesk', fontWeight: 600, fontSize: 14 }}>FDC Engine — Fault Detection & Classification</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <label style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>Equipment:</label>
            <select value={equipmentId} onChange={e => setEquipmentId(e.target.value)}
              style={{ background: 'var(--elevated)', border: '1px solid var(--border)',
                color: 'var(--coral)', borderRadius: 8, padding: '5px 10px',
                fontSize: 11, fontFamily: 'JetBrains Mono', cursor: 'pointer' }}>
              {EQUIPMENT_IDS.map(e => <option key={e}>{e}</option>)}
            </select>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 2, padding: '10px 18px 0', borderBottom: '1px solid var(--border)' }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{
                padding: '8px 14px', fontSize: 11, fontWeight: 500, background: 'none', border: 'none',
                cursor: 'pointer', color: tab === t.id ? 'var(--coral)' : 'var(--text-muted)',
                borderBottom: tab === t.id ? '2px solid var(--coral)' : '2px solid transparent',
                borderRadius: '6px 6px 0 0', transition: 'all .15s',
              }}>{t.label}</button>
          ))}
        </div>

        {/* Content */}
        <div className="panel-body" style={{ paddingTop: 16 }}>
          {tab === 'sensors' && <SensorQualificationTab equipmentId={equipmentId} />}
          {tab === 'runs'    && <TraceRunTab equipmentId={equipmentId} />}
          {tab === 'alarms'  && <AlarmDrillDownTab equipmentId={equipmentId} />}
        </div>
      </div>
    </div>
  )
}
