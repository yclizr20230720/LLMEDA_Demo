import { useState, useMemo } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import {
  ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ReferenceLine, ResponsiveContainer, Scatter,
} from 'recharts'
import { spcApi } from '@/api/endpoints'
import type { SPCConfig, SPCMeasurement } from '@/types'

// ─── Rule metadata ────────────────────────────────────────────────────────────
const RULE_META: Record<number, { label: string; color: string; desc: string }> = {
  1: { label: 'R1', color: '#EF4444', desc: '1 pt > 3σ' },
  2: { label: 'R2', color: '#F97316', desc: '9 pts same side' },
  3: { label: 'R3', color: '#F59E0B', desc: '6 pts trending' },
  4: { label: 'R4', color: '#84CC16', desc: '14 pts alternating' },
  5: { label: 'R5', color: '#8B5CF6', desc: '2/3 pts > 2σ' },
  6: { label: 'R6', color: '#38BDF8', desc: '4/5 pts > 1σ' },
  7: { label: 'R7', color: '#EC4899', desc: '15 pts within 1σ' },
  8: { label: 'R8', color: '#00E5C4', desc: '8 pts > 1σ both sides' },
}

// ─── Rule Toggle Bitmask Buttons ──────────────────────────────────────────────
function RuleToggles({ enabled, onChange }: { enabled: number; onChange: (v: number) => void }) {
  const toggle = (bit: number) => onChange(enabled ^ (1 << (bit - 1)))
  return (
    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
      {[1, 2, 3, 4, 5, 6, 7, 8].map(r => {
        const active = !!(enabled & (1 << (r - 1)))
        const meta = RULE_META[r]
        return (
          <button key={r} onClick={() => toggle(r)} title={meta.desc}
            style={{
              padding: '4px 8px', fontSize: 10, fontFamily: 'JetBrains Mono', fontWeight: 700,
              background: active ? `${meta.color}22` : 'transparent',
              border: `1px solid ${active ? meta.color : 'var(--border)'}`,
              color: active ? meta.color : 'var(--text-muted)',
              borderRadius: 6, cursor: 'pointer', transition: 'all .15s',
              title: meta.desc,
            }}>
            {meta.label}
          </button>
        )
      })}
    </div>
  )
}

// ─── CPK Gauge (compact) ─────────────────────────────────────────────────────
function MiniCpkGauge({ cpk }: { cpk: number }) {
  const color = cpk >= 1.67 ? '#10B981' : cpk >= 1.33 ? '#F59E0B' : '#EF4444'
  const pct = Math.min(100, (cpk / 2.0) * 100)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <svg width={80} height={48} viewBox="0 0 80 48">
        <path d="M8 40 A32 32 0 0 1 72 40" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={6} strokeLinecap="round" />
        <path
          d={(() => {
            const a = (pct / 100 * 180 - 90) * Math.PI / 180
            const x = 40 + 32 * Math.cos(a)
            const y = 40 + 32 * Math.sin(a)
            return `M8 40 A32 32 0 0 1 ${x} ${y}`
          })()}
          fill="none" stroke={color} strokeWidth={6} strokeLinecap="round"
        />
        <text x={40} y={36} textAnchor="middle" fill={color} fontSize={13} fontFamily="JetBrains Mono" fontWeight="700">
          {cpk.toFixed(2)}
        </text>
        <text x={40} y={46} textAnchor="middle" fill="#475569" fontSize={7}>Cpk</text>
      </svg>
      <div style={{ fontSize: 9, color, fontWeight: 600 }}>
        {cpk >= 1.67 ? '6σ' : cpk >= 1.33 ? 'OK' : 'LOW'}
      </div>
    </div>
  )
}

// ─── SPC Chart ────────────────────────────────────────────────────────────────
function SPCChart({
  measurements, config, enabledRules
}: {
  measurements: SPCMeasurement[]
  config: SPCConfig
  enabledRules: number
}) {
  const cl  = config.cl  ?? 0
  const ucl = config.ucl ?? cl + 3
  const lcl = config.lcl ?? cl - 3
  const u2  = config.ucl_2sigma ?? cl + 2 * ((ucl - cl) / 3)
  const l2  = config.lcl_2sigma ?? cl - 2 * ((ucl - cl) / 3)
  const u1  = config.ucl_1sigma ?? cl + (ucl - cl) / 3
  const l1  = config.lcl_1sigma ?? cl - (ucl - cl) / 3
  const sig = config.sigma_estimate ?? (ucl - cl) / 3

  const chartData = measurements.map((m, i) => ({
    idx: i + 1, value: m.measured_value, lot_id: m.lot_id,
    any_violation: m.any_violation,
    rules_violated: [1,2,3,4,5,6,7,8].filter(r => {
      const enabled = !!(enabledRules & (1 << (r - 1)))
      const violated = m[`violation_rule_${r}` as keyof SPCMeasurement] as boolean
      return enabled && violated
    }),
    vm_pred: m.vm_predicted_value,
    vm_lo: m.vm_ci_lower,
    vm_hi: m.vm_ci_upper,
  }))

  // Custom dot renderer — color by rule priority
  const renderDot = (props: any) => {
    const { cx, cy, payload } = props
    if (!cx || !cy) return <g key={props.key ?? cx} />
    const violated = payload.rules_violated as number[]
    if (violated.length === 0) {
      return <circle key={`dot-${payload.idx}`} cx={cx} cy={cy} r={3} fill="var(--teal)" opacity={0.75} />
    }
    // Show highest-priority rule color
    const topRule = Math.min(...violated)
    const color = RULE_META[topRule]?.color || '#EF4444'
    return (
      <g key={`dot-${payload.idx}`}>
        <circle cx={cx} cy={cy} r={6} fill={`${color}30`} stroke={color} strokeWidth={1.5} />
        <circle cx={cx} cy={cy} r={3} fill={color} />
      </g>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={260}>
      <ComposedChart data={chartData} margin={{ top: 8, right: 20, bottom: 4, left: -10 }}>
        <defs>
          {/* 3σ zone shading */}
          <pattern id="viol-bg" patternUnits="userSpaceOnUse" width={4} height={4}>
            <rect width={4} height={4} fill="rgba(239,68,68,0.04)" />
          </pattern>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
        <XAxis dataKey="idx" tick={{ fill: '#475569', fontSize: 8 }} interval={9} />
        <YAxis tick={{ fill: '#475569', fontSize: 9 }} width={58}
          tickFormatter={v => (+v).toFixed(config.sigma_estimate && config.sigma_estimate < 0.001 ? 6 : 4)} />
        <Tooltip
          contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 10 }}
          content={({ active, payload }) => {
            if (!active || !payload?.[0]) return null
            const d = payload[0].payload as typeof chartData[0]
            return (
              <div style={{ padding: '8px 12px', background: '#0F1626', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}>
                <div style={{ fontFamily: 'JetBrains Mono', fontSize: 11, color: 'var(--teal)', marginBottom: 4 }}>
                  Pt {d.idx} · {d.lot_id}
                </div>
                <div style={{ fontFamily: 'JetBrains Mono', fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>
                  {(d.value as number).toFixed(8)}
                </div>
                {d.rules_violated.length > 0 && (
                  <div style={{ marginTop: 4 }}>
                    {d.rules_violated.map(r => (
                      <div key={r} style={{ fontSize: 10, color: RULE_META[r]?.color }}>
                        ▶ Rule {r}: {RULE_META[r]?.desc}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )
          }}
        />
        {/* Zone reference lines */}
        <ReferenceLine y={ucl} stroke="rgba(239,68,68,0.7)"   strokeDasharray="6 3" label={{ value: 'UCL', fill: '#EF4444', fontSize: 8, position: 'right' }} />
        <ReferenceLine y={u2}  stroke="rgba(245,158,11,0.4)"  strokeDasharray="4 3" label={{ value: '+2σ', fill: '#F59E0B', fontSize: 8, position: 'right' }} />
        <ReferenceLine y={u1}  stroke="rgba(56,189,248,0.3)"  strokeDasharray="3 3" />
        <ReferenceLine y={cl}  stroke="rgba(0,229,196,0.6)"   strokeWidth={1.5}     label={{ value: 'CL',  fill: '#00E5C4', fontSize: 8, position: 'right' }} />
        <ReferenceLine y={l1}  stroke="rgba(56,189,248,0.3)"  strokeDasharray="3 3" />
        <ReferenceLine y={l2}  stroke="rgba(245,158,11,0.4)"  strokeDasharray="4 3" label={{ value: '-2σ', fill: '#F59E0B', fontSize: 8, position: 'right' }} />
        <ReferenceLine y={lcl} stroke="rgba(239,68,68,0.7)"   strokeDasharray="6 3" label={{ value: 'LCL', fill: '#EF4444', fontSize: 8, position: 'right' }} />
        {/* USL / LSL if set */}
        {config.usl && <ReferenceLine y={config.usl} stroke="rgba(255,79,106,0.5)" strokeDasharray="8 4" label={{ value: 'USL', fill: '#FF4F6A', fontSize: 8, position: 'right' }} />}
        {config.lsl && <ReferenceLine y={config.lsl} stroke="rgba(255,79,106,0.5)" strokeDasharray="8 4" label={{ value: 'LSL', fill: '#FF4F6A', fontSize: 8, position: 'right' }} />}

        {/* VM prediction band */}
        {chartData.some(d => d.vm_lo != null) && (
          <>
            <Line dataKey="vm_hi" stroke="rgba(139,92,246,0.3)" dot={false} activeDot={false} strokeWidth={1} strokeDasharray="4 2" />
            <Line dataKey="vm_lo" stroke="rgba(139,92,246,0.3)" dot={false} activeDot={false} strokeWidth={1} strokeDasharray="4 2" />
            <Line dataKey="vm_pred" stroke="rgba(139,92,246,0.7)" dot={false} strokeWidth={1.5} strokeDasharray="5 3" />
          </>
        )}

        <Line type="linear" dataKey="value" stroke="var(--teal)" strokeWidth={1.5}
          dot={renderDot} activeDot={false} connectNulls />
      </ComposedChart>
    </ResponsiveContainer>
  )
}

// ─── Live Rule Summary Bar ────────────────────────────────────────────────────
function RuleSummaryBar({ liveRules }: { liveRules: Record<string, { violation_count: number; triggered: boolean; description: string; severity: string }> }) {
  return (
    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
      {[1, 2, 3, 4, 5, 6, 7, 8].map(r => {
        const info = liveRules[`rule_${r}`]
        if (!info) return null
        const meta = RULE_META[r]
        return (
          <div key={r} style={{
            padding: '4px 10px', borderRadius: 6,
            background: info.triggered ? `${meta.color}1A` : 'var(--elevated)',
            border: `1px solid ${info.triggered ? meta.color : 'var(--border)'}`,
            display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 52,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, fontFamily: 'JetBrains Mono',
              color: info.triggered ? meta.color : 'var(--text-muted)' }}>
              {info.violation_count}
            </div>
            <div style={{ fontSize: 9, color: info.triggered ? meta.color : 'var(--text-muted)' }}>
              {meta.label}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ─── Violations Table ─────────────────────────────────────────────────────────
function ViolationsTable({ configId, days }: { configId: string; days: number }) {
  const { data, refetch } = useQuery({
    queryKey: ['spc-violations', configId, days],
    queryFn: () => spcApi.violations(configId, days, 'unacked'),
    enabled: !!configId,
  })
  const violations = data?.data?.data || []

  const ackMut = useMutation({
    mutationFn: ({ sk, note }: { sk: number; note: string }) => spcApi.acknowledge(sk, note),
    onSuccess: () => refetch(),
  })

  return (
    <div style={{ maxHeight: 280, overflowY: 'auto' }}>
      <table className="data-table">
        <thead>
          <tr>
            <th>#</th><th>Rule</th><th>Description</th><th>Severity</th>
            <th className="text-right">Trigger Value</th><th>Lot</th>
            <th className="text-right">σ Dev</th><th>Time</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          {violations.length === 0 && (
            <tr>
              <td colSpan={9} style={{ textAlign: 'center', padding: '24px', color: 'var(--text-muted)', fontSize: 12 }}>
                ✓ No unacknowledged violations
              </td>
            </tr>
          )}
          {violations.map((v: any) => (
            <tr key={v.violation_sk}>
              <td style={{ fontFamily: 'JetBrains Mono', fontSize: 10 }}>{v.violation_sk}</td>
              <td>
                <span style={{ fontFamily: 'JetBrains Mono', fontSize: 11, fontWeight: 700,
                  color: RULE_META[v.rule_number]?.color || 'var(--text-secondary)' }}>
                  Rule {v.rule_number}
                </span>
              </td>
              <td style={{ fontSize: 10, color: 'var(--text-muted)', maxWidth: 180 }}>{v.rule_description}</td>
              <td>
                <span className={`badge ${v.rule_severity === 'CRITICAL' ? 'badge-coral' : v.rule_severity === 'MAJOR' ? 'badge-amber' : 'badge-sky'}`}>
                  {v.rule_severity}
                </span>
              </td>
              <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10 }}>
                {v.trigger_value?.toFixed(6)}
              </td>
              <td style={{ fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--teal)' }}>{v.trigger_lot_id}</td>
              <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10,
                color: Math.abs(v.sigma_deviation ?? 0) > 3 ? 'var(--coral)' : 'var(--text-secondary)' }}>
                {v.sigma_deviation?.toFixed(3)}
              </td>
              <td style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>
                {v.violation_time ? new Date(v.violation_time).toLocaleString() : '—'}
              </td>
              <td>
                <button onClick={() => ackMut.mutate({ sk: v.violation_sk, note: 'Reviewed' })}
                  style={{ padding: '3px 8px', fontSize: 10, background: 'rgba(16,185,129,0.1)',
                    border: '1px solid rgba(16,185,129,0.3)', color: 'var(--pass)',
                    borderRadius: 5, cursor: 'pointer', fontFamily: 'JetBrains Mono' }}>
                  ACK
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ─── Capability Panel ─────────────────────────────────────────────────────────
function CapabilityPanel({ configId, days }: { configId: string; days: number }) {
  const { data } = useQuery({
    queryKey: ['spc-capability', configId, days],
    queryFn: () => spcApi.capability(configId, days),
    enabled: !!configId,
  })
  const cap = data?.data?.data as any
  if (!cap || cap.error) return (
    <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-muted)', fontSize: 12 }}>
      {cap?.error || 'No capability data'}
    </div>
  )

  const capColor = (v: number) => v >= 1.67 ? 'var(--pass)' : v >= 1.33 ? 'var(--warn)' : 'var(--fail)'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <MiniCpkGauge cpk={cap.cpk ?? 0} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        {[
          { k: 'Cp',  v: cap.cp  }, { k: 'Cpk', v: cap.cpk },
          { k: 'Cpm', v: cap.cpm }, { k: 'Pp',  v: cap.pp  },
          { k: 'Ppk', v: cap.ppk }, { k: 'n',   v: cap.n   },
        ].map(({ k, v }) => (
          <div key={k} style={{ background: 'var(--elevated)', border: '1px solid var(--border)',
            borderRadius: 6, padding: '6px 8px' }}>
            <div style={{ fontSize: 8, color: 'var(--text-muted)', textTransform: 'uppercase',
              letterSpacing: '0.06em', fontFamily: 'JetBrains Mono' }}>{k}</div>
            <div style={{ fontFamily: 'JetBrains Mono', fontSize: 13, fontWeight: 700, marginTop: 2,
              color: typeof v === 'number' && k !== 'n' ? capColor(v) : 'var(--text-secondary)' }}>
              {typeof v === 'number' ? (k === 'n' ? v.toLocaleString() : v.toFixed(3)) : '—'}
            </div>
          </div>
        ))}
      </div>
      <div style={{ borderTop: '1px solid var(--border)', paddingTop: 8 }}>
        {[
          { l: 'Mean',    v: cap.mean?.toFixed(6) },
          { l: 'Std σ',   v: cap.std_within?.toFixed(6) },
          { l: 'USL',     v: cap.usl?.toFixed(6) },
          { l: 'LSL',     v: cap.lsl?.toFixed(6) },
          { l: 'Normal?', v: cap.is_normal ? 'Yes' : 'No' },
          { l: 'SW p',    v: cap.shapiro_wilk_p?.toFixed(5) },
        ].map(s => (
          <div key={s.l} style={{ display: 'flex', justifyContent: 'space-between',
            padding: '3px 0', fontSize: 10, borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
            <span style={{ color: 'var(--text-muted)' }}>{s.l}</span>
            <span style={{ fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)', fontSize: 10 }}>{s.v ?? '—'}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export function SPCMonitor() {
  const [configId, setConfigId] = useState('')
  const [days, setDays] = useState(30)
  const [enabledRules, setEnabledRules] = useState(255)   // all 8 rules
  const [activeTab, setActiveTab] = useState<'chart' | 'violations'>('chart')

  const { data: configsData } = useQuery({
    queryKey: ['spc-configs'],
    queryFn: () => spcApi.configs(),
  })
  const configs: SPCConfig[] = configsData?.data?.data || []

  // Auto-select first config
  const selectedConfigId = configId || configs[0]?.config_id || ''
  const selectedConfig = configs.find(c => c.config_id === selectedConfigId)

  const { data: chartData, isLoading } = useQuery({
    queryKey: ['spc-chart', selectedConfigId, days, enabledRules],
    queryFn: () => spcApi.chart(selectedConfigId, days),
    enabled: !!selectedConfigId,
  })

  const measurements: SPCMeasurement[] = chartData?.data?.data?.measurements || []
  const liveRules = chartData?.data?.data?.live_rules || {}
  const totalViolations: number = chartData?.data?.data?.total_violations ?? 0

  return (
    <div style={{ animation: 'fadeIn .25s ease' }}>
      <div className="panel">
        {/* Header bar */}
        <div className="panel-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 2, height: 14, borderRadius: 2, background: 'var(--amber)' }} />
            <span style={{ fontFamily: 'Space Grotesk', fontWeight: 600, fontSize: 14 }}>SPC Monitor</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Config selector */}
            <select value={selectedConfigId} onChange={e => setConfigId(e.target.value)}
              style={{ background: 'var(--elevated)', border: '1px solid var(--border)',
                color: 'var(--amber)', borderRadius: 8, padding: '5px 10px',
                fontSize: 11, fontFamily: 'JetBrains Mono', cursor: 'pointer', minWidth: 200 }}>
              {configs.map(c => (
                <option key={c.config_id} value={c.config_id}>
                  {c.parameter_id} · {c.equipment_id || 'All'}
                </option>
              ))}
            </select>
            {/* Days */}
            {[14, 30, 60, 90].map(d => (
              <button key={d} onClick={() => setDays(d)}
                style={{ padding: '5px 9px', fontSize: 10, fontFamily: 'JetBrains Mono',
                  background: days === d ? 'rgba(245,158,11,0.1)' : 'transparent',
                  border: `1px solid ${days === d ? 'rgba(245,158,11,0.4)' : 'var(--border)'}`,
                  color: days === d ? 'var(--amber)' : 'var(--text-muted)',
                  borderRadius: 6, cursor: 'pointer' }}>{d}d</button>
            ))}
          </div>
        </div>

        <div className="panel-body" style={{ paddingTop: 12 }}>
          {/* Rule toggles + summary stats */}
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 14,
            padding: '10px 14px', background: 'var(--elevated)', borderRadius: 10,
            border: '1px solid var(--border)' }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 6,
                textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
                Western Electric Rules (click to toggle)
              </div>
              <RuleToggles enabled={enabledRules} onChange={setEnabledRules} />
            </div>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 700, fontFamily: 'Space Grotesk',
                  color: totalViolations > 0 ? 'var(--coral)' : 'var(--pass)' }}>
                  {totalViolations}
                </div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Violations
                </div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 700, fontFamily: 'Space Grotesk', color: 'var(--text-secondary)' }}>
                  {measurements.length}
                </div>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Points
                </div>
              </div>
            </div>
          </div>

          {/* Main layout: chart + capability */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 160px', gap: 16 }}>
            <div>
              {/* Rule summary counts */}
              <div style={{ marginBottom: 8 }}>
                <RuleSummaryBar liveRules={liveRules} />
              </div>

              {/* Chart */}
              {isLoading ? (
                <div style={{ height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--text-muted)', fontSize: 12 }}>Loading SPC data…</div>
              ) : selectedConfig ? (
                <SPCChart measurements={measurements} config={selectedConfig} enabledRules={enabledRules} />
              ) : (
                <div style={{ height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--text-muted)', fontSize: 12 }}>Select an SPC config above</div>
              )}

              {/* Config info strip */}
              {selectedConfig && (
                <div style={{ display: 'flex', gap: 14, marginTop: 8, fontSize: 10,
                  color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>
                  <span>Param: <span style={{ color: 'var(--amber)' }}>{selectedConfig.parameter_id}</span></span>
                  <span>Equip: <span style={{ color: 'var(--text-secondary)' }}>{selectedConfig.equipment_id || 'All'}</span></span>
                  <span>UCL: <span style={{ color: 'var(--text-secondary)' }}>{selectedConfig.ucl?.toFixed(6)}</span></span>
                  <span>CL: <span style={{ color: 'var(--teal)' }}>{selectedConfig.cl?.toFixed(6)}</span></span>
                  <span>LCL: <span style={{ color: 'var(--text-secondary)' }}>{selectedConfig.lcl?.toFixed(6)}</span></span>
                </div>
              )}

              {/* Tabs: violations */}
              <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)',
                  fontFamily: 'Space Grotesk', marginBottom: 8 }}>
                  Unacknowledged Violations
                </div>
                {selectedConfigId && (
                  <ViolationsTable configId={selectedConfigId} days={days} />
                )}
              </div>
            </div>

            {/* Capability sidebar */}
            <div style={{ background: 'var(--elevated)', border: '1px solid var(--border)',
              borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 10,
                textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
                Capability
              </div>
              {selectedConfigId && (
                <CapabilityPanel configId={selectedConfigId} days={days} />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
