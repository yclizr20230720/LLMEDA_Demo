import { useState, useRef, useEffect, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, LineChart, Line, ReferenceLine } from 'recharts'
import { cpApi, yieldApi } from '@/api/endpoints'
import { useWaferRenderer } from '@/hooks/useWaferRenderer'
import type { CPWaferSummary, CPBinMap } from '@/types'

// ─── Bin Legend ───────────────────────────────────────────────────────────────
const BIN_META: Record<string, { color: string; label: string }> = {
  '1':  { color: '#10B981', label: 'Pass (Bin 1)' },
  '8':  { color: '#38BDF8', label: 'Parametric Fail' },
  '14': { color: '#8B5CF6', label: 'Functional Fail' },
  '9':  { color: '#F59E0B', label: 'Contact Fail' },
  '12': { color: '#EF4444', label: 'Hard Fail' },
  '6':  { color: '#84CC16', label: 'Retest Pass' },
  '4':  { color: '#EC4899', label: 'Pattern Fail' },
  '0':  { color: '#475569', label: 'Untested' },
}

// ─── Single Wafer Bin Map Canvas ──────────────────────────────────────────────
function WaferBinMap({ lotId, waferId, size = 260 }: { lotId: string; waferId: string; size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { data, isLoading } = useQuery({
    queryKey: ['cp-binmap', lotId, waferId],
    queryFn: () => cpApi.binMap(lotId, waferId),
    enabled: !!lotId && !!waferId,
  })
  const bm = data?.data?.data as CPBinMap | undefined

  useWaferRenderer(
    canvasRef,
    bm?.xs || [], bm?.ys || [], bm?.bins || [], bm?.passes || []
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{ position: 'relative', width: size, height: size }}>
        {isLoading && (
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
            justifyContent: 'center', color: 'var(--text-muted)', fontSize: 11,
          }}>Loading…</div>
        )}
        <canvas ref={canvasRef} width={size} height={size}
          style={{ borderRadius: '50%', display: 'block' }} />
      </div>
      {bm && (
        <div style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center', fontFamily: 'JetBrains Mono' }}>
          <span style={{ color: 'var(--pass)', fontWeight: 700 }}>{bm.gross_yield_pct.toFixed(2)}%</span>
          {' '}yield · {bm.pass_count.toLocaleString()} / {bm.die_count.toLocaleString()} die
        </div>
      )}
    </div>
  )
}

// ─── Bin Map Tab ──────────────────────────────────────────────────────────────
function BinMapTab({ lotId }: { lotId: string }) {
  const { data: galleryData } = useQuery({
    queryKey: ['cp-wafer-summary', lotId],
    queryFn: () => cpApi.waferSummary(lotId),
    enabled: !!lotId,
  })
  const wafers: CPWaferSummary[] = galleryData?.data?.data || []
  const [selectedWafer, setSelectedWafer] = useState<CPWaferSummary | null>(null)

  useEffect(() => {
    if (wafers.length > 0 && !selectedWafer) setSelectedWafer(wafers[0])
  }, [wafers])

  const [hiddenBins, setHiddenBins] = useState<Set<string>>(new Set())
  const toggleBin = (b: string) =>
    setHiddenBins(prev => { const s = new Set(prev); s.has(b) ? s.delete(b) : s.add(b); return s })

  // Aggregate bin pareto across all wafers
  const aggregateBins = useMemo(() => {
    const agg: Record<string, number> = {}
    wafers.forEach(w => {
      if (!w.bin_counts_json) return
      try {
        const bc = JSON.parse(w.bin_counts_json)
        Object.entries(bc).forEach(([b, cnt]) => { agg[b] = (agg[b] || 0) + (cnt as number) })
      } catch { /* skip */ }
    })
    const total = Object.values(agg).reduce((a, b) => a + b, 0)
    let cum = 0
    return Object.entries(agg)
      .sort(([, a], [, b]) => b - a)
      .map(([bin, count]) => {
        cum += count
        return { bin, count, pct: count / total * 100, cum_pct: cum / total * 100 }
      })
  }, [wafers])

  if (!lotId) return (
    <div style={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--text-muted)', fontSize: 12 }}>
      Enter a Lot ID in the header to load bin map data
    </div>
  )

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr 240px', gap: 20 }}>
      {/* Left: wafer gallery (mini) + selected wafer map */}
      <div>
        {selectedWafer && (
          <WaferBinMap lotId={lotId} waferId={selectedWafer.wafer_id} size={248} />
        )}
        <div style={{ marginTop: 10 }}>
          <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 6,
            textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
            Bin Legend
          </div>
          {Object.entries(BIN_META).map(([bin, meta]) => (
            <div key={bin}
              onClick={() => toggleBin(bin)}
              style={{
                display: 'flex', alignItems: 'center', gap: 7, padding: '3px 0',
                cursor: 'pointer', opacity: hiddenBins.has(bin) ? 0.35 : 1,
              }}
            >
              <div style={{ width: 10, height: 10, borderRadius: 2, background: meta.color, flexShrink: 0 }} />
              <span style={{ fontSize: 10, color: 'var(--text-secondary)' }}>
                Bin {bin} — {meta.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Centre: wafer gallery scroll */}
      <div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 8,
          fontFamily: 'JetBrains Mono', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          Wafer Gallery — {wafers.length} wafers
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8,
          maxHeight: 480, overflowY: 'auto', paddingRight: 4 }}>
          {wafers.map(w => {
            const yld = w.gross_yield_pct ?? 0
            const color = yld >= 95 ? '#10B981' : yld >= 90 ? '#F59E0B' : '#EF4444'
            const isSelected = selectedWafer?.wafer_id === w.wafer_id
            return (
              <div key={w.wafer_id}
                onClick={() => setSelectedWafer(w)}
                style={{
                  padding: '8px 6px', borderRadius: 8, cursor: 'pointer', textAlign: 'center',
                  background: isSelected ? 'rgba(0,229,196,0.08)' : 'var(--elevated)',
                  border: `1px solid ${isSelected ? 'rgba(0,229,196,0.4)' : 'var(--border)'}`,
                  transition: 'all .15s',
                }}
              >
                {/* Mini wafer SVG ring */}
                <svg width={50} height={50} viewBox="0 0 50 50" style={{ display: 'block', margin: '0 auto 4px' }}>
                  <circle cx={25} cy={25} r={22} fill={`${color}18`} stroke={color} strokeWidth={1.5} />
                  <text x={25} y={29} textAnchor="middle" fill={color}
                    fontSize={10} fontFamily="JetBrains Mono" fontWeight="700">
                    {yld.toFixed(1)}
                  </text>
                </svg>
                <div style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>
                  S{w.slot_number}
                </div>
                {w.syl_flag && <div style={{ fontSize: 8, color: 'var(--amber)', marginTop: 2 }}>⚠ SYL</div>}
                {w.wafer_pattern_flag && <div style={{ fontSize: 8, color: 'var(--violet)', marginTop: 1 }}>
                  {w.pattern_class_generic}
                </div>}
              </div>
            )
          })}
        </div>
      </div>

      {/* Right: bin pareto */}
      <div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 8,
          fontFamily: 'JetBrains Mono', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          Lot Bin Pareto
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={aggregateBins} layout="vertical" margin={{ left: 6, right: 48, top: 4, bottom: 4 }}>
            <XAxis type="number" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v.toFixed(0)}%`} />
            <YAxis dataKey="bin" type="category" tick={{ fill: '#94A3B8', fontSize: 10, fontFamily: 'JetBrains Mono' }} width={24} />
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
            <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
              formatter={(v: number) => [`${v.toFixed(2)}%`, 'Share']} />
            <Bar dataKey="pct" radius={[0, 3, 3, 0]}
              label={{ position: 'right', fill: '#64748B', fontSize: 9, formatter: (v: number) => `${v.toFixed(1)}%` }}>
              {aggregateBins.map((r, i) => <Cell key={i} fill={BIN_META[r.bin]?.color || '#64748B'} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        {/* Wafer detail */}
        {selectedWafer && (
          <div style={{ marginTop: 12, background: 'var(--elevated)',
            border: '1px solid var(--border)', borderRadius: 8, padding: 12 }}>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 8,
              textTransform: 'uppercase', letterSpacing: '0.06em', fontFamily: 'JetBrains Mono' }}>
              Slot {selectedWafer.slot_number} Details
            </div>
            {[
              { l: 'Gross Yield', v: `${selectedWafer.gross_yield_pct?.toFixed(3)}%` },
              { l: 'Net Yield', v: `${selectedWafer.net_yield_pct?.toFixed(3)}%` },
              { l: '1st Pass', v: `${selectedWafer.first_pass_yield?.toFixed(3)}%` },
              { l: 'Pattern', v: selectedWafer.pattern_class_generic || '—' },
              { l: 'Edge Yield', v: selectedWafer.edge_yield_pct ? `${selectedWafer.edge_yield_pct.toFixed(2)}%` : '—' },
              { l: 'Center Yield', v: selectedWafer.center_yield_pct ? `${selectedWafer.center_yield_pct.toFixed(2)}%` : '—' },
              { l: 'MRB', v: selectedWafer.mrb_result || '—' },
            ].map(s => (
              <div key={s.l} style={{ display: 'flex', justifyContent: 'space-between',
                padding: '3px 0', borderBottom: '1px solid rgba(255,255,255,0.03)', fontSize: 10 }}>
                <span style={{ color: 'var(--text-muted)' }}>{s.l}</span>
                <span style={{ fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)' }}>{s.v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              {selectedWafer.syl_flag && <span className="badge badge-warn">SYL</span>}
              {selectedWafer.sbl_flag && <span className="badge badge-coral">SBL</span>}
              {selectedWafer.wafer_pattern_flag && <span className="badge badge-violet">PATTERN</span>}
              {selectedWafer.mrb_required && <span className="badge badge-coral">MRB</span>}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── MRB Review Tab ───────────────────────────────────────────────────────────
function MRBReviewTab({ lotId }: { lotId: string }) {
  const [days, setDays] = useState(14)
  const { data, isLoading } = useQuery({
    queryKey: ['mrb-review', lotId, days],
    queryFn: () => cpApi.mrbReview(days, lotId || undefined),
  })
  const wafers: CPWaferSummary[] = data?.data?.data || []
  const meta = data?.data?.meta as Record<string, number> | undefined

  const statCards = [
    { l: 'Total MRB', v: meta?.total ?? 0, c: 'var(--text-secondary)' },
    { l: 'Bad Wafer', v: meta?.bad_wafer ?? 0, c: 'var(--coral)' },
    { l: 'Good Wafer', v: meta?.good_wafer ?? 0, c: 'var(--pass)' },
    { l: 'SYL Flagged', v: meta?.syl_count ?? 0, c: 'var(--amber)' },
    { l: 'SBL Flagged', v: meta?.sbl_count ?? 0, c: 'var(--coral)' },
    { l: 'Pattern Flag', v: meta?.pattern_count ?? 0, c: 'var(--violet)' },
  ]

  const yieldColor = (y?: number) => !y ? '' : y >= 95 ? '#10B981' : y >= 90 ? '#F59E0B' : '#EF4444'
  const flag = (v: boolean | undefined) => v ? '✓' : '—'

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        {[7, 14, 30].map(d => (
          <button key={d} onClick={() => setDays(d)}
            style={{ padding: '4px 10px', fontSize: 10, fontFamily: 'JetBrains Mono',
              background: days === d ? 'rgba(0,229,196,0.1)' : 'transparent',
              border: `1px solid ${days === d ? 'rgba(0,229,196,0.35)' : 'var(--border)'}`,
              color: days === d ? 'var(--teal)' : 'var(--text-muted)',
              borderRadius: 6, cursor: 'pointer' }}>{d}d</button>
        ))}
        <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 'auto' }}>
          {wafers.length} wafers under review
        </span>
      </div>

      {/* Summary strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 8, marginBottom: 14 }}>
        {statCards.map(s => (
          <div key={s.l} className="kpi-card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 700, color: s.c, fontFamily: 'Space Grotesk' }}>{s.v}</div>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 3,
              textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Full MRB table */}
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Lot ID</th><th>Wafer ID</th><th>Slot</th>
              <th className="text-right">Gross Yield</th><th className="text-right">Net Yield</th>
              <th>SYL</th><th>SBL</th><th>Pattern</th><th>Cluster</th>
              <th>Partial</th><th>MRB Result</th><th>Tester</th><th>Date</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={13} style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)', fontSize: 12 }}>Loading…</td></tr>
            ) : wafers.map(w => (
              <tr key={w.wafer_id}>
                <td style={{ fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--teal)' }}>{w.lot_id}</td>
                <td style={{ fontFamily: 'JetBrains Mono', fontSize: 10 }}>{w.wafer_id}</td>
                <td style={{ textAlign: 'center', fontFamily: 'JetBrains Mono', fontSize: 10 }}>{w.slot_number}</td>
                <td style={{ textAlign: 'right' }}>
                  <span style={{ fontFamily: 'JetBrains Mono', fontSize: 11, fontWeight: 700, color: yieldColor(w.gross_yield_pct) }}>
                    {w.gross_yield_pct?.toFixed(3)}%
                  </span>
                </td>
                <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--text-secondary)' }}>
                  {w.net_yield_pct?.toFixed(3)}%
                </td>
                <td>{w.syl_flag ? <span style={{ color: 'var(--amber)', fontWeight: 700, fontFamily: 'JetBrains Mono', fontSize: 10 }}>⚠ SYL</span> : <span style={{ color: 'var(--text-muted)' }}>—</span>}</td>
                <td>{w.sbl_flag ? <span style={{ color: 'var(--coral)', fontWeight: 700, fontFamily: 'JetBrains Mono', fontSize: 10 }}>✗ SBL</span> : <span style={{ color: 'var(--text-muted)' }}>—</span>}</td>
                <td>{w.wafer_pattern_flag ? <span style={{ color: 'var(--violet)', fontSize: 10 }}>{w.pattern_class_generic}</span> : <span style={{ color: 'var(--text-muted)' }}>—</span>}</td>
                <td style={{ textAlign: 'center', color: w.wafer_cluster_flag ? 'var(--amber)' : 'var(--text-muted)', fontFamily: 'JetBrains Mono', fontSize: 10 }}>{flag(w.wafer_cluster_flag)}</td>
                <td style={{ textAlign: 'center', color: w.is_partial_wafer ? 'var(--amber)' : 'var(--text-muted)', fontFamily: 'JetBrains Mono', fontSize: 10 }}>{flag(w.is_partial_wafer)}</td>
                <td>
                  {w.mrb_result ? (
                    <span className={`badge ${w.mrb_result === 'GoodWafer' ? 'badge-pass' : w.mrb_result === 'ScrapWafer' ? 'badge-coral' : 'badge-amber'}`}>
                      {w.mrb_result}
                    </span>
                  ) : <span className="badge badge-sky">Pending</span>}
                </td>
                <td style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>{w.tester_id}</td>
                <td style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>{w.event_date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Site Yield Heatmap Tab ───────────────────────────────────────────────────
function SiteYieldTab({ lotId }: { lotId: string }) {
  const [selectedWaferId, setSelectedWaferId] = useState('')
  const { data: wsData } = useQuery({
    queryKey: ['cp-wafer-list', lotId],
    queryFn: () => cpApi.waferSummary(lotId),
    enabled: !!lotId,
  })
  const wafers: CPWaferSummary[] = wsData?.data?.data || []
  useEffect(() => { if (wafers.length > 0 && !selectedWaferId) setSelectedWaferId(wafers[0].wafer_id) }, [wafers])

  const { data } = useQuery({
    queryKey: ['cp-site-yield', lotId, selectedWaferId],
    queryFn: () => cpApi.siteYield(lotId, selectedWaferId || undefined),
    enabled: !!lotId,
  })
  const siteRows = (data?.data?.data || []) as { wafer_id: string; slot_number: number; gross_yield_pct: number; site_yields: Record<string, number> }[]

  // Site layout (9 sites: centre + ring)
  const siteLayout = [
    [null, null,   '4', null, null],
    [null,   '7',  null, '6', null],
    ['2',   null,  '1',  null, '3'],
    [null,   '8',  null, '5', null],
    [null, null,   '9', null, null],
  ]

  const selectedRow = siteRows.find(r => r.wafer_id === selectedWaferId)
  const siteYields = selectedRow?.site_yields || {}
  const allVals = Object.values(siteYields).filter(Boolean)
  const minY = allVals.length ? Math.min(...allVals) : 85
  const maxY = allVals.length ? Math.max(...allVals) : 100
  const cellColor = (y?: number) => {
    if (!y) return 'var(--elevated)'
    const t = (y - minY) / Math.max(maxY - minY, 0.1)
    const r = Math.round(239 * (1 - t) + 16 * t)
    const g = Math.round(68 * (1 - t) + 185 * t)
    const b = Math.round(68 * (1 - t) + 129 * t)
    return `rgb(${r},${g},${b})`
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 20 }}>
      {/* Wafer selector */}
      <div>
        <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 8,
          textTransform: 'uppercase', letterSpacing: '0.07em', fontFamily: 'JetBrains Mono' }}>
          Select Wafer
        </div>
        <div style={{ maxHeight: 400, overflowY: 'auto' }}>
          {wafers.map(w => (
            <div key={w.wafer_id}
              onClick={() => setSelectedWaferId(w.wafer_id)}
              style={{
                padding: '7px 10px', marginBottom: 4, borderRadius: 8, cursor: 'pointer',
                background: selectedWaferId === w.wafer_id ? 'rgba(0,229,196,0.08)' : 'var(--elevated)',
                border: `1px solid ${selectedWaferId === w.wafer_id ? 'rgba(0,229,196,0.35)' : 'var(--border)'}`,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}
            >
              <span style={{ fontFamily: 'JetBrains Mono', fontSize: 10, color: 'var(--text-secondary)' }}>
                S{w.slot_number}
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'JetBrains Mono',
                color: (w.gross_yield_pct ?? 0) >= 95 ? 'var(--pass)' : (w.gross_yield_pct ?? 0) >= 90 ? 'var(--warn)' : 'var(--fail)' }}>
                {w.gross_yield_pct?.toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Site grid heatmap */}
      <div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 12,
          fontFamily: 'JetBrains Mono', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          9-Site Yield Map — {selectedWaferId}
        </div>
        <div style={{ display: 'inline-block', border: '1px solid var(--border)', borderRadius: 12,
          padding: 16, background: 'var(--elevated)' }}>
          {siteLayout.map((row, ri) => (
            <div key={ri} style={{ display: 'flex', gap: 6 }}>
              {row.map((site, ci) => site ? (
                <div key={ci} style={{
                  width: 72, height: 72, borderRadius: 8, margin: '3px',
                  background: cellColor(siteYields[site]),
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  border: '1px solid rgba(255,255,255,0.1)',
                }}>
                  <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.5)', fontFamily: 'JetBrains Mono' }}>S{site}</div>
                  <div style={{ fontSize: 16, fontWeight: 700, fontFamily: 'JetBrains Mono', color: '#fff' }}>
                    {siteYields[site]?.toFixed(1) ?? '—'}
                  </div>
                  <div style={{ fontSize: 8, color: 'rgba(255,255,255,0.4)' }}>%</div>
                </div>
              ) : (
                <div key={ci} style={{ width: 72, height: 72, margin: '3px', borderRadius: 8, opacity: 0 }} />
              ))}
            </div>
          ))}
        </div>
        {/* Gradient scale */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12 }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>{minY.toFixed(1)}%</span>
          <div style={{ flex: 1, height: 8, borderRadius: 4,
            background: 'linear-gradient(to right, #EF4444, #10B981)', border: '1px solid rgba(255,255,255,0.08)' }} />
          <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>{maxY.toFixed(1)}%</span>
        </div>
      </div>
    </div>
  )
}

// ─── Pattern Gallery Tab ───────────────────────────────────────────────────────
function PatternGalleryTab() {
  const [days, setDays] = useState(30)
  const { data, isLoading } = useQuery({
    queryKey: ['cp-pattern-gallery', days],
    queryFn: () => cpApi.patternGallery(days),
  })
  const gallery = (data?.data?.data || []) as {
    pattern: string; count: number; avg_yield?: number; min_yield?: number;
    examples: { wafer_id: string; lot_id: string; slot_number: number; gross_yield_pct?: number }[]
  }[]

  const PATTERN_ICON: Record<string, string> = {
    NORMAL: '◎', EDGE: '◔', CENTER: '●', DONUT: '○',
    SCRATCH: '╱', CLUSTER: '⊡', HALF_EDGE: '◑',
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        {[14, 30, 60].map(d => (
          <button key={d} onClick={() => setDays(d)}
            style={{ padding: '4px 10px', fontSize: 10, fontFamily: 'JetBrains Mono',
              background: days === d ? 'rgba(56,189,248,0.1)' : 'transparent',
              border: `1px solid ${days === d ? 'rgba(56,189,248,0.35)' : 'var(--border)'}`,
              color: days === d ? 'var(--sky)' : 'var(--text-muted)',
              borderRadius: 6, cursor: 'pointer' }}>{d}d</button>
        ))}
      </div>
      {isLoading ? (
        <div style={{ height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--text-muted)', fontSize: 12 }}>Loading patterns…</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 12 }}>
          {gallery.map(g => (
            <div key={g.pattern}
              style={{ background: 'var(--elevated)', border: '1px solid var(--border)', borderRadius: 10, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div style={{ width: 40, height: 40, borderRadius: 8,
                  background: g.pattern === 'NORMAL' ? 'rgba(16,185,129,0.15)' : 'rgba(245,158,11,0.15)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 22, color: g.pattern === 'NORMAL' ? 'var(--pass)' : 'var(--amber)' }}>
                  {PATTERN_ICON[g.pattern] || '●'}
                </div>
                <div>
                  <div style={{ fontFamily: 'Space Grotesk', fontWeight: 600, fontSize: 12, color: 'var(--text-primary)' }}>
                    {g.pattern}
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{g.count} wafers</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 10 }}>
                <div style={{ background: 'var(--card)', borderRadius: 6, padding: '5px 8px', textAlign: 'center' }}>
                  <div style={{ fontSize: 9, color: 'var(--text-muted)' }}>Avg Yield</div>
                  <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'JetBrains Mono',
                    color: (g.avg_yield ?? 0) >= 90 ? 'var(--pass)' : 'var(--warn)' }}>
                    {g.avg_yield?.toFixed(2)}%
                  </div>
                </div>
                <div style={{ background: 'var(--card)', borderRadius: 6, padding: '5px 8px', textAlign: 'center' }}>
                  <div style={{ fontSize: 9, color: 'var(--text-muted)' }}>Min Yield</div>
                  <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'JetBrains Mono', color: 'var(--text-secondary)' }}>
                    {g.min_yield?.toFixed(2)}%
                  </div>
                </div>
              </div>
              <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 4, fontFamily: 'JetBrains Mono' }}>Example lots</div>
              {g.examples.slice(0, 3).map(ex => (
                <div key={ex.wafer_id} style={{ display: 'flex', justifyContent: 'space-between',
                  fontSize: 10, padding: '2px 0', color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>
                  <span style={{ color: 'var(--teal)' }}>{ex.lot_id}</span>
                  <span>S{ex.slot_number}</span>
                  <span style={{ color: (ex.gross_yield_pct ?? 0) >= 90 ? 'var(--pass)' : 'var(--warn)' }}>
                    {ex.gross_yield_pct?.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'binmap',   label: '⬡ Bin Map' },
  { id: 'mrb',      label: '⚖ MRB Review' },
  { id: 'siteyield',label: '◉ Site Yield' },
  { id: 'patterns', label: '◈ Pattern Gallery' },
]

export function CPAnalytics() {
  const [tab, setTab] = useState('binmap')
  const [lotId, setLotId] = useState('M100100')

  return (
    <div style={{ animation: 'fadeIn .25s ease' }}>
      <div className="panel">
        {/* Header */}
        <div className="panel-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 2, height: 14, borderRadius: 2, background: 'var(--sky)' }} />
            <span style={{ fontFamily: 'Space Grotesk', fontWeight: 600, fontSize: 14 }}>CP Bin Map & Yield Analytics</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <label style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'JetBrains Mono' }}>Lot ID</label>
            <input value={lotId} onChange={e => setLotId(e.target.value)}
              placeholder="e.g. M100100"
              style={{ width: 120, background: 'var(--elevated)', border: '1px solid var(--border)',
                color: 'var(--teal)', borderRadius: 8, padding: '5px 10px',
                fontSize: 11, fontFamily: 'JetBrains Mono', outline: 'none' }}
              onFocus={e => (e.currentTarget.style.borderColor = 'rgba(0,229,196,0.4)')}
              onBlur={e => (e.currentTarget.style.borderColor = 'var(--border)')}
            />
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 2, padding: '10px 18px 0', borderBottom: '1px solid var(--border)' }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{
                padding: '8px 14px', fontSize: 11, fontWeight: 500, background: 'none', border: 'none',
                cursor: 'pointer', color: tab === t.id ? 'var(--sky)' : 'var(--text-muted)',
                borderBottom: tab === t.id ? '2px solid var(--sky)' : '2px solid transparent',
                borderRadius: '6px 6px 0 0', transition: 'all .15s',
              }}>{t.label}</button>
          ))}
        </div>

        {/* Content */}
        <div className="panel-body" style={{ paddingTop: 16 }}>
          {tab === 'binmap'    && <BinMapTab lotId={lotId} />}
          {tab === 'mrb'       && <MRBReviewTab lotId={lotId} />}
          {tab === 'siteyield' && <SiteYieldTab lotId={lotId} />}
          {tab === 'patterns'  && <PatternGalleryTab />}
        </div>
      </div>
    </div>
  )
}
