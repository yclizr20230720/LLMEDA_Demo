import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { authApi } from '@/api/endpoints'

// Animated particle canvas
function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = canvasRef.current!
    const ctx = canvas.getContext('2d')!
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    type Particle = { x:number; y:number; vx:number; vy:number; life:number; maxLife:number; r:number }
    const particles: Particle[] = Array.from({ length: 80 }, () => ({
      x: Math.random() * canvas.width, y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4,
      life: Math.random() * 200, maxLife: 150 + Math.random() * 100,
      r: 0.5 + Math.random() * 2,
    }))
    let raf: number
    const draw = () => {
      ctx.fillStyle = 'rgba(6,10,18,0.15)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      for (const p of particles) {
        p.x += p.vx; p.y += p.vy; p.life++
        if (p.life > p.maxLife) {
          p.x = Math.random() * canvas.width; p.y = Math.random() * canvas.height
          p.life = 0; p.maxLife = 150 + Math.random() * 100
        }
        const alpha = Math.sin((p.life / p.maxLife) * Math.PI) * 0.5
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(0,229,196,${alpha})`
        ctx.fill()
      }
      raf = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(raf)
  }, [])
  return <canvas ref={canvasRef} style={{ position:'fixed', inset:0, zIndex:0 }} />
}

const DEMO_USERS = [
  { label: 'Process Engineer', username: 'pe_engineer', password: 'Engineer@123' },
  { label: 'Equipment Engineer', username: 'ee_engineer', password: 'Engineer@123' },
  { label: 'Manager', username: 'manager', password: 'Manager@123' },
  { label: 'System Admin', username: 'admin', password: 'Admin@12345' },
]

export function LoginPage() {
  const [username, setUsername] = useState('pe_engineer')
  const [password, setPassword] = useState('Engineer@123')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { setAuth } = useAuthStore()
  const navigate = useNavigate()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim() || !password.trim()) { setError('Please enter credentials'); return }
    setLoading(true); setError('')
    try {
      const res = await authApi.login(username.trim(), password)
      const { access_token, refresh_token, user } = res.data.data
      setAuth(user, access_token, refresh_token)
      navigate('/', { replace: true })
    } catch (err: any) {
      setError(err?.response?.data?.errors?.[0]?.message || 'Login failed')
    } finally { setLoading(false) }
  }

  const fillDemo = (u: typeof DEMO_USERS[0]) => { setUsername(u.username); setPassword(u.password) }

  return (
    <div style={{ minHeight:'100vh', background:'var(--void)', display:'flex',
      alignItems:'center', justifyContent:'center', position:'relative' }}>
      <ParticleCanvas />

      <div style={{
        position:'relative', zIndex:1, width:440,
        background:'rgba(11,17,32,0.92)', backdropFilter:'blur(24px)',
        border:'1px solid rgba(0,229,196,0.2)', borderRadius:18,
        padding:'40px 36px', boxShadow:'0 40px 80px rgba(0,0,0,0.6)',
      }}>
        {/* Header */}
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ fontSize:28, fontFamily:'Space Grotesk', fontWeight:700,
            background:'linear-gradient(135deg,var(--teal),var(--violet))',
            WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', letterSpacing:'0.04em' }}>
            SEMFAB·IQ
          </div>
          <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:6, fontFamily:'JetBrains Mono' }}>
            FAB-12 Engineering Data Analytics · N5 Node
          </div>
        </div>

        {/* Quick-fill demo users */}
        <div style={{ marginBottom:24 }}>
          <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:8, fontFamily:'JetBrains Mono', textTransform:'uppercase', letterSpacing:'0.08em' }}>
            Quick Login
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
            {DEMO_USERS.map(u => (
              <button key={u.username} onClick={() => fillDemo(u)} style={{
                padding:'7px 10px', background:'rgba(255,255,255,0.04)',
                border:'1px solid var(--border)', borderRadius:8, cursor:'pointer',
                color:'var(--text-secondary)', fontSize:11, textAlign:'left',
                transition:'all .15s',
              }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,229,196,0.08)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.04)')}
              >
                <div style={{ fontWeight:600, color:'var(--teal)', fontSize:10 }}>{u.label}</div>
                <div style={{ fontFamily:'JetBrains Mono', fontSize:9, color:'var(--text-muted)', marginTop:1 }}>
                  {u.username}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin}>
          {[
            { label:'Username', value:username, onChange:setUsername, type:'text', placeholder:'username' },
            { label:'Password', value:password, onChange:setPassword, type:'password', placeholder:'••••••••' },
          ].map(field => (
            <div key={field.label} style={{ marginBottom:16 }}>
              <label style={{ display:'block', fontSize:10, fontFamily:'JetBrains Mono',
                color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:6 }}>
                {field.label}
              </label>
              <input
                type={field.type}
                value={field.value}
                onChange={e => field.onChange(e.target.value)}
                placeholder={field.placeholder}
                required
                style={{
                  width:'100%', padding:'10px 14px',
                  background:'rgba(255,255,255,0.05)', border:'1px solid var(--border)',
                  borderRadius:8, color:'var(--text-primary)', fontSize:13,
                  fontFamily: field.type === 'password' ? 'monospace' : 'inherit',
                  outline:'none', transition:'border .15s',
                }}
                onFocus={e => { e.currentTarget.style.border = '1px solid rgba(0,229,196,0.4)' }}
                onBlur={e => { e.currentTarget.style.border = '1px solid var(--border)' }}
              />
            </div>
          ))}

          {error && (
            <div style={{ padding:'10px 14px', background:'rgba(255,79,106,0.1)',
              border:'1px solid rgba(255,79,106,0.25)', borderRadius:8,
              color:'#FF4F6A', fontSize:12, marginBottom:16 }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width:'100%', padding:'12px', borderRadius:10, border:'none',
              background: loading ? 'rgba(0,229,196,0.3)' : 'linear-gradient(135deg,var(--teal),#00b39a)',
              color:'#000', fontSize:14, fontWeight:700, fontFamily:'Space Grotesk',
              cursor: loading ? 'not-allowed' : 'pointer', letterSpacing:'0.04em',
              transition:'all .2s',
            }}
          >
            {loading ? 'Authenticating…' : 'Sign In to FAB-12'}
          </button>
        </form>

        <div style={{ marginTop:20, textAlign:'center', fontSize:9,
          color:'var(--text-muted)', fontFamily:'JetBrains Mono' }}>
          SEMFAB·IQ v1.0.0 · TTT Semiconductor · Confidential
        </div>
      </div>
    </div>
  )
}
