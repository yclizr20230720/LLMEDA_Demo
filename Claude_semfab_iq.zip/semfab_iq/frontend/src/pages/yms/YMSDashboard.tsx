import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ReferenceLine, ResponsiveContainer, Cell } from 'recharts'
import { yieldApi, alarmApi } from '@/api/endpoints'
import type { YieldKPI, YieldTrendPoint, LotSummary, Alarm } from '@/types'
import { clsx } from 'clsx'

// ─── KPI Strip ────────────────────────────────────────────────────────────────
function KPIStrip({ kpi }: { kpi: YieldKPI }) {
  const items = [
    { label:'Fab Yield', value:`${kpi.fab_yield_pct?.toFixed(2)}%`, color:'var(--teal)',
      sub:`${kpi.wafer_count} wafers` },
    { label:'Avg Gross Yield', value:`${kpi.avg_yield_pct?.toFixed(2)}%`, color:'var(--teal)',
      sub:`σ = ${kpi.std_yield_pct?.toFixed(2)}%` },
    { label:'Lots in Period', value:kpi.lot_count, color:'var(--sky)',
      sub:`${kpi.period_days}d window` },
    { label:'SYL Excursions', value:kpi.syl_wafer_count, color: kpi.syl_wafer_count > 0 ? 'var(--amber)' : 'var(--pass)',
      sub:`SBL: ${kpi.sbl_wafer_count}` },
    { label:'Total Pass Die', value:(kpi.total_pass_die/1e6).toFixed(2)+'M', color:'var(--violet)',
      sub:`of ${(kpi.total_die/1e6).toFixed(2)}M` },
  ]
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:10, marginBottom:16 }}>
      {items.map(it => (
        <div key={it.label} className="kpi-card">
          <div style={{ fontSize:9, color:'var(--text-muted)', textTransform:'uppercase',
            letterSpacing:'0.08em', fontFamily:'JetBrains Mono', marginBottom:6 }}>
            {it.label}
          </div>
          <div style={{ fontSize:22, fontWeight:700, color:it.color, fontFamily:'Space Grotesk', lineHeight:1 }}>
            {it.value}
          </div>
          <div style={{ fontSize:10, color:'var(--text-muted)', marginTop:4 }}>{it.sub}</div>
        </div>
      ))}
    </div>
  )
}

// ─── Yield Trend Chart ────────────────────────────────────────────────────────
function YieldTrendChart({ data }: { data: YieldTrendPoint[] }) {
  const syl = 90, sbl = 85
  return (
    <div className="panel" style={{ marginBottom:16 }}>
      <div className="panel-header">
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:2, height:14, borderRadius:2, background:'var(--teal)' }} />
          <span style={{ fontFamily:'Space Grotesk', fontWeight:600, fontSize:13 }}>
            Gross Yield Trend — P10 / P50 / P90 Band
          </span>
        </div>
        <div style={{ display:'flex', gap:12, fontSize:10, color:'var(--text-muted)' }}>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:12, height:2, background:'rgba(0,229,196,0.4)', display:'inline-block', borderRadius:2 }} /> P10–P90
          </span>
          <span style={{ display:'flex', alignItems:'center', gap:4 }}>
            <span style={{ width:12, height:2, background:'var(--teal)', display:'inline-block', borderRadius:2 }} /> P50
          </span>
        </div>
      </div>
      <div className="panel-body">
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={data} margin={{ top:8, right:12, bottom:0, left:-10 }}>
            <defs>
              <linearGradient id="yBand" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00E5C4" stopOpacity={0.15} />
                <stop offset="100%" stopColor="#00E5C4" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="date" tick={{ fill:'#475569', fontSize:9 }}
              tickFormatter={d => d.slice(5)} interval="preserveStartEnd" />
            <YAxis domain={[75, 100]} tick={{ fill:'#475569', fontSize:9 }}
              tickFormatter={v => `${v}%`} />
            <Tooltip
              contentStyle={{ background:'#0F1626', border:'1px solid rgba(255,255,255,0.08)', borderRadius:8, fontSize:11 }}
              formatter={(v: number, n: string) => [`${v?.toFixed(2)}%`, n]}
            />
            <ReferenceLine y={syl} stroke="rgba(245,158,11,0.5)" strokeDasharray="5 3"
              label={{ value:'SYL 90%', fill:'#F59E0B', fontSize:9 }} />
            <ReferenceLine y={sbl} stroke="rgba(239,68,68,0.5)" strokeDasharray="5 3"
              label={{ value:'SBL 85%', fill:'#EF4444', fontSize:9 }} />
            <Area type="monotone" dataKey="p90" stroke="none" fill="url(#yBand)"
              fillOpacity={1} activeDot={false} legendType="none" />
            <Area type="monotone" dataKey="p10" stroke="none" fill="var(--void)"
              fillOpacity={1} activeDot={false} legendType="none" />
            <Area type="monotone" dataKey="p50" stroke="#00E5C4" strokeWidth={2}
              fill="none" dot={false} activeDot={{ r:4, fill:'var(--teal)' }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

// ─── Lot Score Card ───────────────────────────────────────────────────────────
function LotScoreCard({ rows }: { rows: LotSummary[] }) {
  const [selected, setSelected] = useState<string | null>(null)
  const yieldColor = (y?: number) => !y ? '' : y >= 95 ? 'cell-pass' : y >= 90 ? 'cell-warn' : 'cell-fail'

  return (
    <div className="panel" style={{ marginBottom:16 }}>
      <div className="panel-header">
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:2, height:14, borderRadius:2, background:'var(--violet)' }} />
          <span style={{ fontFamily:'Space Grotesk', fontWeight:600, fontSize:13 }}>Lot Score Card</span>
        </div>
        <span style={{ fontSize:10, color:'var(--text-muted)' }}>{rows.length} lots</span>
      </div>
      <div style={{ padding:'0 0 12px', overflowX:'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Lot ID</th><th>Product</th><th>Node</th><th>Wafers</th>
              <th className="text-right">Avg Yield</th><th className="text-right">1st Pass</th>
              <th className="text-right">Retest%</th><th className="text-right">UPH</th>
              <th>SYL</th><th>SBL</th><th>MRB</th><th>Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.lot_id}
                className={clsx(selected === r.lot_id && 'selected')}
                style={{ cursor:'pointer' }}
                onClick={() => setSelected(r.lot_id === selected ? null : r.lot_id)}
              >
                <td style={{ fontFamily:'JetBrains Mono', color:'var(--teal)', fontSize:11 }}>{r.lot_id}</td>
                <td style={{ fontSize:10 }}>{r.product_id}</td>
                <td><span className="badge badge-violet">{r.process_node}</span></td>
                <td style={{ textAlign:'center' }}>{r.wafer_count}</td>
                <td style={{ textAlign:'right' }}>
                  <span className={yieldColor(r.avg_yield)}>
                    {r.avg_yield?.toFixed(2)}%
                  </span>
                </td>
                <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:11 }}>
                  {r.avg_first_pass?.toFixed(2)}%
                </td>
                <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:11 }}>
                  {r.avg_retest_rate?.toFixed(1)}%
                </td>
                <td style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:11 }}>
                  {r.avg_uph?.toFixed(0)}
                </td>
                <td>{r.any_syl ? <span className="cell-warn">⚠ SYL</span> : <span style={{ color:'var(--text-muted)' }}>—</span>}</td>
                <td>{r.any_sbl ? <span className="cell-fail">✗ SBL</span> : <span style={{ color:'var(--text-muted)' }}>—</span>}</td>
                <td>{r.any_mrb ? <span className="badge badge-coral" style={{ fontSize:9 }}>MRB</span> : <span style={{ color:'var(--text-muted)' }}>—</span>}</td>
                <td style={{ fontSize:10, color:'var(--text-muted)', fontFamily:'JetBrains Mono' }}>{r.last_test_date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── Alarm Feed ───────────────────────────────────────────────────────────────
function AlarmFeed({ alarms }: { alarms: Alarm[] }) {
  const colors: Record<string, string> = {
    CRITICAL:'var(--coral)', MAJOR:'var(--amber)', MINOR:'var(--sky)'
  }
  const icons: Record<string, string> = { SPC:'⌇', FDC:'⚡', YIELD:'◆' }

  return (
    <div className="panel" style={{ height:'100%' }}>
      <div className="panel-header">
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:2, height:14, borderRadius:2, background:'var(--coral)' }} />
          <span style={{ fontFamily:'Space Grotesk', fontWeight:600, fontSize:13 }}>Active Alarms</span>
        </div>
        {alarms.length > 0 && (
          <span className="badge badge-coral animate-pulse-red">{alarms.length}</span>
        )}
      </div>
      <div className="panel-body" style={{ maxHeight:320, overflowY:'auto' }}>
        {alarms.length === 0 ? (
          <div style={{ textAlign:'center', padding:'40px 0', color:'var(--text-muted)', fontSize:12 }}>
            ✓ No active alarms
          </div>
        ) : alarms.map(a => (
          <div key={a.alarm_id} style={{
            padding:'10px 12px', marginBottom:6, borderRadius:8,
            background:`rgba(${a.severity==='CRITICAL'?'255,79,106':a.severity==='MAJOR'?'245,158,11':'56,189,248'},0.07)`,
            borderLeft:`3px solid ${colors[a.severity] || 'var(--text-muted)'}`,
          }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <span style={{ fontSize:14 }}>{icons[a.source] || '●'}</span>
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color: colors[a.severity] }}>{a.title}</div>
                  <div style={{ fontSize:10, color:'var(--text-muted)', marginTop:2 }}>{a.message}</div>
                </div>
              </div>
              <span className={`badge ${a.severity==='CRITICAL'?'badge-coral':a.severity==='MAJOR'?'badge-amber':'badge-sky'}`}>
                {a.severity}
              </span>
            </div>
            <div style={{ fontSize:9, color:'var(--text-muted)', marginTop:6, fontFamily:'JetBrains Mono',
              display:'flex', gap:12 }}>
              <span>{a.source}</span>
              {a.equipment_id && <span>{a.equipment_id}</span>}
              {a.lot_id && <span>{a.lot_id}</span>}
              <span>{a.timestamp ? new Date(a.timestamp).toLocaleTimeString() : ''}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Bin Pareto Mini ──────────────────────────────────────────────────────────
function BinParetoMini({ lotId }: { lotId: string }) {
  const { data } = useQuery({
    queryKey: ['bin-pareto-mini', lotId],
    queryFn: () => yieldApi.binPareto(lotId),
    enabled: !!lotId,
  })
  const rows = (data?.data?.data || []) as { bin_code: string; count: number; pct: number }[]
  const BIN_COLORS: Record<string, string> = {
    '1':'#10B981','8':'#38BDF8','14':'#8B5CF6','9':'#F59E0B','12':'#EF4444','6':'#84CC16',
  }

  return (
    <div className="panel" style={{ height:'100%' }}>
      <div className="panel-header">
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:2, height:14, borderRadius:2, background:'var(--sky)' }} />
          <span style={{ fontFamily:'Space Grotesk', fontWeight:600, fontSize:13 }}>Bin Pareto</span>
        </div>
        <span style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--teal)' }}>{lotId}</span>
      </div>
      <div className="panel-body">
        {rows.length === 0 ? (
          <div style={{ textAlign:'center', padding:'30px 0', color:'var(--text-muted)', fontSize:12 }}>Loading…</div>
        ) : (
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={rows} layout="vertical" margin={{ left:8, right:40, top:4, bottom:4 }}>
              <XAxis type="number" domain={[0, 100]} tick={{ fill:'#475569', fontSize:9 }}
                tickFormatter={v => `${v.toFixed(0)}%`} />
              <YAxis dataKey="bin_code" type="category" tick={{ fill:'#94A3B8', fontSize:10,
                fontFamily:'JetBrains Mono' }} width={32} />
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
              <Tooltip
                contentStyle={{ background:'#0F1626', border:'1px solid rgba(255,255,255,0.08)',
                  borderRadius:8, fontSize:11 }}
                formatter={(v: number) => [`${v.toFixed(2)}%`, 'Share']}
              />
              <Bar dataKey="pct" radius={[0,3,3,0]}
                label={{ position:'right', fill:'#64748B', fontSize:9, formatter:(v:number)=>`${v.toFixed(1)}%` }}>
                {rows.map((r, i) => <Cell key={i} fill={BIN_COLORS[r.bin_code] || '#64748B'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  )
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
export function YMSDashboard() {
  const [product, setProduct] = useState('PROD_N5_001')
  const [days, setDays] = useState(30)

  const kpiQ = useQuery({
    queryKey: ['yield-kpi', product, days],
    queryFn: () => yieldApi.kpi(days, product),
    refetchInterval: 60_000,
  })
  const trendQ = useQuery({
    queryKey: ['yield-trend', product, days],
    queryFn: () => yieldApi.trend(product, days),
  })
  const summaryQ = useQuery({
    queryKey: ['yield-summary', product, days],
    queryFn: () => yieldApi.summary(days, 1, product),
  })
  const alarmQ = useQuery({
    queryKey: ['alarms-yms'],
    queryFn: async () => { const r = await alarmApi.active(1); return r.data.data as Alarm[] },
    refetchInterval: 30_000,
  })

  const kpi: YieldKPI | null = kpiQ.data?.data?.data || null
  const trend: YieldTrendPoint[] = trendQ.data?.data?.data || []
  const lots: LotSummary[] = summaryQ.data?.data?.data || []
  const alarms: Alarm[] = alarmQ.data || []

  // Find most recent lot for bin pareto
  const firstLot = lots[0]?.lot_id || ''

  return (
    <div style={{ animation:'fadeIn .25s ease' }}>
      {/* Controls */}
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:14 }}>
        <div style={{ fontFamily:'Space Grotesk', fontSize:16, fontWeight:700, color:'var(--text-primary)' }}>
          Yield Management
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginLeft:'auto' }}>
          {['PROD_N5_001','PROD_N5_002','PROD_N3_001'].map(p => (
            <button key={p} onClick={() => setProduct(p)} style={{
              padding:'5px 12px', borderRadius:8, border:'1px solid',
              borderColor: product===p ? 'rgba(0,229,196,0.4)' : 'var(--border)',
              background: product===p ? 'rgba(0,229,196,0.1)' : 'transparent',
              color: product===p ? 'var(--teal)' : 'var(--text-muted)',
              fontSize:11, fontFamily:'JetBrains Mono', cursor:'pointer',
            }}>{p}</button>
          ))}
          <div style={{ width:1, height:20, background:'var(--border)' }} />
          {[7, 14, 30, 60].map(d => (
            <button key={d} onClick={() => setDays(d)} style={{
              padding:'5px 10px', borderRadius:8, border:'1px solid',
              borderColor: days===d ? 'rgba(139,92,246,0.4)' : 'var(--border)',
              background: days===d ? 'rgba(139,92,246,0.1)' : 'transparent',
              color: days===d ? 'var(--violet)' : 'var(--text-muted)',
              fontSize:11, fontFamily:'JetBrains Mono', cursor:'pointer',
            }}>{d}d</button>
          ))}
        </div>
      </div>

      {/* KPI Strip */}
      {kpi ? <KPIStrip kpi={kpi} /> : (
        <div style={{ height:90, background:'var(--card)', borderRadius:10, marginBottom:16,
          display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>
          Loading KPIs…
        </div>
      )}

      {/* Trend + Alarm + Bin Pareto */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 280px', gap:14, marginBottom:14, alignItems:'start' }}>
        <div style={{ gridColumn:'1' }}>
          {trend.length > 0 ? <YieldTrendChart data={trend} /> : (
            <div className="panel" style={{ height:260, display:'flex', alignItems:'center',
              justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>
              Loading trend…
            </div>
          )}
        </div>
        <AlarmFeed alarms={alarms} />
        <BinParetoMini lotId={firstLot} />
      </div>

      {/* Lot Score Card */}
      {lots.length > 0 ? <LotScoreCard rows={lots} /> : (
        <div className="panel" style={{ height:200, display:'flex', alignItems:'center',
          justifyContent:'center', color:'var(--text-muted)', fontSize:12 }}>
          Loading lot data…
        </div>
      )}
    </div>
  )
}
