import { NavLink, useLocation } from 'react-router-dom'
import { useUIStore } from '@/store/uiStore'
import { useFabStore } from '@/store/fabStore'
import { clsx } from 'clsx'

const NAV = [
  { path: '/',     icon: '◆', label: 'Yield',     abbr: 'YMS',  accent: '#00E5C4' },
  { path: '/wat',  icon: '〒', label: 'WAT',       abbr: 'WAT',  accent: '#8B5CF6' },
  { path: '/cp',   icon: '⬡', label: 'CP / Bin',  abbr: 'CP',   accent: '#38BDF8' },
  { path: '/spc',  icon: '⌇', label: 'SPC',       abbr: 'SPC',  accent: '#F59E0B' },
  { path: '/fdc',  icon: '⚡', label: 'FDC',       abbr: 'FDC',  accent: '#FF4F6A' },
]

export function Sidebar() {
  const { sidebarCollapsed, toggleSidebar } = useUIStore()
  const { criticalCount } = useFabStore()
  const location = useLocation()
  const W = sidebarCollapsed ? 56 : 200

  return (
    <div style={{
      width: W, minWidth: W, height:'100%', background:'var(--surface)',
      borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column',
      transition:'width .2s ease',
    }}>
      {/* Logo */}
      <div style={{
        padding: sidebarCollapsed ? '18px 0' : '18px 16px',
        borderBottom:'1px solid var(--border)', display:'flex',
        alignItems:'center', justifyContent: sidebarCollapsed ? 'center' : 'space-between',
      }}>
        {!sidebarCollapsed && (
          <div>
            <div style={{ fontFamily:'Space Grotesk', fontWeight:700, fontSize:14, color:'var(--teal)', letterSpacing:'0.04em' }}>
              SEMFAB·IQ
            </div>
            <div style={{ fontSize:9, color:'var(--text-muted)', marginTop:2, fontFamily:'JetBrains Mono' }}>
              FAB-12 · N5
            </div>
          </div>
        )}
        <button
          onClick={toggleSidebar}
          style={{ background:'none', border:'none', color:'var(--text-muted)',
            cursor:'pointer', fontSize:14, padding:4, borderRadius:6,
            display:'flex', alignItems:'center' }}
          title={sidebarCollapsed ? 'Expand' : 'Collapse'}
        >
          {sidebarCollapsed ? '›' : '‹'}
        </button>
      </div>

      {/* Navigation */}
      <nav style={{ flex:1, padding:'8px 0' }}>
        {NAV.map(n => {
          const active = location.pathname === n.path ||
            (n.path !== '/' && location.pathname.startsWith(n.path))
          return (
            <NavLink
              key={n.path} to={n.path}
              style={{
                display:'flex', alignItems:'center', gap:10,
                padding: sidebarCollapsed ? '10px 0' : '10px 14px',
                justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
                textDecoration:'none', transition:'all .15s',
                margin:'1px 6px', borderRadius:8,
                background: active ? `${n.accent}14` : 'transparent',
                borderLeft: active ? `2px solid ${n.accent}` : '2px solid transparent',
              }}
            >
              <span style={{ fontSize:16, width:20, textAlign:'center', color: active ? n.accent : 'var(--text-muted)' }}>
                {n.icon}
              </span>
              {!sidebarCollapsed && (
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color: active ? n.accent : 'var(--text-secondary)', lineHeight:1 }}>
                    {n.label}
                  </div>
                  <div style={{ fontSize:9, color:'var(--text-muted)', fontFamily:'JetBrains Mono', marginTop:1 }}>
                    {n.abbr}
                  </div>
                </div>
              )}
            </NavLink>
          )
        })}
      </nav>

      {/* Alarm badge */}
      {criticalCount > 0 && (
        <div style={{
          margin:'0 8px 12px', padding:'8px 10px',
          background:'rgba(255,79,106,0.1)', border:'1px solid rgba(255,79,106,0.3)',
          borderRadius:8, textAlign:'center',
        }}>
          <div style={{ fontSize:18, fontWeight:700, color:'#FF4F6A', fontFamily:'JetBrains Mono' }}>
            {criticalCount}
          </div>
          {!sidebarCollapsed && (
            <div style={{ fontSize:9, color:'rgba(255,79,106,0.7)', marginTop:2 }}>CRITICAL ALARMS</div>
          )}
        </div>
      )}

      {/* Footer */}
      <div style={{
        padding: sidebarCollapsed ? '10px 0' : '10px 14px',
        borderTop:'1px solid var(--border)',
        fontSize:9, color:'var(--text-muted)', fontFamily:'JetBrains Mono',
        textAlign: sidebarCollapsed ? 'center' : 'left',
      }}>
        {sidebarCollapsed ? 'v1' : 'SEMFAB·IQ v1.0.0'}
      </div>
    </div>
  )
}
