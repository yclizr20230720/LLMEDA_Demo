import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { useFabStore } from '@/store/fabStore'
import { useQuery } from '@tanstack/react-query'
import { alarmApi } from '@/api/endpoints'

function Clock() {
  const [time, setTime] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  return (
    <span style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--text-muted)' }}>
      {time.toLocaleTimeString('en-US', { hour12: false })} &nbsp;|&nbsp;
      {time.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
    </span>
  )
}

export function TopBar() {
  const { user, logout }          = useAuthStore()
  const { activeAlarms, setAlarms, criticalCount } = useFabStore()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  // Poll alarms every 30s
  useQuery({
    queryKey: ['active-alarms'],
    queryFn: async () => {
      const r = await alarmApi.active(1)
      setAlarms(r.data.data || [])
      return r.data.data
    },
    refetchInterval: 30_000,
    retry: false,
  })

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <div style={{
      height:48, background:'var(--surface)', borderBottom:'1px solid var(--border)',
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'0 20px', flexShrink:0,
    }}>
      {/* Left: FAB status */}
      <div style={{ display:'flex', alignItems:'center', gap:16 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <div style={{ width:7, height:7, borderRadius:'50%', background:'#10B981',
            boxShadow:'0 0 6px #10B981' }} />
          <span style={{ fontSize:10, color:'var(--text-muted)', fontFamily:'JetBrains Mono' }}>
            FAB-12 ONLINE
          </span>
        </div>
        <Clock />
      </div>

      {/* Right: alarms + user */}
      <div style={{ display:'flex', alignItems:'center', gap:12 }}>
        {/* Alarm bell */}
        {criticalCount > 0 && (
          <div style={{
            display:'flex', alignItems:'center', gap:6,
            padding:'4px 10px', borderRadius:20,
            background:'rgba(255,79,106,0.12)', border:'1px solid rgba(255,79,106,0.25)',
          }}
            className="animate-pulse-red"
          >
            <span style={{ fontSize:12 }}>🔴</span>
            <span style={{ fontSize:11, color:'#FF4F6A', fontFamily:'JetBrains Mono', fontWeight:700 }}>
              {criticalCount} CRITICAL
            </span>
          </div>
        )}

        {/* User menu */}
        <div style={{ position:'relative' }}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              display:'flex', alignItems:'center', gap:8,
              background:'rgba(255,255,255,0.04)', border:'1px solid var(--border)',
              borderRadius:8, padding:'6px 12px', cursor:'pointer', color:'var(--text-secondary)',
            }}
          >
            <div style={{
              width:22, height:22, borderRadius:'50%',
              background:'linear-gradient(135deg,var(--teal),var(--violet))',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:10, fontWeight:700, color:'#000',
            }}>
              {user?.full_name?.charAt(0) || user?.username?.charAt(0) || '?'}
            </div>
            <span style={{ fontSize:11, fontWeight:500 }}>
              {user?.full_name || user?.username}
            </span>
            <span style={{ fontSize:10, color:'var(--text-muted)' }}>▾</span>
          </button>

          {menuOpen && (
            <div style={{
              position:'absolute', right:0, top:'calc(100% + 6px)', zIndex:100,
              background:'var(--card)', border:'1px solid var(--border)',
              borderRadius:10, padding:'6px', minWidth:160,
              boxShadow:'0 16px 40px rgba(0,0,0,0.4)',
            }}>
              <div style={{ padding:'8px 12px', borderBottom:'1px solid var(--border)', marginBottom:4 }}>
                <div style={{ fontSize:11, color:'var(--text-primary)', fontWeight:600 }}>
                  {user?.full_name}
                </div>
                <div style={{ fontSize:10, color:'var(--text-muted)', fontFamily:'JetBrains Mono', marginTop:2 }}>
                  {user?.role}
                </div>
              </div>
              <button
                onClick={handleLogout}
                style={{
                  width:'100%', padding:'7px 12px', textAlign:'left',
                  background:'none', border:'none', cursor:'pointer',
                  color:'#FF4F6A', fontSize:12, borderRadius:6,
                  display:'flex', alignItems:'center', gap:8,
                }}
              >
                ⏻ Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
