import axios, { AxiosInstance, AxiosRequestConfig, InternalAxiosRequestConfig } from 'axios'

const BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000'

const client: AxiosInstance = axios.create({ baseURL: BASE, timeout: 30_000 })

// Attach JWT from localStorage on every request
client.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers!.Authorization = `Bearer ${token}`
  return config
})

// Auto-refresh on 401
let _refreshing = false
let _queue: Array<(t: string) => void> = []

client.interceptors.response.use(
  (res) => res,
  async (err) => {
    const orig = err.config as AxiosRequestConfig & { _retry?: boolean }
    if (err?.response?.status !== 401 || orig._retry) {
      return Promise.reject(err)
    }
    if (_refreshing) {
      return new Promise((res) => {
        _queue.push((token: string) => {
          orig.headers = { ...orig.headers, Authorization: `Bearer ${token}` }
          res(client(orig))
        })
      })
    }
    orig._retry = true
    _refreshing = true
    try {
      const refresh = localStorage.getItem('refresh_token')
      if (!refresh) throw new Error('No refresh token')
      const { data } = await axios.post(`${BASE}/api/v1/auth/refresh`, {}, {
        headers: { Authorization: `Bearer ${refresh}` },
      })
      const newToken = data.data.access_token
      localStorage.setItem('access_token', newToken)
      _queue.forEach((cb) => cb(newToken))
      _queue = []
      orig.headers = { ...orig.headers, Authorization: `Bearer ${newToken}` }
      return client(orig)
    } catch {
      localStorage.removeItem('access_token')
      localStorage.removeItem('refresh_token')
      window.location.href = '/login'
      return Promise.reject(err)
    } finally {
      _refreshing = false
    }
  }
)

export default client
