import client from './client'

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  login:  (u: string, p: string) => client.post('/api/v1/auth/login', { username: u, password: p }),
  me:     () => client.get('/api/v1/auth/me'),
  logout: () => client.post('/api/v1/auth/logout'),
  changePassword: (old_p: string, new_p: string) =>
    client.post('/api/v1/auth/change-password', { old_password: old_p, new_password: new_p }),
}

// ── Yield ─────────────────────────────────────────────────────────────────────
export const yieldApi = {
  kpi:         (days = 1, product_id?: string) => client.get('/api/v1/yield/kpi', { params: { days, product_id } }),
  trend:       (product_id?: string, days = 30) => client.get('/api/v1/yield/trend', { params: { product_id, days } }),
  summary:     (days = 14, page = 1, product_id?: string) =>
    client.get('/api/v1/yield/summary', { params: { days, page, product_id, per_page: 50 } }),
  waferGallery:(lot_id: string) => client.get('/api/v1/yield/wafer-gallery', { params: { lot_id } }),
  binPareto:   (lot_id: string) => client.get('/api/v1/yield/bin-pareto', { params: { lot_id } }),
  excursions:  (days = 7, severity?: string) => client.get('/api/v1/yield/excursions', { params: { days, severity } }),
  lotDetail:   (lot_id: string) => client.get(`/api/v1/yield/lot/${lot_id}`),
  products:    () => client.get('/api/v1/yield/products'),
}

// ── WAT ───────────────────────────────────────────────────────────────────────
export const watApi = {
  parameters:       () => client.get('/api/v1/wat/parameters'),
  distribution:     (parameter_id: string, lot_id?: string, days = 30) =>
    client.get('/api/v1/wat/distribution', { params: { parameter_id, lot_id, days } }),
  trend:            (parameter_id: string, equipment_id?: string, days = 30) =>
    client.get('/api/v1/wat/trend', { params: { parameter_id, equipment_id, days } }),
  correlationMatrix:(product_id?: string, days = 30) =>
    client.get('/api/v1/wat/correlation-matrix', { params: { product_id, days } }),
  correlationScatter:(param_x: string, param_y: string, days = 30) =>
    client.get('/api/v1/wat/correlation-scatter', { params: { param_x, param_y, days } }),
  anova:            (parameter_id: string, factor = 'equipment_id', days = 30) =>
    client.get('/api/v1/wat/anova', { params: { parameter_id, factor, days } }),
  siteMap:          (parameter_id: string, lot_id: string, wafer_id?: string) =>
    client.get('/api/v1/wat/site-map', { params: { parameter_id, lot_id, wafer_id } }),
  equipmentHealth:  (days = 30) => client.get('/api/v1/wat/equipment-health', { params: { days } }),
}

// ── CP ────────────────────────────────────────────────────────────────────────
export const cpApi = {
  binMap:       (lot_id: string, wafer_id: string) =>
    client.get('/api/v1/cp/bin-map', { params: { lot_id, wafer_id } }),
  waferSummary: (lot_id: string) => client.get('/api/v1/cp/wafer-summary', { params: { lot_id } }),
  mrbReview:    (days = 7, lot_id?: string) => client.get('/api/v1/cp/mrb-review', { params: { days, lot_id } }),
  siteYield:    (lot_id: string, wafer_id?: string) =>
    client.get('/api/v1/cp/site-yield', { params: { lot_id, wafer_id } }),
  patternGallery:(days = 30) => client.get('/api/v1/cp/pattern-gallery', { params: { days } }),
  touchdownSummary:(lot_id: string, wafer_id?: string) =>
    client.get('/api/v1/cp/touchdown-summary', { params: { lot_id, wafer_id } }),
  lotCompare:   (lot_ids: string[]) =>
    client.get('/api/v1/cp/lot-compare', { params: { lot_ids: lot_ids.join(',') } }),
}

// ── SPC ───────────────────────────────────────────────────────────────────────
export const spcApi = {
  configs:    (equipment_id?: string) => client.get('/api/v1/spc/configs', { params: { equipment_id } }),
  chart:      (config_id: string, days = 30) => client.get('/api/v1/spc/chart', { params: { config_id, days } }),
  violations: (config_id?: string, days = 14, ack?: string) =>
    client.get('/api/v1/spc/violations', { params: { config_id, days, ack } }),
  capability: (config_id: string, days = 30) => client.get('/api/v1/spc/capability', { params: { config_id, days } }),
  checkRules: (values: number[], ucl: number, cl: number, lcl: number, sigma?: number) =>
    client.post('/api/v1/spc/check-rules', { values, ucl, cl, lcl, sigma }),
  acknowledge:(violation_sk: number, note = '') =>
    client.post(`/api/v1/spc/violations/${violation_sk}/acknowledge`, { resolution_note: note }),
  dashboardSummary:(days = 7) => client.get('/api/v1/spc/dashboard-summary', { params: { days } }),
}

// ── FDC ───────────────────────────────────────────────────────────────────────
export const fdcApi = {
  traceRuns:          (p?: { equipment_id?: string; is_anomaly?: boolean; days?: number; page?: number }) =>
    client.get('/api/v1/fdc/trace-runs', { params: p }),
  anomalySummary:     (days = 30) => client.get('/api/v1/fdc/anomaly-summary', { params: { days } }),
  pmEvents:           (equipment_id?: string, days = 90) =>
    client.get('/api/v1/fdc/pm-events', { params: { equipment_id, days } }),
  sensors:            (equipment_id?: string) => client.get('/api/v1/fdc/sensors', { params: { equipment_id } }),
  indicators:         (equipment_id?: string, recipe_id?: string) =>
    client.get('/api/v1/fdc/indicators', { params: { equipment_id, recipe_id } }),
  alarmDrillDown:     (equipment_id: string, days = 7) =>
    client.get('/api/v1/fdc/alarm-drill-down', { params: { equipment_id, days } }),
  trend:              (equipment_id?: string, days = 30) =>
    client.get('/api/v1/fdc/trend', { params: { equipment_id, days } }),
}

// ── Equipment ─────────────────────────────────────────────────────────────────
export const equipmentApi = {
  list:       (type?: string) => client.get('/api/v1/equipment/', { params: { type } }),
  get:        (id: string)    => client.get(`/api/v1/equipment/${id}`),
  pmSchedule: () => client.get('/api/v1/equipment/pm-schedule'),
  chambers:   (id: string)   => client.get(`/api/v1/equipment/${id}/chambers`),
}

// ── Alarms ────────────────────────────────────────────────────────────────────
export const alarmApi = {
  active:  (days = 1) => client.get('/api/v1/alarms/active', { params: { days } }),
  history: (days = 7) => client.get('/api/v1/alarms/history', { params: { days } }),
  acknowledge: (alarm_id: string, note = '') =>
    client.post(`/api/v1/alarms/${alarm_id}/acknowledge`, { note }),
}

// ── Defect ────────────────────────────────────────────────────────────────────
export const defectApi = {
  summary:   (lot_id?: string, days = 14) => client.get('/api/v1/defect/summary', { params: { lot_id, days } }),
  pareto:    (lot_id?: string, days = 14) => client.get('/api/v1/defect/pareto', { params: { lot_id, days } }),
  waferMap:  (lot_id: string, wafer_id: string) => client.get('/api/v1/defect/wafer-map', { params: { lot_id, wafer_id } }),
  patterns:  (days = 30) => client.get('/api/v1/defect/pattern-analysis', { params: { days } }),
}
