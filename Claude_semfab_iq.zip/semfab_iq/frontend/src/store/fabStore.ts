import { create } from 'zustand'
import type { Alarm } from '@/types'

interface FabState {
  activeAlarms: Alarm[]
  criticalCount: number
  equipmentStatusMap: Record<string, string>
  setAlarms: (alarms: Alarm[]) => void
  addAlarm: (alarm: Alarm) => void
  setEquipmentStatus: (id: string, status: string) => void
  clearAlarm: (alarm_id: string) => void
}

export const useFabStore = create<FabState>((set) => ({
  activeAlarms: [], criticalCount: 0, equipmentStatusMap: {},
  setAlarms: (alarms) => set({
    activeAlarms: alarms,
    criticalCount: alarms.filter(a => a.severity === 'CRITICAL').length,
  }),
  addAlarm: (alarm) => set((s) => {
    const alarms = [alarm, ...s.activeAlarms].slice(0, 100)
    return { activeAlarms: alarms, criticalCount: alarms.filter(a => a.severity === 'CRITICAL').length }
  }),
  setEquipmentStatus: (id, status) => set((s) => ({
    equipmentStatusMap: { ...s.equipmentStatusMap, [id]: status }
  })),
  clearAlarm: (alarm_id) => set((s) => {
    const alarms = s.activeAlarms.filter(a => a.alarm_id !== alarm_id)
    return { activeAlarms: alarms, criticalCount: alarms.filter(a => a.severity === 'CRITICAL').length }
  }),
}))
