import { create } from 'zustand'

interface UIState {
  sidebarCollapsed: boolean
  activeModule: string
  commandPaletteOpen: boolean
  setSidebarCollapsed: (v: boolean) => void
  toggleSidebar: () => void
  setActiveModule: (m: string) => void
  setCommandPalette: (v: boolean) => void
}

export const useUIStore = create<UIState>((set) => ({
  sidebarCollapsed: false, activeModule: 'yms', commandPaletteOpen: false,
  setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setActiveModule: (m) => set({ activeModule: m }),
  setCommandPalette: (v) => set({ commandPaletteOpen: v }),
}))
