/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void:    '#060A12', surface: '#0B1120', elevated: '#111827',
        card:    '#141E2E', border:  'rgba(255,255,255,0.07)',
        teal:    '#00E5C4', violet:  '#8B5CF6',
        amber:   '#F59E0B', coral:   '#FF4F6A',
        sky:     '#38BDF8', lime:    '#84CC16',
        pass:    '#10B981', warn:    '#F59E0B', fail: '#EF4444',
      },
      fontFamily: {
        display: ['"Space Grotesk"','sans-serif'],
        body:    ['Inter','sans-serif'],
        mono:    ['"JetBrains Mono"','monospace'],
      },
    }
  },
  plugins: [],
}
