"""Audit Logging Middleware"""
import logging
import time
from flask import g, request

log = logging.getLogger("semfab.audit")


def audit_middleware(app):
    @app.before_request
    def before():
        g.start_time = time.time()

    @app.after_request
    def after(response):
        if request.path.startswith("/api/"):
            duration_ms = round((time.time() - getattr(g, "start_time", time.time())) * 1000, 2)
            log.info(
                "%s %s %d %.2fms rid=%s",
                request.method, request.path,
                response.status_code, duration_ms,
                getattr(g, "request_id", "-"),
            )
        return response
