"""Unified JSON Response Envelope"""
from flask import jsonify
import uuid
from datetime import datetime


def success(data=None, meta=None, status_code=200):
    return jsonify({
        "status": "success",
        "data": data,
        "meta": meta or {},
        "errors": [],
        "trace_id": str(uuid.uuid4()),
        "timestamp": datetime.utcnow().isoformat(),
    }), status_code


def error(code: str, message: str, details=None, status_code=400):
    return jsonify({
        "status": "error",
        "data": None,
        "meta": {},
        "errors": [{"code": code, "message": message, "details": details}],
        "trace_id": str(uuid.uuid4()),
        "timestamp": datetime.utcnow().isoformat(),
    }), status_code


def paginated(data, total: int, page: int, per_page: int, extra_meta: dict = None):
    meta = {
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": max(1, (total + per_page - 1) // per_page),
        "has_next": page < max(1, (total + per_page - 1) // per_page),
        "has_prev": page > 1,
    }
    if extra_meta:
        meta.update(extra_meta)
    return success(data=data, meta=meta)
