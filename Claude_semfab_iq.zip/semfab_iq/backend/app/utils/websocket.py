"""WebSocket Event Handlers"""
from flask_socketio import emit, join_room, leave_room
import logging

log = logging.getLogger("semfab.ws")


def register_socket_events(socketio):
    @socketio.on("connect")
    def on_connect(auth):
        log.info("WS client connected")
        emit("connected", {"status": "ok", "fab": "FAB-12", "node": "N5"})

    @socketio.on("subscribe")
    def on_subscribe(data):
        room = data.get("room", "fab-global")
        join_room(room)
        emit("subscribed", {"room": room, "status": "ok"})

    @socketio.on("unsubscribe")
    def on_unsubscribe(data):
        room = data.get("room", "fab-global")
        leave_room(room)

    @socketio.on("disconnect")
    def on_disconnect():
        log.info("WS client disconnected")

    @socketio.on("ping")
    def on_ping():
        emit("pong", {"ts": __import__("time").time()})
