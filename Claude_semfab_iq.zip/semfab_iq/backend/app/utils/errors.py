"""Global Error Handlers"""
from app.utils.response import error


def register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(e):
        return error("BAD_REQUEST", str(e.description), status_code=400)

    @app.errorhandler(401)
    def unauthorized(e):
        return error("UNAUTHORIZED", "Authentication required", status_code=401)

    @app.errorhandler(403)
    def forbidden(e):
        return error("FORBIDDEN", "Insufficient permissions", status_code=403)

    @app.errorhandler(404)
    def not_found(e):
        return error("NOT_FOUND", "Resource not found", status_code=404)

    @app.errorhandler(405)
    def method_not_allowed(e):
        return error("METHOD_NOT_ALLOWED", "Method not allowed", status_code=405)

    @app.errorhandler(422)
    def unprocessable(e):
        return error("VALIDATION_ERROR", str(e), status_code=422)

    @app.errorhandler(429)
    def rate_limited(e):
        return error("RATE_LIMITED", "Too many requests. Please slow down.", status_code=429)

    @app.errorhandler(500)
    def internal_error(e):
        app.logger.exception("Internal server error")
        return error("INTERNAL_ERROR", "An unexpected error occurred", status_code=500)
