"""
SEMFAB·IQ — Complete Demo Data Generator
Seeds: users, equipment, chambers, lots, wafers, WAT results,
       WAT lot summaries, CP wafer summaries, SPC configs + measurements,
       FDC sensors, indicators, trace runs, PM events, defects
"""
import json
import random
import string
from datetime import datetime, timedelta, date
import numpy as np
from scipy import stats as scipy_stats

from app import db
from app.models.user import User
from app.models.lot import Lot, Wafer
from app.models.equipment import Equipment, Chamber
from app.models.wat import WATParameter, WATSpec, WATResult, WATLotSummary
from app.models.cp import CPDieResult, CPWaferSummary
from app.models.spc import SPCConfig, SPCMeasurement, SPCViolation, SPCCapability
from app.models.fdc import FDCSensor, FDCIndicator, FDCTraceRun, FDCPMEvent
from app.models.defect import DefectResult, DefectWaferSummary
from app.services.spc_engine import check_all_rules, compute_capability, one_way_anova

RNG = np.random.default_rng(42)

# ── Master Data Definitions ──────────────────────────────────────────────────

PRODUCTS = [
    {"id": "PROD_N5_001", "node": "N5", "tech": "N5P", "family": "LOGIC"},
    {"id": "PROD_N5_002", "node": "N5", "tech": "N5P", "family": "SRAM"},
    {"id": "PROD_N3_001", "node": "N3", "tech": "N3E", "family": "LOGIC"},
]

EQUIPMENT_DEFS = [
    {"id":"CVD-01","name":"AMAT Centura CVD #01","type":"CVD","sub":"PECVD","vendor":"AMAT","model":"Centura","chambers":4,"area":"CVD_BAY"},
    {"id":"CVD-02","name":"AMAT Centura CVD #02","type":"CVD","sub":"PECVD","vendor":"AMAT","model":"Centura","chambers":4,"area":"CVD_BAY"},
    {"id":"CVD-03","name":"AMAT Producer CVD #03","type":"CVD","sub":"ALD",  "vendor":"AMAT","model":"Producer","chambers":2,"area":"CVD_BAY"},
    {"id":"ETCH-01","name":"LAM TCP Etch #01","type":"ETCH","sub":"DRY_ETCH","vendor":"LAM","model":"TCP","chambers":2,"area":"ETCH_BAY"},
    {"id":"ETCH-02","name":"LAM TCP Etch #02","type":"ETCH","sub":"DRY_ETCH","vendor":"LAM","model":"TCP","chambers":2,"area":"ETCH_BAY"},
    {"id":"CMP-01","name":"AMAT Reflexion CMP #01","type":"CMP","sub":"STD_CMP","vendor":"AMAT","model":"Reflexion","chambers":1,"area":"CMP_BAY"},
    {"id":"CMP-02","name":"AMAT Reflexion CMP #02","type":"CMP","sub":"STD_CMP","vendor":"AMAT","model":"Reflexion","chambers":1,"area":"CMP_BAY"},
    {"id":"LITHO-01","name":"ASML NXT EUV #01","type":"LITHO","sub":"EUV","vendor":"ASML","model":"NXT3400","chambers":1,"area":"LITHO_BAY"},
    {"id":"DIFF-01","name":"TEL Alfa Furnace #01","type":"DIFF","sub":"FURNACE","vendor":"TEL","model":"Alfa","chambers":4,"area":"DIFF_BAY"},
    {"id":"WAT-01","name":"Semitronix WAT #01","type":"WAT","sub":"FAST_WAT","vendor":"Semitronix","model":"XA-5000","chambers":1,"area":"TEST_BAY"},
    {"id":"WAT-02","name":"Semitronix WAT #02","type":"WAT","sub":"FAST_WAT","vendor":"Semitronix","model":"XA-5000","chambers":1,"area":"TEST_BAY"},
    {"id":"CP-01","name":"TEL P-12 Prober #01","type":"CP","sub":"PROBER","vendor":"TEL","model":"P-12","chambers":1,"area":"TEST_BAY"},
]

WAT_PARAM_DEFS = [
    {"id":"IDSAT_N","name":"NMOS Saturation Current","group":"IDSAT","device":"NMOS","mos":"N","unit":"mA","nominal":1.20,"sigma_pct":0.025,"layer":"GO","module":"GATE_OX"},
    {"id":"IDSAT_P","name":"PMOS Saturation Current","group":"IDSAT","device":"PMOS","mos":"P","unit":"mA","nominal":0.65,"sigma_pct":0.030,"layer":"GO","module":"GATE_OX"},
    {"id":"VTN",    "name":"NMOS Threshold Voltage", "group":"VT",   "device":"NMOS","mos":"N","unit":"V", "nominal":0.42,"sigma_pct":0.020,"layer":"GO","module":"GATE_OX"},
    {"id":"VTP",    "name":"PMOS Threshold Voltage", "group":"VT",   "device":"PMOS","mos":"P","unit":"V", "nominal":-0.40,"sigma_pct":0.020,"layer":"GO","module":"GATE_OX"},
    {"id":"IOFF_N", "name":"NMOS Off-State Leakage", "group":"LEAKAGE","device":"NMOS","mos":"N","unit":"pA","nominal":0.08,"sigma_pct":0.150,"layer":"GO","module":"GATE_OX"},
    {"id":"BVJ",    "name":"Junction Breakdown Voltage","group":"BREAKDOWN","device":"DIODE","mos":"N","unit":"V","nominal":8.5,"sigma_pct":0.020,"layer":"AA","module":"NBL"},
    {"id":"REXT",   "name":"External Resistance","group":"RESISTANCE","device":"NMOS","mos":"N","unit":"Ohm","nominal":180.0,"sigma_pct":0.040,"layer":"SA","module":"SALICIDE"},
    {"id":"GATOX_THK","name":"Gate Oxide Thickness","group":"CAPACITANCE","device":"MOSFET","mos":"N","unit":"Angstrom","nominal":28.5,"sigma_pct":0.015,"layer":"GO","module":"GATE_OX"},
    {"id":"NRES",   "name":"N+ Poly Resistance","group":"RESISTANCE","device":"RESISTOR","mos":"N","unit":"Ohm/sq","nominal":215.0,"sigma_pct":0.035,"layer":"PO","module":"POLY"},
    {"id":"CFMOM14","name":"MOM Cap 14T","group":"CAPACITANCE","device":"CAPACITOR","mos":"N","unit":"fF","nominal":12.4,"sigma_pct":0.018,"layer":"M1","module":"M1"},
]

DEFECT_CLASSES = [
    "Particle","Scratch","Crystal","Bridge","Pit","Film","Cu_Crater",
    "Oxide_Chain","Killer_Scratch","Micro_Scratch","Missing_Hole","Film_Bump",
    "Flake","Flake_Crater","Embedded_Small_Particles","Embedded_Big_Particles",
]


# ── Helper Functions ─────────────────────────────────────────────────────────

def _randlot() -> str:
    return "M" + "".join(RNG.integers(0, 10, size=6).astype(str).tolist())

def _randrun() -> str:
    return "RUN_" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))

def _health_tier(score: float) -> str:
    if score >= 90: return "HEALTHY"
    if score >= 75: return "WATCH"
    if score >= 60: return "DEGRADED"
    return "CRITICAL"


# ── User Seed ────────────────────────────────────────────────────────────────

def seed_users():
    if User.query.count() > 0:
        return
    users = [
        {"username":"admin",       "email":"admin@semfab.com",   "role":"SYSTEM_ADMIN",
         "full_name":"System Admin","dept":"IT",        "pw":"Admin@12345"},
        {"username":"pe_engineer", "email":"pe@semfab.com",      "role":"PROCESS_ENGINEER",
         "full_name":"Li Wei",      "dept":"PROCESS",   "pw":"Engineer@123"},
        {"username":"ee_engineer", "email":"ee@semfab.com",      "role":"EQUIPMENT_ENGINEER",
         "full_name":"Chen Ming",   "dept":"EQUIPMENT", "pw":"Engineer@123"},
        {"username":"pi_engineer", "email":"pi@semfab.com",      "role":"PROCESS_INTEGRATION_ENGINEER",
         "full_name":"Wang Fang",   "dept":"PI",        "pw":"Engineer@123"},
        {"username":"manager",     "email":"mgr@semfab.com",     "role":"MANAGER",
         "full_name":"Director Zhang","dept":"MANAGEMENT","pw":"Manager@123"},
        {"username":"fab_op",      "email":"fabop@semfab.com",   "role":"FAB_OPERATOR",
         "full_name":"Lin Jie",     "dept":"PRODUCTION","pw":"Operator@123"},
    ]
    for u in users:
        user = User(
            username=u["username"], email=u["email"], role=u["role"],
            full_name=u["full_name"], department=u["dept"], fab_id="FAB-12", is_active=True,
        )
        user.set_password(u["pw"])
        db.session.add(user)
    db.session.commit()
    print(f"  [seed] {len(users)} users created")


# ── Equipment & Chambers ─────────────────────────────────────────────────────

def seed_equipment():
    if Equipment.query.count() > 0:
        return
    for eq in EQUIPMENT_DEFS:
        # Deterministic health score based on equipment type
        base_health = {"CVD": 85, "ETCH": 88, "CMP": 72, "LITHO": 96,
                       "DIFF": 91, "WAT": 98, "CP": 97}[eq["type"]]
        noise = float(RNG.normal(0, 5))
        health = float(np.clip(base_health + noise, 55, 99))

        z  = round(float(RNG.uniform(0.20, 0.38)), 3)
        g  = round(float(RNG.uniform(0.15, 0.30)), 3)
        cv = round(float(RNG.uniform(0.12, 0.25)), 3)
        v  = round(float(RNG.uniform(0.08, 0.18)), 3)
        # normalize so that 35*z + 30*g + 20*cv + 15*v ≈ health
        raw_score = 35 * z + 30 * g + 20 * cv + 15 * v
        scale = health / max(raw_score, 1)
        z *= scale; g *= scale; cv *= scale; v *= scale

        days_since_pm = int(RNG.integers(5, 90))
        last_pm = date.today() - timedelta(days=days_since_pm)
        next_pm = last_pm + timedelta(days=90)

        equip = Equipment(
            equipment_id=eq["id"],
            equipment_name=eq["name"],
            equipment_type=eq["type"],
            equipment_subtype=eq["sub"],
            oem_vendor=eq["vendor"],
            oem_model=eq["model"],
            fab_id="FAB-12",
            bay_id=f"BAY-{eq['area']}",
            area_id=eq["area"],
            chamber_count=eq["chambers"],
            is_multi_chamber=(eq["chambers"] > 1),
            wafer_size_mm=300,
            equipment_status="PRODUCTION",
            is_golden_tool=(eq["id"] in ["CVD-01","ETCH-01","WAT-01"]),
            health_score=round(health, 2),
            health_tier=_health_tier(health),
            z_score_component=round(z, 3),
            gof_component=round(g, 3),
            cv_stability_component=round(cv, 3),
            volume_component=round(v, 3),
            last_pm_date=last_pm,
            next_pm_date=next_pm,
            pm_interval_days=90,
            run_since_pm=int(days_since_pm * 50),
            is_current=True,
        )
        db.session.add(equip)

        for ch_idx in range(1, eq["chambers"] + 1):
            ch_health = float(np.clip(health + float(RNG.normal(0, 4)), 50, 99))
            ch = Chamber(
                equipment_id=eq["id"],
                chamber_id=f"PM{ch_idx}",
                chamber_name=f"Process Module {ch_idx}",
                chamber_type=eq["sub"],
                chamber_index=ch_idx,
                chamber_status="PRODUCTION",
                health_score=round(ch_health, 2),
                last_pm_date=last_pm,
                run_since_pm=int(days_since_pm * 50 // eq["chambers"]),
                is_reference_chamber=(ch_idx == 1),
            )
            db.session.add(ch)

    db.session.commit()
    print(f"  [seed] {len(EQUIPMENT_DEFS)} equipment + chambers created")


# ── WAT Parameters & Specs ───────────────────────────────────────────────────

def seed_wat_params():
    if WATParameter.query.count() > 0:
        return
    for p in WAT_PARAM_DEFS:
        param = WATParameter(
            parameter_id=p["id"],
            parameter_name=p["name"],
            parameter_group=p["group"],
            device_type=p["device"],
            mos_type=p.get("mos"),
            parameter_type="DC",
            unit=p["unit"],
            display_unit=p["unit"],
            nominal_value=p["nominal"],
            is_spc_monitored=True,
            spc_chart_type="IMR",
            criticality_rank=WAT_PARAM_DEFS.index(p) + 1,
            layer_name=p["layer"],
            process_module=p["module"],
        )
        db.session.add(param)

        for prod in PRODUCTS:
            nom = p["nominal"]
            usl = nom * (1 + 0.15) if nom > 0 else nom * (1 - 0.15)
            lsl = nom * (1 - 0.15) if nom > 0 else nom * (1 + 0.15)
            sig = abs(nom) * p["sigma_pct"]
            spec = WATSpec(
                product_id=prod["id"], technology_id=prod["tech"],
                parameter_id=p["id"], vcc=1.1, temp_c=25.0,
                usl=round(usl, 6), lsl=round(lsl, 6), target=round(nom, 6),
                spc_ucl=round(nom + 3 * sig, 6),
                spc_lcl=round(nom - 3 * sig, 6),
                spc_cl=round(nom, 6),
                spc_sigma=round(sig, 8),
                limit_source="ENGINEERING", limit_version="A",
                effective_date=date.today() - timedelta(days=180),
            )
            db.session.add(spec)

    db.session.commit()
    print(f"  [seed] {len(WAT_PARAM_DEFS)} WAT parameters + specs created")


# ── Lot, Wafer, WAT Results ──────────────────────────────────────────────────

def seed_lots_and_results(n_lots: int = 50):
    if Lot.query.count() >= n_lots // 2:
        return
    base_date = datetime.utcnow() - timedelta(days=45)
    lot_counter = 100100

    for lot_num in range(n_lots):
        prod = PRODUCTS[lot_num % len(PRODUCTS)]
        lot_id = f"M{lot_counter:06d}"
        lot_counter += 1
        lot_start = base_date + timedelta(hours=lot_num * 22)
        lot_complete = lot_start + timedelta(days=int(RNG.integers(18, 26)))

        # Simulate excursion lots
        is_excursion = (lot_num == 18 or lot_num == 32)
        lot_status = "COMPLETED" if lot_complete < datetime.utcnow() else "ACTIVE"
        lot_type = "PRODUCTION" if lot_num % 8 != 0 else ("ENGINEERING" if lot_num % 16 == 0 else "MONITOR")

        lot = Lot(
            lot_id=lot_id, lot_type=lot_type,
            lot_priority=int(RNG.integers(3, 9)),
            product_id=prod["id"], product_revision="A",
            device_family=prod["family"],
            customer_id=f"CUST_{(lot_num % 4) + 1:03d}",
            process_node=prod["node"], technology_id=prod["tech"],
            lot_status=lot_status if not is_excursion else "HOLD",
            hold_code="YIELD_EXCURSION" if is_excursion else None,
            hold_reason="Yield below SBL. RCA in progress." if is_excursion else None,
            wafer_count_start=25, wafer_count_current=25,
            wafer_size_mm=300,
            lot_start_date=lot_start,
            lot_target_date=lot_start + timedelta(days=21),
            lot_complete_date=lot_complete if lot_complete < datetime.utcnow() else None,
            target_yield_pct=95.0, syl_pct=90.0, sbl_pct=85.0,
            is_current=True,
        )
        db.session.add(lot)

        for slot in range(1, 26):
            wafer_id = f"{lot_id}_{slot:02d}"
            # Yield model: base ± noise, excursion lots get much lower yield
            if is_excursion:
                base_yield = float(RNG.normal(78.0, 5.0))
            else:
                base_yield = float(RNG.normal(94.5, 2.8))
            # Edge wafers slightly lower
            if slot in (1, 25, 13):
                base_yield -= float(RNG.uniform(1, 3))
            base_yield = float(np.clip(base_yield, 50, 100))

            wafer = Wafer(
                lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                wafer_status="COMPLETED" if lot_status == "COMPLETED" else "ACTIVE",
                die_per_wafer=5832, die_count_good=int(5832 * base_yield / 100),
                die_size_x_um=5600, die_size_y_um=4200,
                cp_yield_pct=round(base_yield, 3),
            )
            db.session.add(wafer)

            # WAT Results: 9 sites × 10 parameters
            wat_equip = random.choice(["WAT-01", "WAT-02"])
            test_time = lot_start + timedelta(days=14, hours=float(RNG.uniform(0, 8)))

            site_coords = [
                (0,0),(100,0),(-100,0),(0,100),(0,-100),
                (70,70),(-70,70),(70,-70),(-70,-70),
            ]
            site_zones = ["CENTER","RING_100","RING_100","RING_100","RING_100",
                          "RING_70","RING_70","RING_70","RING_70"]

            for site_idx, (sx, sy) in enumerate(site_coords):
                for pdef in WAT_PARAM_DEFS:
                    nom = pdef["nominal"]
                    sig = abs(nom) * pdef["sigma_pct"]
                    # Equipment effect: CVD-01 runs at slightly elevated temp
                    equip_bias = float(RNG.normal(0, sig * 0.15)) if lot_num % 5 == 0 else 0
                    val = float(RNG.normal(nom + equip_bias, sig))
                    # Excursion effect: BVJ specifically impacted
                    if is_excursion and pdef["id"] == "BVJ":
                        val = float(RNG.normal(nom * 0.88, sig * 1.5))

                    usl = nom * 1.15 if nom > 0 else nom * 0.85
                    lsl = nom * 0.85 if nom > 0 else nom * 1.15
                    sigma_dev = (val - nom) / sig if sig > 0 else 0

                    # Outlier detection
                    is_mad_out = abs(sigma_dev) > 3.5
                    is_grubbs_out = abs(sigma_dev) > 4.0

                    result = WATResult(
                        lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                        site_id=site_idx + 1,
                        site_x=round(sx + float(RNG.normal(0, 2)), 2),
                        site_y=round(sy + float(RNG.normal(0, 2)), 2),
                        site_zone=site_zones[site_idx],
                        parameter_id=pdef["id"],
                        parameter_group=pdef["group"],
                        vcc=1.1, temp_c=25.0,
                        measured_value=round(val, 8),
                        usl=round(usl, 6), lsl=round(lsl, 6), target_value=round(nom, 6),
                        pass_fail="P" if lsl <= val <= usl else "F",
                        fail_code=None if lsl <= val <= usl else "OOL",
                        sigma_deviation=round(sigma_dev, 4),
                        equipment_id=wat_equip,
                        recipe_id="WAT_N5_FULL_V3",
                        process_node=prod["node"],
                        product_id=prod["id"],
                        is_outlier_mad=is_mad_out,
                        is_outlier_grubbs=is_grubbs_out,
                        anomaly_score=round(min(1.0, abs(sigma_dev) / 5), 4),
                        test_time=test_time,
                        event_date=test_time.date(),
                        lot_sequence=lot_num + 1,
                    )
                    db.session.add(result)

            # WAT Lot Summary (per wafer per parameter)
            for pdef in WAT_PARAM_DEFS:
                nom = pdef["nominal"]
                sig = abs(nom) * pdef["sigma_pct"]
                vals = [float(RNG.normal(nom, sig)) for _ in range(9)]
                arr = np.array(vals)
                usl = nom * 1.15 if nom > 0 else nom * 0.85
                lsl = nom * 0.85 if nom > 0 else nom * 1.15
                cap = compute_capability(vals, usl, lsl, nom)
                sw_p = cap.get("shapiro_wilk_p")

                summary = WATLotSummary(
                    lot_id=lot_id, wafer_id=wafer_id, parameter_id=pdef["id"],
                    vcc=1.1, temp_c=25.0,
                    product_id=prod["id"], equipment_id=wat_equip,
                    event_date=test_time.date(), n_sites=9,
                    mean_value=round(float(arr.mean()), 8),
                    median_value=round(float(np.median(arr)), 8),
                    std_dev=round(float(arr.std(ddof=1)), 8),
                    min_value=round(float(arr.min()), 8),
                    max_value=round(float(arr.max()), 8),
                    p5_value=round(float(np.percentile(arr, 5)), 8),
                    p25_value=round(float(np.percentile(arr, 25)), 8),
                    p75_value=round(float(np.percentile(arr, 75)), 8),
                    p95_value=round(float(np.percentile(arr, 95)), 8),
                    skewness=round(float(scipy_stats.skew(arr)), 6) if len(arr) >= 3 else None,
                    kurtosis=round(float(scipy_stats.kurtosis(arr)), 6) if len(arr) >= 4 else None,
                    usl=round(usl, 6), lsl=round(lsl, 6),
                    cp=cap.get("cp"), cpk=cap.get("cpk"), cpm=cap.get("cpm"),
                    pp=cap.get("pp"), ppk=cap.get("ppk"),
                    shapiro_wilk_p=sw_p,
                    is_normal_dist=bool(sw_p > 0.05) if sw_p else None,
                    n_pass=sum(1 for v in vals if lsl <= v <= usl),
                    n_fail=sum(1 for v in vals if not (lsl <= v <= usl)),
                    pass_rate_pct=round(sum(1 for v in vals if lsl <= v <= usl) / 9 * 100, 3),
                )
                db.session.add(summary)

            # CP Wafer Summary
            bin_1 = int(5832 * base_yield / 100)
            bin_8 = int((5832 - bin_1) * 0.55)
            bin_14 = int((5832 - bin_1) * 0.25)
            bin_9  = int((5832 - bin_1) * 0.15)
            bin_12 = (5832 - bin_1) - bin_8 - bin_14 - bin_9

            pattern = random.choices(
                ["NORMAL","EDGE","CENTER","DONUT","SCRATCH","CLUSTER","HALF_EDGE"],
                weights=[0.60, 0.12, 0.08, 0.07, 0.05, 0.05, 0.03]
            )[0]

            site_yields = {str(s+1): round(base_yield + float(RNG.normal(0, 1.5)), 3)
                           for s in range(9)}

            cp_ws = CPWaferSummary(
                lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                program_id="CP_N5_LOGIC_V4",
                tester_id=f"CP-{random.randint(1,3):02d}",
                step_id="CP_SORT_01",
                total_die=5832, pass_die=bin_1,
                fail_die=5832 - bin_1, skip_die=0,
                gross_yield_pct=round(base_yield, 4),
                net_yield_pct=round(base_yield * 0.997, 4),
                first_pass_yield=round(base_yield * 0.982, 4),
                retest_count=int(RNG.integers(0, 80)),
                retest_pass_count=int(RNG.integers(0, 20)),
                offline_retest_rate=round(float(RNG.uniform(5, 18)), 3),
                good_part_uph=round(float(RNG.uniform(600, 900)), 1),
                avg_sites=round(float(RNG.uniform(7.5, 8.0)), 2),
                bin_counts_json=json.dumps({"1":bin_1,"8":bin_8,"14":bin_14,"9":bin_9,"12":bin_12}),
                site_yields_json=json.dumps(site_yields),
                pattern_class_generic=pattern,
                pattern_class_primary=f"{pattern}»Center»{pattern}",
                pattern_class_secondary=f"Normal»Normal»{pattern}",
                pattern_confidence=round(float(RNG.uniform(0.75, 0.97)), 4),
                edge_yield_pct=round(base_yield - float(RNG.uniform(1.5, 5)), 4),
                center_yield_pct=round(base_yield + float(RNG.uniform(0, 2.5)), 4),
                edge_center_delta=round(float(RNG.uniform(-6, -1.5)), 4),
                syl_flag=base_yield < 90.0,
                sbl_flag=base_yield < 85.0,
                wafer_pattern_flag=(pattern != "NORMAL"),
                wafer_cluster_flag=(pattern == "CLUSTER"),
                mrb_required=(base_yield < 90.0 or pattern not in ["NORMAL","EDGE"]),
                mrb_result="BadWafer" if base_yield < 85.0 else "GoodWafer",
                event_date=test_time.date(), test_time=test_time,
                product_id=prod["id"], process_node=prod["node"],
            )
            db.session.add(cp_ws)

        if lot_num % 5 == 4:
            db.session.flush()

    db.session.commit()
    print(f"  [seed] {n_lots} lots × 25 wafers × WAT + CP data created")


# ── SPC Configs & Measurements ───────────────────────────────────────────────

def seed_spc():
    if SPCConfig.query.count() > 0:
        return
    base_date = datetime.utcnow() - timedelta(days=60)

    for pdef in WAT_PARAM_DEFS[:6]:  # SPC monitor top 6 parameters
        nom = pdef["nominal"]
        sig = abs(nom) * pdef["sigma_pct"]

        config = SPCConfig(
            config_id=f"SPC_{pdef['id']}_WAT01",
            parameter_id=pdef["id"],
            parameter_source="WAT",
            parameter_desc=pdef["name"],
            equipment_id="WAT-01",
            step_id="WAT_MEASURE_01",
            chart_type="IMR",
            subgroup_size=1,
            ucl=round(nom + 3 * sig, 8), cl=round(nom, 8), lcl=round(nom - 3 * sig, 8),
            ucl_2sigma=round(nom + 2 * sig, 8), lcl_2sigma=round(nom - 2 * sig, 8),
            ucl_1sigma=round(nom + sig, 8), lcl_1sigma=round(nom - sig, 8),
            sigma_estimate=round(sig, 8),
            usl=round(nom * 1.15 if nom > 0 else nom * 0.85, 6),
            lsl=round(nom * 0.85 if nom > 0 else nom * 1.15, 6),
            target=round(nom, 6),
            phase1_lot_count=50,
            phase1_start_date=date.today() - timedelta(days=365),
            phase1_end_date=date.today() - timedelta(days=90),
            phase1_method="RBAR",
            enabled_rules=255,
            alarm_mode="EMAIL",
            alarm_severity="MAJOR",
            is_active=True,
            created_by="admin",
        )
        db.session.add(config)

        # Generate 90 measurement points with realistic patterns
        prev_val = nom
        for i in range(90):
            meas_time = base_date + timedelta(hours=i * 8 + float(RNG.uniform(-1, 1)))

            # Inject specific patterns:
            # Points 40–44: Rule 1 excursion
            # Points 60–68: Rule 2 (9 pts above CL)
            # Points 75–80: Rule 5 (2/3 > 2σ)
            if 40 <= i <= 44:
                val = float(RNG.normal(nom + 3.5 * sig, sig * 0.4))
            elif 60 <= i <= 68:
                val = float(RNG.normal(nom + 0.8 * sig, sig * 0.3))
            elif 75 <= i <= 77:
                val = float(RNG.normal(nom + 2.3 * sig, sig * 0.2))
            else:
                val = float(RNG.normal(nom, sig))

            moving_range = abs(val - prev_val)
            sigma_score = (val - nom) / sig if sig > 0 else 0

            r1 = val > nom + 3*sig or val < nom - 3*sig
            r5 = False  # will be computed by check_all_rules later
            any_viol = r1

            viol_rules = ",".join(str(r) for r in ([1] if r1 else []))

            meas = SPCMeasurement(
                config_id=f"SPC_{pdef['id']}_WAT01",
                parameter_id=pdef["id"],
                lot_id=f"M{100100 + i:06d}",
                equipment_id="WAT-01",
                subgroup_index=i + 1,
                measured_value=round(val, 8),
                subgroup_mean=round(val, 8),
                moving_range=round(moving_range, 8),
                ucl_at_time=round(nom + 3*sig, 8),
                cl_at_time=round(nom, 8),
                lcl_at_time=round(nom - 3*sig, 8),
                usl_at_time=round(nom*1.15 if nom>0 else nom*0.85, 6),
                lsl_at_time=round(nom*0.85 if nom>0 else nom*1.15, 6),
                sigma_score=round(sigma_score, 4),
                violation_rule_1=r1,
                any_violation=any_viol,
                violation_rules_list=viol_rules or None,
                alarm_triggered=r1,
                alarm_severity="CRITICAL" if r1 else None,
                measurement_time=meas_time,
                event_date=meas_time.date(),
            )
            db.session.add(meas)
            prev_val = val

    db.session.commit()
    print(f"  [seed] SPC configs + 90 measurements × 6 parameters created")


# ── FDC Data ─────────────────────────────────────────────────────────────────

def seed_fdc():
    if FDCSensor.query.count() > 0:
        return
    base_date = datetime.utcnow() - timedelta(days=21)

    # Sensors for CVD-01
    sensors = [
        ("CEID10OnlineTime","TIME","sec","1",100.0),
        ("CEID8OfflineTime","TIME","sec","1",100.0),
        ("ChmPress","PRESSURE","Torr","1",91.1),
        ("ChmTemp","TEMPERATURE","C","1",89.7),
        ("ChmTemp1SlotV","TEMPERATURE","C","1",31.8),
        ("ChmTempAfter1SlotV","TEMPERATURE","C","1",89.2),
        ("DAQ10HPCompCurrentR","CURRENT","A","1",99.8),
        ("DAQ10HPCompCurrentT","CURRENT","A","1",100.0),
        ("DAQ10HPHeatCurrentR","CURRENT","A","1",100.0),
        ("DAQ275HPCompCurrentR","CURRENT","A","1",99.9),
        ("DAQ275HPCompCurrentT","CURRENT","A","1",100.0),
        ("DAQ275HPPumpCurrentR","CURRENT","A","1",58.4),
        ("DAQ275HeatCurrentR","CURRENT","A","1",100.0),
    ]
    for alias, stype, units, module, pass_rate in sensors:
        sensor = FDCSensor(
            equipment_id="CVD-01",
            sensor_alias=alias,
            sensor_full_name=f"CVD-01 / PM1 / {alias}",
            sensor_type=stype,
            measurement_units=units,
            module_id=module,
            module_name=f"Module {module}",
            sampling_rate_hz=10.0,
            is_fdc_monitored=True,
            fdc_alarm_enabled=True,
            baseline_sigma_limit=6.0,
        )
        db.session.add(sensor)

    # FDC Indicators
    indicators = [
        ("BPOFG-F040-B4_1","BiasMatchShuntCapLearnedPosition_Shape","SHAPE",342,6,1.75,"EMAIL",2.07,2.05,-0.01),
        ("BPOFG-F040-B4_2","BiasMatchShuntCapLearnedPosition_Max","MAX",342,2,0.58,"EMAIL",1.95,1.91,-0.03),
        ("BPOFG-F040-B4_3","BiasMatchShuntCapLearnedPosition_Area","AREA",342,1,0.29,"EMAIL",2.12,2.08,0.01),
        ("BPOFG-F040-B4_4","ChmPress_Mean","MEAN",174,0,0.00,"NoSPC",None,None,None),
        ("BPOFG-F040-B4_5","ChmTemp_Slope","SLOPE",168,0,0.00,"NoSPC",None,None,None),
        ("BPOFG-F040-B4_6","DAQ275HPPumpCurrentR_Shape","SHAPE",168,0,0.00,"NoSPC",None,None,None),
    ]
    for iid, iname, ftype, runs, alarms, rate, mode, cp, cpk, ca in indicators:
        ind = FDCIndicator(
            indicator_id=iid, indicator_name=iname,
            equipment_id="CVD-01", recipe_id="BPOFG-F040-B4",
            sensor_alias="BiasMatchShuntCapLearnedPosition",
            feature_type=ftype, step_segment="PROCESS",
            alarm_mode=mode,
            cl=0.0, ucl=0.15, lcl=-0.15,
            ca=round(ca, 4) if ca else None,
            cp=round(cp, 4) if cp else None,
            cpk=round(cpk, 4) if cpk else None,
            total_runs=runs, total_alarms=alarms,
            alarm_rate_pct=round(rate, 4),
            is_active=True,
        )
        db.session.add(ind)

    # FDC Trace Runs — 150 runs over 21 days
    for i in range(150):
        run_time = base_date + timedelta(hours=i * 3.4)
        duration = float(RNG.normal(33.5, 2.1))

        # Anomaly cluster: runs 65–75 (post-PM drift), 110–115 (amplitude)
        is_anomaly = (65 <= i <= 75) or (110 <= i <= 115)
        is_post_pm = (i == 30)  # PM was performed before run 30

        if is_anomaly and 65 <= i <= 75:
            anom_class = "PM_DRIFT"
            composite = float(RNG.uniform(0.72, 0.94))
            pm_sc = float(RNG.uniform(0.80, 0.95))
            int_sc = float(RNG.uniform(0.40, 0.60))
            amp_sc = float(RNG.uniform(0.30, 0.50))
            shp_sc = float(RNG.uniform(0.45, 0.65))
            alarm_cnt = int(RNG.integers(2, 5))
        elif is_anomaly and 110 <= i <= 115:
            anom_class = "AMPLITUDE"
            composite = float(RNG.uniform(0.82, 0.97))
            pm_sc = float(RNG.uniform(0.10, 0.20))
            int_sc = float(RNG.uniform(0.20, 0.40))
            amp_sc = float(RNG.uniform(0.88, 0.98))
            shp_sc = float(RNG.uniform(0.55, 0.75))
            alarm_cnt = int(RNG.integers(3, 6))
        else:
            anom_class = "NORMAL"
            composite = float(RNG.uniform(0.02, 0.22))
            pm_sc = float(RNG.uniform(0.01, 0.15))
            int_sc = float(RNG.uniform(0.01, 0.18))
            amp_sc = float(RNG.uniform(0.02, 0.16))
            shp_sc = float(RNG.uniform(0.01, 0.14))
            alarm_cnt = 0

        run = FDCTraceRun(
            run_id=f"RUN_{i:06d}",
            lot_id=f"M{100100 + (i % 50):06d}",
            wafer_id=f"M{100100 + (i % 50):06d}_{(i % 25) + 1:02d}",
            slot_number=(i % 25) + 1,
            equipment_id=random.choice(["CVD-01","CVD-02","ETCH-01"]),
            chamber_id=f"PM{(i % 4) + 1}",
            recipe_id="BPOFG-F040-B4",
            recipe_version="V3",
            step_id="LI-3041",
            route_id="N5_LOGIC_R04",
            product_id="PROD_N5_001",
            process_node="N5",
            run_start_time=run_time,
            run_end_time=run_time + timedelta(seconds=duration),
            run_duration_sec=round(duration, 4),
            run_result="ALARM" if is_anomaly else "PASS",
            alarm_count=alarm_cnt,
            alarm_sensor_list="ChmPress,ChmTemp" if is_anomaly else None,
            interval_anomaly_score=round(int_sc, 6),
            pm_anomaly_score=round(pm_sc, 6),
            amplitude_anomaly_score=round(amp_sc, 6),
            shape_anomaly_score=round(shp_sc, 6),
            composite_anomaly_score=round(composite, 6),
            anomaly_class=anom_class,
            is_anomaly=is_anomaly,
            is_post_pm=is_post_pm,
            pm_wafer_count=i * 5,
            event_date=run_time.date(),
        )
        db.session.add(run)

    # PM Events
    pm_events = [
        {"equipment_id":"CVD-01","pm_type":"SCHEDULED","pm_subtype":"CLEAN",
         "days_ago":35,"trigger":"SCHEDULE","pre":72.4,"post":91.2},
        {"equipment_id":"CMP-01","pm_type":"PREDICTIVE","pm_subtype":"PAD_REPLACE",
         "days_ago":14,"trigger":"HEALTH_SCORE","pre":65.1,"post":88.5},
        {"equipment_id":"ETCH-01","pm_type":"CORRECTIVE","pm_subtype":"REPLACE_PART",
         "days_ago":7, "trigger":"ALARM","pre":59.8,"post":87.1},
    ]
    for pm in pm_events:
        pm_start = datetime.utcnow() - timedelta(days=pm["days_ago"])
        pm_end   = pm_start + timedelta(hours=float(RNG.uniform(4, 18)))
        event = FDCPMEvent(
            equipment_id=pm["equipment_id"],
            chamber_id="PM1",
            pm_type=pm["pm_type"],
            pm_subtype=pm["pm_subtype"],
            pm_code=f"PM_{pm['equipment_id']}_{pm['pm_subtype']}",
            pm_start_time=pm_start, pm_end_time=pm_end,
            pm_duration_hr=round((pm_end - pm_start).total_seconds() / 3600, 3),
            trigger_source=pm["trigger"],
            trigger_health_score=round(pm["pre"], 2),
            performed_by="ee_engineer",
            pre_pm_health_score=round(pm["pre"], 2),
            post_pm_health_score=round(pm["post"], 2),
            health_improvement=round(pm["post"] - pm["pre"], 2),
            qualification_passed=True,
            wafers_impacted=int(RNG.integers(5, 40)),
            event_date=pm_start.date(),
        )
        db.session.add(event)

    db.session.commit()
    print(f"  [seed] FDC sensors, indicators, 150 trace runs, PM events created")


# ── Defect Data ───────────────────────────────────────────────────────────────

def seed_defects():
    if DefectResult.query.count() > 0:
        return
    base_date = datetime.utcnow() - timedelta(days=30)
    lots = Lot.query.filter_by(is_current=True).limit(10).all()

    for lot in lots:
        for slot in range(1, 6):  # 5 wafers per lot for defect data
            wafer_id = f"{lot.lot_id}_{slot:02d}"
            insp_time = base_date + timedelta(days=int(RNG.integers(0, 28)))
            n_defects = int(RNG.integers(20, 420))

            class_counts: dict = {}
            for _ in range(n_defects):
                cls = random.choices(DEFECT_CLASSES, weights=[20,8,5,12,6,7,4,3,2,4,3,3,4,2,5,6])[0]
                class_counts[cls] = class_counts.get(cls, 0) + 1
                kp = float(RNG.uniform(0.02, 0.45)) if cls in ("Killer_Scratch","Bridge","Crystal") else float(RNG.uniform(0, 0.08))

                defect = DefectResult(
                    lot_id=lot.lot_id, wafer_id=wafer_id, slot_number=slot,
                    inspection_tool_id="KLA-5XX",
                    inspection_recipe="INSP_N5_AA_V2",
                    inspection_layer="AA",
                    inspection_step_id="INSP_AA_01",
                    defect_x_um=round(float(RNG.uniform(-150, 150)), 2),
                    defect_y_um=round(float(RNG.uniform(-150, 150)), 2),
                    die_x=int(RNG.integers(-18, 18)),
                    die_y=int(RNG.integers(-18, 18)),
                    defect_size_nm=round(float(RNG.lognormal(4.5, 0.8)), 2),
                    adc_class=cls, adc_confidence=round(float(RNG.uniform(0.70, 0.98)), 4),
                    is_adc_auto=True, final_class=cls, class_category=cls.split("_")[0],
                    is_killer=kp > 0.25, kill_probability=round(kp, 6),
                    sem_reviewed=(float(RNG.random()) > 0.9),
                    is_nuisance=(cls in ("Film","Oxide_Chain")),
                    inspection_time=insp_time, event_date=insp_time.date(),
                    product_id=lot.product_id, process_node=lot.process_node,
                )
                db.session.add(defect)

            # Wafer defect summary
            density = n_defects / 706.86  # 300mm wafer area in cm²
            killer_count = sum(v for k, v in class_counts.items() if k in ("Killer_Scratch","Bridge","Crystal"))
            nuisance_count = sum(v for k, v in class_counts.items() if k in ("Film","Oxide_Chain"))

            pattern = random.choices(
                ["NORMAL","CLUSTER","EDGE","RING","SCRATCH","LINEAR"],
                weights=[0.50, 0.15, 0.15, 0.10, 0.07, 0.03]
            )[0]

            dws = DefectWaferSummary(
                lot_id=lot.lot_id, wafer_id=wafer_id,
                inspection_tool_id="KLA-5XX",
                inspection_step_id="INSP_AA_01",
                inspection_layer="AA",
                total_defects=n_defects, killer_defects=killer_count,
                nuisance_defects=nuisance_count,
                inspection_area_cm2=706.86,
                defect_density_cm2=round(density, 8),
                killer_density_cm2=round(killer_count / 706.86, 8),
                class_counts_json=json.dumps(class_counts),
                pattern_class=pattern,
                pattern_confidence=round(float(RNG.uniform(0.70, 0.95)), 4),
                suspected_equipment_id=random.choice(["CVD-01","ETCH-01","CMP-01"]),
                suspected_step_id="LI-3041",
                hypothesis_confidence=round(float(RNG.uniform(0.55, 0.85)), 4),
                predicted_yield_loss_pct=round(killer_count / 5832 * 100, 4),
                inspection_time=insp_time, event_date=insp_time.date(),
            )
            db.session.add(dws)

    db.session.commit()
    print(f"  [seed] Defect data created for {len(lots)} lots")


# ── Master Seed Function ──────────────────────────────────────────────────────

def seed_all(n_lots: int = 50):
    """Run all seed functions in correct dependency order."""
    print("\n🌱 Starting SEMFAB·IQ demo data seeding...")
    seed_users()
    seed_equipment()
    seed_wat_params()
    seed_lots_and_results(n_lots=n_lots)
    seed_spc()
    seed_fdc()
    seed_defects()
    print("✅ All demo data seeded successfully!\n")
    print("  Demo credentials:")
    print("  ┌─────────────────┬──────────────┬───────────────────────────────┐")
    print("  │ Username        │ Password     │ Role                          │")
    print("  ├─────────────────┼──────────────┼───────────────────────────────┤")
    print("  │ pe_engineer     │ Engineer@123 │ Process Engineer              │")
    print("  │ ee_engineer     │ Engineer@123 │ Equipment Engineer            │")
    print("  │ pi_engineer     │ Engineer@123 │ Process Integration Engineer  │")
    print("  │ manager         │ Manager@123  │ Manager                       │")
    print("  │ admin           │ Admin@12345  │ System Admin                  │")
    print("  └─────────────────┴──────────────┴───────────────────────────────┘")
