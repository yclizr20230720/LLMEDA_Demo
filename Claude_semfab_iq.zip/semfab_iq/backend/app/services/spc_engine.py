"""
SPC Engine — All 8 Western Electric Rules + Full Capability Analysis
Production-grade implementation with proper edge-case handling
"""
from __future__ import annotations
from typing import List, Dict, Tuple, Optional, Any
import numpy as np
from scipy import stats as scipy_stats


# ─── Rule Metadata ───────────────────────────────────────────────────────────

RULE_METADATA: Dict[int, Dict[str, str]] = {
    1: {"desc": "1 point more than 3σ from centerline",            "severity": "CRITICAL"},
    2: {"desc": "9 consecutive points on same side of centerline", "severity": "MAJOR"},
    3: {"desc": "6 consecutive points trending (monotone)",        "severity": "MAJOR"},
    4: {"desc": "14 consecutive points alternating up/down",       "severity": "MINOR"},
    5: {"desc": "2 of 3 consecutive points > 2σ same side",       "severity": "MAJOR"},
    6: {"desc": "4 of 5 consecutive points > 1σ same side",       "severity": "MINOR"},
    7: {"desc": "15 consecutive points within 1σ (stratification)","severity": "MINOR"},
    8: {"desc": "8 consecutive points > 1σ on both sides (mixture)","severity": "MINOR"},
}


# ─── Individual Rule Functions ────────────────────────────────────────────────

def rule_1(values: np.ndarray, ucl: float, lcl: float) -> List[int]:
    """Rule 1: 1 point beyond 3σ (UCL or LCL)"""
    return [int(i) for i, v in enumerate(values) if v > ucl or v < lcl]


def rule_2(values: np.ndarray, cl: float) -> List[int]:
    """Rule 2: 9 consecutive points on same side of centerline"""
    violations = []
    n = len(values)
    for i in range(8, n):
        window = values[i - 8: i + 1]
        if all(v > cl for v in window) or all(v < cl for v in window):
            violations.append(i)
    return violations


def rule_3(values: np.ndarray) -> List[int]:
    """Rule 3: 6 consecutive points strictly increasing or decreasing"""
    violations = []
    n = len(values)
    for i in range(5, n):
        window = values[i - 5: i + 1]
        diffs = np.diff(window)
        if all(d > 0 for d in diffs) or all(d < 0 for d in diffs):
            violations.append(i)
    return violations


def rule_4(values: np.ndarray) -> List[int]:
    """Rule 4: 14 consecutive points alternating up/down"""
    violations = []
    n = len(values)
    for i in range(13, n):
        window = values[i - 13: i + 1]
        alternating = all(
            (window[j] < window[j + 1]) != (window[j + 1] < window[j + 2])
            for j in range(12)
        )
        if alternating:
            violations.append(i)
    return violations


def rule_5(values: np.ndarray, cl: float, sigma: float) -> List[int]:
    """Rule 5: 2 of 3 consecutive points > 2σ on the same side"""
    violations = []
    u2 = cl + 2 * sigma
    l2 = cl - 2 * sigma
    n = len(values)
    for i in range(2, n):
        w = values[i - 2: i + 1]
        above = sum(1 for v in w if v > u2)
        below = sum(1 for v in w if v < l2)
        if above >= 2 or below >= 2:
            violations.append(i)
    return violations


def rule_6(values: np.ndarray, cl: float, sigma: float) -> List[int]:
    """Rule 6: 4 of 5 consecutive points > 1σ on the same side"""
    violations = []
    u1 = cl + sigma
    l1 = cl - sigma
    n = len(values)
    for i in range(4, n):
        w = values[i - 4: i + 1]
        above = sum(1 for v in w if v > u1)
        below = sum(1 for v in w if v < l1)
        if above >= 4 or below >= 4:
            violations.append(i)
    return violations


def rule_7(values: np.ndarray, cl: float, sigma: float) -> List[int]:
    """Rule 7: 15 consecutive points within 1σ (stratification)"""
    violations = []
    u1 = cl + sigma
    l1 = cl - sigma
    n = len(values)
    for i in range(14, n):
        w = values[i - 14: i + 1]
        if all(l1 <= v <= u1 for v in w):
            violations.append(i)
    return violations


def rule_8(values: np.ndarray, cl: float, sigma: float) -> List[int]:
    """Rule 8: 8 consecutive points > 1σ on BOTH sides (mixture)"""
    violations = []
    u1 = cl + sigma
    l1 = cl - sigma
    n = len(values)
    for i in range(7, n):
        w = values[i - 7: i + 1]
        outside = all(v > u1 or v < l1 for v in w)
        has_above = any(v > u1 for v in w)
        has_below = any(v < l1 for v in w)
        if outside and has_above and has_below:
            violations.append(i)
    return violations


# ─── Main Engine ─────────────────────────────────────────────────────────────

def check_all_rules(
    values: List[float],
    ucl: float,
    cl: float,
    lcl: float,
    sigma: float,
    enabled_rules: int = 255,
) -> Dict[str, Any]:
    """
    Run all enabled Western Electric rules.

    enabled_rules is a bitmask: bit k-1 enables rule k.
    255 = all rules enabled (0b11111111).

    Returns per-rule results plus aggregated violation index list.
    """
    if len(values) < 2:
        return {"per_rule": {}, "violation_indices": [], "has_violation": False, "total_violations": 0}

    arr = np.array(values, dtype=float)

    rule_funcs = {
        1: lambda: rule_1(arr, ucl, lcl),
        2: lambda: rule_2(arr, cl),
        3: lambda: rule_3(arr),
        4: lambda: rule_4(arr),
        5: lambda: rule_5(arr, cl, sigma),
        6: lambda: rule_6(arr, cl, sigma),
        7: lambda: rule_7(arr, cl, sigma),
        8: lambda: rule_8(arr, cl, sigma),
    }

    per_rule: Dict[str, Any] = {}
    all_violation_indices: set = set()

    for rule_num in range(1, 9):
        if enabled_rules & (1 << (rule_num - 1)):
            indices = rule_funcs[rule_num]()
            meta = RULE_METADATA[rule_num]
            per_rule[f"rule_{rule_num}"] = {
                "enabled": True,
                "violation_count": len(indices),
                "violation_indices": indices,
                "description": meta["desc"],
                "severity": meta["severity"],
                "triggered": len(indices) > 0,
            }
            all_violation_indices.update(indices)
        else:
            per_rule[f"rule_{rule_num}"] = {
                "enabled": False,
                "violation_count": 0,
                "violation_indices": [],
                "description": RULE_METADATA[rule_num]["desc"],
                "severity": RULE_METADATA[rule_num]["severity"],
                "triggered": False,
            }

    sorted_indices = sorted(all_violation_indices)
    return {
        "per_rule": per_rule,
        "violation_indices": sorted_indices,
        "has_violation": len(sorted_indices) > 0,
        "total_violations": len(sorted_indices),
        "n_points": len(values),
    }


# ─── Sigma Estimation ────────────────────────────────────────────────────────

def estimate_sigma_rbar(values: List[float], subgroup_size: int = 1) -> float:
    """Estimate within-subgroup sigma using Rbar/d2 method"""
    if subgroup_size == 1:
        # IMR: use moving range
        arr = np.array(values, dtype=float)
        if len(arr) < 2:
            return float(np.std(arr, ddof=1)) if len(arr) > 0 else 1.0
        mr = np.abs(np.diff(arr))
        mr_mean = float(np.mean(mr))
        d2 = 1.128  # d2 constant for n=2
        return mr_mean / d2
    else:
        # Subgroup: use d2 lookup
        D2_TABLE = {2: 1.128, 3: 1.693, 4: 2.059, 5: 2.326, 6: 2.534,
                    7: 2.704, 8: 2.847, 9: 2.970, 10: 3.078}
        d2 = D2_TABLE.get(subgroup_size, 2.326)
        n_groups = len(values) // subgroup_size
        ranges = []
        for g in range(n_groups):
            grp = values[g * subgroup_size: (g + 1) * subgroup_size]
            ranges.append(max(grp) - min(grp))
        r_bar = np.mean(ranges) if ranges else 1.0
        return float(r_bar / d2)


# ─── Process Capability ───────────────────────────────────────────────────────

def compute_capability(
    values: List[float],
    usl: float,
    lsl: float,
    target: Optional[float] = None,
    subgroup_size: int = 1,
) -> Dict[str, Any]:
    """
    Compute full process capability suite:
    Cp, Cpk, Cpm, Cpl, Cpu, Pp, Ppk + distributional stats

    Returns dict with all indices, None where calculation not possible.
    """
    if not values or usl <= lsl:
        return {"error": "Insufficient data or invalid spec limits"}

    arr = np.array(values, dtype=float)
    n = len(arr)
    mean = float(np.mean(arr))
    std_overall = float(np.std(arr, ddof=1)) if n > 1 else 0.0
    std_within = estimate_sigma_rbar(values, subgroup_size)
    spec_range = usl - lsl

    def safe_div(num, den):
        return round(num / den, 6) if den and den > 0 else None

    cp  = safe_div(spec_range, 6 * std_within)
    cpu = safe_div(usl - mean,  3 * std_within)
    cpl = safe_div(mean - lsl,  3 * std_within)
    cpk = min(cpu, cpl) if cpu is not None and cpl is not None else None

    pp  = safe_div(spec_range, 6 * std_overall)
    ppu = safe_div(usl - mean,  3 * std_overall)
    ppl = safe_div(mean - lsl,  3 * std_overall)
    ppk = min(ppu, ppl) if ppu is not None and ppl is not None else None

    # Cpm (Taguchi's index)
    cpm = None
    if target is not None and std_within > 0:
        tau = float(np.sqrt(std_within ** 2 + (mean - target) ** 2))
        cpm = safe_div(spec_range, 6 * tau)

    # Normality test
    sw_stat, sw_p = (None, None)
    if 3 <= n <= 5000:
        try:
            sw_stat, sw_p = scipy_stats.shapiro(arr)
            sw_stat, sw_p = float(sw_stat), float(sw_p)
        except Exception:
            pass

    # Distribution percentiles
    pct = np.percentile(arr, [5, 10, 25, 50, 75, 90, 95]) if n >= 4 else [None] * 7

    # Skewness / Kurtosis
    skew = float(scipy_stats.skew(arr)) if n >= 3 else None
    kurt = float(scipy_stats.kurtosis(arr)) if n >= 4 else None

    return {
        "n": n,
        "mean": round(mean, 8),
        "median": round(float(np.median(arr)), 8),
        "std_within": round(std_within, 8),
        "std_overall": round(std_overall, 8),
        "min": round(float(arr.min()), 8),
        "max": round(float(arr.max()), 8),
        "range": round(float(arr.max() - arr.min()), 8),
        "p5": round(float(pct[0]), 8) if pct[0] is not None else None,
        "p10": round(float(pct[1]), 8) if pct[1] is not None else None,
        "p25": round(float(pct[2]), 8) if pct[2] is not None else None,
        "p50": round(float(pct[3]), 8) if pct[3] is not None else None,
        "p75": round(float(pct[4]), 8) if pct[4] is not None else None,
        "p90": round(float(pct[5]), 8) if pct[5] is not None else None,
        "p95": round(float(pct[6]), 8) if pct[6] is not None else None,
        "skewness": round(skew, 6) if skew is not None else None,
        "kurtosis": round(kurt, 6) if kurt is not None else None,
        "usl": usl, "lsl": lsl, "target": target,
        "spec_range": spec_range,
        "cp": cp, "cpk": cpk, "cpm": cpm, "cpl": cpl, "cpu": cpu,
        "pp": pp, "ppk": ppk, "ppu": ppu, "ppl": ppl,
        "shapiro_wilk_stat": sw_stat,
        "shapiro_wilk_p": round(sw_p, 8) if sw_p is not None else None,
        "is_normal": bool(sw_p > 0.05) if sw_p is not None else None,
    }


# ─── ANOVA Engine ─────────────────────────────────────────────────────────────

def one_way_anova(
    groups: Dict[str, List[float]]
) -> Dict[str, Any]:
    """
    One-way ANOVA with eta-squared effect size.

    groups: {group_name: [values...]}
    Returns: F-stat, p-value, eta², SS components, group stats
    """
    if len(groups) < 2:
        return {"error": "Need at least 2 groups"}

    group_names = list(groups.keys())
    group_data  = [np.array(v, dtype=float) for v in groups.values()]
    all_data    = np.concatenate(group_data)
    grand_mean  = float(np.mean(all_data))
    grand_n     = len(all_data)

    ss_total   = float(np.sum((all_data - grand_mean) ** 2))
    ss_between = sum(len(g) * (float(np.mean(g)) - grand_mean) ** 2 for g in group_data)
    ss_within  = ss_total - ss_between

    k  = len(groups)
    df_between = k - 1
    df_within  = grand_n - k

    ms_between = ss_between / df_between if df_between > 0 else 0
    ms_within  = ss_within  / df_within  if df_within  > 0 else 1e-10

    f_stat = ms_between / ms_within if ms_within > 0 else 0
    p_value = float(scipy_stats.f.sf(f_stat, df_between, df_within)) if f_stat > 0 else 1.0

    eta_squared = ss_between / ss_total if ss_total > 0 else 0.0
    omega_sq_num = ss_between - df_between * ms_within
    omega_squared = omega_sq_num / (ss_total + ms_within) if (ss_total + ms_within) > 0 else 0.0

    group_stats = {}
    for name, data in zip(group_names, group_data):
        group_stats[name] = {
            "n": len(data),
            "mean": round(float(np.mean(data)), 8),
            "std": round(float(np.std(data, ddof=1)) if len(data) > 1 else 0, 8),
            "min": round(float(np.min(data)), 8),
            "max": round(float(np.max(data)), 8),
        }

    return {
        "ss_between": round(ss_between, 6),
        "ss_within": round(ss_within, 6),
        "ss_total": round(ss_total, 6),
        "ms_between": round(ms_between, 6),
        "ms_within": round(ms_within, 6),
        "df_between": df_between,
        "df_within": df_within,
        "f_statistic": round(f_stat, 6),
        "p_value": round(p_value, 10),
        "eta_squared": round(eta_squared, 6),
        "omega_squared": round(max(0, omega_squared), 6),
        "is_significant": p_value < 0.05,
        "grand_n": grand_n,
        "grand_mean": round(grand_mean, 8),
        "k_groups": k,
        "group_stats": group_stats,
    }


# ─── Pearson Correlation ──────────────────────────────────────────────────────

def pearson_correlation(
    x: List[float], y: List[float]
) -> Dict[str, Any]:
    """Pearson + Spearman correlation with OLS regression"""
    if len(x) != len(y) or len(x) < 3:
        return {"error": "Need at least 3 matched pairs"}

    xa, ya = np.array(x, dtype=float), np.array(y, dtype=float)
    # Remove NaN pairs
    mask = ~(np.isnan(xa) | np.isnan(ya))
    xa, ya = xa[mask], ya[mask]
    n = len(xa)
    if n < 3:
        return {"error": "Insufficient non-null pairs"}

    p_r, p_p = scipy_stats.pearsonr(xa, ya)
    s_r, s_p = scipy_stats.spearmanr(xa, ya)

    # OLS regression y = a + b*x
    slope, intercept, r_val, p_val, se = scipy_stats.linregress(xa, ya)
    r_squared = float(r_val ** 2)
    n_params = 2
    adj_r_sq = 1 - (1 - r_squared) * (n - 1) / (n - n_params) if n > n_params else r_squared
    f_stat = r_squared / (1 - r_squared) * (n - 2) if r_squared < 1 else float("inf")
    f_p = float(scipy_stats.f.sf(f_stat, 1, n - 2))

    return {
        "n": n,
        "pearson_r": round(float(p_r), 6),
        "pearson_p": round(float(p_p), 10),
        "spearman_r": round(float(s_r), 6),
        "spearman_p": round(float(s_p), 10),
        "ols_slope": round(float(slope), 8),
        "ols_intercept": round(float(intercept), 8),
        "ols_r_squared": round(r_squared, 6),
        "ols_adj_r_squared": round(adj_r_sq, 6),
        "ols_f_stat": round(f_stat, 4),
        "ols_f_p": round(f_p, 10),
        "ols_std_error": round(float(se), 8),
        "is_significant_05": float(p_p) < 0.05,
        "is_significant_01": float(p_p) < 0.01,
    }
