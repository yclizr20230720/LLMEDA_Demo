"""User Authentication Model"""
from datetime import datetime
from app import db
from app.models.base import TimestampMixin

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerifyMismatchError
    _ph = PasswordHasher(time_cost=2, memory_cost=65536, parallelism=2)
    USE_ARGON2 = True
except ImportError:
    import hashlib, os
    USE_ARGON2 = False

ROLES = ["FAB_OPERATOR","PROCESS_ENGINEER","EQUIPMENT_ENGINEER",
         "SENIOR_ENGINEER","PROCESS_INTEGRATION_ENGINEER","MANAGER","SYSTEM_ADMIN"]


class User(db.Model, TimestampMixin):
    __tablename__ = "auth_users"

    user_sk      = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    username     = db.Column(db.String(64), nullable=False, unique=True, index=True)
    email        = db.Column(db.String(128), nullable=False, unique=True)
    password_hash= db.Column(db.String(512), nullable=False)
    full_name    = db.Column(db.String(128))
    role         = db.Column(db.String(32), nullable=False, default="PROCESS_ENGINEER")
    department   = db.Column(db.String(64))
    fab_id       = db.Column(db.String(16), default="FAB-12")
    is_active    = db.Column(db.Boolean, default=True, nullable=False)
    mfa_enabled  = db.Column(db.Boolean, default=False)
    mfa_secret   = db.Column(db.String(64))
    failed_logins= db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime(timezone=True))
    last_login   = db.Column(db.DateTime(timezone=True))
    login_count  = db.Column(db.Integer, default=0)

    def set_password(self, password: str):
        if USE_ARGON2:
            self.password_hash = _ph.hash(password)
        else:
            salt = os.urandom(32).hex()
            h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
            self.password_hash = f"sha256:{salt}:{h}"

    def check_password(self, password: str) -> bool:
        try:
            if USE_ARGON2:
                return _ph.verify(self.password_hash, password)
            else:
                parts = self.password_hash.split(":")
                h = hashlib.sha256(f"{parts[1]}:{password}".encode()).hexdigest()
                return h == parts[2]
        except Exception:
            return False

    def is_locked(self) -> bool:
        if self.locked_until and self.locked_until > datetime.utcnow():
            return True
        return False

    def to_dict(self):
        return {
            "username": self.username, "email": self.email, "full_name": self.full_name,
            "role": self.role, "department": self.department, "fab_id": self.fab_id,
            "is_active": self.is_active, "mfa_enabled": self.mfa_enabled,
            "last_login": self._d(self.last_login), "login_count": self.login_count,
        }

    def to_profile(self):
        d = self.to_dict()
        d["failed_logins"] = self.failed_logins
        d["is_locked"] = self.is_locked()
        return d
