"""Equipment & Chamber Models"""
from app import db
from app.models.base import TimestampMixin


class Equipment(db.Model, TimestampMixin):
    __tablename__ = "eqp_dim_equipment"

    equipment_sk    = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id    = db.Column(db.String(32), nullable=False, unique=True, index=True)
    equipment_name  = db.Column(db.String(128))
    equipment_alias = db.Column(db.String(64))
    equipment_type  = db.Column(db.String(32), nullable=False, index=True)
    equipment_subtype = db.Column(db.String(32))
    oem_vendor      = db.Column(db.String(32))
    oem_model       = db.Column(db.String(64))
    oem_serial      = db.Column(db.String(64))
    fab_id          = db.Column(db.String(16))
    bay_id          = db.Column(db.String(16))
    area_id         = db.Column(db.String(32))
    chamber_count   = db.Column(db.SmallInteger, default=1)
    is_multi_chamber= db.Column(db.Boolean, default=False)
    wafer_size_mm   = db.Column(db.SmallInteger, default=300)
    equipment_status= db.Column(db.String(24), default="PRODUCTION", index=True)
    is_golden_tool  = db.Column(db.Boolean, default=False)
    commissioning_date = db.Column(db.Date)
    health_score    = db.Column(db.Numeric(5, 2), default=100.0)
    health_tier     = db.Column(db.String(16), default="HEALTHY")
    health_updated_at = db.Column(db.DateTime(timezone=True))
    z_score_component = db.Column(db.Numeric(5, 3))
    gof_component   = db.Column(db.Numeric(5, 3))
    cv_stability_component = db.Column(db.Numeric(5, 3))
    volume_component = db.Column(db.Numeric(5, 3))
    last_pm_date    = db.Column(db.Date)
    next_pm_date    = db.Column(db.Date)
    pm_interval_days= db.Column(db.Integer)
    pm_wafer_count  = db.Column(db.Integer)
    run_since_pm    = db.Column(db.Integer, default=0)
    is_current      = db.Column(db.Boolean, default=True, index=True)
    effective_from  = db.Column(db.Date)
    effective_to    = db.Column(db.Date)

    chambers = db.relationship("Chamber", backref="equipment_ref", lazy="select",
                               foreign_keys="Chamber.equipment_id",
                               primaryjoin="Equipment.equipment_id == Chamber.equipment_id")

    @property
    def composite_health(self):
        """Recompute health from components"""
        z  = float(self.z_score_component  or 0) * 35
        g  = float(self.gof_component      or 0) * 30
        cv = float(self.cv_stability_component or 0) * 20
        v  = float(self.volume_component   or 0) * 15
        return round(z + g + cv + v, 2)

    def to_dict(self):
        return {
            "equipment_id": self.equipment_id, "equipment_name": self.equipment_name,
            "equipment_alias": self.equipment_alias, "equipment_type": self.equipment_type,
            "equipment_subtype": self.equipment_subtype, "oem_vendor": self.oem_vendor,
            "oem_model": self.oem_model, "fab_id": self.fab_id, "bay_id": self.bay_id,
            "area_id": self.area_id, "chamber_count": self.chamber_count,
            "is_multi_chamber": self.is_multi_chamber, "wafer_size_mm": self.wafer_size_mm,
            "equipment_status": self.equipment_status, "is_golden_tool": self.is_golden_tool,
            "health_score": self._f(self.health_score), "health_tier": self.health_tier,
            "z_score_component": self._f(self.z_score_component),
            "gof_component": self._f(self.gof_component),
            "cv_stability_component": self._f(self.cv_stability_component),
            "volume_component": self._f(self.volume_component),
            "last_pm_date": self._d(self.last_pm_date),
            "next_pm_date": self._d(self.next_pm_date),
            "pm_interval_days": self.pm_interval_days, "run_since_pm": self.run_since_pm,
            "health_updated_at": self._d(self.health_updated_at),
        }

    def to_dict_with_chambers(self):
        d = self.to_dict()
        d["chambers"] = [c.to_dict() for c in self.chambers]
        return d


class Chamber(db.Model, TimestampMixin):
    __tablename__ = "eqp_dim_chamber"
    __table_args__ = (db.UniqueConstraint("equipment_id","chamber_id",name="uq_equip_chamber"),)

    chamber_sk     = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id   = db.Column(db.String(32), nullable=False, index=True)
    chamber_id     = db.Column(db.String(16), nullable=False)
    chamber_name   = db.Column(db.String(64))
    chamber_type   = db.Column(db.String(32))
    chamber_index  = db.Column(db.SmallInteger)
    chamber_status = db.Column(db.String(24), default="PRODUCTION")
    health_score   = db.Column(db.Numeric(5, 2))
    last_clean_date= db.Column(db.Date)
    last_pm_date   = db.Column(db.Date)
    run_since_pm   = db.Column(db.Integer, default=0)
    is_reference_chamber = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "chamber_name": self.chamber_name, "chamber_type": self.chamber_type,
            "chamber_status": self.chamber_status, "health_score": self._f(self.health_score),
            "last_pm_date": self._d(self.last_pm_date), "run_since_pm": self.run_since_pm,
            "is_reference_chamber": self.is_reference_chamber,
        }
