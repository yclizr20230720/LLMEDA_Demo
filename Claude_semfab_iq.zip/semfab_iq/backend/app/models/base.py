"""Base Model Mixin"""
from datetime import datetime
from app import db


class TimestampMixin:
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow,
                           onupdate=datetime.utcnow, nullable=False)

    @staticmethod
    def _f(v):
        """Safe float conversion"""
        return float(v) if v is not None else None

    @staticmethod
    def _d(v):
        """Safe date conversion"""
        return v.isoformat() if v is not None else None
