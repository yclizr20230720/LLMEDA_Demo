"""FDC Models"""
from app import db
from app.models.base import TimestampMixin


class FDCSensor(db.Model, TimestampMixin):
    __tablename__ = "fdc_dim_sensor"
    __table_args__ = (db.UniqueConstraint("equipment_id","sensor_alias",name="uq_fdc_sensor"),)

    sensor_sk       = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id    = db.Column(db.String(32), nullable=False, index=True)
    sensor_alias    = db.Column(db.String(128), nullable=False)
    sensor_full_name= db.Column(db.String(256))
    sensor_type     = db.Column(db.String(32))
    measurement_units= db.Column(db.String(32))
    module_id       = db.Column(db.String(16))
    module_name     = db.Column(db.String(64))
    sampling_rate_hz= db.Column(db.Numeric(10, 4))
    is_time_series  = db.Column(db.Boolean, default=True)
    is_spc_monitored= db.Column(db.Boolean, default=False)
    is_fdc_monitored= db.Column(db.Boolean, default=True)
    fdc_alarm_enabled= db.Column(db.Boolean, default=True)
    baseline_sigma_limit= db.Column(db.Numeric(6, 2), default=6.0)

    def to_dict(self):
        return {
            "equipment_id": self.equipment_id, "sensor_alias": self.sensor_alias,
            "sensor_full_name": self.sensor_full_name, "sensor_type": self.sensor_type,
            "measurement_units": self.measurement_units, "module_id": self.module_id,
            "sampling_rate_hz": self._f(self.sampling_rate_hz),
            "is_fdc_monitored": self.is_fdc_monitored,
            "baseline_sigma_limit": self._f(self.baseline_sigma_limit),
        }


class FDCIndicator(db.Model, TimestampMixin):
    __tablename__ = "fdc_dim_indicator"

    indicator_sk    = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    indicator_id    = db.Column(db.String(128), nullable=False, unique=True, index=True)
    indicator_name  = db.Column(db.String(256))
    equipment_id    = db.Column(db.String(32), index=True)
    recipe_id       = db.Column(db.String(64))
    sensor_alias    = db.Column(db.String(128))
    feature_type    = db.Column(db.String(24))
    step_segment    = db.Column(db.String(32))
    alarm_mode      = db.Column(db.String(16), default="NoSPC")
    ucl             = db.Column(db.Numeric(20, 10))
    lcl             = db.Column(db.Numeric(20, 10))
    cl              = db.Column(db.Numeric(20, 10))
    ca              = db.Column(db.Numeric(10, 6))
    cp              = db.Column(db.Numeric(10, 6))
    cpk             = db.Column(db.Numeric(10, 6))
    cpk_threshold   = db.Column(db.Numeric(10, 6), default=1.33)
    total_runs      = db.Column(db.Integer, default=0)
    total_alarms    = db.Column(db.Integer, default=0)
    alarm_rate_pct  = db.Column(db.Numeric(8, 4))
    last_alarm_time = db.Column(db.DateTime(timezone=True))
    is_active       = db.Column(db.Boolean, default=True)

    def to_dict(self):
        f = self._f
        return {
            "indicator_id": self.indicator_id, "indicator_name": self.indicator_name,
            "equipment_id": self.equipment_id, "recipe_id": self.recipe_id,
            "sensor_alias": self.sensor_alias, "feature_type": self.feature_type,
            "alarm_mode": self.alarm_mode,
            "ucl": f(self.ucl), "lcl": f(self.lcl), "cl": f(self.cl),
            "ca": f(self.ca), "cp": f(self.cp), "cpk": f(self.cpk),
            "total_runs": self.total_runs, "total_alarms": self.total_alarms,
            "alarm_rate_pct": f(self.alarm_rate_pct),
            "last_alarm_time": self._d(self.last_alarm_time),
        }


class FDCTraceRun(db.Model, TimestampMixin):
    __tablename__ = "fdc_fact_trace_run"
    __table_args__ = (db.Index("ix_fdc_run_equip_date","equipment_id","event_date"),)

    run_sk              = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    run_id              = db.Column(db.String(64), nullable=False, unique=True, index=True)
    lot_id              = db.Column(db.String(32), index=True)
    wafer_id            = db.Column(db.String(40))
    slot_number         = db.Column(db.SmallInteger)
    equipment_id        = db.Column(db.String(32), nullable=False, index=True)
    chamber_id          = db.Column(db.String(16))
    recipe_id           = db.Column(db.String(64))
    recipe_version      = db.Column(db.String(8))
    step_id             = db.Column(db.String(32))
    route_id            = db.Column(db.String(32))
    product_id          = db.Column(db.String(32))
    process_node        = db.Column(db.String(16))
    run_start_time      = db.Column(db.DateTime(timezone=True), nullable=False)
    run_end_time        = db.Column(db.DateTime(timezone=True))
    run_duration_sec    = db.Column(db.Numeric(12, 4))
    process_steps_json  = db.Column(db.Text)
    run_result          = db.Column(db.String(16), default="PASS", index=True)
    alarm_count         = db.Column(db.SmallInteger, default=0)
    alarm_sensor_list   = db.Column(db.Text)
    interval_anomaly_score   = db.Column(db.Numeric(8, 6))
    pm_anomaly_score         = db.Column(db.Numeric(8, 6))
    amplitude_anomaly_score  = db.Column(db.Numeric(8, 6))
    shape_anomaly_score      = db.Column(db.Numeric(8, 6))
    composite_anomaly_score  = db.Column(db.Numeric(8, 6), index=True)
    anomaly_class       = db.Column(db.String(32))
    is_anomaly          = db.Column(db.Boolean, default=False, index=True)
    is_post_pm          = db.Column(db.Boolean, default=False)
    pm_wafer_count      = db.Column(db.Integer)
    is_qualification_run= db.Column(db.Boolean, default=False)
    baseline_run_id     = db.Column(db.String(64))
    qual_match_score    = db.Column(db.Numeric(8, 6))
    event_date          = db.Column(db.Date, nullable=False, index=True)

    def to_dict(self):
        f = self._f
        return {
            "run_id": self.run_id, "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "recipe_id": self.recipe_id, "step_id": self.step_id,
            "product_id": self.product_id, "process_node": self.process_node,
            "run_start_time": self._d(self.run_start_time), "run_end_time": self._d(self.run_end_time),
            "run_duration_sec": f(self.run_duration_sec),
            "run_result": self.run_result, "alarm_count": self.alarm_count,
            "alarm_sensor_list": self.alarm_sensor_list,
            "interval_anomaly_score": f(self.interval_anomaly_score),
            "pm_anomaly_score": f(self.pm_anomaly_score),
            "amplitude_anomaly_score": f(self.amplitude_anomaly_score),
            "shape_anomaly_score": f(self.shape_anomaly_score),
            "composite_anomaly_score": f(self.composite_anomaly_score),
            "anomaly_class": self.anomaly_class, "is_anomaly": self.is_anomaly,
            "is_post_pm": self.is_post_pm, "pm_wafer_count": self.pm_wafer_count,
            "is_qualification_run": self.is_qualification_run,
            "qual_match_score": f(self.qual_match_score),
            "event_date": self._d(self.event_date),
        }


class FDCPMEvent(db.Model, TimestampMixin):
    __tablename__ = "fdc_fact_pm_event"

    pm_sk               = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id        = db.Column(db.String(32), nullable=False, index=True)
    chamber_id          = db.Column(db.String(16))
    pm_type             = db.Column(db.String(32))
    pm_subtype          = db.Column(db.String(32))
    pm_code             = db.Column(db.String(16))
    pm_start_time       = db.Column(db.DateTime(timezone=True), nullable=False)
    pm_end_time         = db.Column(db.DateTime(timezone=True))
    pm_duration_hr      = db.Column(db.Numeric(8, 3))
    trigger_source      = db.Column(db.String(24))
    trigger_health_score= db.Column(db.Numeric(5, 2))
    trigger_alarm_id    = db.Column(db.String(64))
    performed_by        = db.Column(db.String(64))
    oem_support         = db.Column(db.Boolean, default=False)
    parts_json          = db.Column(db.Text)
    pre_pm_health_score = db.Column(db.Numeric(5, 2))
    post_pm_health_score= db.Column(db.Numeric(5, 2))
    health_improvement  = db.Column(db.Numeric(5, 2))
    qualification_passed= db.Column(db.Boolean)
    qual_run_id         = db.Column(db.String(64))
    wafers_impacted     = db.Column(db.Integer, default=0)
    lots_on_hold        = db.Column(db.Integer, default=0)
    cmms_work_order_id  = db.Column(db.String(32))
    event_date          = db.Column(db.Date, nullable=False, index=True)

    def to_dict(self):
        f = self._f
        return {
            "pm_sk": self.pm_sk, "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "pm_type": self.pm_type, "pm_subtype": self.pm_subtype, "pm_code": self.pm_code,
            "pm_start_time": self._d(self.pm_start_time), "pm_end_time": self._d(self.pm_end_time),
            "pm_duration_hr": f(self.pm_duration_hr), "trigger_source": self.trigger_source,
            "trigger_health_score": f(self.trigger_health_score),
            "performed_by": self.performed_by, "oem_support": self.oem_support,
            "pre_pm_health_score": f(self.pre_pm_health_score),
            "post_pm_health_score": f(self.post_pm_health_score),
            "health_improvement": f(self.health_improvement),
            "qualification_passed": self.qualification_passed, "qual_run_id": self.qual_run_id,
            "wafers_impacted": self.wafers_impacted, "lots_on_hold": self.lots_on_hold,
            "cmms_work_order_id": self.cmms_work_order_id, "event_date": self._d(self.event_date),
        }
