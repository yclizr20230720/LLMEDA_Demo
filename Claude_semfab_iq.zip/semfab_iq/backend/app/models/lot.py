"""MES Lot & Wafer Models"""
from app import db
from app.models.base import TimestampMixin


class Lot(db.Model, TimestampMixin):
    __tablename__ = "mes_dim_lot"
    __table_args__ = (db.Index("ix_lot_product_node", "product_id", "process_node"),)

    lot_sk             = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id             = db.Column(db.String(32), nullable=False, index=True)
    lot_type           = db.Column(db.String(20), nullable=False, default="PRODUCTION")
    lot_subtype        = db.Column(db.String(20))
    lot_priority       = db.Column(db.SmallInteger, default=5)
    is_split_lot       = db.Column(db.Boolean, default=False)
    parent_lot_id      = db.Column(db.String(32))
    product_id         = db.Column(db.String(32), nullable=False)
    product_revision   = db.Column(db.String(8))
    device_family      = db.Column(db.String(32))
    customer_id        = db.Column(db.String(32))
    customer_order_id  = db.Column(db.String(64))
    process_node       = db.Column(db.String(16))
    technology_id      = db.Column(db.String(32))
    mask_set_id        = db.Column(db.String(32))
    lot_status         = db.Column(db.String(24), nullable=False, default="ACTIVE", index=True)
    hold_code          = db.Column(db.String(16))
    hold_reason        = db.Column(db.Text)
    wafer_count_start  = db.Column(db.SmallInteger)
    wafer_count_current= db.Column(db.SmallInteger)
    wafer_size_mm      = db.Column(db.SmallInteger, default=300)
    lot_start_date     = db.Column(db.DateTime(timezone=True))
    lot_target_date    = db.Column(db.DateTime(timezone=True))
    lot_complete_date  = db.Column(db.DateTime(timezone=True))
    target_yield_pct   = db.Column(db.Numeric(6, 3))
    syl_pct            = db.Column(db.Numeric(6, 3))
    sbl_pct            = db.Column(db.Numeric(6, 3))
    is_current         = db.Column(db.Boolean, default=True, index=True)
    effective_from     = db.Column(db.DateTime(timezone=True))
    effective_to       = db.Column(db.DateTime(timezone=True))
    source_system      = db.Column(db.String(32))

    wafers = db.relationship("Wafer", backref="lot", lazy="dynamic",
                             foreign_keys="Wafer.lot_id",
                             primaryjoin="Lot.lot_id == Wafer.lot_id")

    def to_dict(self):
        return {
            "lot_id": self.lot_id, "lot_type": self.lot_type, "lot_subtype": self.lot_subtype,
            "lot_priority": self.lot_priority, "product_id": self.product_id,
            "product_revision": self.product_revision, "device_family": self.device_family,
            "customer_id": self.customer_id, "process_node": self.process_node,
            "technology_id": self.technology_id, "lot_status": self.lot_status,
            "hold_code": self.hold_code, "hold_reason": self.hold_reason,
            "wafer_count_start": self.wafer_count_start,
            "wafer_count_current": self.wafer_count_current,
            "wafer_size_mm": self.wafer_size_mm,
            "lot_start_date": self._d(self.lot_start_date),
            "lot_target_date": self._d(self.lot_target_date),
            "lot_complete_date": self._d(self.lot_complete_date),
            "target_yield_pct": self._f(self.target_yield_pct),
            "syl_pct": self._f(self.syl_pct), "sbl_pct": self._f(self.sbl_pct),
            "is_current": self.is_current,
        }


class Wafer(db.Model, TimestampMixin):
    __tablename__ = "mes_dim_wafer"
    __table_args__ = (db.UniqueConstraint("lot_id", "slot_number", name="uq_lot_slot"),)

    wafer_sk          = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id            = db.Column(db.String(32), nullable=False, index=True)
    wafer_id          = db.Column(db.String(40), nullable=False)
    slot_number       = db.Column(db.SmallInteger, nullable=False)
    wafer_status      = db.Column(db.String(20), default="ACTIVE")
    scrap_reason      = db.Column(db.String(64))
    wafer_barcode     = db.Column(db.String(64))
    die_per_wafer     = db.Column(db.Integer)
    die_count_good    = db.Column(db.Integer)
    die_size_x_um     = db.Column(db.Numeric(10, 3))
    die_size_y_um     = db.Column(db.Numeric(10, 3))
    cp_yield_pct      = db.Column(db.Numeric(6, 3))
    wat_status        = db.Column(db.String(16))
    final_disposition = db.Column(db.String(24))

    def to_dict(self):
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "slot_number": self.slot_number,
            "wafer_status": self.wafer_status, "die_per_wafer": self.die_per_wafer,
            "die_count_good": self.die_count_good,
            "cp_yield_pct": self._f(self.cp_yield_pct), "final_disposition": self.final_disposition,
        }
