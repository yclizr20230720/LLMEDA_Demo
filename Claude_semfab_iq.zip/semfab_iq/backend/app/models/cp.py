"""CP (Circuit Probe) Models"""
from app import db
from app.models.base import TimestampMixin


class CPDieResult(db.Model, TimestampMixin):
    __tablename__ = "cp_fact_die_result"
    __table_args__ = (
        db.Index("ix_cp_lot_wafer", "lot_id", "wafer_id"),
        db.Index("ix_cp_bin_date", "hard_bin", "event_date"),
    )

    die_sk              = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id              = db.Column(db.String(32), nullable=False, index=True)
    wafer_id            = db.Column(db.String(40), nullable=False)
    slot_number         = db.Column(db.SmallInteger)
    die_x               = db.Column(db.SmallInteger, nullable=False)
    die_y               = db.Column(db.SmallInteger, nullable=False)
    die_index           = db.Column(db.Integer)
    program_id          = db.Column(db.String(64), nullable=False)
    tester_id           = db.Column(db.String(32))
    load_board_id       = db.Column(db.String(32))
    probe_card_id       = db.Column(db.String(32))
    site_number         = db.Column(db.SmallInteger)
    hard_bin            = db.Column(db.SmallInteger, nullable=False)
    soft_bin            = db.Column(db.SmallInteger)
    is_pass             = db.Column(db.Boolean, nullable=False)
    test_count          = db.Column(db.SmallInteger, default=1)
    retest_hard_bin     = db.Column(db.SmallInteger)
    test_time_ms        = db.Column(db.Numeric(10, 4))
    touchdown_number    = db.Column(db.SmallInteger)
    touch_x             = db.Column(db.Numeric(8, 4))
    touch_y             = db.Column(db.Numeric(8, 4))
    was_tested          = db.Column(db.Boolean, default=True)
    skip_reason         = db.Column(db.String(24))
    is_edge_die         = db.Column(db.Boolean, default=False)
    edge_zone           = db.Column(db.String(16))
    is_inkout_candidate = db.Column(db.Boolean, default=False)
    is_spatial_cluster  = db.Column(db.Boolean, default=False)
    cluster_id          = db.Column(db.Integer)
    test_time           = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date          = db.Column(db.Date, nullable=False, index=True)
    product_id          = db.Column(db.String(32))
    process_node        = db.Column(db.String(16))

    def to_dict(self):
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "slot_number": self.slot_number,
            "die_x": self.die_x, "die_y": self.die_y, "die_index": self.die_index,
            "program_id": self.program_id, "tester_id": self.tester_id,
            "hard_bin": self.hard_bin, "soft_bin": self.soft_bin, "is_pass": self.is_pass,
            "test_count": self.test_count, "touchdown_number": self.touchdown_number,
            "was_tested": self.was_tested, "skip_reason": self.skip_reason,
            "is_edge_die": self.is_edge_die, "is_spatial_cluster": self.is_spatial_cluster,
            "cluster_id": self.cluster_id,
            "test_time": self._d(self.test_time), "event_date": self._d(self.event_date),
        }


class CPWaferSummary(db.Model, TimestampMixin):
    __tablename__ = "cp_fact_wafer_summary"
    __table_args__ = (
        db.UniqueConstraint("lot_id","wafer_id","program_id","step_id",name="uq_cp_wafer_prog"),
        db.Index("ix_cp_ws_lot_date","lot_id","event_date"),
    )

    summary_sk             = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id                 = db.Column(db.String(32), nullable=False, index=True)
    wafer_id               = db.Column(db.String(40), nullable=False)
    slot_number            = db.Column(db.SmallInteger)
    program_id             = db.Column(db.String(64))
    tester_id              = db.Column(db.String(32))
    step_id                = db.Column(db.String(32))
    total_die              = db.Column(db.Integer)
    pass_die               = db.Column(db.Integer)
    fail_die               = db.Column(db.Integer)
    skip_die               = db.Column(db.Integer, default=0)
    gross_yield_pct        = db.Column(db.Numeric(7, 4))
    net_yield_pct          = db.Column(db.Numeric(7, 4))
    first_pass_yield       = db.Column(db.Numeric(7, 4))
    retest_count           = db.Column(db.Integer, default=0)
    retest_pass_count      = db.Column(db.Integer, default=0)
    offline_retest_rate    = db.Column(db.Numeric(7, 4))
    good_part_uph          = db.Column(db.Numeric(10, 3))
    avg_sites              = db.Column(db.Numeric(6, 2))
    os_rate                = db.Column(db.Numeric(6, 3))
    bin_counts_json        = db.Column(db.Text)
    site_yields_json       = db.Column(db.Text)
    pattern_class_generic  = db.Column(db.String(32))
    pattern_class_primary  = db.Column(db.String(32))
    pattern_class_secondary= db.Column(db.String(32))
    pattern_confidence     = db.Column(db.Numeric(6, 4))
    edge_yield_pct         = db.Column(db.Numeric(7, 4))
    center_yield_pct       = db.Column(db.Numeric(7, 4))
    edge_center_delta      = db.Column(db.Numeric(7, 4))
    defect_density_cm2     = db.Column(db.Numeric(12, 6))
    predicted_yield_pct    = db.Column(db.Numeric(7, 4))
    is_partial_wafer       = db.Column(db.Boolean, default=False)
    is_split_wafer         = db.Column(db.Boolean, default=False)
    syl_flag               = db.Column(db.Boolean, default=False, index=True)
    sbl_flag               = db.Column(db.Boolean, default=False)
    wafer_pattern_flag     = db.Column(db.Boolean, default=False)
    wafer_cluster_flag     = db.Column(db.Boolean, default=False)
    mrb_required           = db.Column(db.Boolean, default=False, index=True)
    mrb_result             = db.Column(db.String(16))
    tray_id                = db.Column(db.String(32))
    tray_slot              = db.Column(db.SmallInteger)
    event_date             = db.Column(db.Date, nullable=False, index=True)
    test_time              = db.Column(db.DateTime(timezone=True))
    product_id             = db.Column(db.String(32))
    process_node           = db.Column(db.String(16))

    def to_dict(self):
        f = self._f
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "slot_number": self.slot_number,
            "program_id": self.program_id, "tester_id": self.tester_id, "step_id": self.step_id,
            "total_die": self.total_die, "pass_die": self.pass_die, "fail_die": self.fail_die,
            "skip_die": self.skip_die,
            "gross_yield_pct": f(self.gross_yield_pct), "net_yield_pct": f(self.net_yield_pct),
            "first_pass_yield": f(self.first_pass_yield), "retest_count": self.retest_count,
            "retest_pass_count": self.retest_pass_count,
            "offline_retest_rate": f(self.offline_retest_rate),
            "good_part_uph": f(self.good_part_uph), "avg_sites": f(self.avg_sites),
            "bin_counts_json": self.bin_counts_json, "site_yields_json": self.site_yields_json,
            "pattern_class_generic": self.pattern_class_generic,
            "pattern_class_primary": self.pattern_class_primary,
            "pattern_class_secondary": self.pattern_class_secondary,
            "pattern_confidence": f(self.pattern_confidence),
            "edge_yield_pct": f(self.edge_yield_pct), "center_yield_pct": f(self.center_yield_pct),
            "edge_center_delta": f(self.edge_center_delta),
            "defect_density_cm2": f(self.defect_density_cm2),
            "is_partial_wafer": self.is_partial_wafer, "is_split_wafer": self.is_split_wafer,
            "syl_flag": self.syl_flag, "sbl_flag": self.sbl_flag,
            "wafer_pattern_flag": self.wafer_pattern_flag, "wafer_cluster_flag": self.wafer_cluster_flag,
            "mrb_required": self.mrb_required, "mrb_result": self.mrb_result,
            "event_date": self._d(self.event_date), "test_time": self._d(self.test_time),
            "product_id": self.product_id, "process_node": self.process_node,
        }
