"""WAT Models"""
from app import db
from app.models.base import TimestampMixin


class WATParameter(db.Model, TimestampMixin):
    __tablename__ = "wat_dim_parameter"

    parameter_sk    = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    parameter_id    = db.Column(db.String(64), nullable=False, unique=True, index=True)
    parameter_name  = db.Column(db.String(128), nullable=False)
    parameter_group = db.Column(db.String(32))
    device_type     = db.Column(db.String(32))
    mos_type        = db.Column(db.String(8))
    test_structure  = db.Column(db.String(32))
    parameter_type  = db.Column(db.String(24))
    unit            = db.Column(db.String(16))
    unit_prefix     = db.Column(db.String(8))
    display_unit    = db.Column(db.String(16))
    scale_factor    = db.Column(db.Numeric(20, 10), default=1.0)
    nominal_value   = db.Column(db.Numeric(20, 10))
    is_spc_monitored= db.Column(db.Boolean, default=False)
    spc_chart_type  = db.Column(db.String(16))
    is_dof_parameter= db.Column(db.Boolean, default=False)
    criticality_rank= db.Column(db.SmallInteger)
    layer_name      = db.Column(db.String(32))
    process_module  = db.Column(db.String(32))

    def to_dict(self):
        return {
            "parameter_id": self.parameter_id, "parameter_name": self.parameter_name,
            "parameter_group": self.parameter_group, "device_type": self.device_type,
            "mos_type": self.mos_type, "unit": self.unit, "display_unit": self.display_unit,
            "is_spc_monitored": self.is_spc_monitored, "criticality_rank": self.criticality_rank,
            "layer_name": self.layer_name, "process_module": self.process_module,
        }


class WATSpec(db.Model, TimestampMixin):
    __tablename__ = "wat_dim_spec"
    __table_args__ = (
        db.UniqueConstraint("product_id","technology_id","parameter_id","vcc","temp_c",
                            name="uq_wat_spec"),
    )

    spec_sk       = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    product_id    = db.Column(db.String(32), nullable=False, index=True)
    technology_id = db.Column(db.String(32), nullable=False)
    parameter_id  = db.Column(db.String(64), nullable=False, index=True)
    recipe_id     = db.Column(db.String(64))
    vcc           = db.Column(db.Numeric(8, 4))
    temp_c        = db.Column(db.Numeric(8, 3))
    freq_hz       = db.Column(db.Numeric(16, 4))
    usl           = db.Column(db.Numeric(20, 10))
    lsl           = db.Column(db.Numeric(20, 10))
    target        = db.Column(db.Numeric(20, 10))
    usl_tight     = db.Column(db.Numeric(20, 10))
    lsl_tight     = db.Column(db.Numeric(20, 10))
    spc_ucl       = db.Column(db.Numeric(20, 10))
    spc_lcl       = db.Column(db.Numeric(20, 10))
    spc_cl        = db.Column(db.Numeric(20, 10))
    spc_sigma     = db.Column(db.Numeric(20, 10))
    limit_source  = db.Column(db.String(24))
    limit_version = db.Column(db.String(8))
    effective_date= db.Column(db.Date)
    obsolete_date = db.Column(db.Date)

    def to_dict(self):
        return {
            "product_id": self.product_id, "technology_id": self.technology_id,
            "parameter_id": self.parameter_id, "vcc": self._f(self.vcc),
            "temp_c": self._f(self.temp_c), "usl": self._f(self.usl), "lsl": self._f(self.lsl),
            "target": self._f(self.target), "spc_ucl": self._f(self.spc_ucl),
            "spc_lcl": self._f(self.spc_lcl), "spc_cl": self._f(self.spc_cl),
            "spc_sigma": self._f(self.spc_sigma),
        }


class WATResult(db.Model, TimestampMixin):
    __tablename__ = "wat_fact_result"
    __table_args__ = (
        db.Index("ix_wat_param_date", "parameter_id", "event_date"),
        db.Index("ix_wat_equip_date", "equipment_id", "event_date"),
        db.Index("ix_wat_lot_wafer", "lot_id", "wafer_id"),
    )

    result_sk       = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id          = db.Column(db.String(32), nullable=False, index=True)
    wafer_id        = db.Column(db.String(40), nullable=False)
    slot_number     = db.Column(db.SmallInteger)
    site_id         = db.Column(db.SmallInteger, nullable=False)
    site_x          = db.Column(db.Numeric(8, 4))
    site_y          = db.Column(db.Numeric(8, 4))
    site_zone       = db.Column(db.String(8))
    parameter_id    = db.Column(db.String(64), nullable=False)
    parameter_group = db.Column(db.String(32))
    vcc             = db.Column(db.Numeric(8, 4))
    temp_c          = db.Column(db.Numeric(8, 3))
    freq_hz         = db.Column(db.Numeric(16, 4))
    measured_value  = db.Column(db.Numeric(20, 10), nullable=False)
    raw_value       = db.Column(db.Numeric(20, 10))
    usl             = db.Column(db.Numeric(20, 10))
    lsl             = db.Column(db.Numeric(20, 10))
    target_value    = db.Column(db.Numeric(20, 10))
    pass_fail       = db.Column(db.String(1))
    fail_code       = db.Column(db.String(16))
    sigma_deviation = db.Column(db.Numeric(10, 6))
    cpk_contribution= db.Column(db.Numeric(10, 6))
    equipment_id    = db.Column(db.String(32), index=True)
    chamber_id      = db.Column(db.String(16))
    recipe_id       = db.Column(db.String(64))
    tester_id       = db.Column(db.String(32))
    prober_id       = db.Column(db.String(32))
    route_id        = db.Column(db.String(32))
    step_id         = db.Column(db.String(32))
    process_node    = db.Column(db.String(16))
    product_id      = db.Column(db.String(32))
    is_outlier_mad  = db.Column(db.Boolean, default=False, index=True)
    is_outlier_grubbs = db.Column(db.Boolean, default=False)
    is_outlier_iqr  = db.Column(db.Boolean, default=False)
    outlier_z_score = db.Column(db.Numeric(10, 6))
    is_anomaly_ml   = db.Column(db.Boolean, default=False)
    anomaly_score   = db.Column(db.Numeric(6, 4))
    test_time       = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date      = db.Column(db.Date, nullable=False, index=True)
    lot_sequence    = db.Column(db.Integer)

    def to_dict(self):
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "slot_number": self.slot_number,
            "site_id": self.site_id, "site_x": self._f(self.site_x), "site_y": self._f(self.site_y),
            "site_zone": self.site_zone, "parameter_id": self.parameter_id,
            "parameter_group": self.parameter_group, "vcc": self._f(self.vcc),
            "temp_c": self._f(self.temp_c), "measured_value": self._f(self.measured_value),
            "usl": self._f(self.usl), "lsl": self._f(self.lsl), "target_value": self._f(self.target_value),
            "pass_fail": self.pass_fail, "sigma_deviation": self._f(self.sigma_deviation),
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "recipe_id": self.recipe_id, "process_node": self.process_node, "product_id": self.product_id,
            "is_outlier_mad": self.is_outlier_mad, "anomaly_score": self._f(self.anomaly_score),
            "test_time": self._d(self.test_time), "event_date": self._d(self.event_date),
            "lot_sequence": self.lot_sequence,
        }


class WATLotSummary(db.Model, TimestampMixin):
    __tablename__ = "wat_agg_lot_summary"
    __table_args__ = (
        db.UniqueConstraint("lot_id","wafer_id","parameter_id","vcc","temp_c",name="uq_wat_summary"),
    )

    summary_sk    = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id        = db.Column(db.String(32), nullable=False, index=True)
    wafer_id      = db.Column(db.String(40), nullable=False)
    parameter_id  = db.Column(db.String(64), nullable=False, index=True)
    vcc           = db.Column(db.Numeric(8, 4))
    temp_c        = db.Column(db.Numeric(8, 3))
    product_id    = db.Column(db.String(32))
    equipment_id  = db.Column(db.String(32), index=True)
    event_date    = db.Column(db.Date, nullable=False, index=True)
    n_sites       = db.Column(db.SmallInteger)
    mean_value    = db.Column(db.Numeric(20, 10))
    median_value  = db.Column(db.Numeric(20, 10))
    std_dev       = db.Column(db.Numeric(20, 10))
    variance      = db.Column(db.Numeric(20, 10))
    min_value     = db.Column(db.Numeric(20, 10))
    max_value     = db.Column(db.Numeric(20, 10))
    range_value   = db.Column(db.Numeric(20, 10))
    p5_value      = db.Column(db.Numeric(20, 10))
    p25_value     = db.Column(db.Numeric(20, 10))
    p75_value     = db.Column(db.Numeric(20, 10))
    p95_value     = db.Column(db.Numeric(20, 10))
    skewness      = db.Column(db.Numeric(10, 6))
    kurtosis      = db.Column(db.Numeric(10, 6))
    usl           = db.Column(db.Numeric(20, 10))
    lsl           = db.Column(db.Numeric(20, 10))
    cp            = db.Column(db.Numeric(10, 6))
    cpk           = db.Column(db.Numeric(10, 6))
    cpm           = db.Column(db.Numeric(10, 6))
    pp            = db.Column(db.Numeric(10, 6))
    ppk           = db.Column(db.Numeric(10, 6))
    shapiro_wilk_p= db.Column(db.Numeric(10, 8))
    is_normal_dist= db.Column(db.Boolean)
    dist_fit_type = db.Column(db.String(20))
    n_pass        = db.Column(db.SmallInteger)
    n_fail        = db.Column(db.SmallInteger)
    pass_rate_pct = db.Column(db.Numeric(6, 3))

    def to_dict(self):
        f = self._f
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "parameter_id": self.parameter_id,
            "vcc": f(self.vcc), "temp_c": f(self.temp_c),
            "product_id": self.product_id, "equipment_id": self.equipment_id,
            "event_date": self._d(self.event_date), "n_sites": self.n_sites,
            "mean_value": f(self.mean_value), "median_value": f(self.median_value),
            "std_dev": f(self.std_dev), "min_value": f(self.min_value), "max_value": f(self.max_value),
            "p5_value": f(self.p5_value), "p25_value": f(self.p25_value),
            "p75_value": f(self.p75_value), "p95_value": f(self.p95_value),
            "skewness": f(self.skewness), "kurtosis": f(self.kurtosis),
            "usl": f(self.usl), "lsl": f(self.lsl),
            "cp": f(self.cp), "cpk": f(self.cpk), "cpm": f(self.cpm),
            "pp": f(self.pp), "ppk": f(self.ppk),
            "shapiro_wilk_p": f(self.shapiro_wilk_p), "is_normal_dist": self.is_normal_dist,
            "dist_fit_type": self.dist_fit_type,
            "n_pass": self.n_pass, "n_fail": self.n_fail, "pass_rate_pct": f(self.pass_rate_pct),
        }
