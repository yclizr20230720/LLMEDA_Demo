"""SPC Models"""
from app import db
from app.models.base import TimestampMixin


class SPCConfig(db.Model, TimestampMixin):
    __tablename__ = "spc_dim_parameter_config"

    config_sk        = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id        = db.Column(db.String(64), nullable=False, unique=True, index=True)
    parameter_id     = db.Column(db.String(64), nullable=False, index=True)
    parameter_source = db.Column(db.String(20), nullable=False, default="WAT")
    parameter_desc   = db.Column(db.String(256))
    product_id       = db.Column(db.String(32))
    technology_id    = db.Column(db.String(32))
    equipment_id     = db.Column(db.String(32), index=True)
    chamber_id       = db.Column(db.String(16))
    recipe_id        = db.Column(db.String(64))
    step_id          = db.Column(db.String(32))
    chart_type       = db.Column(db.String(16), nullable=False, default="IMR")
    subgroup_size    = db.Column(db.SmallInteger, default=1)
    subgroup_method  = db.Column(db.String(24))
    ucl              = db.Column(db.Numeric(20, 10))
    cl               = db.Column(db.Numeric(20, 10))
    lcl              = db.Column(db.Numeric(20, 10))
    ucl_2sigma       = db.Column(db.Numeric(20, 10))
    lcl_2sigma       = db.Column(db.Numeric(20, 10))
    ucl_1sigma       = db.Column(db.Numeric(20, 10))
    lcl_1sigma       = db.Column(db.Numeric(20, 10))
    sigma_estimate   = db.Column(db.Numeric(20, 10))
    usl              = db.Column(db.Numeric(20, 10))
    lsl              = db.Column(db.Numeric(20, 10))
    target           = db.Column(db.Numeric(20, 10))
    phase1_lot_count = db.Column(db.Integer)
    phase1_start_date= db.Column(db.Date)
    phase1_end_date  = db.Column(db.Date)
    phase1_method    = db.Column(db.String(24))
    enabled_rules    = db.Column(db.SmallInteger, default=255)
    alarm_mode       = db.Column(db.String(16), default="EMAIL")
    alarm_severity   = db.Column(db.String(16), default="MAJOR")
    is_virtual       = db.Column(db.Boolean, default=False)
    vm_model_id      = db.Column(db.String(64))
    vm_feature_list  = db.Column(db.Text)
    vm_r_squared     = db.Column(db.Numeric(10, 8))
    is_active        = db.Column(db.Boolean, default=True, index=True)
    limit_version    = db.Column(db.Integer, default=1)
    created_by       = db.Column(db.String(64))

    measurements = db.relationship("SPCMeasurement", backref="config_ref", lazy="dynamic",
                                   foreign_keys="SPCMeasurement.config_id",
                                   primaryjoin="SPCConfig.config_id == SPCMeasurement.config_id")

    def to_dict(self):
        f = self._f
        return {
            "config_id": self.config_id, "parameter_id": self.parameter_id,
            "parameter_source": self.parameter_source, "parameter_desc": self.parameter_desc,
            "product_id": self.product_id, "equipment_id": self.equipment_id,
            "chamber_id": self.chamber_id, "step_id": self.step_id, "chart_type": self.chart_type,
            "subgroup_size": self.subgroup_size,
            "ucl": f(self.ucl), "cl": f(self.cl), "lcl": f(self.lcl),
            "ucl_2sigma": f(self.ucl_2sigma), "lcl_2sigma": f(self.lcl_2sigma),
            "ucl_1sigma": f(self.ucl_1sigma), "lcl_1sigma": f(self.lcl_1sigma),
            "sigma_estimate": f(self.sigma_estimate),
            "usl": f(self.usl), "lsl": f(self.lsl), "target": f(self.target),
            "enabled_rules": self.enabled_rules, "alarm_mode": self.alarm_mode,
            "alarm_severity": self.alarm_severity, "is_virtual": self.is_virtual,
            "vm_model_id": self.vm_model_id, "vm_r_squared": f(self.vm_r_squared),
            "is_active": self.is_active, "limit_version": self.limit_version,
        }


class SPCMeasurement(db.Model, TimestampMixin):
    __tablename__ = "spc_fact_measurement"
    __table_args__ = (
        db.Index("ix_spc_config_date", "config_id", "event_date"),
        db.Index("ix_spc_equip_date", "equipment_id", "event_date"),
        db.Index("ix_spc_violation", "any_violation", "event_date"),
    )

    measurement_sk  = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id       = db.Column(db.String(64), nullable=False, index=True)
    parameter_id    = db.Column(db.String(64), nullable=False)
    lot_id          = db.Column(db.String(32), index=True)
    wafer_id        = db.Column(db.String(40))
    slot_number     = db.Column(db.SmallInteger)
    equipment_id    = db.Column(db.String(32), index=True)
    chamber_id      = db.Column(db.String(16))
    recipe_id       = db.Column(db.String(64))
    operator_id     = db.Column(db.String(32))
    shift           = db.Column(db.String(8))
    subgroup_id     = db.Column(db.String(64))
    subgroup_index  = db.Column(db.Integer)
    measured_value  = db.Column(db.Numeric(20, 10), nullable=False)
    subgroup_mean   = db.Column(db.Numeric(20, 10))
    subgroup_range  = db.Column(db.Numeric(20, 10))
    subgroup_std    = db.Column(db.Numeric(20, 10))
    moving_range    = db.Column(db.Numeric(20, 10))
    ucl_at_time     = db.Column(db.Numeric(20, 10))
    cl_at_time      = db.Column(db.Numeric(20, 10))
    lcl_at_time     = db.Column(db.Numeric(20, 10))
    usl_at_time     = db.Column(db.Numeric(20, 10))
    lsl_at_time     = db.Column(db.Numeric(20, 10))
    sigma_score     = db.Column(db.Numeric(10, 6))
    # 8 WE rules as individual booleans
    violation_rule_1= db.Column(db.Boolean, default=False)
    violation_rule_2= db.Column(db.Boolean, default=False)
    violation_rule_3= db.Column(db.Boolean, default=False)
    violation_rule_4= db.Column(db.Boolean, default=False)
    violation_rule_5= db.Column(db.Boolean, default=False)
    violation_rule_6= db.Column(db.Boolean, default=False)
    violation_rule_7= db.Column(db.Boolean, default=False)
    violation_rule_8= db.Column(db.Boolean, default=False)
    any_violation   = db.Column(db.Boolean, default=False, index=True)
    violation_rules_list = db.Column(db.String(32))
    alarm_triggered = db.Column(db.Boolean, default=False)
    alarm_id        = db.Column(db.String(64))
    alarm_severity  = db.Column(db.String(16))
    is_virtual      = db.Column(db.Boolean, default=False)
    vm_predicted_value = db.Column(db.Numeric(20, 10))
    vm_ci_lower     = db.Column(db.Numeric(20, 10))
    vm_ci_upper     = db.Column(db.Numeric(20, 10))
    vm_prediction_error = db.Column(db.Numeric(20, 10))
    measurement_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date      = db.Column(db.Date, nullable=False, index=True)

    def to_dict(self):
        f = self._f
        return {
            "measurement_sk": self.measurement_sk, "config_id": self.config_id,
            "parameter_id": self.parameter_id, "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "subgroup_index": self.subgroup_index, "measured_value": f(self.measured_value),
            "subgroup_mean": f(self.subgroup_mean), "subgroup_range": f(self.subgroup_range),
            "subgroup_std": f(self.subgroup_std), "moving_range": f(self.moving_range),
            "ucl_at_time": f(self.ucl_at_time), "cl_at_time": f(self.cl_at_time),
            "lcl_at_time": f(self.lcl_at_time), "usl_at_time": f(self.usl_at_time),
            "lsl_at_time": f(self.lsl_at_time), "sigma_score": f(self.sigma_score),
            "violation_rule_1": self.violation_rule_1, "violation_rule_2": self.violation_rule_2,
            "violation_rule_3": self.violation_rule_3, "violation_rule_4": self.violation_rule_4,
            "violation_rule_5": self.violation_rule_5, "violation_rule_6": self.violation_rule_6,
            "violation_rule_7": self.violation_rule_7, "violation_rule_8": self.violation_rule_8,
            "any_violation": self.any_violation, "violation_rules_list": self.violation_rules_list,
            "alarm_triggered": self.alarm_triggered, "alarm_severity": self.alarm_severity,
            "is_virtual": self.is_virtual, "vm_predicted_value": f(self.vm_predicted_value),
            "vm_ci_lower": f(self.vm_ci_lower), "vm_ci_upper": f(self.vm_ci_upper),
            "measurement_time": self._d(self.measurement_time),
            "event_date": self._d(self.event_date),
        }


class SPCViolation(db.Model, TimestampMixin):
    __tablename__ = "spc_fact_violation"
    __table_args__ = (db.Index("ix_spc_viol_config_date","config_id","event_date"),)

    violation_sk    = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id       = db.Column(db.String(64), nullable=False, index=True)
    parameter_id    = db.Column(db.String(64), nullable=False)
    equipment_id    = db.Column(db.String(32), index=True)
    chamber_id      = db.Column(db.String(16))
    rule_number     = db.Column(db.SmallInteger, nullable=False)
    rule_description= db.Column(db.String(256))
    rule_severity   = db.Column(db.String(16))
    trigger_measurement_sk = db.Column(db.BigInteger)
    trigger_value   = db.Column(db.Numeric(20, 10))
    trigger_lot_id  = db.Column(db.String(32))
    trigger_wafer_id= db.Column(db.String(40))
    evidence_json   = db.Column(db.Text)
    sigma_deviation = db.Column(db.Numeric(10, 6))
    cl_at_violation = db.Column(db.Numeric(20, 10))
    ucl_at_violation= db.Column(db.Numeric(20, 10))
    lcl_at_violation= db.Column(db.Numeric(20, 10))
    acknowledged_by = db.Column(db.String(64))
    acknowledged_at = db.Column(db.DateTime(timezone=True))
    resolution_code = db.Column(db.String(32))
    resolution_note = db.Column(db.Text)
    lots_affected   = db.Column(db.Integer)
    yield_impact_pct= db.Column(db.Numeric(6, 3))
    agent_rca_session_id = db.Column(db.String(64))
    agent_rca_summary = db.Column(db.Text)
    violation_time  = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date      = db.Column(db.Date, nullable=False, index=True)

    def to_dict(self):
        f = self._f
        return {
            "violation_sk": self.violation_sk, "config_id": self.config_id,
            "parameter_id": self.parameter_id, "equipment_id": self.equipment_id,
            "chamber_id": self.chamber_id, "rule_number": self.rule_number,
            "rule_description": self.rule_description, "rule_severity": self.rule_severity,
            "trigger_value": f(self.trigger_value), "trigger_lot_id": self.trigger_lot_id,
            "sigma_deviation": f(self.sigma_deviation),
            "cl_at_violation": f(self.cl_at_violation),
            "ucl_at_violation": f(self.ucl_at_violation),
            "lcl_at_violation": f(self.lcl_at_violation),
            "acknowledged_by": self.acknowledged_by,
            "acknowledged_at": self._d(self.acknowledged_at),
            "resolution_code": self.resolution_code, "resolution_note": self.resolution_note,
            "lots_affected": self.lots_affected, "yield_impact_pct": f(self.yield_impact_pct),
            "violation_time": self._d(self.violation_time),
            "event_date": self._d(self.event_date),
        }


class SPCCapability(db.Model, TimestampMixin):
    __tablename__ = "spc_agg_capability"
    __table_args__ = (
        db.UniqueConstraint("config_id","period_type","period_start","equipment_id",
                            name="uq_spc_cap"),
    )

    capability_sk   = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id       = db.Column(db.String(64), nullable=False, index=True)
    parameter_id    = db.Column(db.String(64), nullable=False)
    equipment_id    = db.Column(db.String(32))
    product_id      = db.Column(db.String(32))
    period_type     = db.Column(db.String(16))
    period_start    = db.Column(db.Date, nullable=False)
    period_end      = db.Column(db.Date, nullable=False)
    n_observations  = db.Column(db.Integer)
    n_subgroups     = db.Column(db.Integer)
    cp              = db.Column(db.Numeric(10, 6))
    cpk             = db.Column(db.Numeric(10, 6))
    cpm             = db.Column(db.Numeric(10, 6))
    cpl             = db.Column(db.Numeric(10, 6))
    cpu             = db.Column(db.Numeric(10, 6))
    pp              = db.Column(db.Numeric(10, 6))
    ppk             = db.Column(db.Numeric(10, 6))
    mean_value      = db.Column(db.Numeric(20, 10))
    std_dev_within  = db.Column(db.Numeric(20, 10))
    std_dev_overall = db.Column(db.Numeric(20, 10))
    total_violations= db.Column(db.Integer, default=0)
    violations_r1   = db.Column(db.SmallInteger, default=0)
    violations_r2   = db.Column(db.SmallInteger, default=0)
    violations_r3   = db.Column(db.SmallInteger, default=0)
    violations_r4   = db.Column(db.SmallInteger, default=0)
    violations_r5   = db.Column(db.SmallInteger, default=0)
    violations_r6   = db.Column(db.SmallInteger, default=0)
    violations_r7   = db.Column(db.SmallInteger, default=0)
    violations_r8   = db.Column(db.SmallInteger, default=0)

    def to_dict(self):
        f = self._f
        return {
            "config_id": self.config_id, "parameter_id": self.parameter_id,
            "equipment_id": self.equipment_id, "period_type": self.period_type,
            "period_start": self._d(self.period_start), "period_end": self._d(self.period_end),
            "n_observations": self.n_observations, "n_subgroups": self.n_subgroups,
            "cp": f(self.cp), "cpk": f(self.cpk), "cpm": f(self.cpm),
            "cpl": f(self.cpl), "cpu": f(self.cpu), "pp": f(self.pp), "ppk": f(self.ppk),
            "mean_value": f(self.mean_value), "std_dev_within": f(self.std_dev_within),
            "std_dev_overall": f(self.std_dev_overall),
            "total_violations": self.total_violations,
            "violations_by_rule": {
                f"r{i}": getattr(self, f"violations_r{i}") for i in range(1, 9)
            },
        }
