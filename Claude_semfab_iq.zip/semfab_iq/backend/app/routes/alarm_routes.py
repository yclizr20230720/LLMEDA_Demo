"""Active Alarm Routes — Real-time alarm feed for TopBar and YMS"""
from datetime import date, timedelta, datetime
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func, desc, or_

from app import db
from app.models.spc import SPCViolation, SPCConfig
from app.models.fdc import FDCTraceRun
from app.models.cp import CPWaferSummary
from app.utils.response import success, error

alarm_bp = Blueprint("alarms", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


@alarm_bp.route("/active", methods=["GET"])
@jwt_required()
def active_alarms():
    """
    Active alarms aggregated from SPC violations, FDC anomalies, yield excursions.
    Used for TopBar alarm badge and YMS alarm feed.
    """
    days = int(request.args.get("days", 1))
    cut  = _cutoff(days)
    limit = int(request.args.get("limit", 50))

    alarms = []

    # 1. Unacknowledged SPC violations
    spc_viols = (
        SPCViolation.query
        .filter(
            SPCViolation.event_date >= cut,
            SPCViolation.acknowledged_by.is_(None),
            SPCViolation.rule_number > 0,
        )
        .order_by(desc(SPCViolation.violation_time))
        .limit(20)
        .all()
    )
    for v in spc_viols:
        severity = v.rule_severity or "MAJOR"
        alarms.append({
            "alarm_id":     f"SPC-{v.violation_sk}",
            "source":       "SPC",
            "severity":     severity,
            "title":        f"SPC Violation: Rule {v.rule_number}",
            "message":      v.rule_description or f"Rule {v.rule_number} violated",
            "entity_id":    v.config_id,
            "equipment_id": v.equipment_id,
            "lot_id":       v.trigger_lot_id,
            "timestamp":    v.violation_time.isoformat() if v.violation_time else None,
            "acknowledged": False,
        })

    # 2. FDC anomaly runs
    fdc_runs = (
        FDCTraceRun.query
        .filter(
            FDCTraceRun.event_date >= cut,
            FDCTraceRun.is_anomaly == True,
            FDCTraceRun.run_result == "ALARM",
        )
        .order_by(desc(FDCTraceRun.run_start_time))
        .limit(20)
        .all()
    )
    for r in fdc_runs:
        score = float(r.composite_anomaly_score or 0)
        alarms.append({
            "alarm_id":     f"FDC-{r.run_id}",
            "source":       "FDC",
            "severity":     "CRITICAL" if score > 0.85 else "MAJOR",
            "title":        f"FDC Anomaly: {r.anomaly_class or 'UNKNOWN'}",
            "message":      f"{r.equipment_id} / {r.chamber_id} — score {score:.3f}",
            "entity_id":    r.run_id,
            "equipment_id": r.equipment_id,
            "lot_id":       r.lot_id,
            "timestamp":    r.run_start_time.isoformat() if r.run_start_time else None,
            "acknowledged": False,
        })

    # 3. Yield excursions (SBL flag)
    excursions = (
        CPWaferSummary.query
        .filter(
            CPWaferSummary.event_date >= cut,
            CPWaferSummary.sbl_flag == True,
        )
        .order_by(desc(CPWaferSummary.test_time))
        .limit(10)
        .all()
    )
    for w in excursions:
        alarms.append({
            "alarm_id":     f"YIELD-{w.summary_sk}",
            "source":       "YIELD",
            "severity":     "CRITICAL",
            "title":        "Yield SBL Excursion",
            "message":      f"{w.lot_id} / {w.wafer_id} — {float(w.gross_yield_pct):.2f}%",
            "entity_id":    w.lot_id,
            "equipment_id": w.tester_id,
            "lot_id":       w.lot_id,
            "timestamp":    w.test_time.isoformat() if w.test_time else str(w.event_date),
            "acknowledged": False,
        })

    # Sort by timestamp desc and limit
    alarms.sort(key=lambda a: a["timestamp"] or "", reverse=True)
    alarms = alarms[:limit]

    severity_counts = {
        "CRITICAL": sum(1 for a in alarms if a["severity"] == "CRITICAL"),
        "MAJOR":    sum(1 for a in alarms if a["severity"] == "MAJOR"),
        "MINOR":    sum(1 for a in alarms if a["severity"] == "MINOR"),
    }

    return success(alarms, meta={
        "total": len(alarms),
        "by_severity": severity_counts,
        "days": days,
    })


@alarm_bp.route("/<alarm_id>/acknowledge", methods=["POST"])
@jwt_required()
def acknowledge(alarm_id: str):
    """Acknowledge an alarm by its composite ID (e.g. SPC-42, FDC-RUN_000065)."""
    identity = get_jwt_identity()
    body     = request.get_json(silent=True) or {}
    note     = body.get("note", "")

    prefix, _, eid = alarm_id.partition("-")
    prefix = prefix.upper()

    if prefix == "SPC":
        v = SPCViolation.query.get(int(eid))
        if not v:
            return error("NOT_FOUND", f"SPC violation {eid} not found", status_code=404)
        v.acknowledged_by  = identity
        v.acknowledged_at  = datetime.utcnow()
        v.resolution_note  = note
        v.resolution_code  = "ACKNOWLEDGED"
        db.session.commit()
        return success({"alarm_id": alarm_id, "acknowledged_by": identity})

    # FDC / YIELD alarms have no ack table — return accepted
    return success({"alarm_id": alarm_id, "acknowledged_by": identity,
                    "note": "Ack recorded in session only (no persistent store for this type)"})


@alarm_bp.route("/history", methods=["GET"])
@jwt_required()
def history():
    """Historical alarm log (acknowledged + unacknowledged)."""
    days  = int(request.args.get("days", 7))
    source = request.args.get("source")   # SPC | FDC | YIELD
    cut   = _cutoff(days)
    limit = min(500, int(request.args.get("limit", 100)))

    alarms = []

    if not source or source == "SPC":
        spc_viols = (
            SPCViolation.query
            .filter(SPCViolation.event_date >= cut, SPCViolation.rule_number > 0)
            .order_by(desc(SPCViolation.violation_time))
            .limit(limit)
            .all()
        )
        for v in spc_viols:
            alarms.append({
                "alarm_id":       f"SPC-{v.violation_sk}",
                "source":         "SPC",
                "severity":       v.rule_severity or "MAJOR",
                "title":          f"Rule {v.rule_number}: {v.rule_description or ''}",
                "entity_id":      v.config_id,
                "equipment_id":   v.equipment_id,
                "lot_id":         v.trigger_lot_id,
                "timestamp":      v.violation_time.isoformat() if v.violation_time else None,
                "acknowledged":   v.acknowledged_by is not None,
                "acknowledged_by": v.acknowledged_by,
                "resolution_code": v.resolution_code,
            })

    if not source or source == "FDC":
        fdc_runs = (
            FDCTraceRun.query
            .filter(FDCTraceRun.event_date >= cut, FDCTraceRun.is_anomaly == True)
            .order_by(desc(FDCTraceRun.run_start_time))
            .limit(limit)
            .all()
        )
        for r in fdc_runs:
            alarms.append({
                "alarm_id":     f"FDC-{r.run_id}",
                "source":       "FDC",
                "severity":     "CRITICAL" if float(r.composite_anomaly_score or 0) > 0.85 else "MAJOR",
                "title":        f"{r.equipment_id} FDC Anomaly",
                "entity_id":    r.run_id,
                "equipment_id": r.equipment_id,
                "lot_id":       r.lot_id,
                "timestamp":    r.run_start_time.isoformat() if r.run_start_time else None,
                "acknowledged": False,
            })

    alarms.sort(key=lambda a: a.get("timestamp") or "", reverse=True)
    return success(alarms[:limit], meta={"total": len(alarms), "days": days})
