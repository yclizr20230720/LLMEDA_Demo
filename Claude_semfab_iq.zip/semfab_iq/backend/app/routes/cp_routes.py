"""CP (Circuit Probe) Routes — Bin Map, Wafer Summary, MRB, Site Yield, Die Detail"""
import json
from collections import defaultdict
from datetime import date, timedelta, datetime

from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func, desc, and_

from app import db, cache
from app.models.cp import CPDieResult, CPWaferSummary
from app.models.lot import Lot
from app.utils.response import success, error, paginated

cp_bp = Blueprint("cp", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/bin-map", methods=["GET"])
@jwt_required()
@cache.cached(timeout=3600, query_string=True)
def bin_map():
    """
    Columnar binary-optimised bin map for a single wafer.
    Returns xs / ys / bins / passes as separate arrays for sub-2ms Canvas rendering.
    """
    lot_id   = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id or not wafer_id:
        return error("MISSING_PARAM", "lot_id and wafer_id are required")

    dies = (
        CPDieResult.query
        .filter_by(lot_id=lot_id, wafer_id=wafer_id)
        .order_by(CPDieResult.die_y, CPDieResult.die_x)
        .all()
    )
    if not dies:
        return error("NOT_FOUND", f"No die data for {lot_id} / {wafer_id}", status_code=404)

    xs     = [d.die_x     for d in dies]
    ys     = [d.die_y     for d in dies]
    bins   = [d.hard_bin  for d in dies]
    passes = [d.is_pass   for d in dies]

    # Bin statistics
    bin_counts: dict = defaultdict(int)
    for b in bins:
        bin_counts[str(b)] += 1
    total = len(bins)
    pass_count = sum(passes)

    return success({
        "lot_id": lot_id, "wafer_id": wafer_id,
        "xs": xs, "ys": ys, "bins": bins, "passes": passes,
        "die_count": total, "pass_count": pass_count, "fail_count": total - pass_count,
        "gross_yield_pct": round(pass_count / total * 100, 4) if total else 0,
        "bin_counts": dict(bin_counts),
    }, meta={"encoding": "columnar", "renderer_hint": "canvas_bitmap"})


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/wafer-summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def wafer_summary():
    """All wafer summaries for a lot (for gallery view)."""
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    wafers = (
        CPWaferSummary.query
        .filter_by(lot_id=lot_id)
        .order_by(CPWaferSummary.slot_number)
        .all()
    )
    if not wafers:
        return error("NOT_FOUND", f"No wafer data for lot {lot_id}", status_code=404)

    return success(
        [w.to_dict() for w in wafers],
        meta={"lot_id": lot_id, "wafer_count": len(wafers)}
    )


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/mrb-review", methods=["GET"])
@jwt_required()
def mrb_review():
    """
    MRB (Material Review Board) consolidation — wafers flagged for review.
    Columns: SYL, SBL, wafer_pattern, wafer_cluster, partial_wafer, MRB result.
    """
    days         = int(request.args.get("days", 7))
    product_id   = request.args.get("product_id")
    lot_id       = request.args.get("lot_id")
    result_filter = request.args.get("mrb_result")   # GoodWafer | BadWafer
    cut = _cutoff(days)

    q = CPWaferSummary.query.filter(
        CPWaferSummary.event_date >= cut,
        CPWaferSummary.mrb_required == True,
    )
    if product_id: q = q.filter(CPWaferSummary.product_id == product_id)
    if lot_id:     q = q.filter(CPWaferSummary.lot_id == lot_id)
    if result_filter: q = q.filter(CPWaferSummary.mrb_result == result_filter)

    wafers = q.order_by(desc(CPWaferSummary.event_date), CPWaferSummary.lot_id,
                         CPWaferSummary.slot_number).limit(500).all()

    rows = []
    for w in wafers:
        d = w.to_dict()
        # Explicitly expose MRB columns at top level for table rendering
        d["partial_wafer"]     = w.is_partial_wafer
        d["wafer_cluster_flag"] = w.wafer_cluster_flag
        d["wafer_pattern_flag"] = w.wafer_pattern_flag
        rows.append(d)

    summary_stats = {
        "total": len(rows),
        "bad_wafer": sum(1 for r in rows if r["mrb_result"] == "BadWafer"),
        "good_wafer": sum(1 for r in rows if r["mrb_result"] == "GoodWafer"),
        "syl_count": sum(1 for r in rows if r["syl_flag"]),
        "sbl_count": sum(1 for r in rows if r["sbl_flag"]),
        "pattern_count": sum(1 for r in rows if r["wafer_pattern_flag"]),
    }
    return success(rows, meta={**summary_stats, "days": days})


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/die-result/<int:die_sk>", methods=["GET"])
@jwt_required()
def die_result(die_sk: int):
    """Single die detail by primary key."""
    die = CPDieResult.query.get(die_sk)
    if not die:
        return error("NOT_FOUND", f"Die {die_sk} not found", status_code=404)
    return success(die.to_dict())


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/touchdown-summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def touchdown_summary():
    """Retest / touchdown summary: first vs. retest yield per wafer."""
    lot_id   = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    q = (
        db.session.query(
            CPDieResult.touchdown_number,
            func.count(CPDieResult.die_sk).label("n"),
            func.sum(func.cast(CPDieResult.is_pass, db.Integer)).label("pass_n"),
        )
        .filter(CPDieResult.lot_id == lot_id)
    )
    if wafer_id:
        q = q.filter(CPDieResult.wafer_id == wafer_id)

    rows = q.group_by(CPDieResult.touchdown_number).order_by(CPDieResult.touchdown_number).all()

    return success([{
        "touchdown": r.touchdown_number,
        "n": r.n,
        "pass": int(r.pass_n or 0),
        "fail": r.n - int(r.pass_n or 0),
        "yield_pct": round(int(r.pass_n or 0) / r.n * 100, 3) if r.n else 0,
    } for r in rows])


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/site-yield", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def site_yield():
    """Per-site yield breakdown from wafer summary JSON."""
    lot_id   = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    q = CPWaferSummary.query.filter_by(lot_id=lot_id)
    if wafer_id:
        q = q.filter_by(wafer_id=wafer_id)
    wafers = q.order_by(CPWaferSummary.slot_number).all()

    result = []
    for w in wafers:
        site_data = {}
        if w.site_yields_json:
            try:
                site_data = json.loads(w.site_yields_json)
            except Exception:
                pass
        result.append({
            "wafer_id": w.wafer_id,
            "slot_number": w.slot_number,
            "site_yields": site_data,
            "gross_yield_pct": float(w.gross_yield_pct) if w.gross_yield_pct else None,
        })
    return success(result)


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/pattern-gallery", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def pattern_gallery():
    """Wafers grouped by fail pattern class with counts and example wafers."""
    days       = int(request.args.get("days", 30))
    product_id = request.args.get("product_id")
    cut = _cutoff(days)

    q = db.session.query(
        CPWaferSummary.pattern_class_generic,
        func.count(CPWaferSummary.wafer_id).label("count"),
        func.avg(CPWaferSummary.gross_yield_pct).label("avg_yield"),
        func.min(CPWaferSummary.gross_yield_pct).label("min_yield"),
    ).filter(CPWaferSummary.event_date >= cut)

    if product_id:
        q = q.filter(CPWaferSummary.product_id == product_id)

    rows = q.group_by(CPWaferSummary.pattern_class_generic).order_by(desc("count")).all()

    gallery = []
    for r in rows:
        # Fetch up to 6 example wafers per pattern
        examples = (
            CPWaferSummary.query
            .filter(
                CPWaferSummary.event_date >= cut,
                CPWaferSummary.pattern_class_generic == r.pattern_class_generic,
            )
            .order_by(desc(CPWaferSummary.event_date))
            .limit(6)
            .all()
        )
        gallery.append({
            "pattern": r.pattern_class_generic,
            "count": r.count,
            "avg_yield": round(float(r.avg_yield), 3) if r.avg_yield else None,
            "min_yield": round(float(r.min_yield), 3) if r.min_yield else None,
            "examples": [{"wafer_id": e.wafer_id, "lot_id": e.lot_id,
                          "slot_number": e.slot_number,
                          "gross_yield_pct": float(e.gross_yield_pct) if e.gross_yield_pct else None}
                         for e in examples],
        })
    return success(gallery, meta={"days": days, "patterns": len(gallery)})


# ─────────────────────────────────────────────────────────────────────────────
@cp_bp.route("/lot-compare", methods=["GET"])
@jwt_required()
def lot_compare():
    """Compare yield distribution across multiple lots side-by-side."""
    lot_ids_raw = request.args.get("lot_ids", "")
    lot_ids = [l.strip() for l in lot_ids_raw.split(",") if l.strip()]
    if not lot_ids or len(lot_ids) > 10:
        return error("INVALID_PARAM", "Provide 1–10 comma-separated lot_ids")

    result = {}
    for lot_id in lot_ids:
        wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).all()
        if not wafers:
            result[lot_id] = {"error": "No data"}
            continue
        yields = [float(w.gross_yield_pct) for w in wafers if w.gross_yield_pct]
        import numpy as np
        a = np.array(yields)
        result[lot_id] = {
            "n": len(yields),
            "mean": round(float(a.mean()), 3) if len(a) else None,
            "std": round(float(a.std(ddof=1)), 3) if len(a) > 1 else None,
            "min": round(float(a.min()), 3) if len(a) else None,
            "max": round(float(a.max()), 3) if len(a) else None,
            "p10": round(float(np.percentile(a, 10)), 3) if len(a) else None,
            "p90": round(float(np.percentile(a, 90)), 3) if len(a) else None,
            "any_syl": any(w.syl_flag for w in wafers),
            "any_sbl": any(w.sbl_flag for w in wafers),
            "wafers": [w.to_dict() for w in wafers],
        }
    return success(result)
