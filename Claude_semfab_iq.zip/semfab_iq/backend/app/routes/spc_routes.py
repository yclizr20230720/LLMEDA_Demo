"""SPC Monitor Routes — Full 8-rule engine, capability, violations, annotations"""
from datetime import date, timedelta, datetime
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func, desc, and_

from app import db, cache
from app.models.spc import SPCConfig, SPCMeasurement, SPCViolation, SPCCapability
from app.services.spc_engine import check_all_rules, compute_capability
from app.utils.response import success, error, paginated

spc_bp = Blueprint("spc", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/configs", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def list_configs():
    """All active SPC parameter configurations."""
    parameter_source = request.args.get("source")     # WAT | FDC | CP
    equipment_id     = request.args.get("equipment_id")
    parameter_id     = request.args.get("parameter_id")

    q = SPCConfig.query.filter_by(is_active=True)
    if parameter_source: q = q.filter_by(parameter_source=parameter_source)
    if equipment_id:     q = q.filter_by(equipment_id=equipment_id)
    if parameter_id:     q = q.filter_by(parameter_id=parameter_id)

    configs = q.order_by(SPCConfig.parameter_id).all()
    return success([c.to_dict() for c in configs], meta={"count": len(configs)})


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/chart", methods=["GET"])
@jwt_required()
@cache.cached(timeout=60, query_string=True)
def chart():
    """
    SPC chart data: measurements with per-point violation flags already computed.
    Returns config limits + measurements array with violation_rule_1..8 columns.
    """
    config_id    = request.args.get("config_id")
    equipment_id = request.args.get("equipment_id")
    days         = int(request.args.get("days", 30))
    include_vm   = request.args.get("include_vm", "true").lower() == "true"

    if not config_id:
        return error("MISSING_PARAM", "config_id is required")

    config = SPCConfig.query.filter_by(config_id=config_id, is_active=True).first()
    if not config:
        return error("NOT_FOUND", f"SPC config '{config_id}' not found", status_code=404)

    cut = _cutoff(days)
    q = SPCMeasurement.query.filter(
        SPCMeasurement.config_id == config_id,
        SPCMeasurement.event_date >= cut,
    )
    if equipment_id:
        q = q.filter(SPCMeasurement.equipment_id == equipment_id)

    measurements = q.order_by(SPCMeasurement.measurement_time).all()

    # Re-run rules live if any measurement lacks violation data (e.g. new data)
    values = [float(m.measured_value) for m in measurements]
    cl  = float(config.cl  or 0)
    ucl = float(config.ucl or cl + 1)
    lcl = float(config.lcl or cl - 1)
    sig = float(config.sigma_estimate or (ucl - cl) / 3)
    enabled = config.enabled_rules if config.enabled_rules is not None else 255

    live_rules = check_all_rules(values, ucl, cl, lcl, sig, enabled) if values else {}
    per_rule   = live_rules.get("per_rule", {})

    # Build violation index sets per rule
    rule_viol_sets = {
        r: set(per_rule.get(f"rule_{r}", {}).get("violation_indices", []))
        for r in range(1, 9)
    }

    config_dict = config.to_dict()
    # Add 1-sigma and 2-sigma bands for chart zones
    config_dict["ucl_1sigma"] = float(config.ucl_1sigma) if config.ucl_1sigma else round(cl + sig, 8)
    config_dict["lcl_1sigma"] = float(config.lcl_1sigma) if config.lcl_1sigma else round(cl - sig, 8)
    config_dict["ucl_2sigma"] = float(config.ucl_2sigma) if config.ucl_2sigma else round(cl + 2 * sig, 8)
    config_dict["lcl_2sigma"] = float(config.lcl_2sigma) if config.lcl_2sigma else round(cl - 2 * sig, 8)

    meas_list = []
    for i, m in enumerate(measurements):
        d = m.to_dict()
        # Override violation flags with live-computed values
        for r in range(1, 9):
            d[f"violation_rule_{r}"] = i in rule_viol_sets[r]
        d["any_violation"] = any(i in rule_viol_sets[r] for r in range(1, 9))
        d["sigma_score"]   = round((float(m.measured_value) - cl) / sig, 4) if sig else 0
        # Strip VM if not requested
        if not include_vm:
            d.pop("vm_predicted_value", None)
            d.pop("vm_ci_lower", None)
            d.pop("vm_ci_upper", None)
        meas_list.append(d)

    return success({
        "config": config_dict,
        "measurements": meas_list,
        "live_rules": {
            f"rule_{r}": {
                "violation_count": len(rule_viol_sets[r]),
                "triggered": len(rule_viol_sets[r]) > 0,
                "description": per_rule.get(f"rule_{r}", {}).get("description", ""),
                "severity": per_rule.get(f"rule_{r}", {}).get("severity", ""),
            } for r in range(1, 9)
        },
        "total_violations": live_rules.get("total_violations", 0),
    }, meta={"config_id": config_id, "days": days, "n": len(measurements)})


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/violations", methods=["GET"])
@jwt_required()
def violations():
    """Recent SPC violations with acknowledgement status."""
    config_id    = request.args.get("config_id")
    equipment_id = request.args.get("equipment_id")
    rule_number  = request.args.get("rule", type=int)
    ack_status   = request.args.get("ack")   # "unacked" | "acked" | None
    days         = int(request.args.get("days", 14))
    page         = max(1, int(request.args.get("page", 1)))
    per_page     = min(200, int(request.args.get("per_page", 50)))
    cut = _cutoff(days)

    q = SPCViolation.query.filter(SPCViolation.event_date >= cut)
    if config_id:    q = q.filter(SPCViolation.config_id == config_id)
    if equipment_id: q = q.filter(SPCViolation.equipment_id == equipment_id)
    if rule_number:  q = q.filter(SPCViolation.rule_number == rule_number)
    if ack_status == "unacked":
        q = q.filter(SPCViolation.acknowledged_by.is_(None))
    elif ack_status == "acked":
        q = q.filter(SPCViolation.acknowledged_by.isnot(None))

    total = q.count()
    rows  = q.order_by(desc(SPCViolation.violation_time)).offset((page-1)*per_page).limit(per_page).all()
    return paginated([v.to_dict() for v in rows], total=total, page=page, per_page=per_page)


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/capability", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def capability():
    """
    Compute full Cp/Cpk/Cpm/Pp/Ppk for a config using recent measurements.
    """
    config_id    = request.args.get("config_id")
    equipment_id = request.args.get("equipment_id")
    days         = int(request.args.get("days", 30))

    if not config_id:
        return error("MISSING_PARAM", "config_id is required")

    config = SPCConfig.query.filter_by(config_id=config_id).first()
    if not config:
        return error("NOT_FOUND", f"Config '{config_id}' not found", status_code=404)

    if not config.usl or not config.lsl:
        return error("NO_SPEC", "Config has no USL/LSL — cannot compute capability")

    cut = _cutoff(days)
    q   = SPCMeasurement.query.filter(
        SPCMeasurement.config_id == config_id,
        SPCMeasurement.event_date >= cut,
    )
    if equipment_id:
        q = q.filter(SPCMeasurement.equipment_id == equipment_id)

    measurements = q.order_by(SPCMeasurement.measurement_time).all()
    if not measurements:
        return error("NO_DATA", "No measurements found for capability calculation")

    values  = [float(m.measured_value) for m in measurements]
    target  = float(config.target) if config.target else None
    subgrp  = config.subgroup_size or 1

    cap = compute_capability(values, float(config.usl), float(config.lsl), target, subgrp)
    cap["config_id"]    = config_id
    cap["parameter_id"] = config.parameter_id
    cap["equipment_id"] = equipment_id or config.equipment_id
    cap["days"]         = days
    return success(cap)


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/check-rules", methods=["POST"])
@jwt_required()
def check_rules():
    """
    On-demand rule check for arbitrary value array.
    Body: { values, ucl, cl, lcl, sigma, enabled_rules }
    """
    body = request.get_json(silent=True) or {}
    values   = body.get("values")
    ucl      = body.get("ucl")
    cl       = body.get("cl")
    lcl      = body.get("lcl")
    sigma    = body.get("sigma")
    enabled  = int(body.get("enabled_rules", 255))

    if not values or not isinstance(values, list):
        return error("MISSING_PARAM", "values (list of floats) is required")
    if ucl is None or cl is None or lcl is None:
        return error("MISSING_PARAM", "ucl, cl, lcl are required")

    # Derive sigma from control limits if not provided
    if sigma is None:
        sigma = (ucl - cl) / 3.0 if ucl > cl else 1.0

    result = check_all_rules([float(v) for v in values],
                              float(ucl), float(cl), float(lcl), float(sigma), enabled)
    return success(result)


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/violations/<int:violation_sk>/acknowledge", methods=["POST"])
@jwt_required()
def acknowledge(violation_sk: int):
    """Acknowledge a violation with resolution code and note."""
    identity = get_jwt_identity()
    body = request.get_json(silent=True) or {}

    v = SPCViolation.query.get(violation_sk)
    if not v:
        return error("NOT_FOUND", f"Violation {violation_sk} not found", status_code=404)
    if v.acknowledged_by:
        return error("ALREADY_ACKED", f"Already acknowledged by {v.acknowledged_by}")

    v.acknowledged_by   = identity
    v.acknowledged_at   = datetime.utcnow()
    v.resolution_code   = body.get("resolution_code", "REVIEWED")
    v.resolution_note   = body.get("resolution_note", "")
    db.session.commit()
    return success(v.to_dict())


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/configs/<config_id>", methods=["PUT"])
@jwt_required()
def update_config(config_id: str):
    """Update control limits or rule settings for a config."""
    config = SPCConfig.query.filter_by(config_id=config_id).first()
    if not config:
        return error("NOT_FOUND", f"Config '{config_id}' not found", status_code=404)

    body = request.get_json(silent=True) or {}
    editable = ["ucl","cl","lcl","ucl_2sigma","lcl_2sigma","ucl_1sigma","lcl_1sigma",
                "sigma_estimate","usl","lsl","target","enabled_rules",
                "alarm_mode","alarm_severity","is_active"]
    for field in editable:
        if field in body:
            setattr(config, field, body[field])

    config.limit_version = (config.limit_version or 1) + 1
    config.updated_at = datetime.utcnow()
    db.session.commit()
    return success(config.to_dict())


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/annotations", methods=["POST"])
@jwt_required()
def add_annotation():
    """
    Add an annotation (PM event, recipe change, etc.) as a pseudo-violation record
    for display on the SPC chart timeline.
    """
    identity = get_jwt_identity()
    body = request.get_json(silent=True) or {}
    config_id  = body.get("config_id")
    note       = body.get("note", "")
    ann_type   = body.get("annotation_type", "NOTE")  # PM | RECIPE | NOTE
    ann_time   = body.get("timestamp")

    if not config_id:
        return error("MISSING_PARAM", "config_id required")

    config = SPCConfig.query.filter_by(config_id=config_id).first()
    if not config:
        return error("NOT_FOUND", f"Config '{config_id}' not found", status_code=404)

    ts = datetime.fromisoformat(ann_time) if ann_time else datetime.utcnow()
    annotation = SPCViolation(
        config_id       = config_id,
        parameter_id    = config.parameter_id,
        equipment_id    = config.equipment_id,
        rule_number     = 0,    # 0 = annotation, not a WE rule violation
        rule_description= f"[ANNOTATION:{ann_type}] {note}",
        rule_severity   = "INFO",
        trigger_lot_id  = body.get("lot_id"),
        resolution_code = ann_type,
        resolution_note = note,
        acknowledged_by = identity,
        acknowledged_at = datetime.utcnow(),
        violation_time  = ts,
        event_date      = ts.date(),
    )
    db.session.add(annotation)
    db.session.commit()
    return success(annotation.to_dict(), status_code=201)


# ─────────────────────────────────────────────────────────────────────────────
@spc_bp.route("/dashboard-summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=120, query_string=True)
def dashboard_summary():
    """
    SPC health summary for all active configs: how many in-control vs. alarming.
    Used by YMS dashboard alarm strip.
    """
    days = int(request.args.get("days", 7))
    cut  = _cutoff(days)

    configs = SPCConfig.query.filter_by(is_active=True).all()
    summary = []
    for c in configs:
        recent = (
            SPCMeasurement.query
            .filter(SPCMeasurement.config_id == c.config_id,
                    SPCMeasurement.event_date >= cut)
            .order_by(desc(SPCMeasurement.measurement_time))
            .limit(30)
            .all()
        )
        viol_count = sum(1 for m in recent if m.any_violation)
        last_viol  = next((m for m in recent if m.any_violation), None)

        summary.append({
            "config_id":       c.config_id,
            "parameter_id":    c.parameter_id,
            "equipment_id":    c.equipment_id,
            "total_recent":    len(recent),
            "violation_count": viol_count,
            "violation_rate":  round(viol_count / len(recent) * 100, 2) if recent else 0,
            "status":          "ALARM" if viol_count > 0 else "OK",
            "last_violation_time": last_viol.measurement_time.isoformat() if last_viol else None,
        })

    return success(summary, meta={"configs": len(configs),
                                   "alarming": sum(1 for s in summary if s["status"] == "ALARM")})
