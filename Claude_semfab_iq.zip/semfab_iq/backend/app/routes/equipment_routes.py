"""Equipment Routes — Fleet list, health history, chambers, PM schedule"""
from datetime import date, timedelta, datetime
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc

from app import db, cache
from app.models.equipment import Equipment, Chamber
from app.models.fdc import FDCPMEvent
from app.utils.response import success, error, paginated

equipment_bp = Blueprint("equipment", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


@equipment_bp.route("/", methods=["GET"])
@jwt_required()
@cache.cached(timeout=120, query_string=True)
def list_equipment():
    equipment_type = request.args.get("type")
    status         = request.args.get("status", "PRODUCTION")
    area_id        = request.args.get("area_id")
    health_tier    = request.args.get("health_tier")
    sort_by        = request.args.get("sort_by", "health_score")
    page           = max(1, int(request.args.get("page", 1)))
    per_page       = min(100, int(request.args.get("per_page", 50)))

    q = Equipment.query.filter_by(is_current=True)
    if equipment_type: q = q.filter_by(equipment_type=equipment_type)
    if status:         q = q.filter_by(equipment_status=status)
    if area_id:        q = q.filter_by(area_id=area_id)
    if health_tier:    q = q.filter_by(health_tier=health_tier)

    sort_map = {
        "health_score": Equipment.health_score,
        "equipment_id": Equipment.equipment_id,
        "equipment_type": Equipment.equipment_type,
    }
    order_col = sort_map.get(sort_by, Equipment.health_score)
    q = q.order_by(order_col)

    total = q.count()
    equip = q.offset((page-1)*per_page).limit(per_page).all()
    return paginated(
        [e.to_dict() for e in equip],
        total=total, page=page, per_page=per_page,
        extra_meta={
            "critical_count":  sum(1 for e in equip if e.health_tier == "CRITICAL"),
            "degraded_count":  sum(1 for e in equip if e.health_tier == "DEGRADED"),
            "watch_count":     sum(1 for e in equip if e.health_tier == "WATCH"),
            "healthy_count":   sum(1 for e in equip if e.health_tier == "HEALTHY"),
        }
    )


@equipment_bp.route("/<equipment_id>", methods=["GET"])
@jwt_required()
@cache.cached(timeout=120, key_prefix=lambda: f"equip_{request.view_args['equipment_id']}")
def get_equipment(equipment_id: str):
    e = Equipment.query.filter_by(equipment_id=equipment_id, is_current=True).first()
    if not e:
        return error("NOT_FOUND", f"Equipment '{equipment_id}' not found", status_code=404)
    return success(e.to_dict_with_chambers())


@equipment_bp.route("/<equipment_id>/health-history", methods=["GET"])
@jwt_required()
def health_history(equipment_id: str):
    """Return PM events as proxy for health history (health before/after PM)."""
    days = int(request.args.get("days", 90))
    cut  = _cutoff(days)

    events = (
        FDCPMEvent.query
        .filter(FDCPMEvent.equipment_id == equipment_id, FDCPMEvent.event_date >= cut)
        .order_by(FDCPMEvent.pm_start_time)
        .all()
    )
    return success([{
        "date":               str(e.event_date),
        "pm_type":            e.pm_type,
        "pre_pm_health":      float(e.pre_pm_health_score) if e.pre_pm_health_score else None,
        "post_pm_health":     float(e.post_pm_health_score) if e.post_pm_health_score else None,
        "health_improvement": float(e.health_improvement) if e.health_improvement else None,
    } for e in events])


@equipment_bp.route("/<equipment_id>/chambers", methods=["GET"])
@jwt_required()
def get_chambers(equipment_id: str):
    chambers = Chamber.query.filter_by(equipment_id=equipment_id).all()
    return success([c.to_dict() for c in chambers])


@equipment_bp.route("/pm-schedule", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300)
def pm_schedule():
    """Equipment sorted by PM due date — upcoming maintenance calendar."""
    today = date.today()
    overdue = Equipment.query.filter(
        Equipment.next_pm_date < today, Equipment.is_current == True
    ).order_by(Equipment.next_pm_date).all()
    due_soon = Equipment.query.filter(
        Equipment.next_pm_date >= today,
        Equipment.next_pm_date <= today + timedelta(days=14),
        Equipment.is_current == True,
    ).order_by(Equipment.next_pm_date).all()

    return success({
        "overdue":  [e.to_dict() for e in overdue],
        "due_soon": [e.to_dict() for e in due_soon],
        "overdue_count": len(overdue),
        "due_soon_count": len(due_soon),
    })
