"""WAT Analytics Routes — Full implementation"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc, and_
from datetime import date, timedelta
import numpy as np
from scipy import stats as scipy_stats
from collections import defaultdict

from app import db, cache
from app.models.wat import WATResult, WATLotSummary, WATParameter, WATSpec
from app.services.spc_engine import (
    compute_capability, check_all_rules, one_way_anova, pearson_correlation
)
from app.utils.response import success, error, paginated

wat_bp = Blueprint("wat", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


@wat_bp.route("/parameters", methods=["GET"])
@jwt_required()
@cache.cached(timeout=3600)
def list_parameters():
    """All WAT parameters with measurement count."""
    params = db.session.query(
        WATResult.parameter_id, WATResult.parameter_group,
        func.count(WATResult.result_sk).label("n"),
        func.avg(WATResult.measured_value).label("mean"),
        func.min(WATResult.measured_value).label("min_val"),
        func.max(WATResult.measured_value).label("max_val"),
    ).group_by(WATResult.parameter_id, WATResult.parameter_group).all()

    # Augment with parameter metadata
    meta = {p.parameter_id: p.to_dict() for p in WATParameter.query.all()}
    f = lambda v: round(float(v), 6) if v is not None else None
    return success([{
        "parameter_id": p.parameter_id, "parameter_group": p.parameter_group,
        "count": p.n, "mean": f(p.mean), "min": f(p.min_val), "max": f(p.max_val),
        **meta.get(p.parameter_id, {}),
    } for p in params])


@wat_bp.route("/specs", methods=["GET"])
@jwt_required()
@cache.cached(timeout=1800, query_string=True)
def get_specs():
    """Spec limits for a parameter × product × conditions."""
    parameter_id = request.args.get("parameter_id")
    product_id = request.args.get("product_id")
    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id required")
    q = WATSpec.query.filter_by(parameter_id=parameter_id)
    if product_id:
        q = q.filter_by(product_id=product_id)
    specs = q.all()
    return success([s.to_dict() for s in specs])


@wat_bp.route("/distribution", methods=["GET"])
@jwt_required()
def distribution():
    """Full distribution analysis: histogram, KDE, capability, normality."""
    parameter_id = request.args.get("parameter_id")
    lot_id       = request.args.get("lot_id")
    wafer_id     = request.args.get("wafer_id")
    product_id   = request.args.get("product_id")
    equipment_id = request.args.get("equipment_id")
    site_zone    = request.args.get("site_zone")
    vcc          = request.args.get("vcc", type=float)
    temp_c       = request.args.get("temp_c", type=float)
    days         = int(request.args.get("days", 30))
    bins_n       = int(request.args.get("bins", 30))
    exclude_outliers = request.args.get("exclude_outliers", "false").lower() == "true"

    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id is required")

    q = WATResult.query.filter(
        WATResult.parameter_id == parameter_id,
        WATResult.event_date >= _cutoff(days),
    )
    if lot_id:     q = q.filter(WATResult.lot_id == lot_id)
    if wafer_id:   q = q.filter(WATResult.wafer_id == wafer_id)
    if product_id: q = q.filter(WATResult.product_id == product_id)
    if equipment_id: q = q.filter(WATResult.equipment_id == equipment_id)
    if site_zone:  q = q.filter(WATResult.site_zone == site_zone)
    if vcc:        q = q.filter(WATResult.vcc == vcc)
    if temp_c:     q = q.filter(WATResult.temp_c == temp_c)
    if exclude_outliers:
        q = q.filter(WATResult.is_outlier_mad == False)

    results = q.limit(10000).all()
    if not results:
        return error("NO_DATA", f"No WAT data found for parameter {parameter_id}")

    values = [float(r.measured_value) for r in results]
    usl = float(results[0].usl) if results[0].usl is not None else None
    lsl = float(results[0].lsl) if results[0].lsl is not None else None
    target = float(results[0].target_value) if results[0].target_value is not None else None

    arr = np.array(values)

    # Histogram with KDE-bandwidth selection
    hist_counts, hist_edges = np.histogram(arr, bins=bins_n)

    # KDE points for smooth curve
    try:
        kde = scipy_stats.gaussian_kde(arr)
        kde_x = np.linspace(arr.min(), arr.max(), 200)
        kde_y = kde(kde_x)
        kde_data = {"x": [round(float(v), 8) for v in kde_x],
                    "y": [round(float(v), 8) for v in kde_y]}
    except Exception:
        kde_data = None

    # Capability
    capability = {}
    if usl is not None and lsl is not None:
        capability = compute_capability(values, usl, lsl, target)

    # Outlier counts
    mad_outliers = sum(1 for r in results if r.is_outlier_mad)
    grubbs_outliers = sum(1 for r in results if r.is_outlier_grubbs)

    # Equipment breakdown
    equip_breakdown = defaultdict(list)
    for r in results:
        if r.equipment_id:
            equip_breakdown[r.equipment_id].append(float(r.measured_value))

    equip_stats = {}
    for eid, vals in equip_breakdown.items():
        a = np.array(vals)
        equip_stats[eid] = {
            "n": len(vals), "mean": round(float(a.mean()), 6), "std": round(float(a.std(ddof=1)), 6),
        }

    return success({
        "parameter_id": parameter_id, "n": len(values),
        "usl": usl, "lsl": lsl, "target": target,
        "histogram": {
            "counts": hist_counts.tolist(),
            "edges": [round(float(e), 8) for e in hist_edges.tolist()],
        },
        "kde": kde_data,
        "capability": capability,
        "outliers": {"mad": mad_outliers, "grubbs": grubbs_outliers},
        "equipment_breakdown": equip_stats,
        "filters": {
            "lot_id": lot_id, "product_id": product_id,
            "equipment_id": equipment_id, "site_zone": site_zone,
            "days": days, "exclude_outliers": exclude_outliers,
        },
    })


@wat_bp.route("/trend", methods=["GET"])
@jwt_required()
@cache.cached(timeout=180, query_string=True)
def trend():
    """Lot-sequence trend of WAT summary statistics."""
    parameter_id = request.args.get("parameter_id")
    product_id   = request.args.get("product_id")
    equipment_id = request.args.get("equipment_id")
    days = int(request.args.get("days", 30))
    group_by = request.args.get("group_by", "lot")   # lot | date | equipment

    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id is required")

    q = WATLotSummary.query.filter(
        WATLotSummary.parameter_id == parameter_id,
        WATLotSummary.event_date >= _cutoff(days),
    )
    if product_id:   q = q.filter(WATLotSummary.product_id == product_id)
    if equipment_id: q = q.filter(WATLotSummary.equipment_id == equipment_id)

    summaries = q.order_by(WATLotSummary.event_date, WATLotSummary.lot_id).limit(500).all()

    if group_by == "equipment":
        by_equip = defaultdict(list)
        for s in summaries:
            if s.mean_value is not None:
                by_equip[s.equipment_id or "UNKNOWN"].append(s.to_dict())
        return success(dict(by_equip))

    return success(
        [s.to_dict() for s in summaries],
        meta={"parameter_id": parameter_id, "count": len(summaries)},
    )


@wat_bp.route("/correlation-matrix", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def correlation_matrix():
    """Pearson + Spearman correlation matrix across all WAT parameters."""
    product_id = request.args.get("product_id", "PROD_N5_001")
    days = int(request.args.get("days", 30))
    min_pairs = int(request.args.get("min_pairs", 5))
    cut = _cutoff(days)

    # Fetch lot-level means per parameter
    rows = db.session.query(
        WATLotSummary.lot_id,
        WATLotSummary.parameter_id,
        WATLotSummary.mean_value,
    ).filter(
        WATLotSummary.product_id == product_id,
        WATLotSummary.event_date >= cut,
        WATLotSummary.mean_value.isnot(None),
    ).all()

    if not rows:
        return success({"params": [], "r_matrix": [], "p_matrix": [], "lot_count": 0})

    # Pivot: {lot_id: {param_id: mean_value}}
    pivot = defaultdict(dict)
    for r in rows:
        pivot[r.lot_id][r.parameter_id] = float(r.mean_value)

    params = sorted({r.parameter_id for r in rows})
    all_lots = sorted(pivot.keys())

    r_matrix, p_matrix, n_matrix = [], [], []
    for p1 in params:
        row_r, row_p, row_n = [], [], []
        for p2 in params:
            pairs = [(pivot[lot].get(p1), pivot[lot].get(p2)) for lot in all_lots
                     if p1 in pivot[lot] and p2 in pivot[lot]]
            if len(pairs) >= min_pairs:
                xs, ys = zip(*pairs)
                corr = pearson_correlation(list(xs), list(ys))
                row_r.append(corr.get("pearson_r"))
                row_p.append(corr.get("pearson_p"))
                row_n.append(len(pairs))
            else:
                row_r.append(None); row_p.append(None); row_n.append(0)
        r_matrix.append(row_r); p_matrix.append(row_p); n_matrix.append(row_n)

    return success({
        "params": params, "r_matrix": r_matrix, "p_matrix": p_matrix, "n_matrix": n_matrix,
        "lot_count": len(all_lots), "days": days, "product_id": product_id,
    })


@wat_bp.route("/correlation-scatter", methods=["GET"])
@jwt_required()
def correlation_scatter():
    """Scatter data for a specific parameter pair."""
    param_x = request.args.get("param_x")
    param_y = request.args.get("param_y")
    product_id = request.args.get("product_id")
    days = int(request.args.get("days", 30))

    if not param_x or not param_y:
        return error("MISSING_PARAM", "param_x and param_y are required")

    cut = _cutoff(days)
    rows_x = db.session.query(WATLotSummary.lot_id, WATLotSummary.mean_value).filter(
        WATLotSummary.parameter_id == param_x,
        WATLotSummary.event_date >= cut,
        WATLotSummary.mean_value.isnot(None),
    )
    rows_y = db.session.query(WATLotSummary.lot_id, WATLotSummary.mean_value).filter(
        WATLotSummary.parameter_id == param_y,
        WATLotSummary.event_date >= cut,
        WATLotSummary.mean_value.isnot(None),
    )
    if product_id:
        rows_x = rows_x.filter(WATLotSummary.product_id == product_id)
        rows_y = rows_y.filter(WATLotSummary.product_id == product_id)

    dict_x = {r.lot_id: float(r.mean_value) for r in rows_x.all()}
    dict_y = {r.lot_id: float(r.mean_value) for r in rows_y.all()}

    common_lots = sorted(set(dict_x) & set(dict_y))
    if len(common_lots) < 3:
        return error("INSUFFICIENT_DATA", "Need at least 3 common lots for correlation")

    xs = [dict_x[l] for l in common_lots]
    ys = [dict_y[l] for l in common_lots]
    corr = pearson_correlation(xs, ys)

    return success({
        "param_x": param_x, "param_y": param_y,
        "scatter": [{"lot_id": l, "x": round(x, 8), "y": round(y, 8)}
                    for l, x, y in zip(common_lots, xs, ys)],
        "correlation": corr,
    })


@wat_bp.route("/anova", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def anova():
    """One-way ANOVA: equipment/chamber/recipe factor analysis for a parameter."""
    parameter_id = request.args.get("parameter_id")
    factor       = request.args.get("factor", "equipment_id")   # equipment_id | chamber_id | recipe_id
    product_id   = request.args.get("product_id")
    days         = int(request.args.get("days", 30))

    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id is required")
    if factor not in ("equipment_id", "chamber_id", "recipe_id"):
        return error("INVALID_PARAM", "factor must be equipment_id, chamber_id or recipe_id")

    cut = _cutoff(days)
    factor_col = getattr(WATResult, factor)
    rows = db.session.query(factor_col, WATResult.measured_value).filter(
        WATResult.parameter_id == parameter_id,
        WATResult.event_date >= cut,
        WATResult.measured_value.isnot(None),
        factor_col.isnot(None),
        WATResult.is_outlier_mad == False,
    )
    if product_id:
        rows = rows.filter(WATResult.product_id == product_id)

    data = rows.limit(50000).all()
    if not data:
        return error("NO_DATA", "No data for ANOVA analysis")

    groups: dict = defaultdict(list)
    for factor_val, meas_val in data:
        groups[str(factor_val)].append(float(meas_val))

    if len(groups) < 2:
        return error("INSUFFICIENT_GROUPS", "Need at least 2 factor groups for ANOVA")

    result = one_way_anova(groups)
    result["parameter_id"] = parameter_id
    result["factor"] = factor
    result["product_id"] = product_id
    result["days"] = days
    return success(result)


@wat_bp.route("/site-map", methods=["GET"])
@jwt_required()
def site_map():
    """Within-wafer spatial map of measurements."""
    parameter_id = request.args.get("parameter_id")
    lot_id       = request.args.get("lot_id")
    wafer_id     = request.args.get("wafer_id")
    if not parameter_id or not lot_id:
        return error("MISSING_PARAM", "parameter_id and lot_id are required")

    q = WATResult.query.filter(
        WATResult.parameter_id == parameter_id,
        WATResult.lot_id == lot_id,
    )
    if wafer_id:
        q = q.filter(WATResult.wafer_id == wafer_id)

    sites = q.order_by(WATResult.site_id).all()
    if not sites:
        return error("NO_DATA", "No site data found")

    values = [float(r.measured_value) for r in sites]
    mean = np.mean(values)
    std  = np.std(values, ddof=1) if len(values) > 1 else 1

    return success([{
        "site_id": r.site_id, "site_x": float(r.site_x) if r.site_x else None,
        "site_y": float(r.site_y) if r.site_y else None, "site_zone": r.site_zone,
        "measured_value": float(r.measured_value),
        "sigma_score": round((float(r.measured_value) - mean) / std, 4) if std > 0 else 0,
        "pass_fail": r.pass_fail, "is_outlier": r.is_outlier_mad,
    } for r in sites])


@wat_bp.route("/equipment-health", methods=["GET"])
@jwt_required()
@cache.cached(timeout=900, query_string=True)
def equipment_health():
    """Equipment health ranked by ANOVA eta-squared, with Z-score components."""
    from app.models.equipment import Equipment
    days = int(request.args.get("days", 30))
    cut = _cutoff(days)

    # Get fleet-level stats per parameter
    fleet_stats = db.session.query(
        WATResult.parameter_id,
        func.avg(WATResult.measured_value).label("fleet_mean"),
        func.stddev(WATResult.measured_value).label("fleet_std"),
    ).filter(
        WATResult.event_date >= cut,
        WATResult.is_outlier_mad == False,
    ).group_by(WATResult.parameter_id).all()

    fleet_lookup = {r.parameter_id: {
        "fleet_mean": float(r.fleet_mean) if r.fleet_mean else 0,
        "fleet_std": float(r.fleet_std) if r.fleet_std else 1,
    } for r in fleet_stats}

    # Per-equipment stats
    equip_param_stats = db.session.query(
        WATResult.equipment_id,
        WATResult.parameter_id,
        func.avg(WATResult.measured_value).label("equip_mean"),
        func.stddev(WATResult.measured_value).label("equip_std"),
        func.count(WATResult.result_sk).label("n"),
    ).filter(
        WATResult.event_date >= cut,
        WATResult.equipment_id.isnot(None),
        WATResult.is_outlier_mad == False,
    ).group_by(WATResult.equipment_id, WATResult.parameter_id).all()

    equip_scores = defaultdict(lambda: {"z_scores": [], "cv_ratios": [], "n": 0})
    for r in equip_param_stats:
        fleet = fleet_lookup.get(r.parameter_id, {"fleet_mean": 1, "fleet_std": 1})
        fleet_std = fleet["fleet_std"] or 1
        fleet_mean = fleet["fleet_mean"] or 1
        equip_mean = float(r.equip_mean) if r.equip_mean else 0
        equip_std  = float(r.equip_std) if r.equip_std else 0

        z = abs(equip_mean - fleet["fleet_mean"]) / fleet_std
        cv_equip = equip_std / abs(equip_mean) if equip_mean != 0 else 0
        cv_fleet = fleet_std / abs(fleet_mean) if fleet_mean != 0 else 0
        cv_ratio = cv_equip / cv_fleet if cv_fleet > 0 else 1.0

        equip_scores[r.equipment_id]["z_scores"].append(float(np.clip(z, 0, 5)))
        equip_scores[r.equipment_id]["cv_ratios"].append(float(np.clip(cv_ratio, 0, 3)))
        equip_scores[r.equipment_id]["n"] += r.n or 0

    # Merge with Equipment table
    equipment = Equipment.query.filter_by(equipment_type="WAT", is_current=True).all()
    equip_dict = {e.equipment_id: e for e in equipment}

    results = []
    for eid, scores in equip_scores.items():
        e = equip_dict.get(eid)
        z_mean  = float(np.mean(scores["z_scores"]))   if scores["z_scores"]  else 0
        cv_mean = float(np.mean(scores["cv_ratios"])) if scores["cv_ratios"] else 1

        # Score from 0–100 (higher = better)
        z_score  = max(0, 100 - z_mean * 25)
        cv_score = max(0, 100 - (cv_mean - 1) * 40)
        health   = round(0.6 * z_score + 0.4 * cv_score, 2)
        tier     = "HEALTHY" if health >= 90 else "WATCH" if health >= 75 else "DEGRADED" if health >= 60 else "CRITICAL"

        row = {
            "equipment_id": eid, "health_score": health, "health_tier": tier,
            "z_score_mean": round(z_mean, 4), "cv_ratio_mean": round(cv_mean, 4),
            "n_measurements": scores["n"],
        }
        if e:
            row.update(e.to_dict())
            row["health_score"] = health   # override with fresh computed score
            row["health_tier"]  = tier
        results.append(row)

    results.sort(key=lambda x: x["health_score"])
    return success(results, meta={"days": days, "count": len(results)})
