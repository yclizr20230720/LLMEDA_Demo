"""Health Check Routes"""
from flask import Blueprint, jsonify, current_app
from datetime import datetime
from app import db, cache

health_bp = Blueprint("health", __name__)


@health_bp.route("/health")
def health():
    checks = {"api": "ok", "db": "unknown", "cache": "unknown"}
    status_code = 200
    try:
        db.session.execute(db.text("SELECT 1"))
        checks["db"] = "ok"
    except Exception as e:
        checks["db"] = f"error: {str(e)[:60]}"
        status_code = 503
    try:
        cache.set("__health_check__", 1, timeout=5)
        checks["cache"] = "ok"
    except Exception as e:
        checks["cache"] = f"error: {str(e)[:60]}"
    return jsonify({
        "status": "healthy" if status_code == 200 else "degraded",
        "version": "1.0.0", "fab_id": "FAB-12", "process_node": "N5",
        "timestamp": datetime.utcnow().isoformat(),
        "checks": checks,
    }), status_code


@health_bp.route("/api/v1/version")
def version():
    return jsonify({
        "version": "1.0.0", "api": "v1", "platform": "SEMFAB·IQ",
        "fab": "FAB-12", "node": "N5",
    })
