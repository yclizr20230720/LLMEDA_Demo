"""Yield Management System Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt
from sqlalchemy import func, desc, and_, cast, Date
from datetime import date, timedelta, datetime
from app import db, cache
from app.models.lot import Lot
from app.models.cp import CPWaferSummary
from app.utils.response import success, error, paginated

yield_bp = Blueprint("yield", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


@yield_bp.route("/kpi", methods=["GET"])
@jwt_required()
@cache.cached(timeout=60, query_string=True)
def kpi():
    """FAB-level KPI strip for dashboard header."""
    product_id = request.args.get("product_id")
    days = int(request.args.get("days", 1))
    cut = _cutoff(days)

    q = db.session.query(
        func.avg(CPWaferSummary.gross_yield_pct).label("avg_yield"),
        func.min(CPWaferSummary.gross_yield_pct).label("min_yield"),
        func.max(CPWaferSummary.gross_yield_pct).label("max_yield"),
        func.stddev(CPWaferSummary.gross_yield_pct).label("std_yield"),
        func.count(CPWaferSummary.wafer_id).label("wafer_count"),
        func.count(CPWaferSummary.lot_id.distinct()).label("lot_count"),
        func.sum(CPWaferSummary.pass_die).label("total_pass"),
        func.sum(CPWaferSummary.total_die).label("total_die"),
        func.sum(cast(CPWaferSummary.syl_flag, db.Integer)).label("syl_count"),
        func.sum(cast(CPWaferSummary.sbl_flag, db.Integer)).label("sbl_count"),
    ).filter(CPWaferSummary.event_date >= cut)

    if product_id:
        q = q.filter(CPWaferSummary.product_id == product_id)

    row = q.first()
    if not row or not row.avg_yield:
        return success({"msg": "No data available for the requested period"})

    f = lambda v: round(float(v), 3) if v is not None else None
    return success({
        "avg_yield_pct": f(row.avg_yield),
        "min_yield_pct": f(row.min_yield),
        "max_yield_pct": f(row.max_yield),
        "std_yield_pct": f(row.std_yield),
        "wafer_count": int(row.wafer_count or 0),
        "lot_count": int(row.lot_count or 0),
        "total_pass_die": int(row.total_pass or 0),
        "total_die": int(row.total_die or 0),
        "fab_yield_pct": f(float(row.total_pass or 0) / float(row.total_die or 1) * 100),
        "syl_wafer_count": int(row.syl_count or 0),
        "sbl_wafer_count": int(row.sbl_count or 0),
        "period_days": days,
    })


@yield_bp.route("/trend", methods=["GET"])
@jwt_required()
@cache.cached(timeout=120, query_string=True)
def trend():
    """Daily yield trend with P10/P50/P90 bands."""
    product_id = request.args.get("product_id", "PROD_N5_001")
    days = int(request.args.get("days", 30))
    tester_id = request.args.get("tester_id")
    cut = _cutoff(days)

    q = db.session.query(
        CPWaferSummary.event_date,
        func.avg(CPWaferSummary.gross_yield_pct).label("mean"),
        func.min(CPWaferSummary.gross_yield_pct).label("min"),
        func.max(CPWaferSummary.gross_yield_pct).label("max"),
        func.stddev(CPWaferSummary.gross_yield_pct).label("std"),
        func.percentile_cont(0.1).within_group(
            CPWaferSummary.gross_yield_pct).label("p10"),
        func.percentile_cont(0.5).within_group(
            CPWaferSummary.gross_yield_pct).label("p50"),
        func.percentile_cont(0.9).within_group(
            CPWaferSummary.gross_yield_pct).label("p90"),
        func.count(CPWaferSummary.wafer_id).label("n"),
    ).filter(
        CPWaferSummary.event_date >= cut,
        CPWaferSummary.product_id == product_id,
    )

    if tester_id:
        q = q.filter(CPWaferSummary.tester_id == tester_id)

    rows = q.group_by(CPWaferSummary.event_date).order_by(CPWaferSummary.event_date).all()

    f = lambda v: round(float(v), 4) if v is not None else None
    return success([{
        "date": str(r.event_date), "mean": f(r.mean), "min": f(r.min), "max": f(r.max),
        "std": f(r.std), "p10": f(r.p10), "p50": f(r.p50), "p90": f(r.p90), "n": r.n,
    } for r in rows], meta={"product_id": product_id, "days": days, "data_points": len(rows)})


@yield_bp.route("/summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def summary():
    """Lot-level yield summary for score card table."""
    product_id = request.args.get("product_id")
    process_node = request.args.get("process_node")
    lot_type = request.args.get("lot_type")
    tester_id = request.args.get("tester_id")
    days = int(request.args.get("days", 14))
    page = max(1, int(request.args.get("page", 1)))
    per_page = min(200, int(request.args.get("per_page", 50)))
    cut = _cutoff(days)

    q = db.session.query(
        CPWaferSummary.lot_id,
        CPWaferSummary.product_id,
        CPWaferSummary.process_node,
        CPWaferSummary.tester_id,
        CPWaferSummary.step_id,
        func.avg(CPWaferSummary.gross_yield_pct).label("avg_yield"),
        func.avg(CPWaferSummary.first_pass_yield).label("avg_first_pass"),
        func.avg(CPWaferSummary.offline_retest_rate).label("avg_retest_rate"),
        func.avg(CPWaferSummary.good_part_uph).label("avg_uph"),
        func.avg(CPWaferSummary.avg_sites).label("avg_sites"),
        func.sum(CPWaferSummary.total_die).label("total_die"),
        func.sum(CPWaferSummary.pass_die).label("total_pass"),
        func.count(CPWaferSummary.wafer_id).label("wafer_count"),
        func.bool_or(CPWaferSummary.syl_flag).label("any_syl"),
        func.bool_or(CPWaferSummary.sbl_flag).label("any_sbl"),
        func.bool_or(CPWaferSummary.mrb_required).label("any_mrb"),
        func.max(CPWaferSummary.event_date).label("last_test_date"),
        func.max(CPWaferSummary.test_time).label("last_test_time"),
    ).filter(CPWaferSummary.event_date >= cut)

    if product_id:
        q = q.filter(CPWaferSummary.product_id == product_id)
    if process_node:
        q = q.filter(CPWaferSummary.process_node == process_node)
    if tester_id:
        q = q.filter(CPWaferSummary.tester_id == tester_id)

    q = q.group_by(
        CPWaferSummary.lot_id, CPWaferSummary.product_id,
        CPWaferSummary.process_node, CPWaferSummary.tester_id, CPWaferSummary.step_id,
    ).order_by(desc("last_test_time"))

    total = q.count()
    rows = q.offset((page - 1) * per_page).limit(per_page).all()

    f = lambda v: round(float(v), 4) if v is not None else None
    data = [{
        "lot_id": r.lot_id, "product_id": r.product_id, "process_node": r.process_node,
        "tester_id": r.tester_id, "step_id": r.step_id,
        "avg_yield": f(r.avg_yield), "avg_first_pass": f(r.avg_first_pass),
        "avg_retest_rate": f(r.avg_retest_rate), "avg_uph": f(r.avg_uph),
        "avg_sites": f(r.avg_sites), "total_die": r.total_die, "total_pass": r.total_pass,
        "wafer_count": r.wafer_count,
        "any_syl": r.any_syl, "any_sbl": r.any_sbl, "any_mrb": r.any_mrb,
        "last_test_date": str(r.last_test_date) if r.last_test_date else None,
    } for r in rows]

    return paginated(data, total=total, page=page, per_page=per_page)


@yield_bp.route("/wafer-gallery", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def wafer_gallery():
    """All wafer maps for a lot, sorted by slot."""
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).order_by(
        CPWaferSummary.slot_number
    ).all()
    return success([w.to_dict() for w in wafers], meta={"lot_id": lot_id, "count": len(wafers)})


@yield_bp.route("/bin-pareto", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def bin_pareto():
    """Aggregate bin counts for a lot across all wafers, with cumulative %."""
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")
    import json

    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).all()
    if not wafers:
        return error("NOT_FOUND", f"No data found for lot {lot_id}", status_code=404)

    agg: dict = {}
    total = 0
    for w in wafers:
        if w.bin_counts_json:
            try:
                bins = json.loads(w.bin_counts_json)
                for bc, cnt in bins.items():
                    agg[str(bc)] = agg.get(str(bc), 0) + int(cnt)
                    total += int(cnt)
            except Exception:
                pass

    sorted_bins = sorted(agg.items(), key=lambda x: x[1], reverse=True)
    cumulative = 0
    result = []
    for bc, cnt in sorted_bins:
        cumulative += cnt
        result.append({
            "bin_code": bc, "count": cnt,
            "pct": round(cnt / total * 100, 3) if total else 0,
            "cumulative_pct": round(cumulative / total * 100, 3) if total else 0,
        })
    return success(result, meta={"lot_id": lot_id, "total_die": total, "bin_count": len(result)})


@yield_bp.route("/excursions", methods=["GET"])
@jwt_required()
def excursions():
    """Yield excursions — wafers below SYL or SBL in last N days."""
    days = int(request.args.get("days", 7))
    severity = request.args.get("severity")  # CRITICAL, MAJOR, ALL
    product_id = request.args.get("product_id")
    cut = _cutoff(days)

    q = CPWaferSummary.query.filter(
        CPWaferSummary.event_date >= cut,
        CPWaferSummary.syl_flag == True,
    )
    if product_id:
        q = q.filter(CPWaferSummary.product_id == product_id)
    if severity == "CRITICAL":
        q = q.filter(CPWaferSummary.sbl_flag == True)

    wafers = q.order_by(desc(CPWaferSummary.test_time)).limit(100).all()

    data = []
    for w in wafers:
        d = w.to_dict()
        d["severity"] = "CRITICAL" if w.sbl_flag else "MAJOR"
        d["excursion_type"] = "YIELD_DROP"
        data.append(d)

    return success(data, meta={"days": days, "count": len(data)})


@yield_bp.route("/lot/<lot_id>", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, key_prefix=lambda: f"lot_{request.view_args['lot_id']}")
def lot_detail(lot_id: str):
    """Full lot detail: metadata + all wafer summaries."""
    lot = Lot.query.filter_by(lot_id=lot_id, is_current=True).first()
    if not lot:
        return error("NOT_FOUND", f"Lot {lot_id} not found", status_code=404)
    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).order_by(
        CPWaferSummary.slot_number).all()
    import json
    result = lot.to_dict()
    result["wafers"] = [w.to_dict() for w in wafers]
    # Aggregate bin pareto
    agg: dict = {}
    for w in wafers:
        if w.bin_counts_json:
            try:
                for bc, cnt in json.loads(w.bin_counts_json).items():
                    agg[str(bc)] = agg.get(str(bc), 0) + int(cnt)
            except Exception:
                pass
    result["bin_counts_aggregate"] = agg
    return success(result)


@yield_bp.route("/products", methods=["GET"])
@jwt_required()
@cache.cached(timeout=3600)
def list_products():
    """Distinct product list with yield stats."""
    from datetime import timedelta
    cut = _cutoff(90)
    rows = db.session.query(
        CPWaferSummary.product_id,
        CPWaferSummary.process_node,
        func.avg(CPWaferSummary.gross_yield_pct).label("avg_yield"),
        func.count(CPWaferSummary.wafer_id.distinct()).label("wafer_count"),
    ).filter(CPWaferSummary.event_date >= cut).group_by(
        CPWaferSummary.product_id, CPWaferSummary.process_node
    ).order_by(CPWaferSummary.product_id).all()

    return success([{
        "product_id": r.product_id, "process_node": r.process_node,
        "avg_yield_90d": round(float(r.avg_yield), 3) if r.avg_yield else None,
        "wafer_count_90d": r.wafer_count,
    } for r in rows])
