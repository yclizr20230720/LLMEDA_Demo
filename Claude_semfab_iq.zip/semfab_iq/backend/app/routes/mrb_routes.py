"""MRB (Material Review Board) Routes"""
from datetime import date, timedelta, datetime
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func, desc

from app import db
from app.models.cp import CPWaferSummary
from app.models.lot import Lot
from app.utils.response import success, error

mrb_bp = Blueprint("mrb", __name__)


@mrb_bp.route("/review", methods=["GET"])
@jwt_required()
def review():
    """MRB wafers awaiting decision."""
    days     = int(request.args.get("days", 14))
    lot_id   = request.args.get("lot_id")
    cut = date.today() - timedelta(days=days)

    q = CPWaferSummary.query.filter(
        CPWaferSummary.event_date >= cut,
        CPWaferSummary.mrb_required == True,
    )
    if lot_id:
        q = q.filter_by(lot_id=lot_id)

    wafers = q.order_by(desc(CPWaferSummary.event_date)).all()
    return success([w.to_dict() for w in wafers], meta={"pending": len(wafers)})


@mrb_bp.route("/decision", methods=["POST"])
@jwt_required()
def decision():
    """Record MRB decision for a wafer."""
    identity = get_jwt_identity()
    body = request.get_json(silent=True) or {}
    wafer_id   = body.get("wafer_id")
    lot_id     = body.get("lot_id")
    mrb_result = body.get("mrb_result")   # GoodWafer | BadWafer | ScrapWafer

    if not wafer_id or not lot_id or not mrb_result:
        return error("MISSING_PARAM", "wafer_id, lot_id, mrb_result required")
    if mrb_result not in ("GoodWafer", "BadWafer", "ScrapWafer"):
        return error("INVALID_VALUE", "mrb_result must be GoodWafer | BadWafer | ScrapWafer")

    ws = CPWaferSummary.query.filter_by(lot_id=lot_id, wafer_id=wafer_id).first()
    if not ws:
        return error("NOT_FOUND", f"Wafer {wafer_id} not found", status_code=404)

    ws.mrb_result   = mrb_result
    ws.mrb_required = (mrb_result == "ScrapWafer")
    db.session.commit()
    return success({"wafer_id": wafer_id, "lot_id": lot_id, "mrb_result": mrb_result,
                    "decided_by": identity})


@mrb_bp.route("/consolidation", methods=["GET"])
@jwt_required()
def consolidation():
    """Full MRB consolidation report: all flag columns per wafer."""
    lot_id = request.args.get("lot_id")
    days   = int(request.args.get("days", 7))
    cut    = date.today() - timedelta(days=days)

    q = CPWaferSummary.query.filter(CPWaferSummary.event_date >= cut)
    if lot_id:
        q = q.filter_by(lot_id=lot_id)

    wafers = q.order_by(CPWaferSummary.lot_id, CPWaferSummary.slot_number).all()
    return success([{
        **w.to_dict(),
        "partial_wafer":      w.is_partial_wafer,
        "wafer_cluster_flag": w.wafer_cluster_flag,
        "wafer_pattern_flag": w.wafer_pattern_flag,
        "syl_flag":           w.syl_flag,
        "sbl_flag":           w.sbl_flag,
        "mrb_result":         w.mrb_result,
    } for w in wafers], meta={"total": len(wafers)})
