"""Authentication Routes — JWT login / refresh / logout / profile"""
from flask import Blueprint, request, g
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt,
)
from datetime import datetime
from app import db, limiter
from app.models.user import User
from app.utils.response import success, error

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
@limiter.limit("10 per minute")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))

    if not username or not password:
        return error("MISSING_CREDENTIALS", "Username and password are required", status_code=400)

    user = User.query.filter_by(username=username).first()

    # Account not found
    if not user:
        return error("INVALID_CREDENTIALS", "Invalid username or password", status_code=401)

    # Account disabled
    if not user.is_active:
        return error("ACCOUNT_DISABLED", "Account is deactivated. Contact admin.", status_code=403)

    # Account locked
    if user.is_locked():
        return error("ACCOUNT_LOCKED", "Account temporarily locked due to failed attempts.", status_code=429)

    # Wrong password
    if not user.check_password(password):
        user.failed_logins = (user.failed_logins or 0) + 1
        if user.failed_logins >= 5:
            from datetime import timedelta
            user.locked_until = datetime.utcnow() + timedelta(minutes=15)
        db.session.commit()
        return error("INVALID_CREDENTIALS", "Invalid username or password", status_code=401)

    # Success — reset failure counter
    user.failed_logins = 0
    user.locked_until = None
    user.last_login = datetime.utcnow()
    user.login_count = (user.login_count or 0) + 1
    db.session.commit()

    claims = {"role": user.role, "fab_id": user.fab_id, "full_name": user.full_name}
    access_token  = create_access_token(identity=user.username, additional_claims=claims)
    refresh_token = create_refresh_token(identity=user.username)

    return success({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "Bearer",
        "user": user.to_dict(),
    })


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    user = User.query.filter_by(username=identity, is_active=True).first()
    if not user:
        return error("USER_NOT_FOUND", "User not found or disabled", status_code=401)
    claims = {"role": user.role, "fab_id": user.fab_id, "full_name": user.full_name}
    return success({"access_token": create_access_token(identity=user.username, additional_claims=claims)})


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    identity = get_jwt_identity()
    user = User.query.filter_by(username=identity).first()
    if not user:
        return error("USER_NOT_FOUND", "User not found", status_code=404)
    return success(user.to_profile())


@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    # In production, add JWT ID to a Redis blocklist here
    return success({"message": "Logged out successfully"})


@auth_bp.route("/change-password", methods=["POST"])
@jwt_required()
def change_password():
    identity = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    old_pw = str(data.get("old_password", ""))
    new_pw = str(data.get("new_password", ""))
    if not old_pw or not new_pw:
        return error("MISSING_FIELDS", "old_password and new_password required")
    if len(new_pw) < 8:
        return error("WEAK_PASSWORD", "Password must be at least 8 characters")
    user = User.query.filter_by(username=identity).first()
    if not user or not user.check_password(old_pw):
        return error("INVALID_PASSWORD", "Current password is incorrect", status_code=401)
    user.set_password(new_pw)
    db.session.commit()
    return success({"message": "Password changed successfully"})


@auth_bp.route("/users", methods=["GET"])
@jwt_required()
def list_users():
    claims = get_jwt()
    if claims.get("role") not in ["MANAGER", "SYSTEM_ADMIN"]:
        return error("FORBIDDEN", "Insufficient permissions", status_code=403)
    users = User.query.filter_by(is_active=True).order_by(User.username).all()
    return success([u.to_dict() for u in users])
