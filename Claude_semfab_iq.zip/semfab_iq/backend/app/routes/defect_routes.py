"""Defect Inspection Routes — Summary, Pareto, Wafer Map, Pattern Analysis"""
import json
from datetime import date, timedelta
from collections import defaultdict

from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc

from app import db, cache
from app.models.defect import DefectResult, DefectWaferSummary
from app.utils.response import success, error, paginated

defect_bp = Blueprint("defect", __name__)


def _cutoff(days: int) -> date:
    return date.today() - timedelta(days=days)


@defect_bp.route("/summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def summary():
    """Per-wafer defect summary with density and killer count."""
    lot_id   = request.args.get("lot_id")
    days     = int(request.args.get("days", 14))
    page     = max(1, int(request.args.get("page", 1)))
    per_page = min(200, int(request.args.get("per_page", 50)))
    cut = _cutoff(days)

    q = DefectWaferSummary.query.filter(DefectWaferSummary.event_date >= cut)
    if lot_id:
        q = q.filter_by(lot_id=lot_id)

    total = q.count()
    rows  = q.order_by(desc(DefectWaferSummary.event_date)).offset((page-1)*per_page).limit(per_page).all()
    return paginated([r.to_dict() for r in rows], total=total, page=page, per_page=per_page)


@defect_bp.route("/pareto", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def pareto():
    """Defect class Pareto with killer contribution."""
    lot_id             = request.args.get("lot_id")
    inspection_step_id = request.args.get("step_id")
    days               = int(request.args.get("days", 14))
    cut = _cutoff(days)

    q = db.session.query(
        DefectResult.final_class,
        func.count(DefectResult.defect_sk).label("count"),
        func.sum(func.cast(DefectResult.is_killer, db.Integer)).label("killers"),
        func.avg(DefectResult.defect_size_nm).label("avg_size"),
    ).filter(DefectResult.event_date >= cut)

    if lot_id:             q = q.filter(DefectResult.lot_id == lot_id)
    if inspection_step_id: q = q.filter(DefectResult.inspection_step_id == inspection_step_id)

    rows = q.group_by(DefectResult.final_class).order_by(desc("count")).all()

    total_defects = sum(r.count for r in rows)
    cumulative = 0
    result = []
    for r in rows:
        cumulative += r.count
        result.append({
            "class":         r.final_class,
            "count":         r.count,
            "pct":           round(r.count / total_defects * 100, 3) if total_defects else 0,
            "cumulative_pct": round(cumulative / total_defects * 100, 3) if total_defects else 0,
            "killer_count":  int(r.killers or 0),
            "killer_pct":    round(int(r.killers or 0) / r.count * 100, 3) if r.count else 0,
            "avg_size_nm":   round(float(r.avg_size), 2) if r.avg_size else None,
        })
    return success(result, meta={"total_defects": total_defects, "classes": len(result)})


@defect_bp.route("/wafer-map", methods=["GET"])
@jwt_required()
@cache.cached(timeout=1800, query_string=True)
def wafer_map():
    """Defect XY coordinates for a wafer (for spatial scatter map)."""
    lot_id   = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id or not wafer_id:
        return error("MISSING_PARAM", "lot_id and wafer_id are required")

    defects = (
        DefectResult.query
        .filter_by(lot_id=lot_id, wafer_id=wafer_id)
        .order_by(DefectResult.defect_sk)
        .limit(5000)
        .all()
    )

    xs       = [float(d.defect_x_um) if d.defect_x_um else 0 for d in defects]
    ys       = [float(d.defect_y_um) if d.defect_y_um else 0 for d in defects]
    classes  = [d.final_class for d in defects]
    killers  = [d.is_killer for d in defects]
    sizes    = [float(d.defect_size_nm) if d.defect_size_nm else 0 for d in defects]

    class_counts: dict = defaultdict(int)
    for c in classes:
        class_counts[c] += 1

    return success({
        "lot_id": lot_id, "wafer_id": wafer_id,
        "xs": xs, "ys": ys, "classes": classes,
        "killers": killers, "sizes": sizes,
        "total_defects": len(defects),
        "killer_count":  sum(1 for k in killers if k),
        "class_counts":  dict(class_counts),
    })


@defect_bp.route("/classify", methods=["POST"])
@jwt_required()
def classify():
    """
    Update defect classification (human review override).
    Body: { defect_sk, human_class, is_nuisance, sem_reviewed }
    """
    body = request.get_json(silent=True) or {}
    defect_sk   = body.get("defect_sk")
    human_class = body.get("human_class")
    if not defect_sk:
        return error("MISSING_PARAM", "defect_sk required")

    d = DefectResult.query.get(defect_sk)
    if not d:
        return error("NOT_FOUND", f"Defect {defect_sk} not found", status_code=404)

    if human_class:
        d.human_class  = human_class
        d.final_class  = human_class    # human overrides ADC
    if "is_nuisance" in body:
        d.is_nuisance  = bool(body["is_nuisance"])
        if d.is_nuisance:
            d.is_killer = False
    if "sem_reviewed" in body:
        d.sem_reviewed = bool(body["sem_reviewed"])
    db.session.commit()
    return success(d.to_dict())


@defect_bp.route("/pattern-analysis", methods=["GET"])
@jwt_required()
@cache.cached(timeout=600, query_string=True)
def pattern_analysis():
    """Pattern class distribution + suspected root cause equipment."""
    days = int(request.args.get("days", 30))
    cut  = _cutoff(days)

    rows = db.session.query(
        DefectWaferSummary.pattern_class,
        DefectWaferSummary.suspected_equipment_id,
        func.count(DefectWaferSummary.def_summary_sk).label("count"),
        func.avg(DefectWaferSummary.predicted_yield_loss_pct).label("avg_yield_loss"),
    ).filter(DefectWaferSummary.event_date >= cut).group_by(
        DefectWaferSummary.pattern_class,
        DefectWaferSummary.suspected_equipment_id,
    ).order_by(desc("count")).all()

    f = lambda v: round(float(v), 4) if v else None
    return success([{
        "pattern_class":          r.pattern_class,
        "suspected_equipment_id": r.suspected_equipment_id,
        "count":                  r.count,
        "avg_yield_loss_pct":     f(r.avg_yield_loss),
    } for r in rows], meta={"days": days})
