"""SEMFAB·IQ — Application Entry Point"""
import os
import logging
import click
from app import create_app, db, socketio

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

app = create_app(os.getenv("FLASK_ENV", "development"))


@app.cli.command("init-db")
def init_db():
    """Create all tables."""
    with app.app_context():
        db.create_all()
        click.echo("✅  Database tables created.")


@app.cli.command("seed-db")
@click.option("--lots", default=50, help="Number of production lots to generate")
def seed_db(lots):
    """Seed demo data."""
    from app.services.data_generator import seed_all
    with app.app_context():
        db.create_all()
        seed_all(n_lots=lots)


@app.cli.command("drop-db")
@click.confirmation_option(prompt="This will DELETE all data. Continue?")
def drop_db():
    with app.app_context():
        db.drop_all()
        click.echo("⚠️  All tables dropped.")


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_ENV", "development") == "development"
    socketio.run(app, host="0.0.0.0", port=port, debug=debug)
