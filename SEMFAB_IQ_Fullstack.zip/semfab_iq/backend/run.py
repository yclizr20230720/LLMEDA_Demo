"""SEMFAB·IQ — Application Entry Point"""
import os
from app import create_app, socketio, db

app = create_app(os.getenv("FLASK_ENV", "development"))


@app.cli.command("seed-db")
def seed_db():
    """Seed demo data into the database."""
    from app.services.data_generator import seed_all
    seed_all()


@app.cli.command("init-db")
def init_db():
    """Initialize database tables."""
    db.create_all()
    print("✅ Database tables created")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)
