"""SEMFAB·IQ — Application Configuration"""
import os
from datetime import timedelta

class Config:
    # ── Flask Core ──
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-in-production")
    DEBUG = False
    TESTING = False

    # ── Database (PostgreSQL / Greenplum-compatible) ──
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "postgresql://semfab:semfab_secret_2025@localhost:5432/semfab_dw"
    )
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_size": 10,
        "pool_timeout": 30,
        "pool_recycle": 1800,
        "max_overflow": 20,
        "echo": False,
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ── Redis Cache ──
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_URL = REDIS_URL
    CACHE_DEFAULT_TIMEOUT = 300

    # ── JWT ──
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "jwt-secret-change-in-production")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=60)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=7)
    JWT_TOKEN_LOCATION = ["headers"]
    JWT_HEADER_NAME = "Authorization"
    JWT_HEADER_TYPE = "Bearer"

    # ── CORS ──
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")

    # ── Rate Limiting ──
    RATELIMIT_DEFAULT = "1000 per minute"
    RATELIMIT_STORAGE_URL = REDIS_URL

    # ── Celery ──
    CELERY_BROKER_URL = REDIS_URL
    CELERY_RESULT_BACKEND = REDIS_URL

    # ── App Specific ──
    FAB_ID = os.getenv("FAB_ID", "FAB-12")
    PROCESS_NODE = os.getenv("PROCESS_NODE", "N5")
    WAFER_SIZE_MM = 300

class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_ENGINE_OPTIONS = {**Config.SQLALCHEMY_ENGINE_OPTIONS, "echo": False}

class ProductionConfig(Config):
    DEBUG = False

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "postgresql://semfab:semfab_secret_2025@localhost:5432/semfab_test"

config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}
