"""Defect Models"""
from datetime import datetime
from app import db


class DefectResult(db.Model):
    __tablename__ = "def_fact_defect"

    defect_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    slot_number = db.Column(db.SmallInteger)
    inspection_tool_id = db.Column(db.String(32), nullable=False)
    inspection_layer = db.Column(db.String(32))
    inspection_step_id = db.Column(db.String(32))
    defect_x_um = db.Column(db.Numeric(12, 4))
    defect_y_um = db.Column(db.Numeric(12, 4))
    die_x = db.Column(db.SmallInteger)
    die_y = db.Column(db.SmallInteger)
    defect_size_nm = db.Column(db.Numeric(12, 4))
    adc_class = db.Column(db.String(32))
    adc_confidence = db.Column(db.Numeric(6, 4))
    is_adc_auto = db.Column(db.Boolean, default=False)
    final_class = db.Column(db.String(32))
    class_category = db.Column(db.String(32))
    is_killer = db.Column(db.Boolean)
    kill_probability = db.Column(db.Numeric(8, 6))
    sem_reviewed = db.Column(db.Boolean, default=False)
    sem_image_path = db.Column(db.String(256))
    is_nuisance = db.Column(db.Boolean, default=False)
    inspection_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    product_id = db.Column(db.String(32))
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "inspection_tool_id": self.inspection_tool_id, "inspection_layer": self.inspection_layer,
            "defect_x_um": f(self.defect_x_um), "defect_y_um": f(self.defect_y_um),
            "die_x": self.die_x, "die_y": self.die_y,
            "defect_size_nm": f(self.defect_size_nm),
            "adc_class": self.adc_class, "adc_confidence": f(self.adc_confidence),
            "final_class": self.final_class, "class_category": self.class_category,
            "is_killer": self.is_killer, "kill_probability": f(self.kill_probability),
            "sem_reviewed": self.sem_reviewed, "is_nuisance": self.is_nuisance,
            "inspection_time": self.inspection_time.isoformat() if self.inspection_time else None,
        }


class DefectWaferSummary(db.Model):
    __tablename__ = "def_fact_wafer_defect_summary"

    def_summary_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    inspection_tool_id = db.Column(db.String(32))
    inspection_step_id = db.Column(db.String(32))
    inspection_layer = db.Column(db.String(32))
    total_defects = db.Column(db.Integer, default=0)
    killer_defects = db.Column(db.Integer, default=0)
    nuisance_defects = db.Column(db.Integer, default=0)
    inspection_area_cm2 = db.Column(db.Numeric(12, 6))
    defect_density_cm2 = db.Column(db.Numeric(14, 8))
    killer_density_cm2 = db.Column(db.Numeric(14, 8))
    class_counts_json = db.Column(db.Text)
    pattern_class = db.Column(db.String(32))
    pattern_confidence = db.Column(db.Numeric(6, 4))
    suspected_step_id = db.Column(db.String(32))
    suspected_equipment_id = db.Column(db.String(32))
    predicted_yield_loss_pct = db.Column(db.Numeric(7, 4))
    inspection_time = db.Column(db.DateTime(timezone=True))
    event_date = db.Column(db.Date, nullable=False)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "inspection_tool_id": self.inspection_tool_id, "inspection_layer": self.inspection_layer,
            "total_defects": self.total_defects, "killer_defects": self.killer_defects,
            "nuisance_defects": self.nuisance_defects,
            "defect_density_cm2": f(self.defect_density_cm2), "killer_density_cm2": f(self.killer_density_cm2),
            "class_counts_json": self.class_counts_json,
            "pattern_class": self.pattern_class, "pattern_confidence": f(self.pattern_confidence),
            "suspected_step_id": self.suspected_step_id, "suspected_equipment_id": self.suspected_equipment_id,
            "predicted_yield_loss_pct": f(self.predicted_yield_loss_pct),
        }
