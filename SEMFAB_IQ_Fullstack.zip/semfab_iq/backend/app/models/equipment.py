"""Equipment & Chamber Models"""
from datetime import datetime
from app import db


class Equipment(db.Model):
    __tablename__ = "eqp_dim_equipment"

    equipment_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id = db.Column(db.String(32), nullable=False, unique=True, index=True)
    equipment_name = db.Column(db.String(128))
    equipment_type = db.Column(db.String(32), nullable=False)
    equipment_subtype = db.Column(db.String(32))
    oem_vendor = db.Column(db.String(32))
    oem_model = db.Column(db.String(64))
    fab_id = db.Column(db.String(16))
    bay_id = db.Column(db.String(16))
    area_id = db.Column(db.String(32))
    chamber_count = db.Column(db.SmallInteger, default=1)
    is_multi_chamber = db.Column(db.Boolean, default=False)
    equipment_status = db.Column(db.String(24), default="PRODUCTION")
    is_golden_tool = db.Column(db.Boolean, default=False)

    # Health Scores
    health_score = db.Column(db.Numeric(5, 2), default=100.0)
    health_tier = db.Column(db.String(16), default="HEALTHY")
    health_updated_at = db.Column(db.DateTime(timezone=True))
    z_score_component = db.Column(db.Numeric(5, 3))
    gof_component = db.Column(db.Numeric(5, 3))
    cv_stability_component = db.Column(db.Numeric(5, 3))
    volume_component = db.Column(db.Numeric(5, 3))

    # PM
    last_pm_date = db.Column(db.Date)
    next_pm_date = db.Column(db.Date)
    pm_interval_days = db.Column(db.Integer)

    is_current = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    chambers = db.relationship("Chamber", backref="equipment", lazy="dynamic",
                               foreign_keys="Chamber.equipment_id",
                               primaryjoin="Equipment.equipment_id == Chamber.equipment_id")

    def to_dict(self):
        return {
            "equipment_id": self.equipment_id,
            "equipment_name": self.equipment_name,
            "equipment_type": self.equipment_type,
            "equipment_subtype": self.equipment_subtype,
            "oem_vendor": self.oem_vendor,
            "oem_model": self.oem_model,
            "fab_id": self.fab_id,
            "bay_id": self.bay_id,
            "area_id": self.area_id,
            "chamber_count": self.chamber_count,
            "equipment_status": self.equipment_status,
            "is_golden_tool": self.is_golden_tool,
            "health_score": float(self.health_score) if self.health_score else 100.0,
            "health_tier": self.health_tier,
            "z_score_component": float(self.z_score_component) if self.z_score_component else None,
            "gof_component": float(self.gof_component) if self.gof_component else None,
            "cv_stability_component": float(self.cv_stability_component) if self.cv_stability_component else None,
            "volume_component": float(self.volume_component) if self.volume_component else None,
            "last_pm_date": self.last_pm_date.isoformat() if self.last_pm_date else None,
            "next_pm_date": self.next_pm_date.isoformat() if self.next_pm_date else None,
            "health_updated_at": self.health_updated_at.isoformat() if self.health_updated_at else None,
        }


class Chamber(db.Model):
    __tablename__ = "eqp_dim_chamber"

    chamber_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id = db.Column(db.String(32), nullable=False, index=True)
    chamber_id = db.Column(db.String(16), nullable=False)
    chamber_name = db.Column(db.String(64))
    chamber_type = db.Column(db.String(32))
    chamber_status = db.Column(db.String(24))
    health_score = db.Column(db.Numeric(5, 2))
    last_pm_date = db.Column(db.Date)
    run_since_pm = db.Column(db.Integer, default=0)
    is_reference_chamber = db.Column(db.Boolean, default=False)

    __table_args__ = (
        db.UniqueConstraint("equipment_id", "chamber_id", name="uq_equip_chamber"),
    )

    def to_dict(self):
        return {
            "equipment_id": self.equipment_id,
            "chamber_id": self.chamber_id,
            "chamber_name": self.chamber_name,
            "chamber_type": self.chamber_type,
            "chamber_status": self.chamber_status,
            "health_score": float(self.health_score) if self.health_score else None,
            "last_pm_date": self.last_pm_date.isoformat() if self.last_pm_date else None,
            "run_since_pm": self.run_since_pm,
            "is_reference_chamber": self.is_reference_chamber,
        }
