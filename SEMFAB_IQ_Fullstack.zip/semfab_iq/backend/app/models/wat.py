"""WAT Models"""
from datetime import datetime
from app import db


class WATResult(db.Model):
    __tablename__ = "wat_fact_result"

    result_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    slot_number = db.Column(db.SmallInteger)
    site_id = db.Column(db.SmallInteger, nullable=False)
    site_x = db.Column(db.Numeric(8, 4))
    site_y = db.Column(db.Numeric(8, 4))
    site_zone = db.Column(db.String(8))

    parameter_id = db.Column(db.String(64), nullable=False, index=True)
    parameter_group = db.Column(db.String(32))
    vcc = db.Column(db.Numeric(8, 4))
    temp_c = db.Column(db.Numeric(8, 3))
    freq_hz = db.Column(db.Numeric(16, 4))

    measured_value = db.Column(db.Numeric(20, 10), nullable=False)
    usl = db.Column(db.Numeric(20, 10))
    lsl = db.Column(db.Numeric(20, 10))
    target_value = db.Column(db.Numeric(20, 10))
    pass_fail = db.Column(db.String(1))
    sigma_deviation = db.Column(db.Numeric(10, 6))

    equipment_id = db.Column(db.String(32), index=True)
    chamber_id = db.Column(db.String(16))
    recipe_id = db.Column(db.String(64))
    process_node = db.Column(db.String(16))
    product_id = db.Column(db.String(32))

    is_outlier_mad = db.Column(db.Boolean, default=False)
    is_outlier_grubbs = db.Column(db.Boolean, default=False)
    anomaly_score = db.Column(db.Numeric(6, 4))

    test_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    lot_sequence = db.Column(db.Integer)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        return {
            "lot_id": self.lot_id,
            "wafer_id": self.wafer_id,
            "slot_number": self.slot_number,
            "site_id": self.site_id,
            "site_x": float(self.site_x) if self.site_x else None,
            "site_y": float(self.site_y) if self.site_y else None,
            "site_zone": self.site_zone,
            "parameter_id": self.parameter_id,
            "parameter_group": self.parameter_group,
            "vcc": float(self.vcc) if self.vcc else None,
            "temp_c": float(self.temp_c) if self.temp_c else None,
            "measured_value": float(self.measured_value),
            "usl": float(self.usl) if self.usl else None,
            "lsl": float(self.lsl) if self.lsl else None,
            "target_value": float(self.target_value) if self.target_value else None,
            "pass_fail": self.pass_fail,
            "sigma_deviation": float(self.sigma_deviation) if self.sigma_deviation else None,
            "equipment_id": self.equipment_id,
            "chamber_id": self.chamber_id,
            "recipe_id": self.recipe_id,
            "is_outlier_mad": self.is_outlier_mad,
            "anomaly_score": float(self.anomaly_score) if self.anomaly_score else None,
            "test_time": self.test_time.isoformat() if self.test_time else None,
            "event_date": self.event_date.isoformat() if self.event_date else None,
        }


class WATLotSummary(db.Model):
    __tablename__ = "wat_agg_lot_summary"

    summary_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    parameter_id = db.Column(db.String(64), nullable=False)
    vcc = db.Column(db.Numeric(8, 4))
    temp_c = db.Column(db.Numeric(8, 3))
    product_id = db.Column(db.String(32))
    equipment_id = db.Column(db.String(32))
    event_date = db.Column(db.Date, nullable=False)

    n_sites = db.Column(db.SmallInteger)
    mean_value = db.Column(db.Numeric(20, 10))
    median_value = db.Column(db.Numeric(20, 10))
    std_dev = db.Column(db.Numeric(20, 10))
    min_value = db.Column(db.Numeric(20, 10))
    max_value = db.Column(db.Numeric(20, 10))
    p5_value = db.Column(db.Numeric(20, 10))
    p25_value = db.Column(db.Numeric(20, 10))
    p75_value = db.Column(db.Numeric(20, 10))
    p95_value = db.Column(db.Numeric(20, 10))
    skewness = db.Column(db.Numeric(10, 6))
    kurtosis = db.Column(db.Numeric(10, 6))

    usl = db.Column(db.Numeric(20, 10))
    lsl = db.Column(db.Numeric(20, 10))
    cp = db.Column(db.Numeric(10, 6))
    cpk = db.Column(db.Numeric(10, 6))
    cpm = db.Column(db.Numeric(10, 6))
    ppk = db.Column(db.Numeric(10, 6))

    shapiro_wilk_p = db.Column(db.Numeric(10, 8))
    is_normal_dist = db.Column(db.Boolean)
    n_pass = db.Column(db.SmallInteger)
    n_fail = db.Column(db.SmallInteger)
    pass_rate_pct = db.Column(db.Numeric(6, 3))

    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v):
            return float(v) if v is not None else None
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "parameter_id": self.parameter_id, "vcc": f(self.vcc), "temp_c": f(self.temp_c),
            "equipment_id": self.equipment_id, "event_date": self.event_date.isoformat() if self.event_date else None,
            "n_sites": self.n_sites, "mean_value": f(self.mean_value),
            "median_value": f(self.median_value), "std_dev": f(self.std_dev),
            "min_value": f(self.min_value), "max_value": f(self.max_value),
            "p5_value": f(self.p5_value), "p25_value": f(self.p25_value),
            "p75_value": f(self.p75_value), "p95_value": f(self.p95_value),
            "skewness": f(self.skewness), "kurtosis": f(self.kurtosis),
            "usl": f(self.usl), "lsl": f(self.lsl),
            "cp": f(self.cp), "cpk": f(self.cpk), "cpm": f(self.cpm), "ppk": f(self.ppk),
            "shapiro_wilk_p": f(self.shapiro_wilk_p), "is_normal_dist": self.is_normal_dist,
            "n_pass": self.n_pass, "n_fail": self.n_fail, "pass_rate_pct": f(self.pass_rate_pct),
        }
