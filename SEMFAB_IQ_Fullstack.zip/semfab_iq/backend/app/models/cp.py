"""CP Models"""
from datetime import datetime
from app import db


class CPDieResult(db.Model):
    __tablename__ = "cp_fact_die_result"

    die_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    slot_number = db.Column(db.SmallInteger)
    die_x = db.Column(db.SmallInteger, nullable=False)
    die_y = db.Column(db.SmallInteger, nullable=False)
    die_index = db.Column(db.Integer)
    program_id = db.Column(db.String(64), nullable=False)
    tester_id = db.Column(db.String(32))
    hard_bin = db.Column(db.SmallInteger, nullable=False)
    soft_bin = db.Column(db.SmallInteger)
    is_pass = db.Column(db.Boolean, nullable=False)
    test_count = db.Column(db.SmallInteger, default=1)
    touchdown_number = db.Column(db.SmallInteger)
    was_tested = db.Column(db.Boolean, default=True)
    skip_reason = db.Column(db.String(24))
    is_edge_die = db.Column(db.Boolean, default=False)
    is_spatial_cluster = db.Column(db.Boolean, default=False)
    cluster_id = db.Column(db.Integer)
    test_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    product_id = db.Column(db.String(32))
    process_node = db.Column(db.String(16))
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "slot_number": self.slot_number, "die_x": self.die_x, "die_y": self.die_y,
            "hard_bin": self.hard_bin, "soft_bin": self.soft_bin, "is_pass": self.is_pass,
            "tester_id": self.tester_id, "touchdown_number": self.touchdown_number,
            "was_tested": self.was_tested, "skip_reason": self.skip_reason,
            "is_edge_die": self.is_edge_die,
        }


class CPWaferSummary(db.Model):
    __tablename__ = "cp_fact_wafer_summary"

    summary_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    slot_number = db.Column(db.SmallInteger)
    program_id = db.Column(db.String(64))
    tester_id = db.Column(db.String(32))
    step_id = db.Column(db.String(32))

    total_die = db.Column(db.Integer)
    pass_die = db.Column(db.Integer)
    fail_die = db.Column(db.Integer)
    gross_yield_pct = db.Column(db.Numeric(7, 4))
    net_yield_pct = db.Column(db.Numeric(7, 4))
    first_pass_yield = db.Column(db.Numeric(7, 4))
    retest_count = db.Column(db.Integer, default=0)
    offline_retest_rate = db.Column(db.Numeric(7, 4))

    bin_counts_json = db.Column(db.Text)
    site_yields_json = db.Column(db.Text)

    pattern_class_generic = db.Column(db.String(32))
    pattern_class_primary = db.Column(db.String(32))
    pattern_class_secondary = db.Column(db.String(32))
    pattern_confidence = db.Column(db.Numeric(6, 4))

    edge_yield_pct = db.Column(db.Numeric(7, 4))
    center_yield_pct = db.Column(db.Numeric(7, 4))
    edge_center_delta = db.Column(db.Numeric(7, 4))

    is_partial_wafer = db.Column(db.Boolean, default=False)
    syl_flag = db.Column(db.Boolean, default=False)
    sbl_flag = db.Column(db.Boolean, default=False)
    mrb_required = db.Column(db.Boolean, default=False)
    mrb_result = db.Column(db.String(16))

    event_date = db.Column(db.Date, nullable=False)
    test_time = db.Column(db.DateTime(timezone=True))
    product_id = db.Column(db.String(32))
    process_node = db.Column(db.String(16))
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "lot_id": self.lot_id, "wafer_id": self.wafer_id, "slot_number": self.slot_number,
            "program_id": self.program_id, "tester_id": self.tester_id, "step_id": self.step_id,
            "total_die": self.total_die, "pass_die": self.pass_die, "fail_die": self.fail_die,
            "gross_yield_pct": f(self.gross_yield_pct), "net_yield_pct": f(self.net_yield_pct),
            "first_pass_yield": f(self.first_pass_yield), "retest_count": self.retest_count,
            "offline_retest_rate": f(self.offline_retest_rate),
            "bin_counts_json": self.bin_counts_json, "site_yields_json": self.site_yields_json,
            "pattern_class_generic": self.pattern_class_generic,
            "pattern_class_primary": self.pattern_class_primary,
            "pattern_confidence": f(self.pattern_confidence),
            "edge_yield_pct": f(self.edge_yield_pct), "center_yield_pct": f(self.center_yield_pct),
            "edge_center_delta": f(self.edge_center_delta),
            "is_partial_wafer": self.is_partial_wafer, "syl_flag": self.syl_flag, "sbl_flag": self.sbl_flag,
            "mrb_required": self.mrb_required, "mrb_result": self.mrb_result,
            "event_date": self.event_date.isoformat() if self.event_date else None,
            "test_time": self.test_time.isoformat() if self.test_time else None,
            "product_id": self.product_id, "process_node": self.process_node,
        }
