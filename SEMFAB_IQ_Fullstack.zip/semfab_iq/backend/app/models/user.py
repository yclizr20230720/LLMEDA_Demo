"""User & Auth Models"""
from datetime import datetime
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from app import db

ph = PasswordHasher()


class User(db.Model):
    __tablename__ = "auth_users"

    user_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), nullable=False, unique=True, index=True)
    email = db.Column(db.String(128), nullable=False, unique=True)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(128))
    role = db.Column(db.String(32), nullable=False, default="PROCESS_ENGINEER")
    fab_id = db.Column(db.String(16), default="FAB-12")
    is_active = db.Column(db.Boolean, default=True)
    mfa_enabled = db.Column(db.Boolean, default=False)
    mfa_secret = db.Column(db.String(64))
    last_login = db.Column(db.DateTime(timezone=True))
    login_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    ROLES = [
        "FAB_OPERATOR", "PROCESS_ENGINEER", "EQUIPMENT_ENGINEER",
        "SENIOR_ENGINEER", "PROCESS_INTEGRATION_ENGINEER",
        "MANAGER", "SYSTEM_ADMIN"
    ]

    def set_password(self, password: str):
        self.password_hash = ph.hash(password)

    def check_password(self, password: str) -> bool:
        try:
            return ph.verify(self.password_hash, password)
        except VerifyMismatchError:
            return False

    def to_dict(self):
        return {
            "username": self.username,
            "email": self.email,
            "full_name": self.full_name,
            "role": self.role,
            "fab_id": self.fab_id,
            "is_active": self.is_active,
            "mfa_enabled": self.mfa_enabled,
            "last_login": self.last_login.isoformat() if self.last_login else None,
        }
