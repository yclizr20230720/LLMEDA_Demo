"""MES Lot & Wafer Models"""
from datetime import datetime
from app import db


class Lot(db.Model):
    __tablename__ = "mes_dim_lot"

    lot_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    lot_type = db.Column(db.String(20), nullable=False, default="PRODUCTION")
    lot_subtype = db.Column(db.String(20))
    lot_priority = db.Column(db.SmallInteger, default=5)
    is_split_lot = db.Column(db.Boolean, default=False)
    parent_lot_id = db.Column(db.String(32))

    product_id = db.Column(db.String(32), nullable=False)
    device_family = db.Column(db.String(32))
    customer_id = db.Column(db.String(32))
    customer_order_id = db.Column(db.String(64))

    process_node = db.Column(db.String(16))
    technology_id = db.Column(db.String(32))
    mask_set_id = db.Column(db.String(32))

    lot_status = db.Column(db.String(24), nullable=False, default="ACTIVE")
    hold_code = db.Column(db.String(16))
    hold_reason = db.Column(db.Text)

    wafer_count_start = db.Column(db.SmallInteger)
    wafer_count_current = db.Column(db.SmallInteger)
    wafer_size_mm = db.Column(db.SmallInteger, default=300)

    lot_start_date = db.Column(db.DateTime(timezone=True))
    lot_target_date = db.Column(db.DateTime(timezone=True))
    lot_complete_date = db.Column(db.DateTime(timezone=True))

    target_yield_pct = db.Column(db.Numeric(6, 3))
    syl_pct = db.Column(db.Numeric(6, 3))
    sbl_pct = db.Column(db.Numeric(6, 3))

    is_current = db.Column(db.Boolean, default=True)
    effective_from = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)
    effective_to = db.Column(db.DateTime(timezone=True))

    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "lot_id": self.lot_id,
            "lot_type": self.lot_type,
            "lot_subtype": self.lot_subtype,
            "lot_priority": self.lot_priority,
            "product_id": self.product_id,
            "device_family": self.device_family,
            "customer_id": self.customer_id,
            "process_node": self.process_node,
            "technology_id": self.technology_id,
            "lot_status": self.lot_status,
            "hold_code": self.hold_code,
            "hold_reason": self.hold_reason,
            "wafer_count_start": self.wafer_count_start,
            "wafer_count_current": self.wafer_count_current,
            "lot_start_date": self.lot_start_date.isoformat() if self.lot_start_date else None,
            "lot_target_date": self.lot_target_date.isoformat() if self.lot_target_date else None,
            "target_yield_pct": float(self.target_yield_pct) if self.target_yield_pct else None,
            "syl_pct": float(self.syl_pct) if self.syl_pct else None,
            "sbl_pct": float(self.sbl_pct) if self.sbl_pct else None,
        }


class Wafer(db.Model):
    __tablename__ = "mes_dim_wafer"

    wafer_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    lot_id = db.Column(db.String(32), nullable=False, index=True)
    wafer_id = db.Column(db.String(40), nullable=False)
    slot_number = db.Column(db.SmallInteger, nullable=False)
    wafer_status = db.Column(db.String(20), default="ACTIVE")
    die_per_wafer = db.Column(db.Integer)
    die_count_good = db.Column(db.Integer)
    cp_yield_pct = db.Column(db.Numeric(6, 3))
    final_disposition = db.Column(db.String(24))
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint("lot_id", "slot_number", name="uq_lot_slot"),
    )

    def to_dict(self):
        return {
            "lot_id": self.lot_id,
            "wafer_id": self.wafer_id,
            "slot_number": self.slot_number,
            "wafer_status": self.wafer_status,
            "die_per_wafer": self.die_per_wafer,
            "die_count_good": self.die_count_good,
            "cp_yield_pct": float(self.cp_yield_pct) if self.cp_yield_pct else None,
            "final_disposition": self.final_disposition,
        }
