"""SPC Models"""
from datetime import datetime
from app import db


class SPCConfig(db.Model):
    __tablename__ = "spc_dim_parameter_config"

    config_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id = db.Column(db.String(64), nullable=False, unique=True, index=True)
    parameter_id = db.Column(db.String(64), nullable=False)
    parameter_source = db.Column(db.String(20), nullable=False, default="WAT")
    product_id = db.Column(db.String(32))
    technology_id = db.Column(db.String(32))
    equipment_id = db.Column(db.String(32))
    chamber_id = db.Column(db.String(16))
    recipe_id = db.Column(db.String(64))
    step_id = db.Column(db.String(32))
    chart_type = db.Column(db.String(16), nullable=False, default="IMR")
    subgroup_size = db.Column(db.SmallInteger, default=1)

    ucl = db.Column(db.Numeric(20, 10))
    cl = db.Column(db.Numeric(20, 10))
    lcl = db.Column(db.Numeric(20, 10))
    ucl_2sigma = db.Column(db.Numeric(20, 10))
    lcl_2sigma = db.Column(db.Numeric(20, 10))
    ucl_1sigma = db.Column(db.Numeric(20, 10))
    lcl_1sigma = db.Column(db.Numeric(20, 10))
    sigma_estimate = db.Column(db.Numeric(20, 10))
    usl = db.Column(db.Numeric(20, 10))
    lsl = db.Column(db.Numeric(20, 10))
    target = db.Column(db.Numeric(20, 10))

    enabled_rules = db.Column(db.SmallInteger, default=255)
    alarm_mode = db.Column(db.String(16), default="EMAIL")
    alarm_severity = db.Column(db.String(16), default="MAJOR")
    is_virtual = db.Column(db.Boolean, default=False)
    vm_model_id = db.Column(db.String(64))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "config_id": self.config_id, "parameter_id": self.parameter_id,
            "parameter_source": self.parameter_source, "product_id": self.product_id,
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "step_id": self.step_id, "chart_type": self.chart_type,
            "subgroup_size": self.subgroup_size,
            "ucl": f(self.ucl), "cl": f(self.cl), "lcl": f(self.lcl),
            "ucl_2sigma": f(self.ucl_2sigma), "lcl_2sigma": f(self.lcl_2sigma),
            "sigma_estimate": f(self.sigma_estimate),
            "usl": f(self.usl), "lsl": f(self.lsl), "target": f(self.target),
            "enabled_rules": self.enabled_rules, "alarm_mode": self.alarm_mode,
            "is_virtual": self.is_virtual, "is_active": self.is_active,
        }


class SPCMeasurement(db.Model):
    __tablename__ = "spc_fact_measurement"

    measurement_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id = db.Column(db.String(64), nullable=False, index=True)
    parameter_id = db.Column(db.String(64), nullable=False)
    lot_id = db.Column(db.String(32), index=True)
    wafer_id = db.Column(db.String(40))
    equipment_id = db.Column(db.String(32), index=True)
    chamber_id = db.Column(db.String(16))
    subgroup_index = db.Column(db.Integer)
    measured_value = db.Column(db.Numeric(20, 10), nullable=False)
    subgroup_mean = db.Column(db.Numeric(20, 10))
    subgroup_range = db.Column(db.Numeric(20, 10))
    moving_range = db.Column(db.Numeric(20, 10))
    ucl_at_time = db.Column(db.Numeric(20, 10))
    cl_at_time = db.Column(db.Numeric(20, 10))
    lcl_at_time = db.Column(db.Numeric(20, 10))
    sigma_score = db.Column(db.Numeric(10, 6))

    # 8 Western Electric Rules as separate boolean columns
    violation_rule_1 = db.Column(db.Boolean, default=False)
    violation_rule_2 = db.Column(db.Boolean, default=False)
    violation_rule_3 = db.Column(db.Boolean, default=False)
    violation_rule_4 = db.Column(db.Boolean, default=False)
    violation_rule_5 = db.Column(db.Boolean, default=False)
    violation_rule_6 = db.Column(db.Boolean, default=False)
    violation_rule_7 = db.Column(db.Boolean, default=False)
    violation_rule_8 = db.Column(db.Boolean, default=False)
    any_violation = db.Column(db.Boolean, default=False, index=True)
    violation_rules_list = db.Column(db.String(32))
    alarm_triggered = db.Column(db.Boolean, default=False)
    alarm_severity = db.Column(db.String(16))

    is_virtual = db.Column(db.Boolean, default=False)
    vm_predicted_value = db.Column(db.Numeric(20, 10))
    vm_ci_lower = db.Column(db.Numeric(20, 10))
    vm_ci_upper = db.Column(db.Numeric(20, 10))

    measurement_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "config_id": self.config_id, "parameter_id": self.parameter_id,
            "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "subgroup_index": self.subgroup_index,
            "measured_value": f(self.measured_value),
            "subgroup_mean": f(self.subgroup_mean), "subgroup_range": f(self.subgroup_range),
            "moving_range": f(self.moving_range), "sigma_score": f(self.sigma_score),
            "ucl_at_time": f(self.ucl_at_time), "cl_at_time": f(self.cl_at_time),
            "lcl_at_time": f(self.lcl_at_time),
            "violation_rule_1": self.violation_rule_1, "violation_rule_2": self.violation_rule_2,
            "violation_rule_3": self.violation_rule_3, "violation_rule_4": self.violation_rule_4,
            "violation_rule_5": self.violation_rule_5, "violation_rule_6": self.violation_rule_6,
            "violation_rule_7": self.violation_rule_7, "violation_rule_8": self.violation_rule_8,
            "any_violation": self.any_violation, "violation_rules_list": self.violation_rules_list,
            "alarm_triggered": self.alarm_triggered, "alarm_severity": self.alarm_severity,
            "is_virtual": self.is_virtual, "vm_predicted_value": f(self.vm_predicted_value),
            "vm_ci_lower": f(self.vm_ci_lower), "vm_ci_upper": f(self.vm_ci_upper),
            "measurement_time": self.measurement_time.isoformat() if self.measurement_time else None,
            "event_date": self.event_date.isoformat() if self.event_date else None,
        }


class SPCViolation(db.Model):
    __tablename__ = "spc_fact_violation"

    violation_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    config_id = db.Column(db.String(64), nullable=False, index=True)
    parameter_id = db.Column(db.String(64), nullable=False)
    equipment_id = db.Column(db.String(32))
    chamber_id = db.Column(db.String(16))
    rule_number = db.Column(db.SmallInteger, nullable=False)
    rule_description = db.Column(db.String(256))
    rule_severity = db.Column(db.String(16))
    trigger_value = db.Column(db.Numeric(20, 10))
    trigger_lot_id = db.Column(db.String(32))
    sigma_deviation = db.Column(db.Numeric(10, 6))
    acknowledged_by = db.Column(db.String(64))
    acknowledged_at = db.Column(db.DateTime(timezone=True))
    resolution_code = db.Column(db.String(32))
    resolution_note = db.Column(db.Text)
    violation_time = db.Column(db.DateTime(timezone=True), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "violation_sk": self.violation_sk, "config_id": self.config_id,
            "parameter_id": self.parameter_id, "equipment_id": self.equipment_id,
            "chamber_id": self.chamber_id, "rule_number": self.rule_number,
            "rule_description": self.rule_description, "rule_severity": self.rule_severity,
            "trigger_value": f(self.trigger_value), "trigger_lot_id": self.trigger_lot_id,
            "sigma_deviation": f(self.sigma_deviation),
            "acknowledged_by": self.acknowledged_by,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            "resolution_code": self.resolution_code, "resolution_note": self.resolution_note,
            "violation_time": self.violation_time.isoformat() if self.violation_time else None,
        }
