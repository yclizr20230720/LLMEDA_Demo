"""FDC Models"""
from datetime import datetime
from app import db


class FDCTraceRun(db.Model):
    __tablename__ = "fdc_fact_trace_run"

    run_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    run_id = db.Column(db.String(64), nullable=False, unique=True, index=True)
    lot_id = db.Column(db.String(32), index=True)
    wafer_id = db.Column(db.String(40))
    equipment_id = db.Column(db.String(32), nullable=False, index=True)
    chamber_id = db.Column(db.String(16))
    recipe_id = db.Column(db.String(64))
    step_id = db.Column(db.String(32))
    product_id = db.Column(db.String(32))
    process_node = db.Column(db.String(16))

    run_start_time = db.Column(db.DateTime(timezone=True), nullable=False)
    run_end_time = db.Column(db.DateTime(timezone=True))
    run_duration_sec = db.Column(db.Numeric(12, 4))
    process_steps_json = db.Column(db.Text)

    run_result = db.Column(db.String(16), default="PASS")
    alarm_count = db.Column(db.SmallInteger, default=0)
    alarm_sensor_list = db.Column(db.Text)

    interval_anomaly_score = db.Column(db.Numeric(8, 6))
    pm_anomaly_score = db.Column(db.Numeric(8, 6))
    amplitude_anomaly_score = db.Column(db.Numeric(8, 6))
    shape_anomaly_score = db.Column(db.Numeric(8, 6))
    composite_anomaly_score = db.Column(db.Numeric(8, 6))
    anomaly_class = db.Column(db.String(32))
    is_anomaly = db.Column(db.Boolean, default=False)
    is_post_pm = db.Column(db.Boolean, default=False)
    pm_wafer_count = db.Column(db.Integer)

    is_qualification_run = db.Column(db.Boolean, default=False)
    baseline_run_id = db.Column(db.String(64))
    qual_match_score = db.Column(db.Numeric(8, 6))

    event_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "run_id": self.run_id, "lot_id": self.lot_id, "wafer_id": self.wafer_id,
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "recipe_id": self.recipe_id, "step_id": self.step_id,
            "run_start_time": self.run_start_time.isoformat() if self.run_start_time else None,
            "run_end_time": self.run_end_time.isoformat() if self.run_end_time else None,
            "run_duration_sec": f(self.run_duration_sec),
            "run_result": self.run_result, "alarm_count": self.alarm_count,
            "alarm_sensor_list": self.alarm_sensor_list,
            "interval_anomaly_score": f(self.interval_anomaly_score),
            "pm_anomaly_score": f(self.pm_anomaly_score),
            "amplitude_anomaly_score": f(self.amplitude_anomaly_score),
            "shape_anomaly_score": f(self.shape_anomaly_score),
            "composite_anomaly_score": f(self.composite_anomaly_score),
            "anomaly_class": self.anomaly_class, "is_anomaly": self.is_anomaly,
            "is_post_pm": self.is_post_pm, "pm_wafer_count": self.pm_wafer_count,
            "is_qualification_run": self.is_qualification_run,
            "qual_match_score": f(self.qual_match_score),
            "event_date": self.event_date.isoformat() if self.event_date else None,
        }


class FDCPMEvent(db.Model):
    __tablename__ = "fdc_fact_pm_event"

    pm_sk = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    equipment_id = db.Column(db.String(32), nullable=False, index=True)
    chamber_id = db.Column(db.String(16))
    pm_type = db.Column(db.String(32))
    pm_subtype = db.Column(db.String(32))
    pm_code = db.Column(db.String(16))
    pm_start_time = db.Column(db.DateTime(timezone=True), nullable=False)
    pm_end_time = db.Column(db.DateTime(timezone=True))
    pm_duration_hr = db.Column(db.Numeric(8, 3))
    trigger_source = db.Column(db.String(24))
    trigger_health_score = db.Column(db.Numeric(5, 2))
    performed_by = db.Column(db.String(64))
    pre_pm_health_score = db.Column(db.Numeric(5, 2))
    post_pm_health_score = db.Column(db.Numeric(5, 2))
    health_improvement = db.Column(db.Numeric(5, 2))
    qualification_passed = db.Column(db.Boolean)
    qual_run_id = db.Column(db.String(64))
    wafers_impacted = db.Column(db.Integer, default=0)
    cmms_work_order_id = db.Column(db.String(32))
    event_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.utcnow)

    def to_dict(self):
        def f(v): return float(v) if v is not None else None
        return {
            "equipment_id": self.equipment_id, "chamber_id": self.chamber_id,
            "pm_type": self.pm_type, "pm_subtype": self.pm_subtype,
            "pm_start_time": self.pm_start_time.isoformat() if self.pm_start_time else None,
            "pm_end_time": self.pm_end_time.isoformat() if self.pm_end_time else None,
            "pm_duration_hr": f(self.pm_duration_hr), "trigger_source": self.trigger_source,
            "trigger_health_score": f(self.trigger_health_score),
            "performed_by": self.performed_by,
            "pre_pm_health_score": f(self.pre_pm_health_score),
            "post_pm_health_score": f(self.post_pm_health_score),
            "health_improvement": f(self.health_improvement),
            "qualification_passed": self.qualification_passed, "wafers_impacted": self.wafers_impacted,
        }
