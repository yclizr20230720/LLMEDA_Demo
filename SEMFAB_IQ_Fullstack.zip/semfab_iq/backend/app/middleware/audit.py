"""Audit Logging Middleware"""
import logging
from flask import g, request
from datetime import datetime

logger = logging.getLogger("semfab.audit")


def audit_middleware(app):
    @app.after_request
    def log_request(response):
        if request.path.startswith("/api/"):
            logger.info(
                "API %s %s %d %s user=%s",
                request.method, request.path,
                response.status_code,
                getattr(g, "request_id", "-"),
                getattr(g, "current_user", "anonymous"),
            )
        return response
