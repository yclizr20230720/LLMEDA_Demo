"""Request ID Injection Middleware"""
import uuid
from flask import g, request


def inject_request_id(app):
    @app.before_request
    def set_request_id():
        g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))

    @app.after_request
    def add_request_id_header(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        return response
