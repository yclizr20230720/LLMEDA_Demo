"""SEMFAB·IQ — Flask Application Factory"""
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_caching import Cache
from flask_socketio import SocketIO

from config.settings import config_map

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()
cache = Cache()
limiter = Limiter(key_func=get_remote_address)
socketio = SocketIO()


def create_app(config_name: str = None) -> Flask:
    config_name = config_name or os.getenv("FLASK_ENV", "development")
    app = Flask(__name__)
    app.config.from_object(config_map[config_name])

    # ── Extensions ──
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cache.init_app(app)
    limiter.init_app(app)
    CORS(app, origins=app.config["CORS_ORIGINS"], supports_credentials=True)
    socketio.init_app(
        app,
        cors_allowed_origins=app.config["CORS_ORIGINS"],
        async_mode="gevent",
        logger=False,
    )

    # ── Middleware ──
    from app.middleware.request_id import inject_request_id
    from app.middleware.audit import audit_middleware
    inject_request_id(app)
    audit_middleware(app)

    # ── Blueprints ──
    from app.routes.auth import auth_bp
    from app.routes.yield_routes import yield_bp
    from app.routes.wat_routes import wat_bp
    from app.routes.cp_routes import cp_bp
    from app.routes.spc_routes import spc_bp
    from app.routes.fdc_routes import fdc_bp
    from app.routes.defect_routes import defect_bp
    from app.routes.equipment_routes import equipment_bp
    from app.routes.health import health_bp

    app.register_blueprint(health_bp)
    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(yield_bp, url_prefix="/api/v1/yield")
    app.register_blueprint(wat_bp, url_prefix="/api/v1/wat")
    app.register_blueprint(cp_bp, url_prefix="/api/v1/cp")
    app.register_blueprint(spc_bp, url_prefix="/api/v1/spc")
    app.register_blueprint(fdc_bp, url_prefix="/api/v1/fdc")
    app.register_blueprint(defect_bp, url_prefix="/api/v1/defect")
    app.register_blueprint(equipment_bp, url_prefix="/api/v1/equipment")

    # ── Error Handlers ──
    from app.utils.errors import register_error_handlers
    register_error_handlers(app)

    # ── WebSocket Events ──
    from app.utils.websocket import register_socket_events
    register_socket_events(socketio)

    return app
