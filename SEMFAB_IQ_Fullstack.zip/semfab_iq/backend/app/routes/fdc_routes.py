"""FDC Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import desc
from app import db, cache
from app.models.fdc import FDCTraceRun, FDCPMEvent
from app.models.equipment import Equipment
from app.utils.response import success, error

fdc_bp = Blueprint("fdc", __name__)


@fdc_bp.route("/trace-runs", methods=["GET"])
@jwt_required()
def trace_runs():
    equipment_id = request.args.get("equipment_id")
    is_anomaly = request.args.get("is_anomaly")
    from datetime import date, timedelta
    days = int(request.args.get("days", 14))
    cutoff = date.today() - timedelta(days=days)

    query = FDCTraceRun.query.filter(FDCTraceRun.event_date >= cutoff)
    if equipment_id:
        query = query.filter(FDCTraceRun.equipment_id == equipment_id)
    if is_anomaly:
        query = query.filter(FDCTraceRun.is_anomaly == (is_anomaly.lower() == "true"))

    runs = query.order_by(desc(FDCTraceRun.run_start_time)).limit(200).all()
    return success([r.to_dict() for r in runs])


@fdc_bp.route("/anomaly-summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def anomaly_summary():
    from datetime import date, timedelta
    from sqlalchemy import func
    days = int(request.args.get("days", 30))
    cutoff = date.today() - timedelta(days=days)

    results = db.session.query(
        FDCTraceRun.equipment_id,
        func.count(FDCTraceRun.run_id).label("total_runs"),
        func.sum(db.cast(FDCTraceRun.is_anomaly, db.Integer)).label("anomaly_count"),
        func.avg(FDCTraceRun.composite_anomaly_score).label("avg_score"),
        func.max(FDCTraceRun.composite_anomaly_score).label("max_score"),
    ).filter(FDCTraceRun.event_date >= cutoff).group_by(
        FDCTraceRun.equipment_id
    ).order_by(desc("anomaly_count")).all()

    return success([{
        "equipment_id": r.equipment_id,
        "total_runs": r.total_runs,
        "anomaly_count": r.anomaly_count or 0,
        "anomaly_rate_pct": round((r.anomaly_count or 0) / r.total_runs * 100, 2) if r.total_runs else 0,
        "avg_score": round(float(r.avg_score), 4) if r.avg_score else 0,
        "max_score": round(float(r.max_score), 4) if r.max_score else 0,
    } for r in results])


@fdc_bp.route("/pm-events", methods=["GET"])
@jwt_required()
def pm_events():
    equipment_id = request.args.get("equipment_id")
    query = FDCPMEvent.query
    if equipment_id:
        query = query.filter(FDCPMEvent.equipment_id == equipment_id)
    events = query.order_by(desc(FDCPMEvent.pm_start_time)).limit(50).all()
    return success([e.to_dict() for e in events])
