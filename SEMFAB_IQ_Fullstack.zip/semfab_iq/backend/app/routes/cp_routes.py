"""CP Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
import json
from app import db, cache
from app.models.cp import CPDieResult, CPWaferSummary
from app.utils.response import success, error

cp_bp = Blueprint("cp", __name__)


@cp_bp.route("/bin-map", methods=["GET"])
@jwt_required()
@cache.cached(timeout=3600, query_string=True)
def bin_map():
    lot_id = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id or not wafer_id:
        return error("MISSING_PARAM", "lot_id and wafer_id required")

    dies = CPDieResult.query.filter_by(lot_id=lot_id, wafer_id=wafer_id).all()
    if not dies:
        return error("NO_DATA", "No die data found")

    # Columnar compression: separate arrays instead of list of dicts
    xs = [d.die_x for d in dies]
    ys = [d.die_y for d in dies]
    bins = [d.hard_bin for d in dies]
    passes = [d.is_pass for d in dies]

    return success({
        "lot_id": lot_id, "wafer_id": wafer_id,
        "die_count": len(dies),
        "xs": xs, "ys": ys, "bins": bins, "passes": passes,
    })


@cp_bp.route("/wafer-summary", methods=["GET"])
@jwt_required()
def wafer_summary():
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id required")
    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).order_by(
        CPWaferSummary.slot_number
    ).all()
    return success([w.to_dict() for w in wafers])


@cp_bp.route("/mrb-review", methods=["GET"])
@jwt_required()
def mrb_review():
    from datetime import date, timedelta
    days = int(request.args.get("days", 7))
    cutoff = date.today() - timedelta(days=days)
    wafers = CPWaferSummary.query.filter(
        CPWaferSummary.mrb_required == True,
        CPWaferSummary.event_date >= cutoff,
    ).order_by(CPWaferSummary.lot_id, CPWaferSummary.slot_number).all()
    return success([w.to_dict() for w in wafers])
