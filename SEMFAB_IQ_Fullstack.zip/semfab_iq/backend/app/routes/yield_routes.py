"""Yield Routes — YMS Dashboard API"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc, and_
from app import db, cache
from app.models.lot import Lot
from app.models.cp import CPWaferSummary
from app.utils.response import success, error, paginated

yield_bp = Blueprint("yield", __name__)


@yield_bp.route("/summary", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def yield_summary():
    lot_id = request.args.get("lot_id")
    product_id = request.args.get("product_id")
    process_node = request.args.get("process_node")
    days = int(request.args.get("days", 30))

    query = db.session.query(
        CPWaferSummary.lot_id,
        func.avg(CPWaferSummary.gross_yield_pct).label("avg_yield"),
        func.min(CPWaferSummary.gross_yield_pct).label("min_yield"),
        func.max(CPWaferSummary.gross_yield_pct).label("max_yield"),
        func.count(CPWaferSummary.wafer_id).label("wafer_count"),
        func.sum(CPWaferSummary.total_die).label("total_die"),
        func.sum(CPWaferSummary.pass_die).label("total_pass"),
        CPWaferSummary.product_id,
        CPWaferSummary.process_node,
    ).group_by(
        CPWaferSummary.lot_id, CPWaferSummary.product_id, CPWaferSummary.process_node
    )

    if lot_id:
        query = query.filter(CPWaferSummary.lot_id == lot_id)
    if product_id:
        query = query.filter(CPWaferSummary.product_id == product_id)
    if process_node:
        query = query.filter(CPWaferSummary.process_node == process_node)

    from datetime import date, timedelta
    cutoff = date.today() - timedelta(days=days)
    query = query.filter(CPWaferSummary.event_date >= cutoff)
    query = query.order_by(desc(CPWaferSummary.lot_id)).limit(200)

    results = query.all()
    data = [{
        "lot_id": r.lot_id, "avg_yield": round(float(r.avg_yield), 3) if r.avg_yield else None,
        "min_yield": round(float(r.min_yield), 3) if r.min_yield else None,
        "max_yield": round(float(r.max_yield), 3) if r.max_yield else None,
        "wafer_count": r.wafer_count, "total_die": r.total_die, "total_pass": r.total_pass,
        "product_id": r.product_id, "process_node": r.process_node,
    } for r in results]

    return success(data, meta={"count": len(data), "days": days})


@yield_bp.route("/trend", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def yield_trend():
    from datetime import date, timedelta
    product_id = request.args.get("product_id", "PROD_N5_001")
    days = int(request.args.get("days", 30))
    cutoff = date.today() - timedelta(days=days)

    results = db.session.query(
        CPWaferSummary.event_date,
        func.avg(CPWaferSummary.gross_yield_pct).label("mean"),
        func.percentile_cont(0.1).within_group(CPWaferSummary.gross_yield_pct).label("p10"),
        func.percentile_cont(0.9).within_group(CPWaferSummary.gross_yield_pct).label("p90"),
        func.percentile_cont(0.25).within_group(CPWaferSummary.gross_yield_pct).label("p25"),
        func.percentile_cont(0.75).within_group(CPWaferSummary.gross_yield_pct).label("p75"),
        func.count(CPWaferSummary.wafer_id).label("n"),
    ).filter(
        CPWaferSummary.product_id == product_id,
        CPWaferSummary.event_date >= cutoff,
    ).group_by(CPWaferSummary.event_date).order_by(CPWaferSummary.event_date).all()

    data = [{
        "date": str(r.event_date),
        "mean": round(float(r.mean), 3) if r.mean else None,
        "p10": round(float(r.p10), 3) if r.p10 else None,
        "p90": round(float(r.p90), 3) if r.p90 else None,
        "p25": round(float(r.p25), 3) if r.p25 else None,
        "p75": round(float(r.p75), 3) if r.p75 else None,
        "n": r.n,
    } for r in results]
    return success(data)


@yield_bp.route("/wafer-gallery", methods=["GET"])
@jwt_required()
def wafer_gallery():
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).order_by(
        CPWaferSummary.slot_number
    ).all()
    return success([w.to_dict() for w in wafers])


@yield_bp.route("/bin-pareto", methods=["GET"])
@jwt_required()
def bin_pareto():
    lot_id = request.args.get("lot_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id is required")

    import json
    wafers = CPWaferSummary.query.filter_by(lot_id=lot_id).all()
    aggregated = {}
    total = 0
    for w in wafers:
        if w.bin_counts_json:
            bins = json.loads(w.bin_counts_json)
            for bin_code, cnt in bins.items():
                aggregated[bin_code] = aggregated.get(bin_code, 0) + cnt
                total += cnt

    sorted_bins = sorted(aggregated.items(), key=lambda x: x[1], reverse=True)
    cumulative = 0
    result = []
    for bin_code, count in sorted_bins:
        cumulative += count
        result.append({
            "bin_code": bin_code,
            "count": count,
            "pct": round(count / total * 100, 2) if total else 0,
            "cumulative_pct": round(cumulative / total * 100, 2) if total else 0,
        })
    return success(result)


@yield_bp.route("/excursions", methods=["GET"])
@jwt_required()
def excursions():
    from app.models.cp import CPWaferSummary
    from datetime import date, timedelta
    days = int(request.args.get("days", 7))
    cutoff = date.today() - timedelta(days=days)

    low_yield = CPWaferSummary.query.filter(
        CPWaferSummary.syl_flag == True,
        CPWaferSummary.event_date >= cutoff,
    ).order_by(desc(CPWaferSummary.test_time)).limit(50).all()

    return success([{
        **w.to_dict(),
        "severity": "CRITICAL" if w.sbl_flag else "MAJOR",
        "excursion_type": "YIELD_DROP",
    } for w in low_yield])
