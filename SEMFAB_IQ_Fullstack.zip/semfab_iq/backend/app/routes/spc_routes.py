"""SPC Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import desc
from app import db, cache
from app.models.spc import SPCConfig, SPCMeasurement, SPCViolation
from app.services.spc_engine import check_all_rules, compute_capability
from app.utils.response import success, error

spc_bp = Blueprint("spc", __name__)


@spc_bp.route("/configs", methods=["GET"])
@jwt_required()
def list_configs():
    configs = SPCConfig.query.filter_by(is_active=True).all()
    return success([c.to_dict() for c in configs])


@spc_bp.route("/chart", methods=["GET"])
@jwt_required()
@cache.cached(timeout=300, query_string=True)
def chart():
    config_id = request.args.get("config_id")
    if not config_id:
        return error("MISSING_PARAM", "config_id required")
    from datetime import date, timedelta
    days = int(request.args.get("days", 30))
    cutoff = date.today() - timedelta(days=days)

    config = SPCConfig.query.filter_by(config_id=config_id).first()
    if not config:
        return error("NOT_FOUND", "SPC config not found", status_code=404)

    measurements = SPCMeasurement.query.filter(
        SPCMeasurement.config_id == config_id,
        SPCMeasurement.event_date >= cutoff,
    ).order_by(SPCMeasurement.measurement_time).limit(500).all()

    return success({
        "config": config.to_dict(),
        "measurements": [m.to_dict() for m in measurements],
    })


@spc_bp.route("/violations", methods=["GET"])
@jwt_required()
def violations():
    equipment_id = request.args.get("equipment_id")
    from datetime import date, timedelta
    days = int(request.args.get("days", 7))
    cutoff = date.today() - timedelta(days=days)

    query = SPCViolation.query.filter(SPCViolation.event_date >= cutoff)
    if equipment_id:
        query = query.filter(SPCViolation.equipment_id == equipment_id)
    viols = query.order_by(desc(SPCViolation.violation_time)).limit(100).all()
    return success([v.to_dict() for v in viols])


@spc_bp.route("/capability", methods=["GET"])
@jwt_required()
def capability():
    config_id = request.args.get("config_id")
    if not config_id:
        return error("MISSING_PARAM", "config_id required")
    from datetime import date, timedelta
    days = int(request.args.get("days", 90))
    cutoff = date.today() - timedelta(days=days)

    config = SPCConfig.query.filter_by(config_id=config_id).first()
    if not config:
        return error("NOT_FOUND", "Config not found", status_code=404)

    measurements = SPCMeasurement.query.filter(
        SPCMeasurement.config_id == config_id,
        SPCMeasurement.event_date >= cutoff,
    ).all()
    values = [float(m.measured_value) for m in measurements]
    if len(values) < 5:
        return error("INSUFFICIENT_DATA", "Need at least 5 measurements")

    usl = float(config.usl) if config.usl else None
    lsl = float(config.lsl) if config.lsl else None
    target = float(config.target) if config.target else None

    cap = compute_capability(values, usl, lsl, target) if usl and lsl else {}

    violations_check = check_all_rules(values, float(config.ucl or 0),
                                       float(config.cl or 0), float(config.lcl or 0),
                                       float(config.sigma_estimate or 1), config.enabled_rules or 255)
    return success({**cap, "violations_summary": violations_check, "n": len(values)})


@spc_bp.route("/check-rules", methods=["POST"])
@jwt_required()
def check_rules_endpoint():
    data = request.get_json()
    values = data.get("values", [])
    ucl = data.get("ucl", 0)
    cl = data.get("cl", 0)
    lcl = data.get("lcl", 0)
    sigma = data.get("sigma", 1)
    enabled = data.get("enabled_rules", 255)
    if not values:
        return error("MISSING_PARAM", "values array required")
    result = check_all_rules(values, ucl, cl, lcl, sigma, enabled)
    return success(result)
