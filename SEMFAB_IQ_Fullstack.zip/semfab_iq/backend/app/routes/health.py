"""Health & Status Routes"""
from flask import Blueprint, jsonify
from datetime import datetime
from app import db

health_bp = Blueprint("health", __name__)


@health_bp.route("/health")
def health():
    try:
        db.session.execute(db.text("SELECT 1"))
        db_status = "ok"
    except Exception:
        db_status = "error"
    return jsonify({
        "status": "ok",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "db": db_status,
        "fab": "FAB-12",
    })


@health_bp.route("/api/v1/version")
def version():
    return jsonify({"version": "1.0.0", "api": "v1", "platform": "SEMFAB·IQ"})
