"""Auth Routes — JWT login/refresh/logout"""
from flask import Blueprint, request
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from datetime import datetime
from app import db, limiter
from app.models.user import User
from app.utils.response import success, error

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
@limiter.limit("10 per minute")
def login():
    data = request.get_json()
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or not password:
        return error("MISSING_CREDENTIALS", "Username and password required")

    user = User.query.filter_by(username=username, is_active=True).first()
    if not user or not user.check_password(password):
        return error("INVALID_CREDENTIALS", "Invalid username or password", status_code=401)

    # Update last login
    user.last_login = datetime.utcnow()
    user.login_count = (user.login_count or 0) + 1
    db.session.commit()

    access_token = create_access_token(
        identity=user.username,
        additional_claims={"role": user.role, "fab_id": user.fab_id}
    )
    refresh_token = create_refresh_token(identity=user.username)

    return success({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user": user.to_dict(),
    })


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    user = User.query.filter_by(username=identity, is_active=True).first()
    if not user:
        return error("USER_NOT_FOUND", "User not found", status_code=401)
    access_token = create_access_token(
        identity=user.username,
        additional_claims={"role": user.role, "fab_id": user.fab_id}
    )
    return success({"access_token": access_token})


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    identity = get_jwt_identity()
    user = User.query.filter_by(username=identity).first()
    if not user:
        return error("USER_NOT_FOUND", "User not found", status_code=404)
    return success(user.to_dict())


@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    return success({"message": "Logged out successfully"})
