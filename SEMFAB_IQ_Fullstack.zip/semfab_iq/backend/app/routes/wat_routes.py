"""WAT Analytics Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc
import numpy as np
from scipy import stats
from app import db, cache
from app.models.wat import WATResult, WATLotSummary
from app.services.spc_engine import compute_capability, check_all_rules
from app.utils.response import success, error

wat_bp = Blueprint("wat", __name__)


@wat_bp.route("/parameters", methods=["GET"])
@jwt_required()
@cache.cached(timeout=3600)
def list_parameters():
    params = db.session.query(
        WATResult.parameter_id,
        WATResult.parameter_group,
        func.count(WATResult.result_sk).label("n"),
    ).group_by(WATResult.parameter_id, WATResult.parameter_group).all()
    return success([{"parameter_id": p.parameter_id, "parameter_group": p.parameter_group, "count": p.n}
                    for p in params])


@wat_bp.route("/distribution", methods=["GET"])
@jwt_required()
def distribution():
    lot_id = request.args.get("lot_id")
    parameter_id = request.args.get("parameter_id")
    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id is required")

    query = WATResult.query.filter(WATResult.parameter_id == parameter_id)
    if lot_id:
        query = query.filter(WATResult.lot_id == lot_id)
    results = query.limit(5000).all()
    if not results:
        return error("NO_DATA", "No data found for this parameter")

    values = [float(r.measured_value) for r in results]
    arr = np.array(values)
    usl = float(results[0].usl) if results[0].usl else None
    lsl = float(results[0].lsl) if results[0].lsl else None

    sw_stat, sw_p = stats.shapiro(arr[:5000]) if len(arr) <= 5000 else (None, None)
    hist, bin_edges = np.histogram(arr, bins=30)

    capability = {}
    if usl and lsl:
        capability = compute_capability(values, usl, lsl)

    return success({
        "parameter_id": parameter_id,
        "n": len(values),
        "mean": round(float(arr.mean()), 6),
        "median": round(float(np.median(arr)), 6),
        "std": round(float(arr.std()), 6),
        "min": round(float(arr.min()), 6),
        "max": round(float(arr.max()), 6),
        "p5": round(float(np.percentile(arr, 5)), 6),
        "p25": round(float(np.percentile(arr, 25)), 6),
        "p75": round(float(np.percentile(arr, 75)), 6),
        "p95": round(float(np.percentile(arr, 95)), 6),
        "skewness": round(float(stats.skew(arr)), 4),
        "kurtosis": round(float(stats.kurtosis(arr)), 4),
        "shapiro_wilk_p": round(float(sw_p), 6) if sw_p else None,
        "is_normal": float(sw_p) > 0.05 if sw_p else None,
        "usl": usl, "lsl": lsl,
        "capability": capability,
        "histogram": {"counts": hist.tolist(), "edges": [round(e, 6) for e in bin_edges.tolist()]},
        "values": [round(v, 6) for v in values[:2000]],
    })


@wat_bp.route("/correlation-matrix", methods=["GET"])
@jwt_required()
def correlation_matrix():
    from datetime import date, timedelta
    product_id = request.args.get("product_id", "PROD_N5_001")
    days = int(request.args.get("days", 30))
    cutoff = date.today() - timedelta(days=days)

    # Get lot-level means per parameter
    results = db.session.query(
        WATLotSummary.lot_id,
        WATLotSummary.parameter_id,
        WATLotSummary.mean_value,
    ).filter(
        WATLotSummary.product_id == product_id,
        WATLotSummary.event_date >= cutoff,
    ).all()

    if not results:
        return success({"params": [], "matrix": []})

    from collections import defaultdict
    data_by_param = defaultdict(dict)
    for r in results:
        if r.mean_value:
            data_by_param[r.parameter_id][r.lot_id] = float(r.mean_value)

    params = sorted(data_by_param.keys())
    all_lots = sorted(set(lot for p_data in data_by_param.values() for lot in p_data))

    matrix_r, matrix_p = [], []
    for p1 in params:
        row_r, row_p = [], []
        for p2 in params:
            v1 = [data_by_param[p1].get(lot) for lot in all_lots]
            v2 = [data_by_param[p2].get(lot) for lot in all_lots]
            pairs = [(a, b) for a, b in zip(v1, v2) if a is not None and b is not None]
            if len(pairs) > 3:
                arr1, arr2 = zip(*pairs)
                r, p = stats.pearsonr(arr1, arr2)
                row_r.append(round(r, 4))
                row_p.append(round(p, 6))
            else:
                row_r.append(None)
                row_p.append(None)
        matrix_r.append(row_r)
        matrix_p.append(row_p)

    return success({"params": params, "r_matrix": matrix_r, "p_matrix": matrix_p,
                    "lot_count": len(all_lots)})


@wat_bp.route("/trend", methods=["GET"])
@jwt_required()
def trend():
    parameter_id = request.args.get("parameter_id")
    equipment_id = request.args.get("equipment_id")
    if not parameter_id:
        return error("MISSING_PARAM", "parameter_id required")

    from datetime import date, timedelta
    days = int(request.args.get("days", 30))
    cutoff = date.today() - timedelta(days=days)

    query = db.session.query(
        WATLotSummary.lot_id, WATLotSummary.mean_value, WATLotSummary.std_dev,
        WATLotSummary.cpk, WATLotSummary.usl, WATLotSummary.lsl,
        WATLotSummary.event_date, WATLotSummary.equipment_id,
    ).filter(WATLotSummary.parameter_id == parameter_id, WATLotSummary.event_date >= cutoff)

    if equipment_id:
        query = query.filter(WATLotSummary.equipment_id == equipment_id)
    query = query.order_by(WATLotSummary.event_date)

    results = query.limit(500).all()
    return success([{
        "lot_id": r.lot_id,
        "mean": round(float(r.mean_value), 6) if r.mean_value else None,
        "std": round(float(r.std_dev), 6) if r.std_dev else None,
        "cpk": round(float(r.cpk), 4) if r.cpk else None,
        "usl": round(float(r.usl), 6) if r.usl else None,
        "lsl": round(float(r.lsl), 6) if r.lsl else None,
        "date": str(r.event_date),
        "equipment_id": r.equipment_id,
    } for r in results])


@wat_bp.route("/equipment-health", methods=["GET"])
@jwt_required()
@cache.cached(timeout=1800, query_string=True)
def equipment_health():
    from app.models.equipment import Equipment
    equipment_list = Equipment.query.filter_by(is_current=True).order_by(
        Equipment.health_score
    ).all()
    return success([e.to_dict() for e in equipment_list])
