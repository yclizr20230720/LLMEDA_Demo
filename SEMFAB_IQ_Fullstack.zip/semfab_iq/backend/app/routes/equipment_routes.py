"""Equipment Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from app.models.equipment import Equipment, Chamber
from app.utils.response import success, error

equipment_bp = Blueprint("equipment", __name__)


@equipment_bp.route("/", methods=["GET"])
@jwt_required()
def list_equipment():
    eq_type = request.args.get("type")
    query = Equipment.query.filter_by(is_current=True)
    if eq_type:
        query = query.filter_by(equipment_type=eq_type)
    equipment = query.order_by(Equipment.health_score).all()
    return success([e.to_dict() for e in equipment])


@equipment_bp.route("/<equipment_id>", methods=["GET"])
@jwt_required()
def get_equipment(equipment_id: str):
    equip = Equipment.query.filter_by(equipment_id=equipment_id, is_current=True).first()
    if not equip:
        return error("NOT_FOUND", f"Equipment {equipment_id} not found", status_code=404)
    chambers = Chamber.query.filter_by(equipment_id=equipment_id).all()
    result = equip.to_dict()
    result["chambers"] = [c.to_dict() for c in chambers]
    return success(result)
