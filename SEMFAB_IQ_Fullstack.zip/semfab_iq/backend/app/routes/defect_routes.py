"""Defect Routes"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from sqlalchemy import func, desc
from app import db, cache
from app.models.defect import DefectResult, DefectWaferSummary
from app.utils.response import success, error

defect_bp = Blueprint("defect", __name__)


@defect_bp.route("/summary", methods=["GET"])
@jwt_required()
def defect_summary():
    lot_id = request.args.get("lot_id")
    wafer_id = request.args.get("wafer_id")
    if not lot_id:
        return error("MISSING_PARAM", "lot_id required")
    query = DefectWaferSummary.query.filter_by(lot_id=lot_id)
    if wafer_id:
        query = query.filter_by(wafer_id=wafer_id)
    summaries = query.order_by(DefectWaferSummary.wafer_id).all()
    return success([s.to_dict() for s in summaries])


@defect_bp.route("/pareto", methods=["GET"])
@jwt_required()
@cache.cached(timeout=1800, query_string=True)
def defect_pareto():
    from datetime import date, timedelta
    days = int(request.args.get("days", 30))
    step_id = request.args.get("step_id")
    cutoff = date.today() - timedelta(days=days)

    query = db.session.query(
        DefectResult.inspection_step_id,
        DefectResult.final_class,
        func.count(DefectResult.defect_sk).label("count"),
    ).filter(DefectResult.event_date >= cutoff)
    if step_id:
        query = query.filter(DefectResult.inspection_step_id == step_id)

    results = query.group_by(
        DefectResult.inspection_step_id, DefectResult.final_class
    ).order_by(DefectResult.inspection_step_id, desc("count")).all()

    from collections import defaultdict
    by_step = defaultdict(list)
    for r in results:
        by_step[r.inspection_step_id].append({
            "class": r.final_class, "count": r.count
        })

    return success([{"step_id": step, "classes": classes}
                    for step, classes in by_step.items()])
