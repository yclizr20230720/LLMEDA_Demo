"""Unified JSON Response Envelope"""
from flask import jsonify
import uuid


def success(data=None, meta=None, status_code=200):
    return jsonify({
        "status": "success",
        "data": data,
        "meta": meta or {},
        "errors": [],
        "trace_id": str(uuid.uuid4()),
    }), status_code


def error(code: str, message: str, details=None, status_code=400):
    return jsonify({
        "status": "error",
        "data": None,
        "meta": {},
        "errors": [{"code": code, "message": message, "details": details}],
        "trace_id": str(uuid.uuid4()),
    }), status_code


def paginated(data, total: int, page: int, per_page: int):
    return success(data=data, meta={
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
    })
