"""WebSocket Event Registration"""
from flask_socketio import emit, join_room


def register_socket_events(socketio):
    @socketio.on("connect")
    def handle_connect(auth):
        emit("connected", {"status": "ok", "fab": "FAB-12"})

    @socketio.on("subscribe")
    def handle_subscribe(data):
        room = data.get("room", "global")
        join_room(room)
        emit("subscribed", {"room": room})

    @socketio.on("disconnect")
    def handle_disconnect():
        pass
