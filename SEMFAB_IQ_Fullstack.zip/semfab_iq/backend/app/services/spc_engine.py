"""SPC Rules Engine — All 8 Western Electric Rules"""
from typing import List, Dict, Any
import numpy as np


RULE_DESCRIPTIONS = {
    1: "1 point beyond 3σ",
    2: "9 consecutive points same side of centerline",
    3: "6 consecutive points trending (monotone)",
    4: "14 consecutive points alternating up/down",
    5: "2 of 3 consecutive points beyond 2σ same side",
    6: "4 of 5 consecutive points beyond 1σ same side",
    7: "15 consecutive points within 1σ of centerline (stratification)",
    8: "8 consecutive points beyond 1σ on both sides (mixture)",
}

RULE_SEVERITY = {1: "CRITICAL", 2: "MAJOR", 3: "MAJOR", 4: "MINOR",
                 5: "MAJOR", 6: "MINOR", 7: "MINOR", 8: "MINOR"}


def check_rule_1(values: List[float], ucl: float, lcl: float) -> List[int]:
    """1 point beyond 3σ (UCL or LCL)"""
    return [i for i, v in enumerate(values) if v > ucl or v < lcl]


def check_rule_2(values: List[float], cl: float) -> List[int]:
    """9 consecutive points same side of centerline"""
    violations = []
    n = 9
    for i in range(n - 1, len(values)):
        window = values[i - n + 1:i + 1]
        above = all(v > cl for v in window)
        below = all(v < cl for v in window)
        if above or below:
            violations.append(i)
    return violations


def check_rule_3(values: List[float]) -> List[int]:
    """6 consecutive points trending (strictly increasing or decreasing)"""
    violations = []
    n = 6
    for i in range(n - 1, len(values)):
        window = values[i - n + 1:i + 1]
        inc = all(window[j] < window[j + 1] for j in range(n - 1))
        dec = all(window[j] > window[j + 1] for j in range(n - 1))
        if inc or dec:
            violations.append(i)
    return violations


def check_rule_4(values: List[float]) -> List[int]:
    """14 consecutive points alternating up/down"""
    violations = []
    n = 14
    for i in range(n - 1, len(values)):
        window = values[i - n + 1:i + 1]
        alternating = all(
            (window[j] < window[j + 1]) != (window[j + 1] < window[j + 2])
            for j in range(n - 2)
        )
        if alternating:
            violations.append(i)
    return violations


def check_rule_5(values: List[float], cl: float, sigma: float) -> List[int]:
    """2 of 3 consecutive points beyond 2σ same side"""
    violations = []
    two_sigma_u = cl + 2 * sigma
    two_sigma_l = cl - 2 * sigma
    for i in range(2, len(values)):
        window = values[i - 2:i + 1]
        above = sum(1 for v in window if v > two_sigma_u)
        below = sum(1 for v in window if v < two_sigma_l)
        if above >= 2 or below >= 2:
            violations.append(i)
    return violations


def check_rule_6(values: List[float], cl: float, sigma: float) -> List[int]:
    """4 of 5 consecutive points beyond 1σ same side"""
    violations = []
    one_sigma_u = cl + sigma
    one_sigma_l = cl - sigma
    for i in range(4, len(values)):
        window = values[i - 4:i + 1]
        above = sum(1 for v in window if v > one_sigma_u)
        below = sum(1 for v in window if v < one_sigma_l)
        if above >= 4 or below >= 4:
            violations.append(i)
    return violations


def check_rule_7(values: List[float], cl: float, sigma: float) -> List[int]:
    """15 consecutive points within 1σ (stratification)"""
    violations = []
    n = 15
    one_sigma_u = cl + sigma
    one_sigma_l = cl - sigma
    for i in range(n - 1, len(values)):
        window = values[i - n + 1:i + 1]
        if all(one_sigma_l <= v <= one_sigma_u for v in window):
            violations.append(i)
    return violations


def check_rule_8(values: List[float], cl: float, sigma: float) -> List[int]:
    """8 consecutive points beyond 1σ on BOTH sides (mixture)"""
    violations = []
    n = 8
    one_sigma_u = cl + sigma
    one_sigma_l = cl - sigma
    for i in range(n - 1, len(values)):
        window = values[i - n + 1:i + 1]
        outside = all(v > one_sigma_u or v < one_sigma_l for v in window)
        has_above = any(v > one_sigma_u for v in window)
        has_below = any(v < one_sigma_l for v in window)
        if outside and has_above and has_below:
            violations.append(i)
    return violations


def check_all_rules(
    values: List[float],
    ucl: float,
    cl: float,
    lcl: float,
    sigma: float,
    enabled_rules: int = 255,
) -> Dict[str, Any]:
    """Run all enabled Western Electric rules. enabled_rules is a bitmask."""
    results = {}
    all_violations = set()

    rule_fns = {
        1: lambda: check_rule_1(values, ucl, lcl),
        2: lambda: check_rule_2(values, cl),
        3: lambda: check_rule_3(values),
        4: lambda: check_rule_4(values),
        5: lambda: check_rule_5(values, cl, sigma),
        6: lambda: check_rule_6(values, cl, sigma),
        7: lambda: check_rule_7(values, cl, sigma),
        8: lambda: check_rule_8(values, cl, sigma),
    }

    for rule_num, fn in rule_fns.items():
        if enabled_rules & (1 << (rule_num - 1)):
            violations = fn()
            results[f"rule_{rule_num}"] = {
                "violations": violations,
                "count": len(violations),
                "description": RULE_DESCRIPTIONS[rule_num],
                "severity": RULE_SEVERITY[rule_num],
            }
            all_violations.update(violations)

    return {
        "per_rule": results,
        "violation_indices": sorted(all_violations),
        "has_violation": len(all_violations) > 0,
        "total_violations": len(all_violations),
    }


def compute_capability(
    values: List[float], usl: float, lsl: float, target: float = None
) -> Dict[str, float]:
    """Compute Cp, Cpk, Cpm, Pp, Ppk"""
    arr = np.array(values)
    mean = float(np.mean(arr))
    std_within = float(np.std(arr, ddof=1))
    std_overall = float(np.std(arr, ddof=0))

    if std_within == 0 or std_overall == 0:
        return {"cp": None, "cpk": None, "cpm": None, "pp": None, "ppk": None, "mean": mean}

    spec_range = usl - lsl
    cp = spec_range / (6 * std_within)
    cpu = (usl - mean) / (3 * std_within)
    cpl = (mean - lsl) / (3 * std_within)
    cpk = min(cpu, cpl)
    pp = spec_range / (6 * std_overall)
    ppk = min((usl - mean) / (3 * std_overall), (mean - lsl) / (3 * std_overall))

    cpm = None
    if target is not None:
        tau = np.sqrt(std_within ** 2 + (mean - target) ** 2)
        cpm = spec_range / (6 * tau) if tau > 0 else None

    return {
        "cp": round(cp, 4), "cpk": round(cpk, 4), "cpm": round(cpm, 4) if cpm else None,
        "pp": round(pp, 4), "ppk": round(ppk, 4),
        "mean": round(mean, 6), "std_within": round(std_within, 6), "std_overall": round(std_overall, 6),
        "cpu": round(cpu, 4), "cpl": round(cpl, 4),
    }
