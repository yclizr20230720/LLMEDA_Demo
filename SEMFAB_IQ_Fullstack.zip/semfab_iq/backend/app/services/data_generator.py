"""Synthetic Demo Data Generator for development/testing"""
import random
import json
from datetime import datetime, timedelta, date
import numpy as np
from app import db
from app.models.lot import Lot, Wafer
from app.models.equipment import Equipment, Chamber
from app.models.wat import WATResult, WATLotSummary
from app.models.cp import CPDieResult, CPWaferSummary
from app.models.spc import SPCConfig, SPCMeasurement, SPCViolation
from app.models.fdc import FDCTraceRun, FDCPMEvent
from app.models.defect import DefectResult, DefectWaferSummary
from app.models.user import User


PRODUCTS = ["PROD_N5_001", "PROD_N5_002", "PROD_N3_001"]
NODES = ["N5", "N5", "N3"]
EQUIPMENT_LIST = [
    {"id": "CVD-01", "type": "CVD", "subtype": "PECVD", "vendor": "AMAT"},
    {"id": "CVD-02", "type": "CVD", "subtype": "PECVD", "vendor": "AMAT"},
    {"id": "ETCH-01", "type": "ETCH", "subtype": "DRY_ETCH", "vendor": "LAM"},
    {"id": "ETCH-02", "type": "ETCH", "subtype": "DRY_ETCH", "vendor": "LAM"},
    {"id": "CMP-01", "type": "CMP", "subtype": "STD_CMP", "vendor": "AMAT"},
    {"id": "CMP-02", "type": "CMP", "subtype": "STD_CMP", "vendor": "AMAT"},
    {"id": "LITHO-01", "type": "LITHO", "subtype": "EUV", "vendor": "ASML"},
    {"id": "DIFF-01", "type": "DIFF", "subtype": "FURNACE", "vendor": "TEL"},
    {"id": "WAT-01", "type": "WAT", "subtype": "FAST_WAT", "vendor": "Semitronix"},
    {"id": "CP-01", "type": "CP", "subtype": "PROBER", "vendor": "TEL"},
]
WAT_PARAMS = [
    {"id": "IDSAT_N", "group": "IDSAT", "device": "NMOS", "unit": "mA"},
    {"id": "IDSAT_P", "group": "IDSAT", "device": "PMOS", "unit": "mA"},
    {"id": "VTN", "group": "VT", "device": "NMOS", "unit": "V"},
    {"id": "VTP", "group": "VT", "device": "PMOS", "unit": "V"},
    {"id": "IOFF_N", "group": "LEAKAGE", "device": "NMOS", "unit": "pA"},
    {"id": "BVJ", "group": "BREAKDOWN", "device": "DIODE", "unit": "V"},
    {"id": "REXT", "group": "RESISTANCE", "device": "NMOS", "unit": "Ω"},
    {"id": "GATOX_THK", "group": "CAPACITANCE", "device": "MOSFET", "unit": "Å"},
]

def seed_users():
    if User.query.count() > 0:
        return
    users = [
        {"username": "admin", "email": "admin@semfab.com", "role": "SYSTEM_ADMIN",
         "full_name": "FAB Admin", "password": "Admin@12345"},
        {"username": "pe_engineer", "email": "pe@semfab.com", "role": "PROCESS_ENGINEER",
         "full_name": "Li Wei (PE)", "password": "Engineer@123"},
        {"username": "ee_engineer", "email": "ee@semfab.com", "role": "EQUIPMENT_ENGINEER",
         "full_name": "Chen Ming (EE)", "password": "Engineer@123"},
        {"username": "manager", "email": "mgr@semfab.com", "role": "MANAGER",
         "full_name": "Director Zhang", "password": "Manager@123"},
    ]
    for u in users:
        user = User(username=u["username"], email=u["email"],
                    role=u["role"], full_name=u["full_name"])
        user.set_password(u["password"])
        db.session.add(user)
    db.session.commit()
    print(f"✅ Created {len(users)} users")


def seed_equipment():
    if Equipment.query.count() > 0:
        return
    for eq in EQUIPMENT_LIST:
        health = random.uniform(72, 99)
        equip = Equipment(
            equipment_id=eq["id"],
            equipment_name=f"{eq['vendor']} {eq['subtype']} #{eq['id'][-2:]}",
            equipment_type=eq["type"],
            equipment_subtype=eq["subtype"],
            oem_vendor=eq["vendor"],
            fab_id="FAB-12",
            bay_id=f"BAY-{random.randint(1,4):02d}",
            area_id=f"AREA-{eq['type']}",
            chamber_count=random.choice([2, 4]),
            is_multi_chamber=True,
            equipment_status="PRODUCTION",
            health_score=round(health, 2),
            health_tier="HEALTHY" if health > 85 else "WATCH" if health > 70 else "DEGRADED",
            z_score_component=round(random.uniform(0.1, 0.4), 3),
            gof_component=round(random.uniform(0.05, 0.3), 3),
            cv_stability_component=round(random.uniform(0.05, 0.25), 3),
            volume_component=round(random.uniform(0.05, 0.2), 3),
            last_pm_date=date.today() - timedelta(days=random.randint(10, 60)),
            next_pm_date=date.today() + timedelta(days=random.randint(5, 30)),
            pm_interval_days=90,
        )
        db.session.add(equip)
        for ch_idx in range(1, equip.chamber_count + 1):
            ch = Chamber(
                equipment_id=eq["id"],
                chamber_id=f"PM{ch_idx}",
                chamber_name=f"Chamber {ch_idx}",
                chamber_type=eq["subtype"],
                chamber_status="PRODUCTION",
                health_score=round(random.uniform(70, 99), 2),
                run_since_pm=random.randint(50, 500),
                is_reference_chamber=(ch_idx == 1),
            )
            db.session.add(ch)
    db.session.commit()
    print(f"✅ Created {len(EQUIPMENT_LIST)} equipment")


def seed_lots_and_results(n_lots: int = 30):
    if Lot.query.count() > n_lots // 2:
        return
    rng = np.random.default_rng(42)
    base_date = datetime.utcnow() - timedelta(days=30)

    for lot_num in range(n_lots):
        prod_idx = lot_num % len(PRODUCTS)
        lot_id = f"M{900100 + lot_num:06d}"
        lot_date = base_date + timedelta(days=lot_num)

        lot = Lot(
            lot_id=lot_id,
            lot_type=random.choices(["PRODUCTION", "ENGINEERING", "MONITOR"], weights=[0.8, 0.1, 0.1])[0],
            lot_priority=random.randint(3, 8),
            product_id=PRODUCTS[prod_idx],
            process_node=NODES[prod_idx],
            lot_status=random.choices(["ACTIVE", "COMPLETED", "HOLD"], weights=[0.3, 0.6, 0.1])[0],
            wafer_count_start=25,
            wafer_count_current=25,
            lot_start_date=lot_date,
            lot_target_date=lot_date + timedelta(days=21),
            lot_complete_date=lot_date + timedelta(days=random.randint(18, 25)) if random.random() > 0.3 else None,
            target_yield_pct=95.0,
            syl_pct=90.0,
            sbl_pct=85.0,
            is_current=True,
        )
        db.session.add(lot)

        for slot in range(1, 26):
            wafer_id = f"{lot_id}_{slot:02d}"
            base_yield = rng.normal(94.5, 2.5)
            if lot_num == 15:
                base_yield = rng.normal(82.0, 3.0)  # excursion lot
            base_yield = float(np.clip(base_yield, 60, 100))

            wafer = Wafer(
                lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                wafer_status="ACTIVE", die_per_wafer=5000,
                die_count_good=int(5000 * base_yield / 100),
                cp_yield_pct=round(base_yield, 3),
            )
            db.session.add(wafer)

            # WAT results for 9 sites
            equip_id = random.choice(["WAT-01"])
            test_time = lot_date + timedelta(hours=random.uniform(0, 168))
            for site in range(1, 10):
                for param in WAT_PARAMS:
                    base_val = {
                        "IDSAT_N": 1.2, "IDSAT_P": 0.65, "VTN": 0.42, "VTP": -0.45,
                        "IOFF_N": 0.08, "BVJ": 8.5, "REXT": 180, "GATOX_THK": 28.5
                    }.get(param["id"], 1.0)
                    val = rng.normal(base_val, base_val * 0.03)
                    usl = base_val * 1.15
                    lsl = base_val * 0.85
                    sigma_dev = (val - base_val) / (base_val * 0.03)
                    wat = WATResult(
                        lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                        site_id=site,
                        site_x=round(random.uniform(-130, 130), 2),
                        site_y=round(random.uniform(-130, 130), 2),
                        site_zone=random.choice(["CENTER", "RING_70", "EDGE"]),
                        parameter_id=param["id"],
                        parameter_group=param["group"],
                        measured_value=round(float(val), 6),
                        usl=round(usl, 6), lsl=round(lsl, 6),
                        target_value=round(base_val, 6),
                        pass_fail="P" if lsl <= val <= usl else "F",
                        sigma_deviation=round(float(sigma_dev), 4),
                        equipment_id=equip_id,
                        recipe_id="WAT_RECIPE_N5_V3",
                        process_node=NODES[prod_idx],
                        product_id=PRODUCTS[prod_idx],
                        is_outlier_mad=abs(sigma_dev) > 3.5,
                        test_time=test_time,
                        event_date=test_time.date(),
                        lot_sequence=lot_num + 1,
                    )
                    db.session.add(wat)

            # CP Wafer Summary
            bin_counts = {"1": int(5000 * base_yield / 100)}
            fail_remaining = 5000 - bin_counts["1"]
            bin_counts["8"] = int(fail_remaining * 0.6)
            bin_counts["14"] = fail_remaining - bin_counts["8"]

            pattern = random.choices(
                ["NORMAL", "EDGE", "CENTER", "DONUT", "SCRATCH", "CLUSTER"],
                weights=[0.65, 0.1, 0.08, 0.07, 0.05, 0.05]
            )[0]

            cp_summary = CPWaferSummary(
                lot_id=lot_id, wafer_id=wafer_id, slot_number=slot,
                program_id="CP_N5_LOGIC_V3",
                tester_id=f"CP-{random.randint(1,3):02d}",
                step_id="CP_SORT_01",
                total_die=5000, pass_die=bin_counts["1"],
                fail_die=5000 - bin_counts["1"],
                gross_yield_pct=round(base_yield, 4),
                net_yield_pct=round(base_yield * 0.995, 4),
                first_pass_yield=round(base_yield * 0.98, 4),
                retest_count=random.randint(0, 50),
                offline_retest_rate=round(random.uniform(5, 15), 3),
                bin_counts_json=json.dumps(bin_counts),
                pattern_class_generic=pattern,
                pattern_class_primary=f"{pattern}_PRIMARY",
                pattern_confidence=round(random.uniform(0.75, 0.97), 4),
                edge_yield_pct=round(base_yield - random.uniform(1, 5), 4),
                center_yield_pct=round(base_yield + random.uniform(0, 3), 4),
                edge_center_delta=round(random.uniform(-5, -1), 4),
                is_partial_wafer=False,
                syl_flag=base_yield < 90.0,
                sbl_flag=base_yield < 85.0,
                mrb_required=base_yield < 90.0,
                mrb_result="BadWafer" if base_yield < 85.0 else "GoodWafer",
                event_date=test_time.date(),
                test_time=test_time,
                product_id=PRODUCTS[prod_idx],
                process_node=NODES[prod_idx],
            )
            db.session.add(cp_summary)

        db.session.flush()

    db.session.commit()
    print(f"✅ Created {n_lots} lots with WAT + CP data")


def seed_spc_data():
    if SPCConfig.query.count() > 0:
        return
    rng = np.random.default_rng(99)
    base_date = datetime.utcnow() - timedelta(days=30)

    for param in WAT_PARAMS[:4]:
        base_val = {"IDSAT_N": 1.2, "IDSAT_P": 0.65, "VTN": 0.42, "VTP": -0.45}[param["id"]]
        sigma = abs(base_val) * 0.03
        config_id = f"SPC_{param['id']}_WAT01"
        config = SPCConfig(
            config_id=config_id,
            parameter_id=param["id"],
            parameter_source="WAT",
            equipment_id="WAT-01",
            chart_type="IMR",
            ucl=base_val + 3 * sigma,
            cl=base_val,
            lcl=base_val - 3 * sigma,
            ucl_2sigma=base_val + 2 * sigma,
            lcl_2sigma=base_val - 2 * sigma,
            ucl_1sigma=base_val + sigma,
            lcl_1sigma=base_val - sigma,
            sigma_estimate=sigma,
            usl=base_val * 1.15,
            lsl=base_val * 0.85,
            target=base_val,
            enabled_rules=255,
            is_active=True,
        )
        db.session.add(config)

        for i in range(90):
            val = float(rng.normal(base_val, sigma))
            # inject excursion around point 60
            if 58 <= i <= 62:
                val = float(rng.normal(base_val + 3.5 * sigma, sigma * 0.5))
            mr = abs(val - base_val) if i == 0 else None
            sigma_score = (val - base_val) / sigma

            r1 = val > base_val + 3 * sigma or val < base_val - 3 * sigma
            r5_window = [float(rng.normal(base_val, sigma)) for _ in range(3)]
            r5_window[-1] = val
            r5 = sum(1 for v in r5_window if v > base_val + 2 * sigma) >= 2

            meas_time = base_date + timedelta(hours=i * 8)
            meas = SPCMeasurement(
                config_id=config_id, parameter_id=param["id"],
                lot_id=f"M{900100 + i:06d}",
                equipment_id="WAT-01", subgroup_index=i + 1,
                measured_value=round(val, 8),
                ucl_at_time=base_val + 3 * sigma,
                cl_at_time=base_val,
                lcl_at_time=base_val - 3 * sigma,
                sigma_score=round(sigma_score, 4),
                moving_range=mr,
                violation_rule_1=r1, violation_rule_5=r5,
                any_violation=r1 or r5,
                violation_rules_list=",".join(
                    ([str(1)] if r1 else []) + ([str(5)] if r5 else [])
                ) or None,
                alarm_triggered=r1,
                alarm_severity="CRITICAL" if r1 else None,
                measurement_time=meas_time,
                event_date=meas_time.date(),
            )
            db.session.add(meas)

    db.session.commit()
    print("✅ SPC data seeded")


def seed_fdc_data():
    if FDCTraceRun.query.count() > 0:
        return
    rng = np.random.default_rng(77)
    base_date = datetime.utcnow() - timedelta(days=14)

    for i in range(100):
        run_time = base_date + timedelta(hours=i * 3.5)
        composite = float(rng.uniform(0.05, 0.3))
        is_anom = False
        if 40 <= i <= 45:
            composite = float(rng.uniform(0.88, 0.98))
            is_anom = True

        run = FDCTraceRun(
            run_id=f"RUN_{i:05d}",
            lot_id=f"M{900100 + (i % 30):06d}",
            wafer_id=f"M{900100 + (i % 30):06d}_{(i % 25) + 1:02d}",
            equipment_id=random.choice(["CVD-01", "ETCH-01", "CMP-01"]),
            chamber_id=f"PM{random.randint(1,2)}",
            recipe_id="RECIPE_N5_CVD_A",
            step_id="LI-3041",
            product_id="PROD_N5_001",
            process_node="N5",
            run_start_time=run_time,
            run_end_time=run_time + timedelta(seconds=float(rng.normal(35, 2))),
            run_duration_sec=round(float(rng.normal(35, 2)), 2),
            run_result="ALARM" if is_anom else "PASS",
            alarm_count=3 if is_anom else 0,
            interval_anomaly_score=round(float(rng.uniform(0.05, 0.95 if is_anom else 0.3)), 4),
            pm_anomaly_score=round(float(rng.uniform(0.02, 0.85 if is_anom else 0.2)), 4),
            amplitude_anomaly_score=round(float(rng.uniform(0.05, 0.92 if is_anom else 0.25)), 4),
            shape_anomaly_score=round(float(rng.uniform(0.03, 0.9 if is_anom else 0.2)), 4),
            composite_anomaly_score=round(composite, 4),
            anomaly_class="AMPLITUDE" if is_anom else "NORMAL",
            is_anomaly=is_anom,
            is_post_pm=(i == 30),
            pm_wafer_count=i * 5,
            event_date=run_time.date(),
        )
        db.session.add(run)

    db.session.commit()
    print("✅ FDC data seeded")


def seed_all():
    seed_users()
    seed_equipment()
    seed_lots_and_results(n_lots=40)
    seed_spc_data()
    seed_fdc_data()
    print("🚀 All demo data seeded successfully")
