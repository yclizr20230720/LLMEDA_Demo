/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        void: '#060A12',
        base: '#0A0F1C',
        surface: '#0F1626',
        card: '#131B2E',
        elevated: '#192035',
        'bg-hover': '#1E2840',
        teal: { DEFAULT: '#00E5C4', dim: 'rgba(0,229,196,0.15)', glow: 'rgba(0,229,196,0.25)' },
        violet: { DEFAULT: '#8B5CF6', dim: 'rgba(139,92,246,0.15)' },
        amber: { DEFAULT: '#F59E0B', dim: 'rgba(245,158,11,0.15)' },
        coral: { DEFAULT: '#FF4F6A', dim: 'rgba(255,79,106,0.15)' },
        sky: { DEFAULT: '#38BDF8', dim: 'rgba(56,189,248,0.12)' },
        lime: { DEFAULT: '#84CC16', dim: 'rgba(132,204,22,0.12)' },
        pass: '#10B981',
        fail: '#EF4444',
        warn: '#F59E0B',
      },
      fontFamily: {
        display: ['Space Grotesk', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        sm: '6px', md: '10px', lg: '16px', xl: '20px',
      },
      backdropBlur: { glass: '20px', 'glass-xl': '40px' },
      animation: {
        'pulse-teal': 'pulse-teal 2s ease-in-out infinite',
        'pulse-red': 'pulse-red 2s ease-in-out infinite',
        'slide-up': 'slide-up 0.25s ease-out',
        'fade-in': 'fade-in 0.2s ease-out',
        'count-up': 'count-up 1.5s ease-out',
      },
      keyframes: {
        'pulse-teal': {
          '0%,100%': { boxShadow: '0 0 0 0 rgba(0,229,196,0.4)' },
          '50%': { boxShadow: '0 0 0 8px rgba(0,229,196,0)' },
        },
        'pulse-red': {
          '0%,100%': { boxShadow: '0 0 0 0 rgba(255,79,106,0.4)' },
          '50%': { boxShadow: '0 0 0 6px rgba(255,79,106,0)' },
        },
        'slide-up': {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
