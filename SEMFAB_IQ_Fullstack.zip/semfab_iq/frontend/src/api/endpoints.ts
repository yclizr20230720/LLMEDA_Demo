import apiClient from './client';
import type { ApiResponse, User, CPWaferSummary, SPCConfig, SPCMeasurement, FDCTraceRun, Equipment } from '@/types';

// ── Auth ──
export const authApi = {
  login: (username: string, password: string) =>
    apiClient.post<ApiResponse<{ access_token: string; refresh_token: string; user: User }>>('/auth/login', { username, password }),
  me: () => apiClient.get<ApiResponse<User>>('/auth/me'),
  logout: () => apiClient.post('/auth/logout'),
};

// ── Yield ──
export const yieldApi = {
  summary: (params?: Record<string, string | number>) =>
    apiClient.get<ApiResponse<unknown[]>>('/yield/summary', { params }),
  trend: (params?: Record<string, string | number>) =>
    apiClient.get<ApiResponse<unknown[]>>('/yield/trend', { params }),
  waferGallery: (lot_id: string) =>
    apiClient.get<ApiResponse<CPWaferSummary[]>>('/yield/wafer-gallery', { params: { lot_id } }),
  binPareto: (lot_id: string) =>
    apiClient.get<ApiResponse<unknown[]>>('/yield/bin-pareto', { params: { lot_id } }),
  excursions: (days?: number) =>
    apiClient.get<ApiResponse<unknown[]>>('/yield/excursions', { params: { days } }),
};

// ── WAT ──
export const watApi = {
  parameters: () => apiClient.get<ApiResponse<unknown[]>>('/wat/parameters'),
  distribution: (parameter_id: string, lot_id?: string) =>
    apiClient.get<ApiResponse<unknown>>('/wat/distribution', { params: { parameter_id, lot_id } }),
  correlationMatrix: (product_id?: string, days?: number) =>
    apiClient.get<ApiResponse<unknown>>('/wat/correlation-matrix', { params: { product_id, days } }),
  trend: (parameter_id: string, equipment_id?: string, days?: number) =>
    apiClient.get<ApiResponse<unknown[]>>('/wat/trend', { params: { parameter_id, equipment_id, days } }),
  equipmentHealth: () => apiClient.get<ApiResponse<Equipment[]>>('/wat/equipment-health'),
};

// ── CP ──
export const cpApi = {
  binMap: (lot_id: string, wafer_id: string) =>
    apiClient.get<ApiResponse<unknown>>('/cp/bin-map', { params: { lot_id, wafer_id } }),
  waferSummary: (lot_id: string) =>
    apiClient.get<ApiResponse<CPWaferSummary[]>>('/cp/wafer-summary', { params: { lot_id } }),
  mrbReview: (days?: number) =>
    apiClient.get<ApiResponse<CPWaferSummary[]>>('/cp/mrb-review', { params: { days } }),
};

// ── SPC ──
export const spcApi = {
  configs: () => apiClient.get<ApiResponse<SPCConfig[]>>('/spc/configs'),
  chart: (config_id: string, days?: number) =>
    apiClient.get<ApiResponse<{ config: SPCConfig; measurements: SPCMeasurement[] }>>('/spc/chart', { params: { config_id, days } }),
  violations: (equipment_id?: string, days?: number) =>
    apiClient.get<ApiResponse<unknown[]>>('/spc/violations', { params: { equipment_id, days } }),
  capability: (config_id: string) =>
    apiClient.get<ApiResponse<unknown>>('/spc/capability', { params: { config_id } }),
  checkRules: (values: number[], ucl: number, cl: number, lcl: number, sigma: number, enabled_rules?: number) =>
    apiClient.post<ApiResponse<unknown>>('/spc/check-rules', { values, ucl, cl, lcl, sigma, enabled_rules }),
};

// ── FDC ──
export const fdcApi = {
  traceRuns: (params?: Record<string, string | number | boolean>) =>
    apiClient.get<ApiResponse<FDCTraceRun[]>>('/fdc/trace-runs', { params }),
  anomalySummary: (days?: number) =>
    apiClient.get<ApiResponse<unknown[]>>('/fdc/anomaly-summary', { params: { days } }),
  pmEvents: (equipment_id?: string) =>
    apiClient.get<ApiResponse<unknown[]>>('/fdc/pm-events', { params: { equipment_id } }),
};

// ── Equipment ──
export const equipmentApi = {
  list: (type?: string) => apiClient.get<ApiResponse<Equipment[]>>('/equipment/', { params: { type } }),
  get: (equipment_id: string) => apiClient.get<ApiResponse<Equipment>>(`/equipment/${equipment_id}`),
};

// ── Defect ──
export const defectApi = {
  summary: (lot_id: string, wafer_id?: string) =>
    apiClient.get<ApiResponse<unknown[]>>('/defect/summary', { params: { lot_id, wafer_id } }),
  pareto: (days?: number, step_id?: string) =>
    apiClient.get<ApiResponse<unknown[]>>('/defect/pareto', { params: { days, step_id } }),
};
