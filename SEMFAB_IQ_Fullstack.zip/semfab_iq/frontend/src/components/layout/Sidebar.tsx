import { NavLink } from 'react-router-dom'
import { clsx } from 'clsx'
import { useUIStore } from '@/store/uiStore'
import { useFabStore } from '@/store/fabStore'

const NAV_GROUPS = [
  {
    label: 'Yield Intelligence',
    items: [
      { path: '/yms', icon: '📈', label: 'YMS Dashboard' },
      { path: '/mrb', icon: '🚦', label: 'MRB Review', alert: true },
    ],
  },
  {
    label: 'Process Analytics',
    items: [
      { path: '/wat', icon: '🔬', label: 'WAT Analytics' },
      { path: '/cp', icon: '🗺️', label: 'CP Bin Map' },
      { path: '/defect', icon: '🔍', label: 'Defect DMS' },
    ],
  },
  {
    label: 'Process Control',
    items: [
      { path: '/spc', icon: '📉', label: 'SPC Monitor', alert: true },
      { path: '/fdc', icon: '⚡', label: 'FDC Engine' },
    ],
  },
  {
    label: 'AI Intelligence',
    items: [
      { path: '/agent', icon: '🤖', label: 'Agent Chat' },
      { path: '/knowledge', icon: '📚', label: 'Knowledge Base' },
    ],
  },
]

export function Sidebar() {
  const { sidebarCollapsed, toggleSidebar } = useUIStore()
  const { criticalCount } = useFabStore()
  const w = sidebarCollapsed ? 'w-16' : 'w-56'

  return (
    <aside className={clsx(
      w, 'flex-shrink-0 h-screen bg-base border-r border-white/[0.06] flex flex-col',
      'transition-all duration-200 overflow-y-auto overflow-x-hidden'
    )}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-white/[0.06]">
        {!sidebarCollapsed && (
          <span className="font-display font-bold text-lg bg-gradient-to-r from-teal to-violet bg-clip-text text-transparent whitespace-nowrap">
            SEMFAB·IQ
          </span>
        )}
        <button
          onClick={toggleSidebar}
          className="ml-auto text-slate-500 hover:text-slate-300 transition-colors p-1 rounded"
        >
          {sidebarCollapsed ? '→' : '←'}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 px-2 space-y-4">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            {!sidebarCollapsed && (
              <div className="text-[10px] font-semibold text-slate-600 uppercase tracking-widest px-2 mb-1">
                {group.label}
              </div>
            )}
            <div className="space-y-0.5">
              {group.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => clsx(
                    'flex items-center gap-2.5 px-2.5 py-2 rounded-md text-[12.5px] transition-all duration-150 group',
                    isActive
                      ? 'bg-teal/15 text-teal border border-teal/20'
                      : 'text-slate-400 hover:bg-elevated hover:text-slate-200 border border-transparent'
                  )}
                >
                  <span className="text-sm flex-shrink-0">{item.icon}</span>
                  {!sidebarCollapsed && (
                    <>
                      <span className="flex-1 whitespace-nowrap">{item.label}</span>
                      {item.alert && criticalCount > 0 && (
                        <span className="text-[10px] bg-coral text-white rounded-full px-1.5 py-0.5 font-bold animate-pulse-red">
                          {criticalCount}
                        </span>
                      )}
                    </>
                  )}
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      {!sidebarCollapsed && (
        <div className="p-3 border-t border-white/[0.06]">
          <div className="text-[10px] text-slate-600 font-mono">v1.0.0 · FAB-12 · N5</div>
        </div>
      )}
    </aside>
  )
}
