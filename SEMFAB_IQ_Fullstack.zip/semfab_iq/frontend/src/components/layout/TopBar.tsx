import { useState, useEffect } from 'react'
import { useAuthStore } from '@/store/authStore'
import { useFabStore } from '@/store/fabStore'

export function TopBar() {
  const { user, logout } = useAuthStore()
  const { criticalCount, currentFab, currentNode } = useFabStore()
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <header className="h-14 bg-void/95 backdrop-blur-glass border-b border-white/[0.06] flex items-center px-5 gap-4 flex-shrink-0">
      {/* Fab Context */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-teal animate-pulse-teal" />
        <span className="text-[11px] text-slate-400 font-mono">{currentFab} · {currentNode} · Live</span>
      </div>

      <div className="flex-1" />

      {/* Alarm Counter */}
      {criticalCount > 0 && (
        <div className="flex items-center gap-1.5 bg-coral/15 border border-coral/30 rounded-md px-3 py-1.5 cursor-pointer hover:bg-coral/20 transition-colors">
          <span className="text-coral text-[11px] font-bold animate-pulse-red">🔴</span>
          <span className="text-coral text-[11px] font-semibold">{criticalCount} Critical</span>
        </div>
      )}

      {/* Clock */}
      <span className="text-[11px] text-slate-500 font-mono hidden md:block">
        {time.toLocaleTimeString('en-US', { hour12: false })}
      </span>

      {/* User Menu */}
      <div className="flex items-center gap-2 cursor-pointer group">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal to-violet flex items-center justify-center text-[12px] font-bold text-void">
          {user?.full_name?.[0] || user?.username?.[0] || 'U'}
        </div>
        {user && (
          <div className="hidden md:block">
            <div className="text-[12px] text-slate-300 font-medium leading-none">{user.full_name || user.username}</div>
            <div className="text-[10px] text-slate-600 leading-none mt-0.5">{user.role}</div>
          </div>
        )}
        <button
          onClick={logout}
          className="text-[11px] text-slate-600 hover:text-slate-400 ml-1 transition-colors"
          title="Logout"
        >
          ⎋
        </button>
      </div>
    </header>
  )
}
