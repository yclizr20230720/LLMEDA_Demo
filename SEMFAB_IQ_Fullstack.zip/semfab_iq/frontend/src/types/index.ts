// ── Core Domain Types ──

export interface ApiResponse<T> {
  status: 'success' | 'error';
  data: T;
  meta: Record<string, unknown>;
  errors: ApiError[];
  trace_id: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

export interface User {
  username: string;
  email: string;
  full_name: string;
  role: string;
  fab_id: string;
  is_active: boolean;
  mfa_enabled: boolean;
  last_login: string | null;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

export interface Lot {
  lot_id: string;
  lot_type: string;
  lot_priority: number;
  product_id: string;
  process_node: string;
  lot_status: string;
  wafer_count_start: number;
  target_yield_pct: number;
  syl_pct: number;
  sbl_pct: number;
  lot_start_date: string | null;
  lot_target_date: string | null;
}

export interface Equipment {
  equipment_id: string;
  equipment_name: string;
  equipment_type: string;
  equipment_subtype: string;
  oem_vendor: string;
  fab_id: string;
  bay_id: string;
  equipment_status: string;
  health_score: number;
  health_tier: 'HEALTHY' | 'WATCH' | 'DEGRADED' | 'CRITICAL';
  z_score_component: number;
  gof_component: number;
  cv_stability_component: number;
  volume_component: number;
  last_pm_date: string | null;
  next_pm_date: string | null;
}

export interface WATResult {
  lot_id: string;
  wafer_id: string;
  site_id: number;
  site_x: number;
  site_y: number;
  site_zone: string;
  parameter_id: string;
  parameter_group: string;
  vcc: number | null;
  temp_c: number | null;
  measured_value: number;
  usl: number | null;
  lsl: number | null;
  target_value: number | null;
  pass_fail: string;
  sigma_deviation: number;
  equipment_id: string;
  anomaly_score: number | null;
  test_time: string;
  event_date: string;
}

export interface WATLotSummary {
  lot_id: string;
  wafer_id: string;
  parameter_id: string;
  equipment_id: string;
  event_date: string;
  n_sites: number;
  mean_value: number;
  median_value: number;
  std_dev: number;
  min_value: number;
  max_value: number;
  p5_value: number;
  p25_value: number;
  p75_value: number;
  p95_value: number;
  skewness: number;
  kurtosis: number;
  cp: number | null;
  cpk: number | null;
  cpm: number | null;
  ppk: number | null;
  is_normal_dist: boolean | null;
  n_pass: number;
  n_fail: number;
  pass_rate_pct: number;
}

export interface CPWaferSummary {
  lot_id: string;
  wafer_id: string;
  slot_number: number;
  program_id: string;
  tester_id: string;
  step_id: string;
  total_die: number;
  pass_die: number;
  fail_die: number;
  gross_yield_pct: number;
  net_yield_pct: number;
  first_pass_yield: number;
  retest_count: number;
  offline_retest_rate: number;
  bin_counts_json: string;
  site_yields_json: string;
  pattern_class_generic: string;
  pattern_class_primary: string;
  pattern_confidence: number;
  edge_yield_pct: number;
  center_yield_pct: number;
  edge_center_delta: number;
  syl_flag: boolean;
  sbl_flag: boolean;
  mrb_required: boolean;
  mrb_result: string;
  event_date: string;
  test_time: string;
  product_id: string;
  process_node: string;
}

export interface SPCConfig {
  config_id: string;
  parameter_id: string;
  parameter_source: string;
  equipment_id: string;
  chart_type: string;
  ucl: number | null;
  cl: number | null;
  lcl: number | null;
  ucl_2sigma: number | null;
  lcl_2sigma: number | null;
  sigma_estimate: number | null;
  usl: number | null;
  lsl: number | null;
  target: number | null;
  enabled_rules: number;
  is_active: boolean;
}

export interface SPCMeasurement {
  config_id: string;
  parameter_id: string;
  lot_id: string;
  equipment_id: string;
  subgroup_index: number;
  measured_value: number;
  sigma_score: number;
  ucl_at_time: number;
  cl_at_time: number;
  lcl_at_time: number;
  violation_rule_1: boolean;
  violation_rule_2: boolean;
  violation_rule_3: boolean;
  violation_rule_4: boolean;
  violation_rule_5: boolean;
  violation_rule_6: boolean;
  violation_rule_7: boolean;
  violation_rule_8: boolean;
  any_violation: boolean;
  violation_rules_list: string | null;
  alarm_triggered: boolean;
  is_virtual: boolean;
  vm_predicted_value: number | null;
  vm_ci_lower: number | null;
  vm_ci_upper: number | null;
  measurement_time: string;
  event_date: string;
}

export interface FDCTraceRun {
  run_id: string;
  lot_id: string;
  wafer_id: string;
  equipment_id: string;
  chamber_id: string;
  recipe_id: string;
  run_start_time: string;
  run_end_time: string;
  run_duration_sec: number;
  run_result: string;
  alarm_count: number;
  interval_anomaly_score: number;
  pm_anomaly_score: number;
  amplitude_anomaly_score: number;
  shape_anomaly_score: number;
  composite_anomaly_score: number;
  anomaly_class: string;
  is_anomaly: boolean;
  is_post_pm: boolean;
  event_date: string;
}

export type HealthTier = 'HEALTHY' | 'WATCH' | 'DEGRADED' | 'CRITICAL';
export type LotStatus = 'ACTIVE' | 'HOLD' | 'COMPLETED' | 'SCRAPPED';
export type AlarmSeverity = 'CRITICAL' | 'MAJOR' | 'MINOR' | 'INFO';
