import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from '@/store/authStore'
import { AppShell } from '@/components/layout/AppShell'
import { LoginPage } from '@/pages/LoginPage'
import { YMSDashboard } from '@/pages/yms/YMSDashboard'
import { WATAnalytics } from '@/pages/wat/WATAnalytics'
import { CPAnalytics } from '@/pages/cp/CPAnalytics'
import { SPCMonitor } from '@/pages/spc/SPCMonitor'
import { FDCEngine } from '@/pages/fdc/FDCEngine'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore()
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={
        <ProtectedRoute>
          <AppShell />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="/yms" replace />} />
        <Route path="yms" element={<YMSDashboard />} />
        <Route path="wat" element={<WATAnalytics />} />
        <Route path="cp" element={<CPAnalytics />} />
        <Route path="spc" element={<SPCMonitor />} />
        <Route path="fdc" element={<FDCEngine />} />
      </Route>
    </Routes>
  )
}
