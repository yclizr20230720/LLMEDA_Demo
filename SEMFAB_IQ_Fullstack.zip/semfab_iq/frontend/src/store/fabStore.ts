import { create } from 'zustand';

interface Alarm {
  id: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR' | 'INFO';
  message: string;
  equipment_id?: string;
  lot_id?: string;
  timestamp: string;
  acknowledged: boolean;
}

interface FabStore {
  currentFab: string;
  currentProduct: string;
  currentNode: string;
  activeAlarms: Alarm[];
  criticalCount: number;
  equipmentStatusMap: Record<string, string>;
  addAlarm: (alarm: Alarm) => void;
  acknowledgeAlarm: (id: string) => void;
  setEquipmentStatus: (id: string, status: string) => void;
  setFab: (fab: string) => void;
  setProduct: (product: string) => void;
}

export const useFabStore = create<FabStore>((set, get) => ({
  currentFab: 'FAB-12',
  currentProduct: 'PROD_N5_001',
  currentNode: 'N5',
  activeAlarms: [],
  criticalCount: 0,
  equipmentStatusMap: {},

  addAlarm: (alarm) =>
    set((s) => {
      const alarms = [alarm, ...s.activeAlarms].slice(0, 50);
      return { activeAlarms: alarms, criticalCount: alarms.filter(a => a.severity === 'CRITICAL' && !a.acknowledged).length };
    }),

  acknowledgeAlarm: (id) =>
    set((s) => {
      const alarms = s.activeAlarms.map(a => a.id === id ? { ...a, acknowledged: true } : a);
      return { activeAlarms: alarms, criticalCount: alarms.filter(a => a.severity === 'CRITICAL' && !a.acknowledged).length };
    }),

  setEquipmentStatus: (id, status) =>
    set((s) => ({ equipmentStatusMap: { ...s.equipmentStatusMap, [id]: status } })),

  setFab: (fab) => set({ currentFab: fab }),
  setProduct: (product) => set({ currentProduct: product }),
}));
