import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UIStore {
  sidebarCollapsed: boolean;
  activeModule: string;
  commandPaletteOpen: boolean;
  toggleSidebar: () => void;
  setActiveModule: (module: string) => void;
  setCommandPalette: (open: boolean) => void;
}

export const useUIStore = create<UIStore>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      activeModule: 'yms',
      commandPaletteOpen: false,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setActiveModule: (module) => set({ activeModule: module }),
      setCommandPalette: (open) => set({ commandPaletteOpen: open }),
    }),
    { name: 'semfab-ui', partialize: (s) => ({ sidebarCollapsed: s.sidebarCollapsed }) }
  )
);
