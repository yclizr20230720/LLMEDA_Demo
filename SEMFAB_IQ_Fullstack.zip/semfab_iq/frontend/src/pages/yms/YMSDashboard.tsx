import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine,
  ResponsiveContainer, Legend, ComposedChart
} from 'recharts'
import { yieldApi } from '@/api/endpoints'
import { clsx } from 'clsx'

// ─── KPI Card ───────────────────────────────────────────────────────────────
function KPICard({ label, value, delta, deltaGood, accent, unit = '' }: {
  label: string; value: string | number; delta?: string
  deltaGood?: boolean; accent: string; unit?: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative bg-card border border-white/[0.06] rounded-lg p-4 overflow-hidden hover:-translate-y-0.5 hover:border-teal/20 transition-all duration-200 cursor-default"
    >
      <div className={`absolute top-0 left-0 right-0 h-[2px] ${accent}`} />
      <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1.5">{label}</div>
      <div className={`font-display text-2xl font-bold leading-none`} style={{ color: 'var(--teal)' }}>
        {value}<span className="text-sm ml-0.5 opacity-70">{unit}</span>
      </div>
      {delta && (
        <div className={clsx('text-[11px] mt-1.5 flex items-center gap-1', deltaGood ? 'text-pass' : 'text-fail')}>
          <span>{deltaGood ? '▲' : '▼'}</span>{delta}
        </div>
      )}
    </motion.div>
  )
}

// ─── Yield Trend Chart ────────────────────────────────────────────────────────
function YieldTrendPanel({ product }: { product: string }) {
  const [days, setDays] = useState(30)
  const { data, isLoading } = useQuery({
    queryKey: ['yield-trend', product, days],
    queryFn: () => yieldApi.trend({ product_id: product, days }),
  })

  const chartData = data?.data.data as { date: string; mean: number; p10: number; p90: number; n: number }[] | undefined

  return (
    <div className="panel h-full">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-teal" />
          <span className="font-display text-[13px] font-semibold text-slate-200">
            Product Yield Trend & SYL/SBL Check
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500">{product}</span>
          {[7, 14, 30, 90].map(d => (
            <button key={d}
              onClick={() => setDays(d)}
              className={clsx('text-[10px] px-2 py-0.5 rounded font-mono transition-all',
                days === d ? 'bg-teal/15 text-teal border border-teal/20' : 'text-slate-500 hover:text-slate-300'
              )}>{d}d</button>
          ))}
        </div>
      </div>
      <div className="panel-body">
        {isLoading ? (
          <div className="h-40 flex items-center justify-center text-slate-600 text-sm">Loading…</div>
        ) : (
          <ResponsiveContainer width="100%" height={150}>
            <ComposedChart data={chartData || []} margin={{ top: 4, right: 8, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="yieldGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00E5C4" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#00E5C4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => v.slice(5)} />
              <YAxis domain={[80, 100]} tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v}%`} />
              <Tooltip
                contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                formatter={(v: number, name: string) => [`${v?.toFixed(2)}%`, name]}
              />
              <ReferenceLine y={90} stroke="rgba(245,158,11,0.6)" strokeDasharray="6 4" label={{ value: 'SYL', fill: '#F59E0B', fontSize: 9 }} />
              <ReferenceLine y={85} stroke="rgba(255,79,106,0.6)" strokeDasharray="6 4" label={{ value: 'SBL', fill: '#FF4F6A', fontSize: 9 }} />
              <Area type="monotone" dataKey="p90" stroke="transparent" fill="rgba(0,229,196,0.06)" />
              <Area type="monotone" dataKey="mean" stroke="#00E5C4" strokeWidth={2} fill="url(#yieldGrad)" dot={false} />
              <Area type="monotone" dataKey="p10" stroke="transparent" fill="rgba(0,0,0,0)" />
            </ComposedChart>
          </ResponsiveContainer>
        )}
        <div className="flex gap-4 mt-3 text-[10px] text-slate-500">
          {[
            { label: 'SYL', color: '#F59E0B', dash: true },
            { label: 'SBL', color: '#FF4F6A', dash: true },
            { label: 'Mean Yield', color: '#00E5C4', dash: false },
            { label: 'P10–P90 Band', color: 'rgba(0,229,196,0.3)', dash: false },
          ].map(l => (
            <div key={l.label} className="flex items-center gap-1.5">
              <div style={{ width: 16, height: 2, background: l.color, borderTop: l.dash ? `2px dashed ${l.color}` : 'none', marginTop: l.dash ? -2 : 0 }} />
              <span>{l.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Score Card Table ─────────────────────────────────────────────────────────
function ScoreCardTable() {
  const [selectedLot, setSelectedLot] = useState<string | null>(null)
  const { data, isLoading } = useQuery({
    queryKey: ['yield-summary'],
    queryFn: () => yieldApi.summary({ days: 14 }),
  })

  type SummaryRow = { lot_id: string; avg_yield: number; min_yield: number; max_yield: number; wafer_count: number; product_id: string }
  const rows = (data?.data?.data as SummaryRow[] | undefined) || []

  const yieldColor = (y: number) => {
    if (y >= 95) return 'cell-pass'
    if (y >= 90) return 'cell-warn'
    return 'cell-fail'
  }

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-amber" />
          <span className="font-display text-[13px] font-semibold text-slate-200">Score Card — Lot Level</span>
        </div>
        <div className="flex gap-2 items-center">
          <span className="badge badge-teal">{rows.length} lots</span>
          <span className="text-[10px] text-slate-500 font-mono">Last 14d</span>
        </div>
      </div>
      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-slate-600 text-sm">Loading…</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>LOT ID</th>
                <th className="text-right">Yield</th>
                <th className="text-right">Min</th>
                <th className="text-right">Max</th>
                <th className="text-right">Wafers</th>
                <th>Product</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.lot_id}
                  className={clsx('cursor-pointer', selectedLot === row.lot_id && 'selected')}
                  onClick={() => setSelectedLot(selectedLot === row.lot_id ? null : row.lot_id)}
                >
                  <td className="text-teal font-mono text-[11px] font-medium">{row.lot_id}</td>
                  <td className="text-right">
                    <span className={yieldColor(row.avg_yield ?? 0)}>
                      {row.avg_yield?.toFixed(2) ?? '—'}%
                    </span>
                  </td>
                  <td className="text-right text-slate-500">{row.min_yield?.toFixed(1) ?? '—'}%</td>
                  <td className="text-right text-slate-500">{row.max_yield?.toFixed(1) ?? '—'}%</td>
                  <td className="text-right">{row.wafer_count}</td>
                  <td className="text-slate-500 text-[10px]">{row.product_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

// ─── Alarm Feed ────────────────────────────────────────────────────────────────
function AlarmFeed() {
  const { data, isLoading } = useQuery({
    queryKey: ['excursions'],
    queryFn: () => yieldApi.excursions(7),
    refetchInterval: 30000,
  })

  type ExcRow = { lot_id: string; wafer_id: string; gross_yield_pct: number; severity: string; event_date: string }
  const excursions = (data?.data?.data as ExcRow[] | undefined) || []

  const DEMO_ALARMS = [
    { id: '1', severity: 'CRITICAL', title: 'FDC Alert — CVD-01 Pressure Drift', meta: 'Lot M900472 · Score: 0.96', time: '03:47', type: 'FDC' },
    { id: '2', severity: 'CRITICAL', title: 'Yield Excursion — LOT_109 @ 85.0%', meta: 'PROD_N5_001 · FT1 · −10.1%', time: '02:31', type: 'YIELD' },
    { id: '3', severity: 'MAJOR', title: 'SPC Rule-5 — CVD-04 OXIDE_THK_S3', meta: '2/3 pts > 2σ · Probe check', time: '01:14', type: 'SPC' },
    { id: '4', severity: 'MAJOR', title: 'PM Due — CMP-05 Health Score 68/100', meta: 'Pad conditioner degradation', time: '00:42', type: 'PM' },
    { id: '5', severity: 'INFO', title: 'Agent RCA Complete — M900123', meta: 'Root cause: DHF_TEMP × GATOX', time: '23:55', type: 'AGENT' },
  ]

  const sevColor: Record<string, string> = { CRITICAL: 'border-l-coral', MAJOR: 'border-l-amber', MINOR: 'border-l-sky', INFO: 'border-l-violet' }
  const sevIcon: Record<string, string> = { CRITICAL: '🔴', MAJOR: '🟡', MINOR: '🔵', INFO: '🟢' }
  const typeColor: Record<string, string> = { FDC: 'badge-amber', YIELD: 'badge-coral', SPC: 'badge-violet', PM: 'badge-teal', AGENT: 'badge-pass' }

  return (
    <div className="panel h-full flex flex-col">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-coral" />
          <span className="font-display text-[13px] font-semibold text-slate-200">Live Alarm Feed</span>
        </div>
        <span className="badge badge-coral">{DEMO_ALARMS.filter(a => a.severity === 'CRITICAL').length} Critical</span>
      </div>
      <div className="flex-1 overflow-auto p-3 space-y-2">
        {DEMO_ALARMS.map(alarm => (
          <div key={alarm.id}
            className={clsx(
              'flex items-start gap-2.5 p-2.5 rounded-md border border-white/[0.06] bg-surface cursor-pointer hover:bg-elevated transition-all border-l-2',
              sevColor[alarm.severity],
              alarm.severity === 'CRITICAL' && 'animate-pulse-red'
            )}
          >
            <span className="text-sm mt-0.5 flex-shrink-0">{sevIcon[alarm.severity]}</span>
            <div className="flex-1 min-w-0">
              <div className="text-[12px] font-medium text-slate-200 leading-tight">{alarm.title}</div>
              <div className="flex items-center gap-2 mt-1">
                <span className={clsx('badge text-[9px]', typeColor[alarm.type])}>{alarm.type}</span>
                <span className="text-[10px] text-slate-600 truncate">{alarm.meta}</span>
              </div>
            </div>
            <span className="text-[10px] text-slate-600 font-mono flex-shrink-0">{alarm.time}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Bin Pareto Chart ─────────────────────────────────────────────────────────
function BinParetoMini() {
  const demoData = [
    { bin: '1-P-Bin_1', pct: 87.01, color: '#10B981' },
    { bin: '8-F-Bin_8', pct: 7.77, color: '#38BDF8' },
    { bin: '14-F-Bin', pct: 2.55, color: '#8B5CF6' },
    { bin: '9-F-Bin_9', pct: 1.99, color: '#F59E0B' },
    { bin: '12-F', pct: 0.34, color: '#FF4F6A' },
    { bin: '4-F', pct: 0.34, color: '#84CC16' },
  ]
  return (
    <div className="panel h-full">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-sky" />
          <span className="font-display text-[13px] font-semibold text-slate-200">Bin Pareto — LOT_63.1</span>
        </div>
      </div>
      <div className="panel-body">
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={demoData} layout="vertical" margin={{ left: 10, right: 30, top: 4, bottom: 4 }}>
            <XAxis type="number" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v}%`} />
            <YAxis dataKey="bin" type="category" tick={{ fill: '#94A3B8', fontSize: 9, fontFamily: 'JetBrains Mono' }} width={60} />
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
            <Tooltip
              contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
              formatter={(v: number) => [`${v}%`, 'Yield']}
            />
            <Bar dataKey="pct" radius={[0, 3, 3, 0]}
              fill="#00E5C4"
              label={{ position: 'right', fill: '#64748B', fontSize: 9, formatter: (v: number) => `${v}%` }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
export function YMSDashboard() {
  const product = 'PROD_N5_001'

  const kpis = [
    { label: 'FAB Yield Today', value: '94.7', unit: '%', delta: '−0.6% vs 7d avg', deltaGood: false, accent: 'bg-gradient-to-r from-teal to-transparent' },
    { label: 'Active Alarms', value: '7', delta: '3 Critical · 4 Major', deltaGood: false, accent: 'bg-gradient-to-r from-coral to-transparent' },
    { label: 'Lots In Process', value: '143', delta: '+8 vs yesterday', deltaGood: true, accent: 'bg-gradient-to-r from-amber to-transparent' },
    { label: 'Equipment OEE', value: '88.4', unit: '%', delta: '+1.2% vs target', deltaGood: true, accent: 'bg-gradient-to-r from-sky to-transparent' },
    { label: 'Agent Actions 24h', value: '12', delta: '11 auto · 1 pending', deltaGood: true, accent: 'bg-gradient-to-r from-violet to-transparent' },
    { label: 'DPPM Fallout', value: '4.2', delta: '−0.8 (best model)', deltaGood: true, accent: 'bg-gradient-to-r from-lime to-transparent' },
  ]

  return (
    <div className="space-y-4 animate-fade-in">
      {/* KPI Strip */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-3">
        {kpis.map((k, i) => (
          <motion.div key={k.label} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <KPICard {...k} />
          </motion.div>
        ))}
      </div>

      {/* Row 1: Yield Trend + Alarm Feed */}
      <div className="grid grid-cols-3 gap-4" style={{ height: 280 }}>
        <div className="col-span-2">
          <YieldTrendPanel product={product} />
        </div>
        <div>
          <AlarmFeed />
        </div>
      </div>

      {/* Row 2: Score Card + Bin Pareto */}
      <div className="grid grid-cols-3 gap-4" style={{ height: 280 }}>
        <div className="col-span-2">
          <ScoreCardTable />
        </div>
        <div>
          <BinParetoMini />
        </div>
      </div>
    </div>
  )
}
