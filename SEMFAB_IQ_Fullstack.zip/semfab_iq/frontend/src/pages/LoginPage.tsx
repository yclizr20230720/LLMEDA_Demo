import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useAuthStore } from '@/store/authStore'
import { authApi } from '@/api/endpoints'

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')!
    canvas.width = window.innerWidth; canvas.height = window.innerHeight
    const particles = Array.from({ length: 18 }, () => ({
      x: Math.random() * canvas.width, y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 2 + 1, a: Math.random() * 0.5 + 0.1,
    }))
    let raf: number
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(0,229,196,${p.a})`
        ctx.fill()
      })
      raf = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(raf)
  }, [])
  return <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />
}

export function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { setAuth, isAuthenticated } = useAuthStore()
  const navigate = useNavigate()

  useEffect(() => { if (isAuthenticated) navigate('/yms', { replace: true }) }, [isAuthenticated, navigate])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      const res = await authApi.login(username, password)
      const { access_token, refresh_token, user } = res.data.data
      setAuth(user, access_token, refresh_token)
      navigate('/yms', { replace: true })
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { errors?: { message?: string }[] } } })?.response?.data?.errors?.[0]?.message || 'Invalid credentials'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="relative h-screen bg-void flex items-center justify-center overflow-hidden">
      {/* Circuit board SVG pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="circuit" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M0 30 H20 M40 30 H60 M30 0 V20 M30 40 V60" stroke="#00E5C4" strokeWidth="0.5" fill="none"/>
              <circle cx="30" cy="30" r="3" fill="none" stroke="#00E5C4" strokeWidth="0.5"/>
              <circle cx="0" cy="30" r="1.5" fill="#00E5C4"/>
              <circle cx="60" cy="30" r="1.5" fill="#00E5C4"/>
              <circle cx="30" cy="0" r="1.5" fill="#00E5C4"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#circuit)"/>
        </svg>
      </div>
      <ParticleCanvas />

      {/* Login Card */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-sm mx-4"
      >
        <div className="glass-card glass-card-elevated p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <h1 className="font-display font-bold text-3xl bg-gradient-to-r from-teal via-sky to-violet bg-clip-text text-transparent">
                SEMFAB·IQ
              </h1>
              <p className="text-slate-500 text-sm mt-1">Engineering Data Analytics Platform</p>
              <div className="text-[10px] text-slate-600 font-mono mt-2 flex items-center justify-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-teal animate-pulse-teal inline-block"/>
                FAB-12 · N5 · Online
              </div>
            </motion.div>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="engineer_id"
                autoComplete="username"
                className="w-full bg-surface border border-white/[0.08] text-slate-200 rounded-md px-3.5 py-2.5 text-sm font-mono placeholder-slate-600 focus:outline-none focus:border-teal/50 focus:ring-1 focus:ring-teal/30 transition-all"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                className="w-full bg-surface border border-white/[0.08] text-slate-200 rounded-md px-3.5 py-2.5 text-sm font-mono placeholder-slate-600 focus:outline-none focus:border-teal/50 focus:ring-1 focus:ring-teal/30 transition-all"
              />
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-coral text-xs bg-coral/10 border border-coral/20 rounded-md px-3 py-2"
              >
                ⚠ {error}
              </motion.div>
            )}

            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full py-2.5 rounded-md font-semibold text-sm text-void transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #00E5C4, #8B5CF6)', boxShadow: '0 4px 16px rgba(0,229,196,0.25)' }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-void/30 border-t-void rounded-full animate-spin" />
                  Authenticating…
                </span>
              ) : 'Sign In to FAB-12'}
            </button>
          </form>

          {/* Demo credentials hint */}
          <div className="mt-5 pt-4 border-t border-white/[0.06] text-center">
            <p className="text-[10px] text-slate-600">Demo: <span className="font-mono text-slate-500">pe_engineer / Engineer@123</span></p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
