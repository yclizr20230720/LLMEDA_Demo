import { useState, useMemo } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Legend
} from 'recharts'
import { spcApi } from '@/api/endpoints'
import { clsx } from 'clsx'
import type { SPCMeasurement } from '@/types'

const WE_RULES = [
  { id: 1, label: 'R1: 1pt > 3σ', severity: 'CRITICAL', color: '#EF4444' },
  { id: 2, label: 'R2: 9pts same side', severity: 'MAJOR', color: '#F59E0B' },
  { id: 3, label: 'R3: 6pts trend', severity: 'MAJOR', color: '#F59E0B' },
  { id: 4, label: 'R4: 14 alternating', severity: 'MINOR', color: '#38BDF8' },
  { id: 5, label: 'R5: 2/3 > 2σ', severity: 'MAJOR', color: '#F59E0B' },
  { id: 6, label: 'R6: 4/5 > 1σ', severity: 'MINOR', color: '#38BDF8' },
  { id: 7, label: 'R7: 15pts in 1σ', severity: 'MINOR', color: '#38BDF8' },
  { id: 8, label: 'R8: 8pts both sides', severity: 'MINOR', color: '#38BDF8' },
]

// Custom dot renderer for SPC violations
function SPCDot(props: { cx?: number; cy?: number; payload?: SPCMeasurement; activeRules: Set<number> }) {
  const { cx = 0, cy = 0, payload, activeRules } = props
  if (!payload) return null

  const violatedRules = WE_RULES.filter(r =>
    activeRules.has(r.id) &&
    (payload as Record<string, boolean>)[`violation_rule_${r.id}`]
  )
  if (violatedRules.length === 0) {
    return <circle cx={cx} cy={cy} r={2.5} fill="#00E5C4" opacity={0.7} />
  }
  const color = violatedRules.some(r => r.severity === 'CRITICAL') ? '#EF4444'
    : violatedRules.some(r => r.severity === 'MAJOR') ? '#F59E0B' : '#38BDF8'
  return (
    <g>
      <circle cx={cx} cy={cy} r={7} fill={color} opacity={0.15} />
      <circle cx={cx} cy={cy} r={4} fill={color} />
      <circle cx={cx} cy={cy} r={4} fill="none" stroke="white" strokeWidth={0.8} />
    </g>
  )
}

function CPKGauge({ cpk }: { cpk: number }) {
  const color = cpk >= 1.67 ? '#10B981' : cpk >= 1.33 ? '#F59E0B' : '#EF4444'
  const pct = Math.min(100, (cpk / 2) * 100)
  const angle = (pct / 100) * 180 - 90
  const rad = (angle * Math.PI) / 180
  const R = 60
  const nx = 70 + R * Math.cos(rad)
  const ny = 70 + R * Math.sin(rad)

  return (
    <div className="flex flex-col items-center">
      <svg width="140" height="80" viewBox="0 0 140 80">
        {/* Background arc */}
        <path d="M 10 70 A 60 60 0 0 1 130 70" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={12} strokeLinecap="round" />
        {/* Colored arc */}
        <path d={`M 10 70 A 60 60 0 0 1 ${nx} ${ny}`} fill="none" stroke={color} strokeWidth={12} strokeLinecap="round" />
        {/* Zone markers */}
        {[1.0, 1.33, 1.67].map((v, i) => {
          const a2 = ((v / 2) * 180 - 90) * Math.PI / 180
          const mx = 70 + 72 * Math.cos(a2)
          const my = 70 + 72 * Math.sin(a2)
          return <line key={i} x1={70 + 54 * Math.cos(a2)} y1={70 + 54 * Math.sin(a2)} x2={mx} y2={my}
            stroke="rgba(255,255,255,0.2)" strokeWidth={1} />
        })}
        {/* Needle */}
        <line x1={70} y1={70} x2={nx} y2={ny} stroke={color} strokeWidth={2} strokeLinecap="round" />
        <circle cx={70} cy={70} r={4} fill={color} />
        {/* Value */}
        <text x={70} y={62} textAnchor="middle" fill={color} fontSize={14} fontFamily="JetBrains Mono" fontWeight="bold">{cpk.toFixed(3)}</text>
        <text x={70} y={75} textAnchor="middle" fill="#475569" fontSize={8}>Cpk</text>
      </svg>
      <div className="text-[9px] text-slate-600 text-center">
        {cpk >= 1.67 ? '✓ Six Sigma capable' : cpk >= 1.33 ? '⚠ Acceptable' : '✗ Incapable'}
      </div>
    </div>
  )
}

function SPCChart({ configId }: { configId: string }) {
  const [enabledRules, setEnabledRules] = useState<Set<number>>(new Set([1, 2, 3, 5]))
  const [showVirtual, setShowVirtual] = useState(true)
  const [showAnnotations, setShowAnnotations] = useState(true)
  const [zoomRange, setZoomRange] = useState<[number, number] | null>(null)
  const [days, setDays] = useState(30)

  const { data, isLoading } = useQuery({
    queryKey: ['spc-chart', configId, days],
    queryFn: () => spcApi.chart(configId, days),
    enabled: !!configId,
  })

  const { data: capData } = useQuery({
    queryKey: ['spc-capability', configId],
    queryFn: () => spcApi.capability(configId),
    enabled: !!configId,
  })

  const result = data?.data?.data as { config: { ucl: number; cl: number; lcl: number; ucl_2sigma: number; lcl_2sigma: number; ucl_1sigma: number; lcl_1sigma: number; usl: number; lsl: number }; measurements: SPCMeasurement[] } | undefined
  const config = result?.config
  const measurements = result?.measurements || []

  // Annotate with PM events (demo)
  const PM_ANNOTATIONS = [{ index: 30, type: 'PM', label: 'PM' }, { index: 60, type: 'Recipe', label: 'Rec' }]

  const chartData = measurements.map((m, i) => ({
    ...m,
    index: i,
    violates: m.any_violation,
  }))

  const toggleRule = (id: number) => {
    const next = new Set(enabledRules)
    next.has(id) ? next.delete(id) : next.add(id)
    setEnabledRules(next)
  }

  type CapData = { cpk: number; cp: number; mean: number; std_within: number }
  const cap = (capData?.data?.data as CapData | undefined)

  // Demo data if empty
  const DEMO_DATA = useMemo(() => {
    const cl = 1.2, sigma = 0.036
    return Array.from({ length: 60 }, (_, i) => {
      const val = cl + (Math.random() - 0.5) * sigma * 6 + (i === 40 ? sigma * 4 : 0)
      return {
        index: i, lot_id: `M${9001 + i}`, measured_value: val,
        cl_at_time: cl, ucl_at_time: cl + 3 * sigma, lcl_at_time: cl - 3 * sigma,
        violation_rule_1: Math.abs(val - cl) > 3 * sigma,
        violation_rule_5: false, any_violation: Math.abs(val - cl) > 3 * sigma,
        is_virtual: false,
      }
    })
  }, [])

  const displayData = chartData.length > 0 ? chartData : DEMO_DATA
  const displayCl = config?.cl ?? 1.2
  const displayUcl = config?.ucl ?? 1.308
  const displayLcl = config?.lcl ?? 1.092

  const violationCount = displayData.filter(d => d.any_violation).length

  return (
    <div className="space-y-4">
      {/* Controls row */}
      <div className="flex items-start gap-4 flex-wrap">
        {/* Rule toggles */}
        <div className="space-y-1.5">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider">Western Electric Rules</div>
          <div className="flex flex-wrap gap-1.5">
            {WE_RULES.map(r => (
              <button key={r.id}
                onClick={() => toggleRule(r.id)}
                className={clsx('px-2 py-1 rounded text-[10px] font-mono border transition-all',
                  enabledRules.has(r.id)
                    ? `border-current text-[${r.color}]`
                    : 'border-white/[0.06] text-slate-600 hover:text-slate-400'
                )}
                style={{ color: enabledRules.has(r.id) ? r.color : undefined }}
              >{r.label}</button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-1.5 ml-auto">
          <div className="flex items-center gap-3">
            {[7, 14, 30, 60, 90].map(d => (
              <button key={d} onClick={() => setDays(d)}
                className={clsx('text-[10px] px-2 py-0.5 rounded font-mono border transition-all',
                  days === d ? 'border-teal/30 text-teal bg-teal/10' : 'border-transparent text-slate-500 hover:text-slate-300'
                )}>{d}d</button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
              <input type="checkbox" checked={showVirtual} onChange={e => setShowVirtual(e.target.checked)} className="accent-teal" />
              VM prediction
            </label>
            <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
              <input type="checkbox" checked={showAnnotations} onChange={e => setShowAnnotations(e.target.checked)} className="accent-teal" />
              PM/Recipe events
            </label>
          </div>
        </div>
      </div>

      {/* Violation Summary */}
      {violationCount > 0 && (
        <div className="flex items-center gap-2 p-2.5 bg-coral/10 border border-coral/20 rounded-lg">
          <span className="text-coral text-sm">⚠</span>
          <span className="text-[12px] text-coral font-medium">{violationCount} violations detected</span>
          <div className="flex gap-1.5 ml-2">
            {WE_RULES.filter(r => enabledRules.has(r.id) && displayData.some(d => (d as Record<string, boolean>)[`violation_rule_${r.id}`])).map(r => (
              <span key={r.id} className="badge text-[9px]" style={{ background: `${r.color}20`, color: r.color, border: `1px solid ${r.color}40` }}>
                {r.label}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* SPC Chart */}
      {isLoading ? (
        <div className="h-52 flex items-center justify-center text-slate-500 text-sm">Loading SPC data…</div>
      ) : (
        <div className="relative">
          <ResponsiveContainer width="100%" height={220}>
            <ComposedChart data={displayData} margin={{ top: 8, right: 16, bottom: 0, left: -10 }}>
              <defs>
                <linearGradient id="zoneOuter" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#EF4444" stopOpacity={0.06} />
                  <stop offset="100%" stopColor="#EF4444" stopOpacity={0.01} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="index" tick={{ fill: '#475569', fontSize: 9 }} interval="preserveStartEnd" />
              <YAxis tick={{ fill: '#475569', fontSize: 9 }} domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                content={({ active, payload }) => {
                  if (!active || !payload?.[0]) return null
                  const d = payload[0].payload as Record<string, string | number | boolean>
                  const violated = WE_RULES.filter(r => enabledRules.has(r.id) && d[`violation_rule_${r.id}`])
                  return (
                    <div className="bg-[#0F1626] border border-white/[0.08] rounded-lg p-2.5 text-[11px]">
                      <div className="text-teal font-mono font-bold mb-1">{d.lot_id}</div>
                      <div className="text-slate-300">Value: <span className="font-mono">{Number(d.measured_value).toFixed(6)}</span></div>
                      <div className="text-slate-500">CL: {Number(d.cl_at_time).toFixed(4)} | σ: {Number(d.sigma_score)?.toFixed(2)}σ</div>
                      {violated.length > 0 && (
                        <div className="mt-1.5 space-y-0.5">
                          {violated.map(r => (
                            <div key={r.id} className="flex items-center gap-1.5" style={{ color: r.color }}>
                              <span className="text-[9px]">⚠</span>
                              <span className="text-[10px]">{r.label}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                }}
              />
              {/* Control limit bands */}
              <ReferenceLine y={displayUcl} stroke="rgba(239,68,68,0.6)" strokeDasharray="6 3"
                label={{ value: 'UCL', fill: '#EF4444', fontSize: 8, position: 'right' }} />
              <ReferenceLine y={displayLcl} stroke="rgba(239,68,68,0.6)" strokeDasharray="6 3"
                label={{ value: 'LCL', fill: '#EF4444', fontSize: 8, position: 'right' }} />
              <ReferenceLine y={config?.ucl_2sigma ?? displayCl + (displayUcl - displayCl) * 0.667} stroke="rgba(245,158,11,0.3)" strokeDasharray="3 3" />
              <ReferenceLine y={config?.lcl_2sigma ?? displayCl - (displayCl - displayLcl) * 0.667} stroke="rgba(245,158,11,0.3)" strokeDasharray="3 3" />
              <ReferenceLine y={displayCl} stroke="rgba(0,229,196,0.6)" strokeWidth={1.5}
                label={{ value: 'CL', fill: '#00E5C4', fontSize: 8, position: 'right' }} />

              {/* PM Annotations */}
              {showAnnotations && PM_ANNOTATIONS.map(pm => (
                <ReferenceLine key={pm.index} x={pm.index} stroke="rgba(139,92,246,0.4)" strokeDasharray="4 3"
                  label={{ value: pm.label, fill: '#8B5CF6', fontSize: 8, position: 'top' }} />
              ))}

              {/* VM confidence band */}
              {showVirtual && (
                <Line type="monotone" dataKey="vm_ci_upper" stroke="rgba(56,189,248,0.3)" dot={false} strokeDasharray="3 3" />
              )}

              {/* Main measurement line with custom dots */}
              <Line type="monotone" dataKey="measured_value" stroke="#00E5C4" strokeWidth={1.5}
                dot={(dotProps) => <SPCDot {...dotProps} payload={dotProps.payload as SPCMeasurement} activeRules={enabledRules} />}
                activeDot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Bottom: Cpk Gauge + Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-surface border border-white/[0.06] rounded-lg p-3 flex flex-col items-center justify-center">
          <CPKGauge cpk={cap?.cpk ?? 1.42} />
        </div>
        {[
          { label: 'Cp', value: cap?.cp?.toFixed(3) ?? '1.51' },
          { label: 'Mean', value: cap?.mean?.toFixed(5) ?? '1.20041' },
          { label: 'σ (within)', value: cap?.std_within?.toFixed(5) ?? '0.03614' },
        ].map(s => (
          <div key={s.label} className="bg-surface border border-white/[0.06] rounded-lg p-4 flex flex-col justify-center">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">{s.label}</div>
            <div className="font-mono text-lg font-bold text-slate-200">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function SPCMonitor() {
  const [selectedConfig, setSelectedConfig] = useState('')

  const { data: configsData } = useQuery({
    queryKey: ['spc-configs'],
    queryFn: () => spcApi.configs(),
  })
  type Config = { config_id: string; parameter_id: string; equipment_id: string }
  const configs = (configsData?.data?.data as Config[] | undefined) || []

  const DEMO_CONFIGS: Config[] = [
    { config_id: 'SPC_IDSAT_N_WAT01', parameter_id: 'IDSAT_N', equipment_id: 'WAT-01' },
    { config_id: 'SPC_VTN_WAT01', parameter_id: 'VTN', equipment_id: 'WAT-01' },
    { config_id: 'SPC_IDSAT_P_WAT01', parameter_id: 'IDSAT_P', equipment_id: 'WAT-01' },
    { config_id: 'SPC_VTP_WAT01', parameter_id: 'VTP', equipment_id: 'WAT-01' },
  ]

  const displayConfigs = configs.length > 0 ? configs : DEMO_CONFIGS
  const activeConfigId = selectedConfig || displayConfigs[0]?.config_id || ''

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="panel">
        <div className="panel-header">
          <div className="flex items-center gap-2">
            <div className="w-0.5 h-3.5 rounded-full bg-amber" />
            <span className="font-display text-[14px] font-semibold">SPC Monitor — All 8 Western Electric Rules</span>
          </div>
          <div className="flex items-center gap-3">
            {/* Config selector */}
            <select value={activeConfigId} onChange={e => setSelectedConfig(e.target.value)}
              className="bg-elevated border border-white/[0.08] text-slate-300 rounded px-2.5 py-1.5 text-xs font-mono focus:outline-none focus:border-teal/40 cursor-pointer">
              {displayConfigs.map(c => (
                <option key={c.config_id} value={c.config_id}>
                  {c.parameter_id} — {c.equipment_id}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="p-4">
          <SPCChart configId={activeConfigId} />
        </div>
      </div>

      {/* All Configs Summary */}
      <div className="panel">
        <div className="panel-header">
          <div className="flex items-center gap-2">
            <div className="w-0.5 h-3.5 rounded-full bg-violet" />
            <span className="font-display text-[13px] font-semibold">All Active SPC Monitors</span>
          </div>
          <span className="badge badge-amber">{displayConfigs.length} active</span>
        </div>
        <div className="overflow-auto max-h-40">
          <table className="data-table">
            <thead>
              <tr><th>Config ID</th><th>Parameter</th><th>Equipment</th><th className="text-right">UCL</th><th className="text-right">CL</th><th className="text-right">LCL</th><th>Status</th></tr>
            </thead>
            <tbody>
              {displayConfigs.map(c => (
                <tr key={c.config_id} className={clsx('cursor-pointer', activeConfigId === c.config_id && 'selected')}
                  onClick={() => setSelectedConfig(c.config_id)}>
                  <td className="text-teal text-[10px] font-mono">{c.config_id}</td>
                  <td className="font-mono text-[11px]">{c.parameter_id}</td>
                  <td className="text-slate-500 text-[10px]">{c.equipment_id}</td>
                  <td className="text-right text-[10px] font-mono text-fail">—</td>
                  <td className="text-right text-[10px] font-mono text-teal">—</td>
                  <td className="text-right text-[10px] font-mono text-fail">—</td>
                  <td><span className="badge badge-pass">Active</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
