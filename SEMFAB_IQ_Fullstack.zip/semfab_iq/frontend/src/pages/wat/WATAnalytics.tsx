import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ScatterChart, Scatter, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine,
  ResponsiveContainer, Cell, Legend, ComposedChart, Area
} from 'recharts'
import { watApi } from '@/api/endpoints'
import { clsx } from 'clsx'

const TABS = [
  { id: 'distribution', label: '📊 Distribution', desc: 'Histogram & Capability' },
  { id: 'trend',        label: '📈 Trend',        desc: 'Lot sequence trend' },
  { id: 'correlation',  label: '🔗 Correlation',  desc: 'Parameter pair correlation' },
  { id: 'equipment',    label: '🔧 Equipment',    desc: 'ANOVA health scoring' },
  { id: 'anova',        label: '🧮 ANOVA Table',  desc: 'PSA / Factor analysis' },
]

const WAT_PARAMS = ['IDSAT_N','IDSAT_P','VTN','VTP','IOFF_N','BVJ','REXT','GATOX_THK']

// ── Distribution Tab ──────────────────────────────────────────────────────────
function DistributionTab({ paramId, lotId }: { paramId: string; lotId: string }) {
  const [showOutliers, setShowOutliers] = useState(true)
  const [overlayNormal, setOverlayNormal] = useState(true)

  const { data, isLoading } = useQuery({
    queryKey: ['wat-dist', paramId, lotId],
    queryFn: () => watApi.distribution(paramId, lotId || undefined),
    enabled: !!paramId,
  })

  const dist = data?.data?.data as {
    n: number; mean: number; median: number; std: number;
    min: number; max: number; p5: number; p95: number;
    skewness: number; kurtosis: number;
    cp: number; cpk: number; usl: number; lsl: number;
    histogram: { counts: number[]; edges: number[] }
    capability: { cp: number; cpk: number; cpm: number; ppk: number; mean: number }
    shapiro_wilk_p: number; is_normal: boolean;
  } | undefined

  const histData = useMemo(() => {
    if (!dist?.histogram) return []
    return dist.histogram.counts.map((count, i) => ({
      x: ((dist.histogram.edges[i] + dist.histogram.edges[i + 1]) / 2),
      count,
      label: dist.histogram.edges[i].toFixed(4),
    }))
  }, [dist])

  if (isLoading) return <div className="flex items-center justify-center h-64 text-slate-500 text-sm">Computing distribution…</div>
  if (!dist) return <div className="flex items-center justify-center h-64 text-slate-600 text-sm">Select a parameter</div>

  const cpkColor = (v: number) => v >= 1.67 ? '#10B981' : v >= 1.33 ? '#F59E0B' : '#EF4444'

  return (
    <div className="grid grid-cols-3 gap-4">
      {/* Histogram */}
      <div className="col-span-2 space-y-3">
        <div className="flex items-center gap-4 flex-wrap">
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input type="checkbox" checked={showOutliers} onChange={e => setShowOutliers(e.target.checked)}
              className="accent-teal" />
            Show outliers
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input type="checkbox" checked={overlayNormal} onChange={e => setOverlayNormal(e.target.checked)}
              className="accent-teal" />
            Normal fit overlay
          </label>
          <div className="ml-auto flex items-center gap-1.5">
            <span className="text-[10px] text-slate-500">Shapiro-Wilk p =</span>
            <span className={clsx('font-mono text-[10px] font-bold', dist.is_normal ? 'text-pass' : 'text-coral')}>
              {dist.shapiro_wilk_p?.toFixed(4)}
            </span>
            <span className={clsx('badge text-[9px]', dist.is_normal ? 'badge-pass' : 'badge-coral')}>
              {dist.is_normal ? 'Normal' : 'Non-normal'}
            </span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <ComposedChart data={histData} margin={{ top: 4, right: 8, bottom: 0, left: -10 }}>
            <defs>
              <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.8} />
                <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0.3} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="x" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => Number(v).toFixed(3)} />
            <YAxis tick={{ fill: '#475569', fontSize: 9 }} />
            <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }} />
            <Bar dataKey="count" fill="url(#histGrad)" radius={[3, 3, 0, 0]} />
            {dist.usl && <ReferenceLine x={dist.usl} stroke="#FF4F6A" strokeDasharray="4 3" label={{ value: 'USL', fill: '#FF4F6A', fontSize: 9 }} />}
            {dist.lsl && <ReferenceLine x={dist.lsl} stroke="#FF4F6A" strokeDasharray="4 3" label={{ value: 'LSL', fill: '#FF4F6A', fontSize: 9 }} />}
            {dist.mean && <ReferenceLine x={dist.mean} stroke="#00E5C4" strokeWidth={1.5} label={{ value: 'μ', fill: '#00E5C4', fontSize: 9 }} />}
          </ComposedChart>
        </ResponsiveContainer>

        {/* Descriptive Stats Row */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'Mean', value: dist.mean?.toFixed(5) },
            { label: 'Median', value: dist.median?.toFixed(5) },
            { label: 'Std Dev', value: dist.std?.toFixed(5) },
            { label: 'N', value: dist.n },
            { label: 'P5', value: dist.p5?.toFixed(5) },
            { label: 'P95', value: dist.p95?.toFixed(5) },
            { label: 'Skewness', value: dist.skewness?.toFixed(3) },
            { label: 'Kurtosis', value: dist.kurtosis?.toFixed(3) },
          ].map(s => (
            <div key={s.label} className="bg-surface border border-white/[0.04] rounded p-2">
              <div className="text-[9px] text-slate-600 uppercase tracking-wider mb-0.5">{s.label}</div>
              <div className="font-mono text-[11px] text-slate-300">{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Capability Panel */}
      <div className="space-y-3">
        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
          <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-4">Process Capability</div>
          {dist.capability && Object.entries({
            Cp: dist.capability.cp, Cpk: dist.capability.cpk,
            Cpm: dist.capability.cpm, Ppk: dist.capability.ppk
          }).map(([k, v]) => v != null && (
            <div key={k} className="mb-3">
              <div className="flex justify-between mb-1">
                <span className="text-[11px] text-slate-400 font-mono">{k}</span>
                <span className="text-[12px] font-bold font-mono" style={{ color: cpkColor(v) }}>
                  {v.toFixed(3)}
                </span>
              </div>
              <div className="h-1.5 bg-elevated rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${Math.min(100, (v / 2) * 100)}%`, background: cpkColor(v) }} />
              </div>
            </div>
          ))}

          {/* Spec Limits */}
          <div className="mt-4 pt-3 border-t border-white/[0.06] space-y-2">
            {[
              { label: 'USL', value: dist.usl, color: '#FF4F6A' },
              { label: 'LSL', value: dist.lsl, color: '#FF4F6A' },
              { label: 'Mean', value: dist.mean, color: '#00E5C4' },
            ].map(l => (
              <div key={l.label} className="flex justify-between">
                <span className="text-[10px] text-slate-500">{l.label}</span>
                <span className="font-mono text-[10px]" style={{ color: l.color }}>{l.value?.toFixed(5)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Box Plot Mini */}
        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
          <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-3">Box Plot</div>
          <div className="relative h-12 flex items-center">
            {/* IQR box */}
            {dist.p5 != null && dist.p95 != null && (
              <div className="absolute inset-0 flex items-center">
                <div className="w-full relative h-6">
                  <div className="absolute inset-y-0 border-2 border-violet rounded"
                    style={{
                      left: `${((dist.p5 - dist.min) / (dist.max - dist.min)) * 100}%`,
                      right: `${100 - ((dist.p95 - dist.min) / (dist.max - dist.min)) * 100}%`,
                      background: 'rgba(139,92,246,0.15)',
                    }} />
                  {/* Median line */}
                  <div className="absolute inset-y-0 w-0.5 bg-teal"
                    style={{ left: `${((dist.median - dist.min) / (dist.max - dist.min)) * 100}%` }} />
                  {/* Whiskers */}
                  <div className="absolute top-1/2 h-0.5 bg-slate-500"
                    style={{ left: 0, right: `${100 - ((dist.p5 - dist.min) / (dist.max - dist.min)) * 100}%` }} />
                  <div className="absolute top-1/2 h-0.5 bg-slate-500"
                    style={{ left: `${((dist.p95 - dist.min) / (dist.max - dist.min)) * 100}%`, right: 0 }} />
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-between mt-2 text-[9px] font-mono text-slate-600">
            <span>{dist.min?.toFixed(3)}</span>
            <span style={{ color: '#8B5CF6' }}>IQR</span>
            <span>{dist.max?.toFixed(3)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Trend Tab ─────────────────────────────────────────────────────────────────
function TrendTab({ paramId }: { paramId: string }) {
  const [equipment, setEquipment] = useState('')
  const [markOutliers, setMarkOutliers] = useState(true)
  const [showLimits, setShowLimits] = useState(true)
  const [hiddenEquipment, setHiddenEquipment] = useState<Set<string>>(new Set())

  const { data, isLoading } = useQuery({
    queryKey: ['wat-trend', paramId, equipment],
    queryFn: () => watApi.trend(paramId, equipment || undefined, 30),
    enabled: !!paramId,
  })

  type TrendRow = { lot_id: string; mean: number; std: number; cpk: number; usl: number; lsl: number; date: string; equipment_id: string }
  const rows = (data?.data?.data as TrendRow[] | undefined) || []
  const allEquip = [...new Set(rows.map(r => r.equipment_id).filter(Boolean))]

  const toggleEquip = (e: string) => {
    const next = new Set(hiddenEquipment)
    next.has(e) ? next.delete(e) : next.add(e)
    setHiddenEquipment(next)
  }

  const EQUIP_COLORS = ['#00E5C4', '#8B5CF6', '#F59E0B', '#38BDF8', '#FF4F6A', '#84CC16']

  const filteredRows = rows.filter(r => !hiddenEquipment.has(r.equipment_id))
  const usl = rows[0]?.usl
  const lsl = rows[0]?.lsl

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-4 flex-wrap">
        <select value={equipment} onChange={e => setEquipment(e.target.value)}
          className="bg-surface border border-white/[0.08] text-slate-300 rounded px-2 py-1.5 text-xs font-mono focus:outline-none focus:border-teal/40">
          <option value="">All Equipment</option>
          {allEquip.map(e => <option key={e} value={e}>{e}</option>)}
        </select>
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" checked={markOutliers} onChange={e => setMarkOutliers(e.target.checked)} className="accent-teal" />
          Mark outliers
        </label>
        <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" checked={showLimits} onChange={e => setShowLimits(e.target.checked)} className="accent-teal" />
          Show spec limits
        </label>
        {/* Equipment legend toggles */}
        <div className="ml-auto flex items-center gap-2 flex-wrap">
          {allEquip.map((e, i) => (
            <button key={e}
              onClick={() => toggleEquip(e)}
              className={clsx('flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-mono transition-all border',
                hiddenEquipment.has(e) ? 'opacity-40 border-white/[0.06]' : 'border-white/[0.1]'
              )}
              style={{ color: EQUIP_COLORS[i % EQUIP_COLORS.length] }}
            >
              <div className="w-2 h-2 rounded-full" style={{ background: EQUIP_COLORS[i % EQUIP_COLORS.length] }} />
              {e}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="h-52 flex items-center justify-center text-slate-500 text-sm">Loading trend data…</div>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <ComposedChart data={filteredRows} margin={{ top: 4, right: 16, bottom: 0, left: -10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="lot_id" tick={{ fill: '#475569', fontSize: 8 }} interval="preserveStartEnd" />
            <YAxis tick={{ fill: '#475569', fontSize: 9 }} />
            <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
              formatter={(v: number, name: string) => [v?.toFixed(5), name]} />
            {showLimits && usl && <ReferenceLine y={usl} stroke="rgba(255,79,106,0.6)" strokeDasharray="5 3" label={{ value: 'USL', fill: '#FF4F6A', fontSize: 9 }} />}
            {showLimits && lsl && <ReferenceLine y={lsl} stroke="rgba(255,79,106,0.6)" strokeDasharray="5 3" label={{ value: 'LSL', fill: '#FF4F6A', fontSize: 9 }} />}
            <Line type="monotone" dataKey="mean" name="Mean"
              stroke="#00E5C4" strokeWidth={2} dot={(props) => {
                const isOutlier = Math.abs((props.payload.mean - (usl + lsl) / 2) / ((usl - lsl) / 6)) > 3
                if (!markOutliers || !isOutlier) return <circle key={props.key} cx={props.cx} cy={props.cy} r={2} fill="#00E5C4" />
                return <circle key={props.key} cx={props.cx} cy={props.cy} r={5} fill="#FF4F6A" stroke="#fff" strokeWidth={1} />
              }} />
          </ComposedChart>
        </ResponsiveContainer>
      )}

      {/* Lot Table underneath */}
      <div className="max-h-36 overflow-y-auto">
        <table className="data-table">
          <thead><tr><th>Lot</th><th className="text-right">Mean</th><th className="text-right">Std</th><th className="text-right">Cpk</th><th>Equipment</th><th>Date</th></tr></thead>
          <tbody>
            {filteredRows.slice(0, 20).map(r => (
              <tr key={r.lot_id + r.equipment_id}>
                <td className="text-teal">{r.lot_id}</td>
                <td className="text-right">{r.mean?.toFixed(5)}</td>
                <td className="text-right">{r.std?.toFixed(5)}</td>
                <td className="text-right">
                  <span className={r.cpk >= 1.33 ? 'cell-pass' : r.cpk >= 1.0 ? 'cell-warn' : 'cell-fail'}>
                    {r.cpk?.toFixed(3)}
                  </span>
                </td>
                <td className="text-slate-500 text-[10px]">{r.equipment_id}</td>
                <td className="text-slate-600 text-[10px]">{r.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Correlation Tab ────────────────────────────────────────────────────────────
function CorrelationTab() {
  const [xParam, setXParam] = useState('IDSAT_N')
  const [yParam, setYParam] = useState('VTN')
  const [highlightSig, setHighlightSig] = useState(true)

  const { data, isLoading } = useQuery({
    queryKey: ['wat-correlation'],
    queryFn: () => watApi.correlationMatrix('PROD_N5_001', 30),
  })

  type CorrData = { params: string[]; r_matrix: (number | null)[][]; p_matrix: (number | null)[][]; lot_count: number }
  const corrData = data?.data?.data as CorrData | undefined
  const params = corrData?.params || WAT_PARAMS
  const rMatrix = corrData?.r_matrix || []
  const pMatrix = corrData?.p_matrix || []

  const cellColor = (r: number | null, p: number | null) => {
    if (r === null) return 'rgba(255,255,255,0.04)'
    if (highlightSig && p !== null && p > 0.05) return 'rgba(255,255,255,0.03)'
    const abs = Math.abs(r)
    if (r > 0) return `rgba(0,229,196,${abs * 0.85})`
    return `rgba(255,79,106,${abs * 0.85})`
  }

  return (
    <div className="grid grid-cols-5 gap-4">
      <div className="col-span-3 space-y-3">
        {/* Controls */}
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
            <input type="checkbox" checked={highlightSig} onChange={e => setHighlightSig(e.target.checked)} className="accent-teal" />
            Highlight p &lt; 0.05 only
          </label>
          <span className="text-[10px] text-slate-600">N = {corrData?.lot_count || 0} lots</span>
        </div>

        {/* Heatmap */}
        <div className="overflow-auto">
          <div className="min-w-fit">
            <div className="flex">
              <div className="w-20 flex-shrink-0" />
              {params.map(p => (
                <div key={p} className="w-14 text-[8px] text-slate-500 text-center truncate px-0.5 rotate-45 origin-left h-12 flex items-end pb-1">{p}</div>
              ))}
            </div>
            {params.map((p1, i) => (
              <div key={p1} className="flex items-center">
                <div className="w-20 text-[9px] text-slate-500 font-mono text-right pr-2 flex-shrink-0">{p1}</div>
                {params.map((p2, j) => {
                  const r = rMatrix[i]?.[j] ?? null
                  const p = pMatrix[i]?.[j] ?? null
                  return (
                    <div key={p2}
                      className="w-14 h-8 flex items-center justify-center cursor-pointer transition-all hover:scale-110 hover:z-10 relative text-[9px] font-mono font-bold"
                      style={{ background: cellColor(r, p), color: r === null ? 'transparent' : Math.abs(r ?? 0) > 0.6 ? '#fff' : 'rgba(255,255,255,0.6)' }}
                      title={r !== null ? `r=${r?.toFixed(3)}, p=${p?.toFixed(4)}` : ''}
                      onClick={() => { if (p1 !== p2) { setXParam(p2); setYParam(p1) } }}
                    >
                      {r !== null && i !== j ? r.toFixed(2) : '—'}
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-[10px] text-slate-500">
          <div className="w-4 h-3 rounded" style={{ background: 'rgba(255,79,106,0.8)' }} /> Strong negative (r = −1)
          <div className="w-4 h-3 rounded" style={{ background: 'rgba(255,255,255,0.05)' }} /> No correlation
          <div className="w-4 h-3 rounded" style={{ background: 'rgba(0,229,196,0.8)' }} /> Strong positive (r = +1)
          <span className="ml-2 text-slate-600">Click a cell to view scatter</span>
        </div>
      </div>

      {/* Scatter plot of selected pair */}
      <div className="col-span-2">
        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
          <div className="text-[11px] text-slate-400 mb-3 font-mono">
            Scatter: <span className="text-teal">{yParam}</span> vs <span className="text-violet">{xParam}</span>
          </div>
          <div className="flex items-center gap-3 mb-2">
            <select value={xParam} onChange={e => setXParam(e.target.value)}
              className="flex-1 bg-elevated border border-white/[0.06] text-slate-300 rounded px-2 py-1 text-[10px] font-mono focus:outline-none">
              {WAT_PARAMS.map(p => <option key={p}>{p}</option>)}
            </select>
            <span className="text-slate-600 text-xs">×</span>
            <select value={yParam} onChange={e => setYParam(e.target.value)}
              className="flex-1 bg-elevated border border-white/[0.06] text-slate-300 rounded px-2 py-1 text-[10px] font-mono focus:outline-none">
              {WAT_PARAMS.map(p => <option key={p}>{p}</option>)}
            </select>
          </div>
          {/* Demo scatter */}
          <div className="relative h-48 w-full">
            <svg width="100%" height="100%" viewBox="0 0 200 180">
              {Array.from({ length: 60 }, (_, i) => {
                const x = 20 + Math.random() * 160
                const y = 20 + (180 - x) * 0.6 + (Math.random() - 0.5) * 50
                return (
                  <circle key={i} cx={x} cy={Math.max(10, Math.min(170, y))} r={3}
                    fill="rgba(0,229,196,0.6)" stroke="rgba(0,229,196,0.2)" strokeWidth={0.5} />
                )
              })}
              {/* Regression line */}
              <line x1="20" y1="148" x2="180" y2="52" stroke="rgba(255,255,255,0.4)" strokeWidth={1} strokeDasharray="4 3" />
              {/* Axis labels */}
              <text x="100" y="178" textAnchor="middle" fill="#475569" fontSize="8">{xParam}</text>
              <text x="8" y="90" textAnchor="middle" fill="#475569" fontSize="8" transform="rotate(-90, 8, 90)">{yParam}</text>
            </svg>
          </div>
          <div className="text-[10px] font-mono text-slate-500 text-center mt-1">
            Demo scatter · r = −0.73 · p = 0.0002 · n = 60
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Equipment Health Tab ───────────────────────────────────────────────────────
function EquipmentTab() {
  const [sortBy, setSortBy] = useState<'health_score' | 'eta_squared'>('health_score')
  const [selectedEquip, setSelectedEquip] = useState<string | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ['equipment-health'],
    queryFn: () => watApi.equipmentHealth(),
  })

  type EqRow = { equipment_id: string; equipment_type: string; health_score: number; health_tier: string; z_score_component: number; gof_component: number; cv_stability_component: number; volume_component: number }
  const equipment = (data?.data?.data as EqRow[] | undefined) || []

  const healthColor = (tier: string) => ({
    HEALTHY: '#10B981', WATCH: '#F59E0B', DEGRADED: '#FF9500', CRITICAL: '#EF4444'
  }[tier] || '#64748B')

  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="col-span-2 space-y-2">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-[11px] text-slate-500">Sort by:</span>
          {['health_score', 'eta_squared'].map(s => (
            <button key={s}
              onClick={() => setSortBy(s as typeof sortBy)}
              className={clsx('text-[10px] px-2 py-1 rounded font-mono transition-all border',
                sortBy === s ? 'bg-teal/15 text-teal border-teal/20' : 'text-slate-500 border-white/[0.06] hover:text-slate-300'
              )}
            >{s === 'health_score' ? 'Health Score' : 'Eta²'}</button>
          ))}
        </div>

        {isLoading ? (
          <div className="h-40 flex items-center justify-center text-slate-500 text-sm">Loading equipment data…</div>
        ) : equipment.length === 0 ? (
          /* Demo equipment when no data */
          [
            { equipment_id: 'CVD-01', equipment_type: 'CVD', health_score: 88.4, health_tier: 'HEALTHY', z_score_component: 0.31, gof_component: 0.25, cv_stability_component: 0.20, volume_component: 0.12 },
            { equipment_id: 'CVD-02', equipment_type: 'CVD', health_score: 72.1, health_tier: 'WATCH', z_score_component: 0.38, gof_component: 0.18, cv_stability_component: 0.11, volume_component: 0.05 },
            { equipment_id: 'ETCH-01', equipment_type: 'ETCH', health_score: 95.2, health_tier: 'HEALTHY', z_score_component: 0.22, gof_component: 0.28, cv_stability_component: 0.24, volume_component: 0.15 },
            { equipment_id: 'CMP-01', equipment_type: 'CMP', health_score: 64.8, health_tier: 'DEGRADED', z_score_component: 0.40, gof_component: 0.12, cv_stability_component: 0.08, volume_component: 0.04 },
            { equipment_id: 'DIFF-01', equipment_type: 'DIFF', health_score: 91.3, health_tier: 'HEALTHY', z_score_component: 0.28, gof_component: 0.26, cv_stability_component: 0.22, volume_component: 0.15 },
          ].map(eq => (
            <div key={eq.equipment_id}
              className={clsx('bg-surface border rounded-lg p-3 cursor-pointer transition-all hover:border-white/[0.12]',
                selectedEquip === eq.equipment_id ? 'border-teal/30 bg-teal/[0.04]' : 'border-white/[0.06]'
              )}
              onClick={() => setSelectedEquip(selectedEquip === eq.equipment_id ? null : eq.equipment_id)}
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: healthColor(eq.health_tier) }} />
                <span className="font-mono text-[12px] text-slate-300 font-medium">{eq.equipment_id}</span>
                <span className="text-[10px] text-slate-600">{eq.equipment_type}</span>
                <div className="ml-auto flex items-center gap-3">
                  <span className="text-[11px] font-bold font-mono" style={{ color: healthColor(eq.health_tier) }}>
                    {eq.health_score.toFixed(1)}
                  </span>
                  <span className="badge text-[9px]" style={{
                    background: `${healthColor(eq.health_tier)}20`,
                    color: healthColor(eq.health_tier),
                    border: `1px solid ${healthColor(eq.health_tier)}30`,
                  }}>{eq.health_tier}</span>
                </div>
              </div>
              {/* Component bar */}
              <div className="mt-2 flex gap-0.5 h-2">
                {[
                  { v: eq.z_score_component * 100 * 2.86, color: '#00E5C4', label: 'Z-score (35%)' },
                  { v: eq.gof_component * 100 * 3.33, color: '#8B5CF6', label: 'GOF (30%)' },
                  { v: eq.cv_stability_component * 100 * 5, color: '#F59E0B', label: 'CV (20%)' },
                  { v: eq.volume_component * 100 * 6.67, color: '#38BDF8', label: 'Volume (15%)' },
                ].map(c => (
                  <div key={c.label} className="rounded-sm" title={`${c.label}: ${c.v.toFixed(1)}`}
                    style={{ width: `${c.v}%`, background: c.color, opacity: 0.8 }} />
                ))}
              </div>
              <div className="flex gap-3 mt-1">
                {['Z-score (35%)', 'GOF (30%)', 'CV (20%)', 'Vol (15%)'].map((l, i) => (
                  <span key={l} className="text-[8px] text-slate-600">{l}</span>
                ))}
              </div>
            </div>
          ))
        ) : equipment.map(eq => (
          <div key={eq.equipment_id}
            className={clsx('bg-surface border rounded-lg p-3 cursor-pointer transition-all hover:border-white/[0.12]',
              selectedEquip === eq.equipment_id ? 'border-teal/30 bg-teal/[0.04]' : 'border-white/[0.06]'
            )}
            onClick={() => setSelectedEquip(selectedEquip === eq.equipment_id ? null : eq.equipment_id)}
          >
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full" style={{ background: healthColor(eq.health_tier) }} />
              <span className="font-mono text-[12px] text-slate-300">{eq.equipment_id}</span>
              <span className="text-[10px] text-slate-600">{eq.equipment_type}</span>
              <span className="ml-auto font-bold font-mono text-[11px]" style={{ color: healthColor(eq.health_tier) }}>
                {eq.health_score?.toFixed(1)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Panel */}
      <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
        <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-3">
          {selectedEquip ? `${selectedEquip} — Detail` : 'Select Equipment'}
        </div>
        {selectedEquip ? (
          <div className="space-y-3">
            <div>
              <div className="text-[10px] text-slate-500 mb-2">Health Score Decomposition</div>
              <ResponsiveContainer width="100%" height={120}>
                <BarChart data={[
                  { component: 'Z-Score', weight: 35, score: 72, color: '#00E5C4' },
                  { component: 'GOF', weight: 30, score: 81, color: '#8B5CF6' },
                  { component: 'CV', weight: 20, score: 88, color: '#F59E0B' },
                  { component: 'Volume', weight: 15, score: 95, color: '#38BDF8' },
                ]} margin={{ top: 4, right: 8, bottom: 0, left: -10 }}>
                  <XAxis dataKey="component" tick={{ fill: '#475569', fontSize: 8 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: '#475569', fontSize: 8 }} />
                  <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }} />
                  <Bar dataKey="score" radius={[3, 3, 0, 0]}>
                    {['#00E5C4', '#8B5CF6', '#F59E0B', '#38BDF8'].map((c, i) => (
                      <Cell key={i} fill={c} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-1.5 text-[11px]">
              {[
                { label: 'Last PM', value: '2025-06-10' },
                { label: 'Next PM', value: '2025-09-08' },
                { label: 'Runs since PM', value: '1,247' },
                { label: 'Alarm Rate 30d', value: '0.58%' },
              ].map(s => (
                <div key={s.label} className="flex justify-between">
                  <span className="text-slate-500">{s.label}</span>
                  <span className="font-mono text-slate-300">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-slate-600 text-xs text-center mt-8">Click an equipment row to see details</div>
        )}
      </div>
    </div>
  )
}

// ── ANOVA Table Tab ───────────────────────────────────────────────────────────
function AnovaTab({ paramId }: { paramId: string }) {
  const DEMO_ANOVA = [
    { factor: 'EQPID', f_stat: 28.4, p_value: 9.83e-8, eta_sq: 0.421, health: 78 },
    { factor: 'CHAMBER', f_stat: 12.1, p_value: 2.1e-5, eta_sq: 0.234, health: 85 },
    { factor: 'RECIPE', f_stat: 6.8, p_value: 0.0023, eta_sq: 0.156, health: 91 },
    { factor: 'OPERATOR', f_stat: 3.2, p_value: 0.041, eta_sq: 0.089, health: 94 },
    { factor: 'SHIFT', f_stat: 1.4, p_value: 0.241, eta_sq: 0.034, health: 97 },
  ]
  return (
    <div className="space-y-4">
      <div className="text-[11px] text-slate-500">
        ANOVA Factor Analysis for <span className="font-mono text-teal">{paramId}</span> — Eta² measures % variance explained by each factor
      </div>
      <table className="data-table">
        <thead>
          <tr>
            <th>Factor</th>
            <th className="text-right">F-Stat</th>
            <th className="text-right">p-value</th>
            <th className="text-right">Eta²</th>
            <th>Impact Bar</th>
            <th>Significance</th>
          </tr>
        </thead>
        <tbody>
          {DEMO_ANOVA.map(row => (
            <tr key={row.factor} className="cursor-pointer">
              <td className="font-mono text-[11px] text-slate-300 font-medium">{row.factor}</td>
              <td className="text-right">{row.f_stat.toFixed(2)}</td>
              <td className="text-right">
                <span className={row.p_value < 0.001 ? 'text-coral font-bold' : row.p_value < 0.05 ? 'text-amber' : 'text-slate-500'}>
                  {row.p_value.toExponential(2)}
                </span>
              </td>
              <td className="text-right">
                <span className={row.eta_sq > 0.3 ? 'cell-fail' : row.eta_sq > 0.1 ? 'cell-warn' : 'cell-pass'}>
                  {(row.eta_sq * 100).toFixed(1)}%
                </span>
              </td>
              <td>
                <div className="h-2 bg-elevated rounded-full overflow-hidden w-32">
                  <div className="h-full rounded-full transition-all"
                    style={{ width: `${row.eta_sq * 100}%`, background: row.eta_sq > 0.3 ? '#EF4444' : row.eta_sq > 0.1 ? '#F59E0B' : '#10B981' }} />
                </div>
              </td>
              <td>
                <span className={row.p_value < 0.001 ? 'badge badge-coral' : row.p_value < 0.05 ? 'badge badge-amber' : 'badge badge-pass'}>
                  {row.p_value < 0.001 ? '***' : row.p_value < 0.01 ? '**' : row.p_value < 0.05 ? '*' : 'ns'}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="text-[10px] text-slate-600 font-mono">
        *** p &lt; 0.001 &nbsp;** p &lt; 0.01 &nbsp;* p &lt; 0.05 &nbsp;ns = not significant
      </div>
    </div>
  )
}

// ── Main WAT Analytics Page ───────────────────────────────────────────────────
export function WATAnalytics() {
  const [activeTab, setActiveTab] = useState('distribution')
  const [selectedParam, setSelectedParam] = useState('IDSAT_N')
  const [lotFilter, setLotFilter] = useState('')

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header Controls */}
      <div className="panel">
        <div className="panel-header">
          <div className="flex items-center gap-2">
            <div className="w-0.5 h-3.5 rounded-full bg-violet" />
            <span className="font-display text-[14px] font-semibold text-slate-200">WAT Analytics Workbench</span>
          </div>
          <div className="flex items-center gap-3">
            {/* Parameter Selector */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Parameter</span>
              <select value={selectedParam} onChange={e => setSelectedParam(e.target.value)}
                className="bg-elevated border border-white/[0.08] text-teal rounded px-2.5 py-1.5 text-xs font-mono focus:outline-none focus:border-teal/40 cursor-pointer">
                {WAT_PARAMS.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            {/* Lot Filter */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Lot</span>
              <input
                value={lotFilter}
                onChange={e => setLotFilter(e.target.value)}
                placeholder="M900…"
                className="bg-elevated border border-white/[0.08] text-slate-300 rounded px-2.5 py-1.5 text-xs font-mono w-28 focus:outline-none focus:border-teal/40 placeholder-slate-600"
              />
            </div>
            <div className="h-4 w-px bg-white/[0.08]" />
            <span className="badge badge-violet">PROD_N5_001</span>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex gap-1 px-4 pt-3 pb-0 border-b border-white/[0.06]">
          {TABS.map(tab => (
            <button key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={clsx(
                'px-3 py-2 text-[12px] font-medium rounded-t-md transition-all border-b-2',
                activeTab === tab.id
                  ? 'text-teal border-teal bg-teal/[0.08]'
                  : 'text-slate-500 border-transparent hover:text-slate-300 hover:bg-elevated'
              )}
              title={tab.desc}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === 'distribution' && <DistributionTab paramId={selectedParam} lotId={lotFilter} />}
              {activeTab === 'trend' && <TrendTab paramId={selectedParam} />}
              {activeTab === 'correlation' && <CorrelationTab />}
              {activeTab === 'equipment' && <EquipmentTab />}
              {activeTab === 'anova' && <AnovaTab paramId={selectedParam} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
