import { useState, useRef, useEffect, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'framer-motion'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, LineChart, Line } from 'recharts'
import { cpApi, yieldApi } from '@/api/endpoints'
import { useWaferRenderer } from '@/hooks/useWaferRenderer'
import { clsx } from 'clsx'

const BIN_COLORS: Record<number, string> = {
  1: '#10B981', 8: '#38BDF8', 14: '#8B5CF6',
  9: '#F59E0B', 12: '#EF4444', 6: '#84CC16', 4: '#EC4899', 0: '#475569',
}
const BIN_LABELS: Record<string, string> = {
  '1': 'Pass', '8': 'Bin_8', '14': 'Bin_14', '9': 'Bin_9', '12': 'Bin_12',
}

function WaferMapCanvas({ xs, ys, bins, passes, selected, onDieClick }: {
  xs: number[]; ys: number[]; bins: number[]; passes: boolean[];
  selected: Set<number>; onDieClick: (idx: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const binColorMap = useMemo(() => {
    return Object.fromEntries(
      Object.entries(BIN_COLORS).map(([k, hex]) => {
        const r = parseInt(hex.slice(1, 3), 16)
        const g = parseInt(hex.slice(3, 5), 16)
        const b = parseInt(hex.slice(5, 7), 16)
        return [Number(k), [r, g, b] as [number, number, number]]
      })
    ) as Record<number, [number, number, number]>
  }, [])

  useWaferRenderer(canvasRef, xs, ys, bins, passes, binColorMap)

  return (
    <div className="relative flex flex-col items-center">
      <canvas ref={canvasRef} width={300} height={300}
        className="rounded-full cursor-crosshair border border-white/10"
        onClick={(e) => {
          const rect = canvasRef.current?.getBoundingClientRect()
          if (!rect) return
          const cx = e.clientX - rect.left
          const cy = e.clientY - rect.top
          // Find nearest die
          if (!xs.length) return
          const minX = Math.min(...xs), maxX = Math.max(...xs)
          const minY = Math.min(...ys), maxY = Math.max(...ys)
          const scaleX = 300 / (maxX - minX + 2)
          const scaleY = 300 / (maxY - minY + 2)
          const dieX = Math.round(cx / scaleX + minX - 0.5)
          const dieY = Math.round(cy / scaleY + minY - 0.5)
          const idx = xs.findIndex((x, i) => x === dieX && ys[i] === dieY)
          if (idx !== -1) onDieClick(idx)
        }}
      />
    </div>
  )
}

function MRBConsolidation() {
  const { data } = useQuery({ queryKey: ['mrb-review'], queryFn: () => cpApi.mrbReview(7) })
  type MRBRow = { lot_id: string; wafer_id: string; slot_number: number; syl_flag: boolean; sbl_flag: boolean; mrb_result: string; gross_yield_pct: number; pattern_class_generic: string; is_partial_wafer: boolean }
  const rows = (data?.data?.data as MRBRow[] | undefined) || []

  // Demo data if empty
  const DEMO = [
    { lot_id: 'LOT_63.1', wafer_id: 'LOT_63.1_01', slot_number: 1, partial_wafer: false, wafer_cluster: false, wafer_pattern: true, wf_syl: true, wf_sbl: false, pcm_violate: false, mrb_result: 'BadWafer' },
    { lot_id: 'LOT_63.1', wafer_id: 'LOT_63.1_02', slot_number: 2, partial_wafer: false, wafer_cluster: false, wafer_pattern: false, wf_syl: false, wf_sbl: false, pcm_violate: false, mrb_result: 'GoodWafer' },
    { lot_id: 'LOT_63.1', wafer_id: 'LOT_63.1_03', slot_number: 3, partial_wafer: false, wafer_cluster: false, wafer_pattern: false, wf_syl: false, wf_sbl: false, pcm_violate: true, mrb_result: 'BadWafer' },
    { lot_id: 'LOT_63.1', wafer_id: 'LOT_63.1_05', slot_number: 5, partial_wafer: false, wafer_cluster: false, wafer_pattern: false, wf_syl: false, wf_sbl: false, pcm_violate: false, mrb_result: 'GoodWafer' },
    { lot_id: 'LOT_63.1', wafer_id: 'LOT_63.1_09', slot_number: 9, partial_wafer: true, wafer_cluster: false, wafer_pattern: true, wf_syl: false, wf_sbl: false, pcm_violate: false, mrb_result: 'BadWafer' },
  ]

  const displayRows = rows.length > 0 ? rows.map(r => ({
    lot_id: r.lot_id, wafer_id: r.wafer_id, slot_number: r.slot_number,
    partial_wafer: r.is_partial_wafer, wafer_cluster: false, wafer_pattern: r.pattern_class_generic !== 'NORMAL',
    wf_syl: r.syl_flag, wf_sbl: r.sbl_flag, pcm_violate: false, mrb_result: r.mrb_result,
  })) : DEMO

  const FlagCell = ({ v }: { v: boolean }) => v
    ? <span className="cell-flag">True</span>
    : <span className="text-slate-600 text-[10px]">False</span>

  return (
    <div className="panel">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-coral" />
          <span className="font-display text-[13px] font-semibold">IMD MRB Consolidation</span>
        </div>
        <div className="flex gap-2">
          <span className="badge badge-pass">{displayRows.filter(r => r.mrb_result === 'GoodWafer').length} Good</span>
          <span className="badge badge-coral">{displayRows.filter(r => r.mrb_result === 'BadWafer').length} Bad</span>
        </div>
      </div>
      <div className="overflow-auto max-h-48">
        <table className="data-table">
          <thead>
            <tr>
              <th>LOT_ID</th><th>WF_ID</th><th>Partial</th><th>Cluster</th>
              <th>Pattern</th><th>SYL</th><th>SBL</th><th>PCM</th><th>MRB Result</th>
            </tr>
          </thead>
          <tbody>
            {displayRows.map(r => (
              <tr key={r.wafer_id}>
                <td className="text-teal text-[10px]">{r.lot_id}</td>
                <td className="font-mono text-[10px]">{r.wafer_id}</td>
                <td><FlagCell v={r.partial_wafer} /></td>
                <td><FlagCell v={r.wafer_cluster} /></td>
                <td><FlagCell v={r.wafer_pattern} /></td>
                <td><FlagCell v={r.wf_syl} /></td>
                <td><FlagCell v={r.wf_sbl} /></td>
                <td><FlagCell v={r.pcm_violate} /></td>
                <td>
                  <span className={r.mrb_result === 'GoodWafer' ? 'cell-pass' : 'cell-fail'}>
                    ● {r.mrb_result}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function WaferGallery({ lotId }: { lotId: string }) {
  const [selectedWafer, setSelectedWafer] = useState<string | null>(null)
  const { data } = useQuery({
    queryKey: ['wafer-gallery', lotId],
    queryFn: () => yieldApi.waferGallery(lotId),
    enabled: !!lotId,
  })
  type GalleryRow = { wafer_id: string; slot_number: number; gross_yield_pct: number; mrb_result: string; pattern_class_generic: string }
  const wafers = (data?.data?.data as GalleryRow[] | undefined) || []

  // Demo wafers if empty
  const DEMO_WAFERS = Array.from({ length: 12 }, (_, i) => ({
    wafer_id: `LOT_63.1_${String(i + 1).padStart(2, '0')}`,
    slot_number: i + 1,
    gross_yield_pct: 70 + Math.random() * 28,
    mrb_result: Math.random() > 0.75 ? 'BadWafer' : 'GoodWafer',
    pattern_class_generic: ['NORMAL', 'EDGE', 'CENTER', 'DONUT'][Math.floor(Math.random() * 4)],
  }))

  const displayWafers = wafers.length > 0 ? wafers : DEMO_WAFERS

  return (
    <div className="panel">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <div className="w-0.5 h-3.5 rounded-full bg-violet" />
          <span className="font-display text-[13px] font-semibold">Wafer Map Gallery</span>
        </div>
        <span className="text-[10px] text-slate-500 font-mono">{lotId}</span>
      </div>
      <div className="panel-body">
        <div className="grid grid-cols-6 gap-2">
          {displayWafers.map(w => {
            const isBad = w.mrb_result === 'BadWafer' || w.gross_yield_pct < 85
            return (
              <div key={w.wafer_id}
                onClick={() => setSelectedWafer(selectedWafer === w.wafer_id ? null : w.wafer_id)}
                className={clsx(
                  'flex flex-col items-center gap-1 p-2 rounded-lg border cursor-pointer transition-all hover:scale-105',
                  selectedWafer === w.wafer_id ? 'border-teal/40 bg-teal/[0.04]' : isBad ? 'border-fail/30' : 'border-white/[0.06]',
                )}
              >
                {/* Mini SVG wafer */}
                <svg width="48" height="48" viewBox="0 0 48 48">
                  <defs>
                    <clipPath id={`clip-${w.slot_number}`}>
                      <circle cx="24" cy="24" r="22" />
                    </clipPath>
                  </defs>
                  <g clipPath={`url(#clip-${w.slot_number})`}>
                    {Array.from({ length: 64 }, (_, i) => {
                      const row = Math.floor(i / 8), col = i % 8
                      const x = col * 6, y = row * 6
                      const cx = x + 3, cy = y + 3
                      const dist = Math.hypot(cx - 24, cy - 24)
                      if (dist > 23) return null
                      const rand = Math.random()
                      let fill = '#10B981'
                      if (isBad && rand > 0.5) fill = '#EF4444'
                      else if (rand > 0.9) fill = '#38BDF8'
                      return <rect key={i} x={x + 0.3} y={y + 0.3} width={5.4} height={5.4} fill={fill} opacity={0.85} rx={0.5} />
                    })}
                  </g>
                  <circle cx="24" cy="24" r="22" fill="none" stroke={isBad ? 'rgba(239,68,68,0.4)' : 'rgba(255,255,255,0.1)'} strokeWidth={1.5} />
                </svg>
                <div className="text-[9px] text-slate-500 font-mono">W{w.slot_number}</div>
                <div className={clsx('text-[10px] font-bold font-mono', isBad ? 'text-fail' : 'text-pass')}>
                  {w.gross_yield_pct.toFixed(1)}%
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function BinMapView({ lotId }: { lotId: string }) {
  const [selectedWaferId, setSelectedWaferId] = useState('')
  const [renderMode, setRenderMode] = useState<'canvas' | 'svg'>('canvas')
  const [selectedDie, setSelectedDie] = useState<number | null>(null)
  const [hiddenBins, setHiddenBins] = useState<Set<number>>(new Set())

  const { data: waferData } = useQuery({
    queryKey: ['wafer-summary-cp', lotId],
    queryFn: () => cpApi.waferSummary(lotId),
    enabled: !!lotId,
  })
  type SummaryRow = { wafer_id: string; slot_number: number; gross_yield_pct: number }
  const wafers = (waferData?.data?.data as SummaryRow[] | undefined) || []

  const { data: mapData, isLoading } = useQuery({
    queryKey: ['bin-map', lotId, selectedWaferId],
    queryFn: () => cpApi.binMap(lotId, selectedWaferId),
    enabled: !!lotId && !!selectedWaferId,
  })
  type MapData = { xs: number[]; ys: number[]; bins: number[]; passes: boolean[]; die_count: number }
  const map = (mapData?.data?.data as MapData | undefined)

  // Generate demo data when no real data
  const DEMO_XS: number[] = [], DEMO_YS: number[] = [], DEMO_BINS: number[] = [], DEMO_PASSES: boolean[] = []
  for (let y = -18; y <= 18; y++) {
    for (let x = -18; x <= 18; x++) {
      if (Math.hypot(x, y) > 18.5) continue
      DEMO_XS.push(x); DEMO_YS.push(y)
      const r = Math.random()
      const bin = r > 0.88 ? 8 : r > 0.78 ? 14 : r > 0.72 ? 9 : 1
      DEMO_BINS.push(bin); DEMO_PASSES.push(bin === 1)
    }
  }

  const xs = map?.xs ?? DEMO_XS
  const ys = map?.ys ?? DEMO_YS
  const bins = map?.bins ?? DEMO_BINS
  const passes = map?.passes ?? DEMO_PASSES

  const filteredXs = xs.filter((_, i) => !hiddenBins.has(bins[i]))
  const filteredYs = ys.filter((_, i) => !hiddenBins.has(bins[i]))
  const filteredBins = bins.filter(b => !hiddenBins.has(b))
  const filteredPasses = passes.filter((_, i) => !hiddenBins.has(bins[i]))

  const uniqueBins = [...new Set(bins)].sort((a, b) => a - b)
  const binCounts = uniqueBins.reduce((acc, b) => ({ ...acc, [b]: bins.filter(x => x === b).length }), {} as Record<number, number>)
  const totalDie = xs.length

  const toggleBin = (bin: number) => {
    const next = new Set(hiddenBins)
    next.has(bin) ? next.delete(bin) : next.add(bin)
    setHiddenBins(next)
  }

  const selectedDieInfo = selectedDie !== null ? {
    x: xs[selectedDie], y: ys[selectedDie],
    bin: bins[selectedDie], pass: passes[selectedDie],
  } : null

  return (
    <div className="grid grid-cols-4 gap-4">
      {/* Controls */}
      <div className="col-span-4 flex items-center gap-4 flex-wrap">
        {wafers.length > 0 && (
          <select value={selectedWaferId} onChange={e => setSelectedWaferId(e.target.value)}
            className="bg-elevated border border-white/[0.08] text-slate-300 rounded px-2.5 py-1.5 text-xs font-mono focus:outline-none">
            <option value="">Select Wafer</option>
            {wafers.map(w => <option key={w.wafer_id} value={w.wafer_id}>Slot {w.slot_number} — {w.gross_yield_pct?.toFixed(1)}%</option>)}
          </select>
        )}
        <div className="flex items-center gap-1.5 bg-elevated border border-white/[0.06] rounded p-0.5">
          {(['canvas', 'svg'] as const).map(m => (
            <button key={m} onClick={() => setRenderMode(m)}
              className={clsx('px-2.5 py-1 rounded text-[10px] font-mono transition-all',
                renderMode === m ? 'bg-teal/15 text-teal' : 'text-slate-500 hover:text-slate-300'
              )}>{m.toUpperCase()}</button>
          ))}
        </div>
        {/* Bin Legend + Toggle */}
        <div className="flex items-center gap-2 flex-wrap ml-auto">
          {uniqueBins.map(bin => (
            <button key={bin}
              onClick={() => toggleBin(bin)}
              className={clsx('flex items-center gap-1.5 px-2 py-1 rounded border text-[10px] font-mono transition-all',
                hiddenBins.has(bin) ? 'opacity-30 border-white/[0.04]' : 'border-white/[0.1]'
              )}
              style={{ color: BIN_COLORS[bin] || '#64748B' }}
            >
              <div className="w-2 h-2 rounded-sm flex-shrink-0" style={{ background: BIN_COLORS[bin] || '#64748B' }} />
              Bin {bin} ({((binCounts[bin] / totalDie) * 100).toFixed(1)}%)
            </button>
          ))}
        </div>
      </div>

      {/* Wafer Map */}
      <div className="col-span-2 flex flex-col items-center gap-3">
        {isLoading ? (
          <div className="w-64 h-64 rounded-full bg-surface border border-white/[0.06] flex items-center justify-center text-slate-500 text-sm">
            Loading…
          </div>
        ) : (
          <WaferMapCanvas
            xs={filteredXs} ys={filteredYs} bins={filteredBins} passes={filteredPasses}
            selected={selectedDie !== null ? new Set([selectedDie]) : new Set()}
            onDieClick={idx => setSelectedDie(selectedDie === idx ? null : idx)}
          />
        )}
        <div className="text-[10px] text-slate-500 font-mono">
          {totalDie.toLocaleString()} dies · {passes.filter(Boolean).length.toLocaleString()} pass ·{' '}
          <span className="text-pass">{((passes.filter(Boolean).length / totalDie) * 100).toFixed(2)}% yield</span>
        </div>
        {selectedDieInfo && (
          <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
            className="w-full bg-elevated border border-teal/20 rounded-lg p-3 text-[11px]">
            <div className="text-teal font-mono font-semibold mb-1.5">Selected Die</div>
            <div className="grid grid-cols-2 gap-y-1">
              {[
                ['X', selectedDieInfo.x], ['Y', selectedDieInfo.y],
                ['Bin', selectedDieInfo.bin], ['Status', selectedDieInfo.pass ? '✓ Pass' : '✗ Fail'],
              ].map(([k, v]) => (
                <div key={String(k)} className="flex gap-2">
                  <span className="text-slate-500 w-10">{k}:</span>
                  <span className={clsx('font-mono', k === 'Status' ? (selectedDieInfo.pass ? 'text-pass' : 'text-fail') : 'text-slate-300')}>{v}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>

      {/* Bin Pareto */}
      <div className="col-span-2 space-y-4">
        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
          <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-3">Bin Pareto — All Lots</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart
              data={uniqueBins.map(b => ({ bin: `Bin ${b}`, count: binCounts[b], pct: ((binCounts[b] / totalDie) * 100) }))}
              layout="vertical" margin={{ left: 10, right: 40, top: 4, bottom: 4 }}
            >
              <XAxis type="number" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v.toFixed(1)}%`}
                domain={[0, 100]} />
              <YAxis dataKey="bin" type="category" tick={{ fill: '#94A3B8', fontSize: 9, fontFamily: 'JetBrains Mono' }} width={45} />
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
              <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                formatter={(v: number) => [`${v.toFixed(2)}%`, 'Yield']} />
              <Bar dataKey="pct" radius={[0, 3, 3, 0]}
                label={{ position: 'right', fill: '#64748B', fontSize: 8, formatter: (v: number) => `${v.toFixed(1)}%` }}>
                {uniqueBins.map((bin, i) => (
                  <Cell key={i} fill={BIN_COLORS[bin] || '#64748B'} opacity={hiddenBins.has(bin) ? 0.2 : 0.9} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Site Yield Heatmap */}
        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
          <div className="text-[11px] text-slate-500 uppercase tracking-wider mb-2">Site-to-Site Yield</div>
          <div className="grid grid-cols-5 gap-1">
            {Array.from({ length: 9 }, (_, i) => {
              const y = 85 + Math.random() * 13
              return (
                <div key={i} className="text-center">
                  <div className="h-6 rounded text-[9px] flex items-center justify-center font-mono font-bold"
                    style={{ background: y > 95 ? 'rgba(16,185,129,0.3)' : y > 90 ? 'rgba(245,158,11,0.3)' : 'rgba(239,68,68,0.3)',
                      color: y > 95 ? '#10B981' : y > 90 ? '#F59E0B' : '#EF4444' }}>
                    {y.toFixed(1)}%
                  </div>
                  <div className="text-[8px] text-slate-600 mt-0.5">S{i + 1}</div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

export function CPAnalytics() {
  const [activeTab, setActiveTab] = useState<'binmap' | 'gallery' | 'mrb'>('binmap')
  const [lotId, setLotId] = useState('LOT_63.1')

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="panel">
        <div className="panel-header">
          <div className="flex items-center gap-2">
            <div className="w-0.5 h-3.5 rounded-full bg-teal" />
            <span className="font-display text-[14px] font-semibold">CP Analytics — Bin Map & Die Traceability</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-slate-500">Lot:</span>
            <input value={lotId} onChange={e => setLotId(e.target.value)}
              className="bg-elevated border border-white/[0.08] text-teal rounded px-2.5 py-1.5 text-xs font-mono w-32 focus:outline-none focus:border-teal/40" />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-4 pt-3 pb-0 border-b border-white/[0.06]">
          {[
            { id: 'binmap', label: '🗺️ Bin Map' },
            { id: 'gallery', label: '🖼️ Wafer Gallery' },
            { id: 'mrb', label: '🚦 MRB Review' },
          ].map(t => (
            <button key={t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={clsx('px-3 py-2 text-[12px] font-medium rounded-t-md transition-all border-b-2',
                activeTab === t.id ? 'text-teal border-teal bg-teal/[0.08]' : 'text-slate-500 border-transparent hover:text-slate-300'
              )}>{t.label}</button>
          ))}
        </div>

        <div className="p-4">
          {activeTab === 'binmap' && <BinMapView lotId={lotId} />}
          {activeTab === 'gallery' && <WaferGallery lotId={lotId} />}
          {activeTab === 'mrb' && <MRBConsolidation />}
        </div>
      </div>
    </div>
  )
}
