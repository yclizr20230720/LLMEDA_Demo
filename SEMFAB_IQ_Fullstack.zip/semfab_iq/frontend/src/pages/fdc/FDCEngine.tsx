import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Cell, RadarChart, Radar,
  PolarGrid, PolarAngleAxis, ScatterChart, Scatter
} from 'recharts'
import { fdcApi } from '@/api/endpoints'
import { clsx } from 'clsx'

const SENSORS = [
  { alias: 'CEID10OnlineTime', module: 1, total: 11839, points: 11839, rate: 100.0, status: 'PASS' },
  { alias: 'ChmPress', module: 1, total: 11839, points: 10785, rate: 91.1, status: 'WARN' },
  { alias: 'ChmTemp', module: 1, total: 11839, points: 10630, rate: 89.7, status: 'WARN' },
  { alias: 'ChmTemp1SlotV', module: 1, total: 11839, points: 880, rate: 31.8, status: 'FAIL' },
  { alias: 'DAQ10HPCompCurrentR', module: 1, total: 11839, points: 11819, rate: 99.8, status: 'PASS' },
  { alias: 'DAQ10HPCompCurrentT', module: 1, total: 11839, points: 11839, rate: 100.0, status: 'PASS' },
  { alias: 'DAQ275HPCompCurrentR', module: 1, total: 11839, points: 11839, rate: 100.0, status: 'PASS' },
  { alias: 'DAQ275HPCompCurrentT', module: 1, total: 11839, points: 11839, rate: 100.0, status: 'PASS' },
  { alias: 'DAQ275HPPumpCurrentR', module: 1, total: 11839, points: 6920, rate: 58.4, status: 'FAIL' },
  { alias: 'DAQ275HeatCurrentR', module: 1, total: 11839, points: 11839, rate: 100.0, status: 'PASS' },
]

function generateTrace(n: number, baseline: number, sigma: number, anomalyStart?: number) {
  return Array.from({ length: n }, (_, i) => {
    const isAnomaly = anomalyStart !== undefined && i >= anomalyStart
    return baseline + (isAnomaly ? sigma * 3.5 : 0) + (Math.random() - 0.5) * sigma * 2
  })
}

function TraceOverlayChart({ sensorAlias }: { sensorAlias: string }) {
  const n = 120
  const baseline = 5.35
  const sigma = 0.08
  const baseTrace = useMemo(() => generateTrace(n, baseline, sigma), [])
  const qualTrace = useMemo(() => generateTrace(n, baseline, sigma, 85), [])

  const data = Array.from({ length: n }, (_, i) => ({
    t: i * 2,
    baseline: parseFloat(baseTrace[i].toFixed(4)),
    qualification: parseFloat(qualTrace[i].toFixed(4)),
  }))

  const anomalyAt = 85 * 2
  const isAnomalous = qualTrace.slice(85).some(v => Math.abs(v - baseline) > sigma * 3)

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3">
        <span className="font-mono text-[11px] text-slate-400">{sensorAlias}</span>
        {isAnomalous && (
          <span className="badge badge-coral animate-pulse-red">⚠ ANOMALY DETECTED</span>
        )}
      </div>
      <ResponsiveContainer width="100%" height={150}>
        <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
          <XAxis dataKey="t" tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v}s`} />
          <YAxis domain={['auto', 'auto']} tick={{ fill: '#475569', fontSize: 9 }} />
          <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
            formatter={(v: number, name: string) => [v.toFixed(4), name === 'baseline' ? 'Baseline' : 'Qualification']} />
          <ReferenceLine x={anomalyAt} stroke="rgba(139,92,246,0.5)" strokeDasharray="4 3"
            label={{ value: 'Diverge', fill: '#8B5CF6', fontSize: 8 }} />
          <Line type="monotone" dataKey="baseline" stroke="rgba(255,79,106,0.8)" strokeWidth={1.5} dot={false} name="Baseline" />
          <Line type="monotone" dataKey="qualification" stroke="rgba(56,189,248,0.8)" strokeWidth={1.5} dot={false} name="Qualification" />
        </LineChart>
      </ResponsiveContainer>
      <div className="flex gap-4 text-[10px]">
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-0.5 bg-coral/80 rounded" />
          <span className="text-slate-500">Baseline</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-0.5 bg-sky/80 rounded" />
          <span className="text-slate-500">Qualification</span>
        </div>
      </div>
    </div>
  )
}

function AnomalyRadar({ run }: { run: { interval: number; pm: number; amplitude: number; shape: number; composite: number } }) {
  const data = [
    { subject: 'Interval', value: run.interval * 100, fullMark: 100 },
    { subject: 'PM Drift', value: run.pm * 100, fullMark: 100 },
    { subject: 'Amplitude', value: run.amplitude * 100, fullMark: 100 },
    { subject: 'Shape', value: run.shape * 100, fullMark: 100 },
    { subject: 'Composite', value: run.composite * 100, fullMark: 100 },
  ]
  const color = run.composite > 0.8 ? '#EF4444' : run.composite > 0.5 ? '#F59E0B' : '#10B981'
  return (
    <div className="flex flex-col items-center">
      <RadarChart width={160} height={130} data={data} margin={{ top: 8, right: 8, bottom: 8, left: 8 }}>
        <PolarGrid stroke="rgba(255,255,255,0.08)" />
        <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748B', fontSize: 8 }} />
        <Radar name="Score" dataKey="value" stroke={color} fill={color} fillOpacity={0.2} strokeWidth={1.5} />
      </RadarChart>
      <div className="font-mono text-[13px] font-bold" style={{ color }}>
        {(run.composite * 100).toFixed(1)}
      </div>
      <div className="text-[9px] text-slate-600">Composite Score</div>
    </div>
  )
}

function TraceRunTable({ onSelect }: { onSelect: (run: { run_id: string; equipment_id: string; anomaly: boolean; composite: number }) => void }) {
  const [filterAnomaly, setFilterAnomaly] = useState(false)
  const [selectedRun, setSelectedRun] = useState<string | null>(null)
  const [equipment, setEquipment] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['fdc-trace-runs', filterAnomaly, equipment],
    queryFn: () => fdcApi.traceRuns({ is_anomaly: filterAnomaly || undefined, equipment_id: equipment || undefined, days: 14 }),
  })
  type RunRow = { run_id: string; equipment_id: string; chamber_id: string; is_anomaly: boolean; composite_anomaly_score: number; run_result: string; run_start_time: string; alarm_count: number }
  const runs = (data?.data?.data as RunRow[] | undefined) || []

  const DEMO_RUNS: RunRow[] = Array.from({ length: 15 }, (_, i) => ({
    run_id: `RUN_${String(i).padStart(5, '0')}`,
    equipment_id: ['CVD-01', 'ETCH-01', 'CMP-01'][i % 3],
    chamber_id: `PM${(i % 2) + 1}`,
    is_anomaly: i >= 8 && i <= 11,
    composite_anomaly_score: i >= 8 && i <= 11 ? 0.85 + Math.random() * 0.1 : Math.random() * 0.25,
    run_result: i >= 8 && i <= 11 ? 'ALARM' : 'PASS',
    run_start_time: new Date(Date.now() - i * 3600000 * 3.5).toISOString(),
    alarm_count: i >= 8 && i <= 11 ? 3 : 0,
  }))

  const displayRuns = runs.length > 0
    ? (filterAnomaly ? runs.filter(r => r.is_anomaly) : runs)
    : (filterAnomaly ? DEMO_RUNS.filter(r => r.is_anomaly) : DEMO_RUNS)

  const scoreColor = (s: number) => s > 0.8 ? '#EF4444' : s > 0.5 ? '#F59E0B' : '#10B981'

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3">
        <select value={equipment} onChange={e => setEquipment(e.target.value)}
          className="bg-elevated border border-white/[0.08] text-slate-300 rounded px-2 py-1 text-[10px] font-mono focus:outline-none">
          <option value="">All Equipment</option>
          {['CVD-01', 'ETCH-01', 'CMP-01'].map(e => <option key={e}>{e}</option>)}
        </select>
        <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
          <input type="checkbox" checked={filterAnomaly} onChange={e => setFilterAnomaly(e.target.checked)} className="accent-coral" />
          Anomalies only
        </label>
        <span className="text-[10px] text-slate-600 ml-auto">{displayRuns.length} runs</span>
      </div>

      <div className="overflow-auto max-h-48">
        <table className="data-table">
          <thead>
            <tr>
              <th>Run ID</th><th>Equipment</th><th>Chamber</th>
              <th className="text-right">Score</th><th>Result</th>
              <th>Start Time</th><th className="text-right">Alarms</th>
            </tr>
          </thead>
          <tbody>
            {displayRuns.map(r => (
              <tr key={r.run_id}
                className={clsx('cursor-pointer', selectedRun === r.run_id && 'selected')}
                onClick={() => {
                  setSelectedRun(r.run_id === selectedRun ? null : r.run_id)
                  onSelect({ run_id: r.run_id, equipment_id: r.equipment_id, anomaly: r.is_anomaly, composite: r.composite_anomaly_score })
                }}
              >
                <td className="font-mono text-[10px] text-teal">{r.run_id}</td>
                <td className="text-[10px]">{r.equipment_id}</td>
                <td className="text-slate-500 text-[10px]">{r.chamber_id}</td>
                <td className="text-right">
                  <span className="font-mono text-[11px] font-bold" style={{ color: scoreColor(r.composite_anomaly_score) }}>
                    {(r.composite_anomaly_score * 100).toFixed(0)}
                  </span>
                </td>
                <td>
                  <span className={r.run_result === 'PASS' ? 'cell-pass' : 'cell-fail'}>
                    {r.run_result}
                  </span>
                </td>
                <td className="text-slate-600 text-[10px] font-mono">
                  {new Date(r.run_start_time).toLocaleTimeString()}
                </td>
                <td className="text-right">
                  {r.alarm_count > 0
                    ? <span className="text-coral font-bold text-[11px]">{r.alarm_count}</span>
                    : <span className="text-slate-600">—</span>
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function SensorQualificationTable({ selectedSensor, onSelect }: {
  selectedSensor: string | null; onSelect: (s: string) => void
}) {
  const [sigmaLimit, setSigmaLimit] = useState(6)
  const [passThreshold, setPassThreshold] = useState(90)

  const statusColor = (s: string) => ({ PASS: '#10B981', WARN: '#F59E0B', FAIL: '#EF4444' })[s] || '#64748B'
  const barColor = (rate: number) => rate >= 95 ? '#10B981' : rate >= 80 ? '#F59E0B' : '#EF4444'

  return (
    <div className="space-y-3">
      {/* Config */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500">Sigma limit:</span>
          <input type="range" min={3} max={9} value={sigmaLimit} onChange={e => setSigmaLimit(+e.target.value)}
            className="w-20 accent-teal" />
          <span className="font-mono text-[11px] text-teal">±{sigmaLimit}σ</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500">Pass threshold:</span>
          <input type="range" min={70} max={100} value={passThreshold} onChange={e => setPassThreshold(+e.target.value)}
            className="w-20 accent-teal" />
          <span className="font-mono text-[11px] text-teal">{passThreshold}%</span>
        </div>
        <span className="badge badge-pass ml-auto">
          {SENSORS.filter(s => s.rate >= passThreshold).length}/{SENSORS.length} Pass
        </span>
      </div>

      {/* Sensor Table */}
      <div className="overflow-auto max-h-52">
        {SENSORS.map(s => (
          <div key={s.alias}
            onClick={() => onSelect(s.alias)}
            className={clsx(
              'flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer transition-all mb-0.5',
              selectedSensor === s.alias ? 'bg-teal/[0.08] border border-teal/20' : 'hover:bg-elevated border border-transparent'
            )}
          >
            <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: statusColor(s.status) }} />
            <span className="font-mono text-[10px] text-slate-300 flex-1 truncate">{s.alias}</span>

            {/* Pass rate bar */}
            <div className="w-24 h-1.5 bg-elevated rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${s.rate}%`, background: barColor(s.rate) }} />
            </div>

            <span className="font-mono text-[10px] w-10 text-right" style={{ color: barColor(s.rate) }}>
              {s.rate.toFixed(0)}%
            </span>
            <span className="font-mono text-[9px] text-slate-600 w-14 text-right">
              {s.points.toLocaleString()}
            </span>
            <span className={clsx('badge text-[9px] w-10 text-center', {
              'badge-pass': s.status === 'PASS',
              'badge-amber': s.status === 'WARN',
              'badge-coral': s.status === 'FAIL',
            })}>{s.status}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function FDCEngine() {
  const [activeTab, setActiveTab] = useState<'qualification' | 'trace' | 'alarm'>('qualification')
  const [selectedSensor, setSelectedSensor] = useState<string | null>('DAQ275HPPumpCurrentR')
  const [selectedRun, setSelectedRun] = useState<{ run_id: string; equipment_id: string; anomaly: boolean; composite: number } | null>(null)

  const { data: anomalySummary } = useQuery({
    queryKey: ['fdc-anomaly-summary'],
    queryFn: () => fdcApi.anomalySummary(30),
  })
  type AnomalyRow = { equipment_id: string; total_runs: number; anomaly_count: number; anomaly_rate_pct: number; avg_score: number }
  const summary = (anomalySummary?.data?.data as AnomalyRow[] | undefined) || []

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Summary Strip */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Anomaly Rate 30d', value: '3.4%', color: '#F59E0B', icon: '⚡' },
          { label: 'Equipment Monitored', value: '10', color: '#00E5C4', icon: '🏭' },
          { label: 'Sensors Active', value: '73', color: '#8B5CF6', icon: '📡' },
          { label: 'PM Due This Week', value: '2', color: '#EF4444', icon: '🔧' },
        ].map(k => (
          <div key={k.label} className="bg-card border border-white/[0.06] rounded-lg px-4 py-3 flex items-center gap-3">
            <span className="text-xl">{k.icon}</span>
            <div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wider">{k.label}</div>
              <div className="font-display text-xl font-bold" style={{ color: k.color }}>{k.value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="panel">
        <div className="panel-header">
          <div className="flex items-center gap-2">
            <div className="w-0.5 h-3.5 rounded-full bg-amber" />
            <span className="font-display text-[14px] font-semibold">FDC Engine — Trace Anomaly Detection</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-4 pt-3 pb-0 border-b border-white/[0.06]">
          {[
            { id: 'qualification', label: '🔬 Sensor Qualification' },
            { id: 'trace', label: '📡 Trace Run Review' },
            { id: 'alarm', label: '🚨 Alarm Drill-Down' },
          ].map(t => (
            <button key={t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={clsx('px-3 py-2 text-[12px] font-medium rounded-t-md transition-all border-b-2',
                activeTab === t.id ? 'text-teal border-teal bg-teal/[0.08]' : 'text-slate-500 border-transparent hover:text-slate-300'
              )}>{t.label}</button>
          ))}
        </div>

        <div className="p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === 'qualification' && (
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <div className="text-[11px] text-slate-400 mb-3 flex items-center gap-2">
                      Sensor Summary — 73/73 Matches
                      <span className="badge badge-pass">Mean ±6σ · Pass 97.26%</span>
                    </div>
                    <SensorQualificationTable selectedSensor={selectedSensor} onSelect={setSelectedSensor} />
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-400 mb-3">
                      FDC Raw Trace — <span className="font-mono text-teal">{selectedSensor || 'Select a sensor'}</span>
                    </div>
                    {selectedSensor && <TraceOverlayChart sensorAlias={selectedSensor} />}
                  </div>
                </div>
              )}

              {activeTab === 'trace' && (
                <div className="grid grid-cols-3 gap-6">
                  <div className="col-span-2">
                    <TraceRunTable onSelect={setSelectedRun} />
                  </div>
                  <div className="space-y-4">
                    {selectedRun ? (
                      <>
                        <div className="bg-surface border border-white/[0.06] rounded-lg p-4">
                          <div className="text-[11px] text-slate-500 mb-2 uppercase tracking-wider">Anomaly Scores</div>
                          <AnomalyRadar run={{
                            interval: selectedRun.composite * 0.85,
                            pm: selectedRun.composite * 0.7,
                            amplitude: selectedRun.composite * 0.95,
                            shape: selectedRun.composite * 0.6,
                            composite: selectedRun.composite,
                          }} />
                        </div>
                        <div className="bg-surface border border-white/[0.06] rounded-lg p-4 space-y-2 text-[11px]">
                          <div className="text-slate-500 uppercase tracking-wider text-[10px] mb-2">Run Detail</div>
                          {[
                            ['Run ID', selectedRun.run_id],
                            ['Equipment', selectedRun.equipment_id],
                            ['Status', selectedRun.anomaly ? '⚠ ANOMALY' : '✓ Normal'],
                          ].map(([k, v]) => (
                            <div key={String(k)} className="flex justify-between">
                              <span className="text-slate-500">{k}</span>
                              <span className={clsx('font-mono', selectedRun.anomaly && k === 'Status' ? 'text-coral' : 'text-slate-300')}>{v}</span>
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <div className="text-slate-600 text-xs text-center mt-16">Select a run to view anomaly scores</div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'alarm' && (
                <div className="grid grid-cols-2 gap-6">
                  {/* Equipment Alarm Summary */}
                  <div>
                    <div className="text-[11px] text-slate-400 mb-3 uppercase tracking-wider">Equipment Alarm Rate — 30d</div>
                    <table className="data-table">
                      <thead>
                        <tr><th>Equipment</th><th className="text-right">Runs</th><th className="text-right">Alarms</th><th className="text-right">Rate</th><th className="text-right">Avg Score</th></tr>
                      </thead>
                      <tbody>
                        {(summary.length > 0 ? summary : [
                          { equipment_id: 'CVD-01', total_runs: 348, anomaly_count: 15, anomaly_rate_pct: 0.58, avg_score: 0.12 },
                          { equipment_id: 'ETCH-01', total_runs: 500, anomaly_count: 0, anomaly_rate_pct: 0, avg_score: 0.08 },
                          { equipment_id: 'CMP-01', total_runs: 375, anomaly_count: 2, anomaly_rate_pct: 0.07, avg_score: 0.09 },
                        ] as AnomalyRow[]).map(r => (
                          <tr key={r.equipment_id} className="cursor-pointer">
                            <td className="text-teal text-[10px] font-mono">{r.equipment_id}</td>
                            <td className="text-right">{r.total_runs}</td>
                            <td className="text-right">
                              <span className={r.anomaly_count > 0 ? 'text-amber font-bold' : 'text-slate-600'}>{r.anomaly_count}</span>
                            </td>
                            <td className="text-right">
                              <span className={r.anomaly_rate_pct > 1 ? 'cell-fail' : r.anomaly_rate_pct > 0.3 ? 'cell-warn' : 'text-slate-500'}>
                                {r.anomaly_rate_pct.toFixed(2)}%
                              </span>
                            </td>
                            <td className="text-right font-mono text-[10px]">{r.avg_score.toFixed(3)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* FDC Alarm Trend */}
                  <div>
                    <div className="text-[11px] text-slate-400 mb-3 uppercase tracking-wider">Alarm Rate Trend — CVD-01</div>
                    <ResponsiveContainer width="100%" height={160}>
                      <LineChart
                        data={['Jan','Feb','Mar','Apr','May','Jun'].map((m, i) => ({
                          month: m,
                          rate: [0.2, 0.4, 0.3, 0.8, 0.58, 0.42][i],
                        }))}
                        margin={{ top: 4, right: 8, bottom: 0, left: -10 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 9 }} />
                        <YAxis tick={{ fill: '#475569', fontSize: 9 }} tickFormatter={v => `${v}%`} />
                        <Tooltip contentStyle={{ background: '#0F1626', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, fontSize: 11 }}
                          formatter={(v: number) => [`${v.toFixed(2)}%`, 'Alarm Rate']} />
                        <ReferenceLine y={1.0} stroke="rgba(255,79,106,0.4)" strokeDasharray="4 3"
                          label={{ value: 'UCL 1%', fill: '#FF4F6A', fontSize: 8 }} />
                        <Line type="monotone" dataKey="rate" stroke="#F59E0B" strokeWidth={2}
                          dot={{ r: 4, fill: '#F59E0B' }} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
