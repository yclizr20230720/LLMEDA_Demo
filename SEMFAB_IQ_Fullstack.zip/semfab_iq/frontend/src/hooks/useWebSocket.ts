import { useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useFabStore } from '@/store/fabStore';
import { useAuthStore } from '@/store/authStore';

const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:5000';

let socket: Socket | null = null;

export function useWebSocket() {
  const { token } = useAuthStore();
  const { addAlarm } = useFabStore();
  const reconnectTimeout = useRef<ReturnType<typeof setTimeout>>();

  const connect = useCallback(() => {
    if (socket?.connected) return;
    socket = io(WS_URL, {
      auth: { token },
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 30000,
    });

    socket.on('connect', () => {
      socket?.emit('subscribe', { room: 'fab-global' });
    });

    socket.on('alarm.critical', (data) => {
      addAlarm({ id: data.id || Date.now().toString(), severity: 'CRITICAL', message: data.message, equipment_id: data.equipment_id, lot_id: data.lot_id, timestamp: new Date().toISOString(), acknowledged: false });
    });

    socket.on('alarm.major', (data) => {
      addAlarm({ id: data.id || Date.now().toString(), severity: 'MAJOR', message: data.message, equipment_id: data.equipment_id, timestamp: new Date().toISOString(), acknowledged: false });
    });

    socket.on('disconnect', () => {
      reconnectTimeout.current = setTimeout(connect, 5000);
    });
  }, [token, addAlarm]);

  useEffect(() => {
    if (token) connect();
    return () => {
      clearTimeout(reconnectTimeout.current);
      socket?.disconnect();
    };
  }, [token, connect]);

  return { socket, isConnected: socket?.connected ?? false };
}
