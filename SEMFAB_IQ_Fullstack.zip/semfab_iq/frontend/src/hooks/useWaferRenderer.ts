import { useEffect, useRef, useCallback } from 'react';

interface DieData {
  die_x: number;
  die_y: number;
  hard_bin: number;
  is_pass: boolean;
}

interface BinColorMap {
  [binCode: number]: [number, number, number]; // [R, G, B]
}

const DEFAULT_BIN_COLORS: BinColorMap = {
  1: [16, 185, 129],   // pass - green
  8: [56, 189, 248],   // fail bin 8 - sky
  14: [139, 92, 246],  // fail bin 14 - violet
  9: [245, 158, 11],   // fail bin 9 - amber
  12: [255, 79, 106],  // fail bin 12 - coral
  0: [71, 85, 105],    // untested - slate
};

export function useWaferRenderer(
  canvasRef: React.RefObject<HTMLCanvasElement>,
  xs: number[],
  ys: number[],
  bins: number[],
  passes: boolean[],
  binColorMap: BinColorMap = DEFAULT_BIN_COLORS
) {
  const lastRenderTime = useRef<number>(0);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !xs.length) return;

    const t0 = performance.now();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;

    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const rangeX = maxX - minX || 1;
    const rangeY = maxY - minY || 1;

    const dieW = W / (rangeX + 2);
    const dieH = H / (rangeY + 2);
    const dieSize = Math.min(dieW, dieH);

    ctx.clearRect(0, 0, W, H);

    // Wafer circle clip
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(cx, cy) - 4, 0, Math.PI * 2);
    ctx.clip();

    // Build and draw via ImageData for max performance
    const imageData = ctx.createImageData(W, H);
    const data = imageData.data;

    const n = xs.length;
    for (let i = 0; i < n; i++) {
      const px = Math.round((xs[i] - minX + 0.5) * dieSize + (W - (rangeX + 1) * dieSize) / 2);
      const py = Math.round((ys[i] - minY + 0.5) * dieSize + (H - (rangeY + 1) * dieSize) / 2);
      const bin = bins[i];
      const color = binColorMap[bin] || (passes[i] ? [16, 185, 129] : [239, 68, 68]);

      // Fill die pixels
      const ds = Math.max(1, Math.floor(dieSize) - 1);
      for (let dy = 0; dy < ds; dy++) {
        for (let dx = 0; dx < ds; dx++) {
          const pixX = px + dx;
          const pixY = py + dy;
          if (pixX >= 0 && pixX < W && pixY >= 0 && pixY < H) {
            const idx = (pixY * W + pixX) * 4;
            data[idx] = color[0];
            data[idx + 1] = color[1];
            data[idx + 2] = color[2];
            data[idx + 3] = 220;
          }
        }
      }
    }

    ctx.putImageData(imageData, 0, 0);
    ctx.restore();

    // Wafer border
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(cx, cy) - 4, 0, Math.PI * 2);
    ctx.stroke();

    lastRenderTime.current = performance.now() - t0;
  }, [xs, ys, bins, passes, binColorMap, canvasRef]);

  useEffect(() => {
    render();
  }, [render]);

  return { render, lastRenderTimeMs: lastRenderTime.current };
}
