# SEMFAB·IQ — Engineering Data Analytics Platform

> Full-stack semiconductor FAB analytics: React + Vite frontend, Python Flask backend, PostgreSQL (Greenplum-compatible) DataMart

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+ (for local frontend dev)
- Python 3.11+ (for local backend dev)

### 1. Start with Docker Compose

```bash
docker-compose up -d
```

Services:
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **PostgreSQL**: localhost:5432
- **Redis**: localhost:6379

### 2. Seed Demo Data

```bash
docker exec semfab_backend flask init-db
docker exec semfab_backend flask seed-db
```

### 3. Login

| User | Password | Role |
|------|----------|------|
| pe_engineer | Engineer@123 | Process Engineer |
| ee_engineer | Engineer@123 | Equipment Engineer |
| manager | Manager@123 | Manager |
| admin | Admin@12345 | System Admin |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│  React + Vite Frontend (Port 5173)                   │
│  Tailwind CSS · Recharts · Framer Motion            │
│  Zustand State · TanStack Query · Socket.IO         │
└────────────────────┬────────────────────────────────┘
                     │ REST + WebSocket
┌────────────────────▼────────────────────────────────┐
│  Python Flask API (Port 5000)                        │
│  JWT Auth · Flask-Limiter · Flask-Caching           │
│  SQLAlchemy ORM · Flask-Migrate · SocketIO          │
└──────────┬──────────────────────────┬───────────────┘
           │                          │
┌──────────▼───────┐      ┌──────────▼────────┐
│  PostgreSQL       │      │  Redis Cache       │
│  (Greenplum DW)  │      │  (512MB LRU)       │
│  Port 5432        │      │  Port 6379         │
└───────────────────┘      └────────────────────┘
```

## 📁 Project Structure

```
semfab_iq/
├── frontend/                   # React + Vite application
│   ├── src/
│   │   ├── api/               # Axios client + API endpoints
│   │   ├── components/        # Reusable UI components
│   │   │   ├── layout/        # AppShell, Sidebar, TopBar
│   │   │   ├── charts/        # SPC, FDC, Yield charts
│   │   │   └── wafer/         # Canvas wafer renderers
│   │   ├── hooks/             # useWebSocket, useWaferRenderer
│   │   ├── pages/             # Module pages
│   │   │   ├── yms/           # Yield Management System
│   │   │   ├── wat/           # WAT Analytics Workbench
│   │   │   ├── cp/            # CP Bin Map & MRB
│   │   │   ├── spc/           # SPC Monitor (8 WE Rules)
│   │   │   └── fdc/           # FDC Engine
│   │   ├── store/             # Zustand state (auth, fab, ui)
│   │   └── types/             # TypeScript domain types
│   └── tailwind.config.js
│
├── backend/                    # Flask microservice API
│   ├── app/
│   │   ├── models/            # SQLAlchemy ORM models
│   │   ├── routes/            # Blueprint route handlers
│   │   ├── services/          # Business logic
│   │   │   ├── spc_engine.py  # All 8 Western Electric rules
│   │   │   └── data_generator.py  # Demo data seeding
│   │   ├── middleware/        # Request ID, Audit logging
│   │   └── utils/             # Response envelope, errors
│   ├── config/settings.py
│   └── run.py
│
├── infra/
│   └── db/migrations/001_init.sql  # PostgreSQL DDL
│
└── docker-compose.yml
```

## 🔌 API Endpoints

| Module | Endpoint | Description |
|--------|----------|-------------|
| Auth | `POST /api/v1/auth/login` | JWT login |
| Auth | `POST /api/v1/auth/refresh` | Token refresh |
| Yield | `GET /api/v1/yield/trend` | Lot yield trend |
| Yield | `GET /api/v1/yield/excursions` | Active excursions |
| WAT | `GET /api/v1/wat/distribution` | Parameter distribution |
| WAT | `GET /api/v1/wat/correlation-matrix` | Pearson correlation |
| WAT | `GET /api/v1/wat/trend` | Parameter trend |
| CP | `GET /api/v1/cp/bin-map` | Die bin map (columnar) |
| CP | `GET /api/v1/cp/mrb-review` | MRB wafers |
| SPC | `GET /api/v1/spc/chart` | SPC chart data |
| SPC | `POST /api/v1/spc/check-rules` | Run WE rules on data |
| SPC | `GET /api/v1/spc/capability` | Cp/Cpk computation |
| FDC | `GET /api/v1/fdc/trace-runs` | FDC trace runs |
| FDC | `GET /api/v1/fdc/anomaly-summary` | Equipment anomaly rates |
| Equipment | `GET /api/v1/equipment/` | Equipment list + health |

## 🎨 Design System

- **Font**: Space Grotesk (display) + Inter (body) + JetBrains Mono (data)
- **Colors**: Teal `#00E5C4` · Violet `#8B5CF6` · Amber `#F59E0B` · Coral `#FF4F6A`
- **Theme**: Dark Industrial Glassmorphism · `#060A12` void background
- **Components**: Panel, KPI Card, Data Table, Badge, Cell Pills

## ⚙️ Configuration

Copy `.env.example` to `.env` and adjust:

```env
DATABASE_URL=postgresql://semfab:semfab_secret_2025@localhost:5432/semfab_dw
REDIS_URL=redis://localhost:6379/0
JWT_SECRET_KEY=change-in-production
CORS_ORIGINS=http://localhost:5173
```

---

*SEMFAB·IQ v1.0 · FAB-12 · N5 Node · Built with 💚 for semiconductor engineers*
