-- SEMFAB·IQ PostgreSQL Schema
-- Run: psql -U semfab -d semfab_dw -f 001_init.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Auth
CREATE TABLE IF NOT EXISTS auth_users (
    user_sk BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    email VARCHAR(128) NOT NULL UNIQUE,
    password_hash VARCHAR(256) NOT NULL,
    full_name VARCHAR(128),
    role VARCHAR(32) NOT NULL DEFAULT 'PROCESS_ENGINEER',
    fab_id VARCHAR(16) DEFAULT 'FAB-12',
    is_active BOOLEAN DEFAULT TRUE,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    mfa_secret VARCHAR(64),
    last_login TIMESTAMPTZ,
    login_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Lot
CREATE TABLE IF NOT EXISTS mes_dim_lot (
    lot_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    lot_type VARCHAR(20) NOT NULL DEFAULT 'PRODUCTION',
    lot_subtype VARCHAR(20),
    lot_priority SMALLINT DEFAULT 5,
    is_split_lot BOOLEAN DEFAULT FALSE,
    parent_lot_id VARCHAR(32),
    product_id VARCHAR(32) NOT NULL,
    device_family VARCHAR(32),
    customer_id VARCHAR(32),
    customer_order_id VARCHAR(64),
    process_node VARCHAR(16),
    technology_id VARCHAR(32),
    mask_set_id VARCHAR(32),
    lot_status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    hold_code VARCHAR(16),
    hold_reason TEXT,
    wafer_count_start SMALLINT,
    wafer_count_current SMALLINT,
    wafer_size_mm SMALLINT DEFAULT 300,
    lot_start_date TIMESTAMPTZ,
    lot_target_date TIMESTAMPTZ,
    lot_complete_date TIMESTAMPTZ,
    lot_ship_date TIMESTAMPTZ,
    target_yield_pct NUMERIC(6,3),
    syl_pct NUMERIC(6,3),
    sbl_pct NUMERIC(6,3),
    effective_from TIMESTAMPTZ DEFAULT NOW(),
    effective_to TIMESTAMPTZ,
    is_current BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    source_system VARCHAR(32)
);
CREATE INDEX IF NOT EXISTS idx_mes_lot_id ON mes_dim_lot(lot_id) WHERE is_current=TRUE;
CREATE INDEX IF NOT EXISTS idx_mes_lot_product ON mes_dim_lot(product_id, process_node);

-- Wafer
CREATE TABLE IF NOT EXISTS mes_dim_wafer (
    wafer_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    slot_number SMALLINT NOT NULL,
    wafer_status VARCHAR(20) DEFAULT 'ACTIVE',
    die_per_wafer INTEGER,
    die_count_good INTEGER,
    cp_yield_pct NUMERIC(6,3),
    final_disposition VARCHAR(24),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(lot_id, slot_number)
);

-- Equipment
CREATE TABLE IF NOT EXISTS eqp_dim_equipment (
    equipment_sk BIGSERIAL PRIMARY KEY,
    equipment_id VARCHAR(32) NOT NULL UNIQUE,
    equipment_name VARCHAR(128),
    equipment_type VARCHAR(32) NOT NULL,
    equipment_subtype VARCHAR(32),
    oem_vendor VARCHAR(32),
    oem_model VARCHAR(64),
    fab_id VARCHAR(16),
    bay_id VARCHAR(16),
    area_id VARCHAR(32),
    chamber_count SMALLINT DEFAULT 1,
    is_multi_chamber BOOLEAN DEFAULT FALSE,
    equipment_status VARCHAR(24) DEFAULT 'PRODUCTION',
    is_golden_tool BOOLEAN DEFAULT FALSE,
    health_score NUMERIC(5,2) DEFAULT 100.0,
    health_tier VARCHAR(16) DEFAULT 'HEALTHY',
    health_updated_at TIMESTAMPTZ,
    z_score_component NUMERIC(5,3),
    gof_component NUMERIC(5,3),
    cv_stability_component NUMERIC(5,3),
    volume_component NUMERIC(5,3),
    last_pm_date DATE,
    next_pm_date DATE,
    pm_interval_days INTEGER,
    is_current BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chamber
CREATE TABLE IF NOT EXISTS eqp_dim_chamber (
    chamber_sk BIGSERIAL PRIMARY KEY,
    equipment_id VARCHAR(32) NOT NULL,
    chamber_id VARCHAR(16) NOT NULL,
    chamber_name VARCHAR(64),
    chamber_type VARCHAR(32),
    chamber_status VARCHAR(24),
    health_score NUMERIC(5,2),
    last_pm_date DATE,
    run_since_pm INTEGER DEFAULT 0,
    is_reference_chamber BOOLEAN DEFAULT FALSE,
    UNIQUE(equipment_id, chamber_id)
);

-- WAT Result
CREATE TABLE IF NOT EXISTS wat_fact_result (
    result_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    slot_number SMALLINT,
    site_id SMALLINT NOT NULL,
    site_x NUMERIC(8,4),
    site_y NUMERIC(8,4),
    site_zone VARCHAR(8),
    parameter_id VARCHAR(64) NOT NULL,
    parameter_group VARCHAR(32),
    vcc NUMERIC(8,4),
    temp_c NUMERIC(8,3),
    freq_hz NUMERIC(16,4),
    measured_value NUMERIC(20,10) NOT NULL,
    usl NUMERIC(20,10),
    lsl NUMERIC(20,10),
    target_value NUMERIC(20,10),
    pass_fail CHAR(1),
    sigma_deviation NUMERIC(10,6),
    equipment_id VARCHAR(32),
    chamber_id VARCHAR(16),
    recipe_id VARCHAR(64),
    process_node VARCHAR(16),
    product_id VARCHAR(32),
    is_outlier_mad BOOLEAN DEFAULT FALSE,
    is_outlier_grubbs BOOLEAN DEFAULT FALSE,
    anomaly_score NUMERIC(6,4),
    test_time TIMESTAMPTZ NOT NULL,
    event_date DATE NOT NULL,
    lot_sequence INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wat_result_param ON wat_fact_result(parameter_id, event_date);
CREATE INDEX IF NOT EXISTS idx_wat_result_lot ON wat_fact_result(lot_id, wafer_id, site_id);

-- WAT Lot Summary
CREATE TABLE IF NOT EXISTS wat_agg_lot_summary (
    summary_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    parameter_id VARCHAR(64) NOT NULL,
    vcc NUMERIC(8,4),
    temp_c NUMERIC(8,3),
    product_id VARCHAR(32),
    equipment_id VARCHAR(32),
    event_date DATE NOT NULL,
    n_sites SMALLINT,
    mean_value NUMERIC(20,10),
    median_value NUMERIC(20,10),
    std_dev NUMERIC(20,10),
    min_value NUMERIC(20,10),
    max_value NUMERIC(20,10),
    p5_value NUMERIC(20,10),
    p25_value NUMERIC(20,10),
    p75_value NUMERIC(20,10),
    p95_value NUMERIC(20,10),
    skewness NUMERIC(10,6),
    kurtosis NUMERIC(10,6),
    usl NUMERIC(20,10),
    lsl NUMERIC(20,10),
    cp NUMERIC(10,6),
    cpk NUMERIC(10,6),
    cpm NUMERIC(10,6),
    pp NUMERIC(10,6),
    ppk NUMERIC(10,6),
    shapiro_wilk_p NUMERIC(10,8),
    is_normal_dist BOOLEAN,
    n_pass SMALLINT,
    n_fail SMALLINT,
    pass_rate_pct NUMERIC(6,3),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(lot_id, wafer_id, parameter_id, vcc, temp_c)
);

-- CP Die Result
CREATE TABLE IF NOT EXISTS cp_fact_die_result (
    die_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    slot_number SMALLINT,
    die_x SMALLINT NOT NULL,
    die_y SMALLINT NOT NULL,
    die_index INTEGER,
    program_id VARCHAR(64) NOT NULL,
    tester_id VARCHAR(32),
    hard_bin SMALLINT NOT NULL,
    soft_bin SMALLINT,
    is_pass BOOLEAN NOT NULL,
    test_count SMALLINT DEFAULT 1,
    touchdown_number SMALLINT,
    was_tested BOOLEAN DEFAULT TRUE,
    skip_reason VARCHAR(24),
    is_edge_die BOOLEAN DEFAULT FALSE,
    is_spatial_cluster BOOLEAN DEFAULT FALSE,
    cluster_id INTEGER,
    test_time TIMESTAMPTZ NOT NULL,
    event_date DATE NOT NULL,
    product_id VARCHAR(32),
    process_node VARCHAR(16),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cp_die_lot ON cp_fact_die_result(lot_id, wafer_id);
CREATE INDEX IF NOT EXISTS idx_cp_die_bin ON cp_fact_die_result(hard_bin, event_date);

-- CP Wafer Summary
CREATE TABLE IF NOT EXISTS cp_fact_wafer_summary (
    summary_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    slot_number SMALLINT,
    program_id VARCHAR(64),
    tester_id VARCHAR(32),
    step_id VARCHAR(32),
    total_die INTEGER,
    pass_die INTEGER,
    fail_die INTEGER,
    gross_yield_pct NUMERIC(7,4),
    net_yield_pct NUMERIC(7,4),
    first_pass_yield NUMERIC(7,4),
    retest_count INTEGER DEFAULT 0,
    offline_retest_rate NUMERIC(7,4),
    bin_counts_json TEXT,
    site_yields_json TEXT,
    pattern_class_generic VARCHAR(32),
    pattern_class_primary VARCHAR(32),
    pattern_class_secondary VARCHAR(32),
    pattern_confidence NUMERIC(6,4),
    edge_yield_pct NUMERIC(7,4),
    center_yield_pct NUMERIC(7,4),
    edge_center_delta NUMERIC(7,4),
    is_partial_wafer BOOLEAN DEFAULT FALSE,
    syl_flag BOOLEAN DEFAULT FALSE,
    sbl_flag BOOLEAN DEFAULT FALSE,
    mrb_required BOOLEAN DEFAULT FALSE,
    mrb_result VARCHAR(16),
    event_date DATE NOT NULL,
    test_time TIMESTAMPTZ,
    product_id VARCHAR(32),
    process_node VARCHAR(16),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cp_ws_lot ON cp_fact_wafer_summary(lot_id, event_date);

-- SPC Config
CREATE TABLE IF NOT EXISTS spc_dim_parameter_config (
    config_sk BIGSERIAL PRIMARY KEY,
    config_id VARCHAR(64) NOT NULL UNIQUE,
    parameter_id VARCHAR(64) NOT NULL,
    parameter_source VARCHAR(20) NOT NULL DEFAULT 'WAT',
    product_id VARCHAR(32),
    technology_id VARCHAR(32),
    equipment_id VARCHAR(32),
    chamber_id VARCHAR(16),
    recipe_id VARCHAR(64),
    step_id VARCHAR(32),
    chart_type VARCHAR(16) NOT NULL DEFAULT 'IMR',
    subgroup_size SMALLINT DEFAULT 1,
    ucl NUMERIC(20,10),
    cl NUMERIC(20,10),
    lcl NUMERIC(20,10),
    ucl_2sigma NUMERIC(20,10),
    lcl_2sigma NUMERIC(20,10),
    ucl_1sigma NUMERIC(20,10),
    lcl_1sigma NUMERIC(20,10),
    sigma_estimate NUMERIC(20,10),
    usl NUMERIC(20,10),
    lsl NUMERIC(20,10),
    target NUMERIC(20,10),
    enabled_rules SMALLINT DEFAULT 255,
    alarm_mode VARCHAR(16) DEFAULT 'EMAIL',
    alarm_severity VARCHAR(16) DEFAULT 'MAJOR',
    is_virtual BOOLEAN DEFAULT FALSE,
    vm_model_id VARCHAR(64),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- SPC Measurement
CREATE TABLE IF NOT EXISTS spc_fact_measurement (
    measurement_sk BIGSERIAL PRIMARY KEY,
    config_id VARCHAR(64) NOT NULL,
    parameter_id VARCHAR(64) NOT NULL,
    lot_id VARCHAR(32),
    wafer_id VARCHAR(40),
    equipment_id VARCHAR(32),
    chamber_id VARCHAR(16),
    subgroup_index INTEGER,
    measured_value NUMERIC(20,10) NOT NULL,
    subgroup_mean NUMERIC(20,10),
    subgroup_range NUMERIC(20,10),
    subgroup_std NUMERIC(20,10),
    moving_range NUMERIC(20,10),
    ucl_at_time NUMERIC(20,10),
    cl_at_time NUMERIC(20,10),
    lcl_at_time NUMERIC(20,10),
    sigma_score NUMERIC(10,6),
    violation_rule_1 BOOLEAN DEFAULT FALSE,
    violation_rule_2 BOOLEAN DEFAULT FALSE,
    violation_rule_3 BOOLEAN DEFAULT FALSE,
    violation_rule_4 BOOLEAN DEFAULT FALSE,
    violation_rule_5 BOOLEAN DEFAULT FALSE,
    violation_rule_6 BOOLEAN DEFAULT FALSE,
    violation_rule_7 BOOLEAN DEFAULT FALSE,
    violation_rule_8 BOOLEAN DEFAULT FALSE,
    any_violation BOOLEAN DEFAULT FALSE,
    violation_rules_list VARCHAR(32),
    alarm_triggered BOOLEAN DEFAULT FALSE,
    alarm_severity VARCHAR(16),
    is_virtual BOOLEAN DEFAULT FALSE,
    vm_predicted_value NUMERIC(20,10),
    vm_ci_lower NUMERIC(20,10),
    vm_ci_upper NUMERIC(20,10),
    measurement_time TIMESTAMPTZ NOT NULL,
    event_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_spc_meas_config ON spc_fact_measurement(config_id, event_date);

-- SPC Violation
CREATE TABLE IF NOT EXISTS spc_fact_violation (
    violation_sk BIGSERIAL PRIMARY KEY,
    config_id VARCHAR(64) NOT NULL,
    parameter_id VARCHAR(64) NOT NULL,
    equipment_id VARCHAR(32),
    chamber_id VARCHAR(16),
    rule_number SMALLINT NOT NULL,
    rule_description VARCHAR(256),
    rule_severity VARCHAR(16),
    trigger_value NUMERIC(20,10),
    trigger_lot_id VARCHAR(32),
    sigma_deviation NUMERIC(10,6),
    acknowledged_by VARCHAR(64),
    acknowledged_at TIMESTAMPTZ,
    resolution_code VARCHAR(32),
    resolution_note TEXT,
    violation_time TIMESTAMPTZ NOT NULL,
    event_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- FDC Trace Run
CREATE TABLE IF NOT EXISTS fdc_fact_trace_run (
    run_sk BIGSERIAL PRIMARY KEY,
    run_id VARCHAR(64) NOT NULL UNIQUE,
    lot_id VARCHAR(32),
    wafer_id VARCHAR(40),
    equipment_id VARCHAR(32) NOT NULL,
    chamber_id VARCHAR(16),
    recipe_id VARCHAR(64),
    step_id VARCHAR(32),
    product_id VARCHAR(32),
    process_node VARCHAR(16),
    run_start_time TIMESTAMPTZ NOT NULL,
    run_end_time TIMESTAMPTZ,
    run_duration_sec NUMERIC(12,4),
    run_result VARCHAR(16) DEFAULT 'PASS',
    alarm_count SMALLINT DEFAULT 0,
    alarm_sensor_list TEXT,
    interval_anomaly_score NUMERIC(8,6),
    pm_anomaly_score NUMERIC(8,6),
    amplitude_anomaly_score NUMERIC(8,6),
    shape_anomaly_score NUMERIC(8,6),
    composite_anomaly_score NUMERIC(8,6),
    anomaly_class VARCHAR(32),
    is_anomaly BOOLEAN DEFAULT FALSE,
    is_post_pm BOOLEAN DEFAULT FALSE,
    pm_wafer_count INTEGER,
    is_qualification_run BOOLEAN DEFAULT FALSE,
    baseline_run_id VARCHAR(64),
    qual_match_score NUMERIC(8,6),
    event_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_fdc_run_equip ON fdc_fact_trace_run(equipment_id, event_date);

-- FDC PM Event
CREATE TABLE IF NOT EXISTS fdc_fact_pm_event (
    pm_sk BIGSERIAL PRIMARY KEY,
    equipment_id VARCHAR(32) NOT NULL,
    chamber_id VARCHAR(16),
    pm_type VARCHAR(32),
    pm_subtype VARCHAR(32),
    pm_code VARCHAR(16),
    pm_start_time TIMESTAMPTZ NOT NULL,
    pm_end_time TIMESTAMPTZ,
    pm_duration_hr NUMERIC(8,3),
    trigger_source VARCHAR(24),
    trigger_health_score NUMERIC(5,2),
    performed_by VARCHAR(64),
    pre_pm_health_score NUMERIC(5,2),
    post_pm_health_score NUMERIC(5,2),
    health_improvement NUMERIC(5,2),
    qualification_passed BOOLEAN,
    qual_run_id VARCHAR(64),
    wafers_impacted INTEGER DEFAULT 0,
    cmms_work_order_id VARCHAR(32),
    event_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Defect
CREATE TABLE IF NOT EXISTS def_fact_defect (
    defect_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    slot_number SMALLINT,
    inspection_tool_id VARCHAR(32) NOT NULL,
    inspection_layer VARCHAR(32),
    inspection_step_id VARCHAR(32),
    defect_x_um NUMERIC(12,4),
    defect_y_um NUMERIC(12,4),
    die_x SMALLINT,
    die_y SMALLINT,
    defect_size_nm NUMERIC(12,4),
    adc_class VARCHAR(32),
    adc_confidence NUMERIC(6,4),
    is_adc_auto BOOLEAN DEFAULT FALSE,
    final_class VARCHAR(32),
    class_category VARCHAR(32),
    is_killer BOOLEAN,
    kill_probability NUMERIC(8,6),
    sem_reviewed BOOLEAN DEFAULT FALSE,
    sem_image_path VARCHAR(256),
    is_nuisance BOOLEAN DEFAULT FALSE,
    inspection_time TIMESTAMPTZ NOT NULL,
    event_date DATE NOT NULL,
    product_id VARCHAR(32),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS def_fact_wafer_defect_summary (
    def_summary_sk BIGSERIAL PRIMARY KEY,
    lot_id VARCHAR(32) NOT NULL,
    wafer_id VARCHAR(40) NOT NULL,
    inspection_tool_id VARCHAR(32),
    inspection_step_id VARCHAR(32),
    inspection_layer VARCHAR(32),
    total_defects INTEGER DEFAULT 0,
    killer_defects INTEGER DEFAULT 0,
    nuisance_defects INTEGER DEFAULT 0,
    inspection_area_cm2 NUMERIC(12,6),
    defect_density_cm2 NUMERIC(14,8),
    killer_density_cm2 NUMERIC(14,8),
    class_counts_json TEXT,
    pattern_class VARCHAR(32),
    pattern_confidence NUMERIC(6,4),
    suspected_step_id VARCHAR(32),
    suspected_equipment_id VARCHAR(32),
    predicted_yield_loss_pct NUMERIC(7,4),
    inspection_time TIMESTAMPTZ,
    event_date DATE NOT NULL
);

COMMENT ON TABLE mes_dim_lot IS 'MES Lot Master - SCD Type 2';
COMMENT ON TABLE eqp_dim_equipment IS 'Equipment Master with composite health scoring';
COMMENT ON TABLE spc_fact_measurement IS 'SPC measurements - 8 WE rules as individual boolean columns';
COMMENT ON TABLE fdc_fact_trace_run IS 'FDC trace run with 4 anomaly score types + composite';
