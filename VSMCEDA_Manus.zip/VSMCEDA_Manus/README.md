# SEMFAB·IQ — Semiconductor Engineering Data Analytics Platform

> **Version:** 2.0.0 | **Architecture:** Full-Stack Microservice | **Database:** GreenPlum/PostgreSQL

A production-grade, AI-powered semiconductor wafer manufacturing yield management and engineering data analytics platform, modeled after Semitronix DataExp and benchmarked against TSMC's IMC (Intelligent Manufacturing Center).

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    SEMFAB·IQ Platform                       │
├──────────────┬──────────────────┬───────────────────────────┤
│   Frontend   │     Backend      │        Database           │
│  React+Vite  │  Python Flask    │  PostgreSQL (GreenPlum)   │
│  TypeScript  │  Microservices   │  Redis Cache              │
│  TailwindCSS │  JWT Auth        │  12 DataMart Domains      │
│  Recharts    │  SSE Streaming   │  60+ Tables               │
│  Zustand     │  SPC/FDC/WAT     │  20+ Analytical Views     │
└──────────────┴──────────────────┴───────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+ (for local frontend dev)
- Python 3.11+ (for local backend dev)

### 1. Clone & Start with Docker

```bash
git clone <repo>
cd semfab-iq-fullstack
docker-compose up -d
```

Access:
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000/api
- **API Health:** http://localhost:5000/api/health

### 2. Local Development

**Backend:**
```bash
cd backend
pip install -r requirements.txt
export DATABASE_URL=postgresql://semfab_admin:semfab_secure_2025@localhost:5432/semfab_iq
export REDIS_URL=redis://:semfab_redis_2025@localhost:6379/0
export JWT_SECRET_KEY=dev-secret-key
python run.py
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## 🔐 Default Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | Admin@2025 | ADMIN |
| chen_wei | Admin@2025 | SENIOR_ENGINEER |
| li_ming | Admin@2025 | PROCESS_ENGINEER |
| wang_fang | Admin@2025 | PROCESS_ENGINEER |
| fab_op1 | Admin@2025 | FAB_OPERATOR |

## 📊 Platform Modules

| Module | Description | API Endpoint |
|--------|-------------|--------------|
| YMS Dashboard | 6-KPI strip, yield trend, SYL/SBL, Score Card, MRB | `/api/dashboard/*` |
| WAT Analytics | Distribution, ANOVA, Correlation, Trend, Site Map | `/api/wat/*` |
| SPC Monitor | Xbar-R charts, Western Electric rules, Cpk | `/api/spc/*` |
| FDC Engine | Trace analysis, anomaly detection, PM events | `/api/fdc/*` |
| Defect DMS | Pareto, wafer map, ADC gallery, WPA patterns | `/api/defect/*` |
| Equipment Fleet | Health scores, utilization, PM schedule | `/api/equipment/*` |
| SemiMind++ AI | SSE streaming LLM, robot actions, RCA knowledge | `/api/agent/*` |
| Advanced Analytics | MSC R&R, DPPM, Process Timeline, Smart Sampling | `/api/advanced/*` |

## 🗄️ Database Schema

The system uses **12 DataMart Domains** with 60+ tables:

| Domain | Key Tables | Purpose |
|--------|-----------|---------|
| MES | mes_dim_lot, mes_fact_lot_operation | WIP tracking, cycle time |
| WAT | wat_fact_result, wat_agg_lot_summary | Parametric test analysis |
| CP | cp_fact_die_result, cp_fact_wafer_summary | Die-level test, bin analysis |
| SPC | spc_fact_measurement, spc_fact_violation | Statistical process control |
| FDC | fdc_fact_trace_run, fdc_fact_trace_data | Fault detection |
| DEF | def_fact_defect, def_fact_wafer_defect_summary | Defect management |
| YLD | yld_fact_excursion, yld_fact_rca_knowledge | Yield intelligence |
| AGT | agt_fact_session, agt_fact_robot_action | AI agent audit |

## 🤖 AI Configuration

Set `LLM_API_KEY` environment variable for real LLM responses:

```bash
export LLM_API_KEY=your-openai-api-key
export LLM_MODEL=gpt-4o  # or gpt-4-turbo, claude-3-opus, etc.
```

Without an API key, the system uses intelligent demo responses.

## 🏭 RBAC Roles

| Role | Permissions |
|------|-------------|
| FAB_OPERATOR | Read-only dashboards |
| PROCESS_ENGINEER | Full analytics, alarm ACK |
| SENIOR_ENGINEER | Approve agent actions |
| MANAGER | All modules + reports |
| ADMIN | Full system access |

## 📡 API Reference

All endpoints return JSON. Authentication via JWT Bearer token.

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"Admin@2025"}'

# Use token
curl http://localhost:5000/api/dashboard/kpis \
  -H "Authorization: Bearer <token>"
```

## 🔧 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| DATABASE_URL | postgresql://... | PostgreSQL connection string |
| REDIS_URL | redis://... | Redis connection string |
| JWT_SECRET_KEY | — | JWT signing secret |
| LLM_API_KEY | — | OpenAI/LLM API key |
| LLM_API_URL | https://api.openai.com/v1 | LLM API base URL |
| LLM_MODEL | gpt-4o | LLM model name |
| FLASK_ENV | development | Flask environment |

---

*SEMFAB·IQ v2.0 — Built for semiconductor excellence*
