-- ============================================================
-- SEMFAB·IQ — Seed Data for Development & Demo
-- ============================================================

-- Default admin user (password: Admin@2025)
INSERT INTO users (username, email, password_hash, full_name, role, department) VALUES
('admin', 'admin@semfab.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Vc0LNqM8K7hM3Jm9YBXO', 'System Admin', 'ADMIN', 'IT'),
('chen_wei', 'chen.wei@semfab.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Vc0LNqM8K7hM3Jm9YBXO', 'Chen Wei', 'SENIOR_ENGINEER', 'Process Integration'),
('li_ming', 'li.ming@semfab.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Vc0LNqM8K7hM3Jm9YBXO', 'Li Ming', 'PROCESS_ENGINEER', 'ETCH'),
('wang_fang', 'wang.fang@semfab.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Vc0LNqM8K7hM3Jm9YBXO', 'Wang Fang', 'PROCESS_ENGINEER', 'CMP'),
('fab_op1', 'fab.op1@semfab.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniYE6Vc0LNqM8K7hM3Jm9YBXO', 'FAB Operator 1', 'FAB_OPERATOR', 'Operations');

-- Equipment
INSERT INTO eqp_dim_equipment (equipment_id, equipment_name, equipment_type, equipment_subtype, oem_vendor, oem_model, bay_id, area_id, health_score, health_tier, utilization_pct, throughput_wph, alarm_count_24h, last_pm_date, next_pm_date) VALUES
('ETCH-01', 'Lam Kiyo Etch #1', 'ETCH', 'PLASMA_ETCH', 'LAM', 'Kiyo-G', 'BAY-01', 'ETCH', 92.5, 'HEALTHY', 87.3, 45.2, 0, '2025-05-15', '2025-08-13'),
('ETCH-02', 'Lam Kiyo Etch #2', 'ETCH', 'PLASMA_ETCH', 'LAM', 'Kiyo-G', 'BAY-01', 'ETCH', 78.2, 'WATCH', 72.1, 41.8, 2, '2025-04-20', '2025-07-19'),
('ETCH-03', 'AMAT Centris Etch', 'ETCH', 'PLASMA_ETCH', 'AMAT', 'Centris', 'BAY-01', 'ETCH', 55.4, 'DEGRADED', 61.5, 38.5, 5, '2025-03-10', '2025-06-08'),
('CVD-01', 'AMAT Centura CVD #1', 'CVD', 'PECVD', 'AMAT', 'Centura', 'BAY-02', 'CVD', 95.1, 'HEALTHY', 91.2, 52.0, 0, '2025-06-01', '2025-08-30'),
('CVD-02', 'AMAT Centura CVD #2', 'CVD', 'PECVD', 'AMAT', 'Centura', 'BAY-02', 'CVD', 88.7, 'HEALTHY', 84.6, 49.3, 1, '2025-05-20', '2025-08-18'),
('CVD-03', 'TEL Trias CVD', 'CVD', 'LPCVD', 'TEL', 'Trias', 'BAY-02', 'CVD', 42.3, 'CRITICAL', 45.8, 28.1, 8, '2025-02-14', '2025-05-15'),
('CMP-01', 'AMAT Reflexion CMP #1', 'CMP', 'OXIDE_CMP', 'AMAT', 'Reflexion', 'BAY-03', 'CMP', 89.4, 'HEALTHY', 82.5, 38.7, 1, '2025-05-28', '2025-08-26'),
('CMP-02', 'AMAT Reflexion CMP #2', 'CMP', 'METAL_CMP', 'AMAT', 'Reflexion', 'BAY-03', 'CMP', 67.8, 'WATCH', 68.9, 34.2, 3, '2025-04-15', '2025-07-14'),
('CMP-03', 'Ebara FREX CMP', 'CMP', 'OXIDE_CMP', 'EBARA', 'FREX', 'BAY-03', 'CMP', 71.2, 'WATCH', 74.3, 36.1, 2, '2025-05-05', '2025-08-03'),
('LITHO-01', 'ASML NXT:2050i', 'LITHO', 'DUV', 'ASML', 'NXT:2050i', 'BAY-04', 'LITHO', 97.8, 'HEALTHY', 94.5, 120.0, 0, '2025-06-10', '2025-09-08'),
('LITHO-02', 'ASML EUV NXE:3600D', 'LITHO', 'EUV', 'ASML', 'NXE:3600D', 'BAY-04', 'LITHO', 93.2, 'HEALTHY', 88.7, 95.0, 0, '2025-06-05', '2025-09-03'),
('WAT-01', 'Keysight B1500A WAT #1', 'WAT', 'PARAMETRIC', 'KEYSIGHT', 'B1500A', 'BAY-05', 'WAT', 99.1, 'HEALTHY', 76.3, 18.5, 0, '2025-06-15', '2025-09-13'),
('WAT-02', 'Keysight B1500A WAT #2', 'WAT', 'PARAMETRIC', 'KEYSIGHT', 'B1500A', 'BAY-05', 'WAT', 98.5, 'HEALTHY', 72.1, 17.8, 0, '2025-06-12', '2025-09-10'),
('INSP-01', 'KLA 2920 Inspector', 'INSPECT', 'OPTICAL', 'KLA', '2920', 'BAY-06', 'INSP', 91.3, 'HEALTHY', 85.2, 25.0, 0, '2025-05-25', '2025-08-23'),
('INSP-02', 'KLA 2930 Inspector', 'INSPECT', 'OPTICAL', 'KLA', '2930', 'BAY-06', 'INSP', 86.7, 'HEALTHY', 79.8, 23.5, 1, '2025-05-18', '2025-08-16'),
('IMP-01', 'AMAT VIISta Implanter', 'IMP', 'ION_IMPLANT', 'AMAT', 'VIISta', 'BAY-07', 'IMP', 94.6, 'HEALTHY', 88.1, 42.3, 0, '2025-06-08', '2025-09-06');

-- WAT Parameters
INSERT INTO wat_dim_parameter (parameter_id, parameter_name, parameter_group, device_type, mos_type, unit, display_unit, layer_name, process_module, usl, lsl, target_value, criticality_rank) VALUES
('NMOS_VT', 'NMOS Threshold Voltage', 'MOSFET', 'NMOS', 'N', 'V', 'V', 'POLY', 'GATE', 0.42, 0.28, 0.35, 1),
('PMOS_VT', 'PMOS Threshold Voltage', 'MOSFET', 'PMOS', 'P', 'V', 'V', 'POLY', 'GATE', -0.28, -0.42, -0.35, 1),
('NMOS_IDSAT', 'NMOS Saturation Current', 'MOSFET', 'NMOS', 'N', 'uA/um', 'μA/μm', 'POLY', 'GATE', 1450, 1150, 1300, 2),
('GATOX_THK', 'Gate Oxide Thickness', 'DIELECTRIC', 'BOTH', 'N', 'A', 'Å', 'GO', 'GATE_OX', 30.0, 26.0, 28.0, 1),
('POLY_CD', 'Poly Gate CD', 'LITHO', 'BOTH', 'N', 'nm', 'nm', 'PO', 'POLY', 28.5, 25.5, 27.0, 2),
('CMP_RATE', 'CMP Polish Rate', 'CMP', 'BOTH', 'N', 'A/min', 'Å/min', 'M1', 'CMP', 3200, 2400, 2800, 3),
('CONTACT_R', 'Contact Resistance', 'INTERCONNECT', 'BOTH', 'N', 'Ohm', 'Ω', 'CT', 'CONTACT', 180, 80, 120, 2),
('METAL_R', 'Metal Sheet Resistance', 'INTERCONNECT', 'BOTH', 'N', 'Ohm/sq', 'Ω/sq', 'M1', 'METAL', 0.085, 0.055, 0.070, 3);

-- Lots
INSERT INTO mes_dim_lot (lot_id, lot_type, lot_subtype, lot_priority, product_id, device_family, customer_id, process_node, lot_status, wafer_count_start, wafer_count_current, lot_start_date, lot_target_date, target_yield_pct, syl_pct, sbl_pct) VALUES
('M900001', 'PRODUCTION', 'HOT_LOT', 1, 'AI-CHIP-N5', 'AI_ACCELERATOR', 'NVIDIA', 'N5', 'ACTIVE', 25, 25, NOW() - INTERVAL '5 days', NOW() + INTERVAL '10 days', 95.0, 90.0, 85.0),
('M900002', 'PRODUCTION', 'STANDARD', 5, 'CPU-N3', 'CPU', 'APPLE', 'N3', 'ACTIVE', 25, 25, NOW() - INTERVAL '8 days', NOW() + INTERVAL '7 days', 94.5, 89.0, 84.0),
('M900003', 'PRODUCTION', 'HOT_LOT', 2, 'GPU-N5', 'GPU', 'AMD', 'N5', 'ACTIVE', 25, 25, NOW() - INTERVAL '3 days', NOW() + INTERVAL '12 days', 93.0, 88.0, 83.0),
('M900004', 'PRODUCTION', 'STANDARD', 5, 'MCU-28NM', 'MCU', 'STM', '28nm', 'ACTIVE', 25, 25, NOW() - INTERVAL '12 days', NOW() + INTERVAL '3 days', 96.0, 91.0, 86.0),
('M900005', 'PRODUCTION', 'STANDARD', 5, 'RF-CHIP-16NM', 'RF', 'QCOMM', '16nm', 'HOLD', 25, 23, NOW() - INTERVAL '15 days', NOW() + INTERVAL '0 days', 94.0, 89.0, 84.0),
('M900006', 'PRODUCTION', 'STANDARD', 5, 'AI-CHIP-N5', 'AI_ACCELERATOR', 'NVIDIA', 'N5', 'ACTIVE', 25, 25, NOW() - INTERVAL '2 days', NOW() + INTERVAL '13 days', 95.0, 90.0, 85.0),
('M900007', 'PRODUCTION', 'STANDARD', 5, 'CPU-N3', 'CPU', 'APPLE', 'N3', 'ACTIVE', 25, 25, NOW() - INTERVAL '6 days', NOW() + INTERVAL '9 days', 94.5, 89.0, 84.0),
('M900008', 'ENGINEERING', 'STANDARD', 8, 'GPU-N5', 'GPU', 'AMD', 'N5', 'COMPLETE', 5, 5, NOW() - INTERVAL '20 days', NOW() - INTERVAL '5 days', 93.0, 88.0, 83.0),
('M900009', 'PRODUCTION', 'STANDARD', 5, 'MCU-28NM', 'MCU', 'STM', '28nm', 'COMPLETE', 25, 25, NOW() - INTERVAL '25 days', NOW() - INTERVAL '10 days', 96.0, 91.0, 86.0),
('M900010', 'PRODUCTION', 'STANDARD', 5, 'AI-CHIP-N5', 'AI_ACCELERATOR', 'NVIDIA', 'N5', 'ACTIVE', 25, 25, NOW() - INTERVAL '1 day', NOW() + INTERVAL '14 days', 95.0, 90.0, 85.0);

-- CP Wafer Summaries
INSERT INTO cp_fact_wafer_summary (lot_id, wafer_id, slot_number, tester_id, total_die, pass_die, fail_die, gross_yield_pct, net_yield_pct, first_pass_yield, bin_counts_json, pattern_class_generic, pattern_confidence, edge_yield_pct, center_yield_pct, syl_flag, sbl_flag, mrb_required, product_id, process_node) VALUES
('M900001', 'M900001_W01', 1, 'WAT-01', 8500, 8075, 425, 95.00, 94.82, 94.12, '{"1":8075,"2":210,"3":125,"4":90}', 'NORMAL', 0.92, 93.2, 96.8, FALSE, FALSE, FALSE, 'AI-CHIP-N5', 'N5'),
('M900001', 'M900001_W02', 2, 'WAT-01', 8500, 8160, 340, 96.00, 95.88, 95.29, '{"1":8160,"2":180,"3":95,"4":65}', 'NORMAL', 0.94, 94.5, 97.2, FALSE, FALSE, FALSE, 'AI-CHIP-N5', 'N5'),
('M900001', 'M900001_W03', 3, 'WAT-01', 8500, 7990, 510, 94.00, 93.76, 93.18, '{"1":7990,"2":240,"3":155,"4":115}', 'EDGE', 0.78, 88.3, 97.1, FALSE, FALSE, FALSE, 'AI-CHIP-N5', 'N5'),
('M900002', 'M900002_W01', 1, 'WAT-02', 9200, 8740, 460, 95.00, 94.78, 94.35, '{"1":8740,"2":230,"3":140,"4":90}', 'NORMAL', 0.91, 93.8, 96.5, FALSE, FALSE, FALSE, 'CPU-N3', 'N3'),
('M900002', 'M900002_W02', 2, 'WAT-02', 9200, 8648, 552, 94.00, 93.82, 93.15, '{"1":8648,"2":275,"3":165,"4":112}', 'NORMAL', 0.89, 92.1, 95.8, FALSE, FALSE, FALSE, 'CPU-N3', 'N3'),
('M900003', 'M900003_W01', 1, 'WAT-01', 8800, 8272, 528, 94.00, 93.75, 93.18, '{"1":8272,"2":264,"3":158,"4":106}', 'RING', 0.82, 89.5, 96.3, FALSE, FALSE, FALSE, 'GPU-N5', 'N5'),
('M900004', 'M900004_W01', 1, 'WAT-02', 7200, 6984, 216, 97.00, 96.88, 96.52, '{"1":6984,"2":108,"3":65,"4":43}', 'NORMAL', 0.95, 95.8, 97.9, FALSE, FALSE, FALSE, 'MCU-28NM', '28nm'),
('M900005', 'M900005_W01', 1, 'WAT-01', 8100, 6966, 1134, 86.00, 85.72, 84.93, '{"1":6966,"2":567,"3":340,"4":227}', 'CLUSTER', 0.88, 78.2, 91.5, TRUE, TRUE, TRUE, 'RF-CHIP-16NM', '16nm'),
('M900005', 'M900005_W02', 2, 'WAT-01', 8100, 7533, 567, 93.00, 92.78, 92.15, '{"1":7533,"2":284,"3":170,"4":113}', 'NORMAL', 0.90, 91.2, 94.5, FALSE, FALSE, FALSE, 'RF-CHIP-16NM', '16nm'),
('M900008', 'M900008_W01', 1, 'WAT-01', 8800, 8272, 528, 94.00, 93.75, 93.18, '{"1":8272,"2":264,"3":158,"4":106}', 'NORMAL', 0.93, 92.8, 95.1, FALSE, FALSE, FALSE, 'GPU-N5', 'N5');

-- SPC Configurations
INSERT INTO spc_dim_parameter_config (config_id, parameter_id, product_id, equipment_id, chart_type, ucl, cl, lcl, usl, lsl, target, enabled_rules, alarm_severity) VALUES
('SPC_NMOS_VT_ALL', 'NMOS_VT', NULL, NULL, 'XBAR_R', 0.395, 0.350, 0.305, 0.42, 0.28, 0.35, 255, 'MAJOR'),
('SPC_PMOS_VT_ALL', 'PMOS_VT', NULL, NULL, 'XBAR_R', -0.305, -0.350, -0.395, -0.28, -0.42, -0.35, 255, 'MAJOR'),
('SPC_GATOX_THK_ALL', 'GATOX_THK', NULL, NULL, 'XBAR_R', 29.5, 28.0, 26.5, 30.0, 26.0, 28.0, 255, 'CRITICAL'),
('SPC_POLY_CD_ALL', 'POLY_CD', NULL, NULL, 'XBAR_R', 28.0, 27.0, 26.0, 28.5, 25.5, 27.0, 255, 'MAJOR'),
('SPC_CMP_RATE_CMP01', 'CMP_RATE', NULL, 'CMP-01', 'XBAR_R', 3050, 2800, 2550, 3200, 2400, 2800, 255, 'MINOR');

-- Live Alarms
INSERT INTO rt_live_alarm (alarm_source, alarm_type, equipment_id, lot_id, step_id, parameter_id, severity, alarm_code, alarm_message, measured_value, threshold_value, sigma_deviation, status) VALUES
('FDC', 'TRACE_ANOMALY', 'CMP-03', 'M900005', 'CMP-STEP-01', NULL, 'CRITICAL', 'FDC-E001', 'Chamber pressure anomaly detected - 3.2σ above baseline', 45.8, 42.0, 3.2, 'OPEN'),
('FDC', 'TRACE_ANOMALY', 'ETCH-03', 'M900002', 'ETCH-STEP-01', NULL, 'CRITICAL', 'FDC-E002', 'RF power reflected exceeds threshold - potential match failure', 285.3, 250.0, 2.8, 'OPEN'),
('FDC', 'PM_DUE', 'CMP-02', 'M900005', NULL, NULL, 'MAJOR', 'PM-W001', 'Polishing pad wear indicator at 87% - schedule PM', NULL, 85.0, NULL, 'OPEN'),
('SPC', 'SPC_VIOLATION', 'CVD-02', 'M900006', NULL, 'GATOX_THK', 'MAJOR', 'SPC-R005', 'Temperature zone 3 drifting +1.8°C from setpoint', 28.8, 28.0, 2.1, 'OPEN'),
('FDC', 'TRACE_ANOMALY', 'INSP-01', 'M900004', NULL, NULL, 'MINOR', 'FDC-I001', 'Defect density spike on lot M900004 - edge ring pattern', NULL, NULL, NULL, 'OPEN');

-- Agent Actions
INSERT INTO agt_fact_robot_action (action_type, action_target_type, action_target_id, action_params_json, confidence_score, authorization_level, execution_status, lots_affected, wafers_saved, estimated_value_usd) VALUES
('LOT_HOLD', 'LOT', 'M900005', '{"reason":"FDC anomaly CMP-03 chamber pressure","hold_code":"FDC-HOLD","notify_engineer":true}', 0.96, 'AUTO', 'COMPLETE', 1, 0, 0),
('PM_SCHEDULE', 'EQUIPMENT', 'CMP-02', '{"pm_type":"PAD_CHANGE","scheduled_time":"2025-06-28T06:00:00Z","estimated_duration_hr":4}', 0.91, 'ENGINEER_APPROVED', 'PENDING', 0, 12, 48000),
('RECIPE_ADJUST', 'EQUIPMENT', 'CVD-02', '{"parameter":"ZONE3_TEMP_SETPOINT","current_value":400.0,"new_value":398.2,"delta":-1.8,"recipe_id":"CVD_GATE_OX_R04"}', 0.88, 'SENIOR_APPROVED', 'PENDING', 3, 8, 32000);

-- RCA Knowledge
INSERT INTO yld_fact_rca_knowledge (symptom_category, symptom_description, root_cause_category, root_cause_description, physical_mechanism, corrective_action, corrective_action_type, yield_recovery_pct, confidence_score, occurrence_count, success_rate, equipment_ids, parameter_ids) VALUES
('WAT_SHIFT', 'NMOS_VT shift +2.5σ with edge ring pattern', 'EQUIPMENT', 'CVD furnace temperature zone non-uniformity', 'Temperature gradient causes radial junction depth variation affecting threshold voltage', 'Adjust furnace zone 3 setpoint by +2.5°C and verify with monitor wafer', 'RECIPE_ADJUST', 2.8, 0.94, 7, 0.92, 'CVD-01,CVD-02', 'NMOS_VT,PMOS_VT'),
('DEFECT_CLUSTER', 'Cluster defect pattern near center with >500 defects/wafer', 'MATERIAL', 'Slurry particle contamination in CMP process', 'Oversized particles in slurry cause mechanical damage during polishing', 'Replace CMP slurry batch and clean distribution lines', 'MATERIAL_CHANGE', 3.5, 0.89, 4, 0.88, 'CMP-01,CMP-02,CMP-03', NULL),
('YIELD_DROP', 'Sudden yield drop >5% across multiple lots', 'EQUIPMENT', 'Etch chamber pressure drift causing CD variation', 'Chamber pressure instability leads to non-uniform etch rate and CD widening', 'Perform chamber conditioning and re-qualify with CD measurement', 'EQUIPMENT_MAINTENANCE', 4.2, 0.91, 12, 0.90, 'ETCH-01,ETCH-02,ETCH-03', 'POLY_CD');
