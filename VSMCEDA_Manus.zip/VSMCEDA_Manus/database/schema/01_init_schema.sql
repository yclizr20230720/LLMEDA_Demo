-- ============================================================
-- SEMFAB·IQ — PostgreSQL Schema (GreenPlum-compatible)
-- Version: 2.0 | 12 DataMart Domains | Production-Grade
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- ── DOMAIN 1: MES ──────────────────────────────────────────

CREATE TABLE mes_dim_lot (
    lot_sk              BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    lot_type            VARCHAR(20)     NOT NULL DEFAULT 'PRODUCTION',
    lot_subtype         VARCHAR(20),
    lot_priority        SMALLINT        DEFAULT 5,
    product_id          VARCHAR(32)     NOT NULL,
    product_revision    VARCHAR(8),
    device_family       VARCHAR(32),
    customer_id         VARCHAR(32),
    process_node        VARCHAR(16),
    technology_id       VARCHAR(32),
    lot_status          VARCHAR(24)     NOT NULL DEFAULT 'ACTIVE',
    hold_code           VARCHAR(16),
    hold_reason         TEXT,
    wafer_count_start   SMALLINT        DEFAULT 25,
    wafer_count_current SMALLINT,
    wafer_size_mm       SMALLINT        DEFAULT 300,
    lot_start_date      TIMESTAMPTZ,
    lot_target_date     TIMESTAMPTZ,
    lot_complete_date   TIMESTAMPTZ,
    target_yield_pct    NUMERIC(6,3),
    syl_pct             NUMERIC(6,3)    DEFAULT 90.0,
    sbl_pct             NUMERIC(6,3)    DEFAULT 85.0,
    is_current          BOOLEAN         DEFAULT TRUE,
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_mes_lot_id ON mes_dim_lot(lot_id) WHERE is_current=TRUE;
CREATE INDEX idx_mes_lot_product ON mes_dim_lot(product_id, process_node);
CREATE INDEX idx_mes_lot_status ON mes_dim_lot(lot_status, lot_type);

CREATE TABLE mes_dim_wafer (
    wafer_sk            BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT        NOT NULL,
    die_per_wafer       INTEGER,
    die_count_good      INTEGER,
    die_count_bad       INTEGER,
    wafer_status        VARCHAR(20)     DEFAULT 'ACTIVE',
    cp_yield_pct        NUMERIC(6,3),
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    UNIQUE (lot_id, slot_number)
);

CREATE TABLE mes_dim_route_step (
    step_sk             BIGSERIAL       PRIMARY KEY,
    route_id            VARCHAR(32)     NOT NULL DEFAULT 'N5_LOGIC_R04',
    step_id             VARCHAR(32)     NOT NULL,
    step_sequence       INTEGER         NOT NULL,
    step_name           VARCHAR(128),
    step_type           VARCHAR(24)     DEFAULT 'PROCESS',
    process_area        VARCHAR(32),
    process_module      VARCHAR(32),
    layer_name          VARCHAR(32),
    front_end_backend   VARCHAR(8)      DEFAULT 'FEOL',
    nominal_duration_min NUMERIC(8,2),
    UNIQUE (route_id, step_id)
);

CREATE TABLE mes_fact_lot_operation (
    operation_sk        BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40),
    route_id            VARCHAR(32)     DEFAULT 'N5_LOGIC_R04',
    step_id             VARCHAR(32)     NOT NULL,
    step_sequence       INTEGER,
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    operator_id         VARCHAR(32),
    shift               VARCHAR(8),
    recipe_id           VARCHAR(64),
    queue_start_time    TIMESTAMPTZ,
    process_start_time  TIMESTAMPTZ,
    process_end_time    TIMESTAMPTZ,
    queue_time_hr       NUMERIC(10,4),
    process_time_min    NUMERIC(10,4),
    cycle_time_hr       NUMERIC(10,4),
    operation_status    VARCHAR(20)     NOT NULL DEFAULT 'COMPLETE',
    lot_disposition     VARCHAR(20)     DEFAULT 'PASS',
    hold_triggered      BOOLEAN         DEFAULT FALSE,
    hold_source         VARCHAR(32),
    mrb_required        BOOLEAN         DEFAULT FALSE,
    mrb_decision        VARCHAR(20),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_mes_op_lot ON mes_fact_lot_operation(lot_id, step_id);
CREATE INDEX idx_mes_op_equip ON mes_fact_lot_operation(equipment_id, event_date);

-- ── DOMAIN 2: WAT ──────────────────────────────────────────

CREATE TABLE wat_dim_parameter (
    param_sk            BIGSERIAL       PRIMARY KEY,
    parameter_id        VARCHAR(64)     NOT NULL UNIQUE,
    parameter_name      VARCHAR(128),
    parameter_group     VARCHAR(32),
    device_type         VARCHAR(32),
    mos_type            VARCHAR(4),
    unit                VARCHAR(16),
    display_unit        VARCHAR(16),
    layer_name          VARCHAR(32),
    process_module      VARCHAR(32),
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    target_value        NUMERIC(20,10),
    criticality_rank    SMALLINT        DEFAULT 5,
    is_active           BOOLEAN         DEFAULT TRUE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE wat_fact_result (
    result_sk           BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    site_id             SMALLINT        NOT NULL,
    site_x              NUMERIC(8,4),
    site_y              NUMERIC(8,4),
    site_zone           VARCHAR(16)     DEFAULT 'CENTER',
    parameter_id        VARCHAR(64)     NOT NULL,
    vcc                 NUMERIC(8,4),
    temp_c              NUMERIC(8,3)    DEFAULT 25.0,
    measured_value      NUMERIC(20,10)  NOT NULL,
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    target_value        NUMERIC(20,10),
    pass_fail           CHAR(1)         DEFAULT 'P',
    sigma_deviation     NUMERIC(10,6),
    is_outlier_mad      BOOLEAN         DEFAULT FALSE,
    is_outlier_grubbs   BOOLEAN         DEFAULT FALSE,
    is_anomaly_ml       BOOLEAN         DEFAULT FALSE,
    anomaly_score       NUMERIC(6,4)    DEFAULT 0.0,
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    step_id             VARCHAR(32),
    route_id            VARCHAR(32),
    process_node        VARCHAR(16),
    product_id          VARCHAR(32),
    test_time           TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_wat_result_param ON wat_fact_result(parameter_id, event_date);
CREATE INDEX idx_wat_result_equip ON wat_fact_result(equipment_id, parameter_id);
CREATE INDEX idx_wat_result_lot ON wat_fact_result(lot_id, wafer_id, site_id);

CREATE TABLE wat_agg_lot_summary (
    summary_sk          BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    product_id          VARCHAR(32),
    equipment_id        VARCHAR(32),
    event_date          DATE            NOT NULL,
    n_sites             SMALLINT,
    mean_value          NUMERIC(20,10),
    median_value        NUMERIC(20,10),
    std_dev             NUMERIC(20,10),
    min_value           NUMERIC(20,10),
    max_value           NUMERIC(20,10),
    p25_value           NUMERIC(20,10),
    p75_value           NUMERIC(20,10),
    skewness            NUMERIC(10,6),
    kurtosis            NUMERIC(10,6),
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    cp                  NUMERIC(10,6),
    cpk                 NUMERIC(10,6),
    cpm                 NUMERIC(10,6),
    ppk                 NUMERIC(10,6),
    shapiro_wilk_p      NUMERIC(10,8),
    is_normal_dist      BOOLEAN,
    n_pass              SMALLINT,
    n_fail              SMALLINT,
    pass_rate_pct       NUMERIC(6,3),
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    UNIQUE (lot_id, wafer_id, parameter_id)
);

CREATE TABLE wat_fact_anova_equipment (
    anova_sk            BIGSERIAL       PRIMARY KEY,
    parameter_id        VARCHAR(64)     NOT NULL,
    product_id          VARCHAR(32)     NOT NULL,
    process_node        VARCHAR(16),
    date_range_start    DATE,
    date_range_end      DATE,
    lot_count           INTEGER,
    n_observations      INTEGER,
    factor_type         VARCHAR(24)     NOT NULL DEFAULT 'EQPID',
    factor_value        VARCHAR(64)     NOT NULL,
    f_statistic         NUMERIC(16,6),
    p_value             NUMERIC(12,10),
    eta_squared         NUMERIC(10,8),
    omega_squared       NUMERIC(10,8),
    group_mean          NUMERIC(20,10),
    group_std           NUMERIC(20,10),
    group_n             INTEGER,
    fleet_mean          NUMERIC(20,10),
    fleet_std           NUMERIC(20,10),
    composite_health_score NUMERIC(6,2),
    health_tier         VARCHAR(16),
    computed_at         TIMESTAMPTZ     DEFAULT NOW()
);

-- ── DOMAIN 3: CP ───────────────────────────────────────────

CREATE TABLE cp_dim_bin (
    bin_sk              BIGSERIAL       PRIMARY KEY,
    program_id          VARCHAR(64)     NOT NULL DEFAULT 'DEFAULT_CP',
    bin_code            SMALLINT        NOT NULL,
    bin_type            VARCHAR(8)      NOT NULL DEFAULT 'HARD',
    bin_name            VARCHAR(64),
    bin_category        VARCHAR(20)     DEFAULT 'FAIL',
    is_pass_bin         BOOLEAN         NOT NULL DEFAULT FALSE,
    fail_category       VARCHAR(32),
    fail_mechanism      VARCHAR(64),
    priority_rank       SMALLINT,
    yield_impact_est    NUMERIC(6,3),
    UNIQUE (program_id, bin_code)
);

CREATE TABLE cp_fact_die_result (
    die_sk              BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    die_x               SMALLINT        NOT NULL,
    die_y               SMALLINT        NOT NULL,
    program_id          VARCHAR(64)     DEFAULT 'DEFAULT_CP',
    tester_id           VARCHAR(32),
    hard_bin            SMALLINT        NOT NULL DEFAULT 1,
    soft_bin            SMALLINT,
    is_pass             BOOLEAN         NOT NULL DEFAULT TRUE,
    test_count          SMALLINT        DEFAULT 1,
    was_tested          BOOLEAN         DEFAULT TRUE,
    skip_reason         VARCHAR(24),
    is_edge_die         BOOLEAN         DEFAULT FALSE,
    is_spatial_cluster  BOOLEAN         DEFAULT FALSE,
    cluster_id          INTEGER,
    test_time           TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_cp_die_wafer ON cp_fact_die_result(lot_id, wafer_id, die_x, die_y);
CREATE INDEX idx_cp_die_bin ON cp_fact_die_result(hard_bin, event_date);

CREATE TABLE cp_fact_wafer_summary (
    summary_sk          BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    program_id          VARCHAR(64)     DEFAULT 'DEFAULT_CP',
    tester_id           VARCHAR(32),
    step_id             VARCHAR(32),
    total_die           INTEGER,
    pass_die            INTEGER,
    fail_die            INTEGER,
    skip_die            INTEGER         DEFAULT 0,
    gross_yield_pct     NUMERIC(7,4),
    net_yield_pct       NUMERIC(7,4),
    first_pass_yield    NUMERIC(7,4),
    retest_count        INTEGER         DEFAULT 0,
    offline_retest_rate NUMERIC(7,4),
    bin_counts_json     TEXT,
    pattern_class_generic  VARCHAR(32)  DEFAULT 'NORMAL',
    pattern_class_primary  VARCHAR(32),
    pattern_confidence  NUMERIC(6,4),
    edge_yield_pct      NUMERIC(7,4),
    center_yield_pct    NUMERIC(7,4),
    defect_density_cm2  NUMERIC(12,6),
    predicted_yield_pct NUMERIC(7,4),
    syl_flag            BOOLEAN         DEFAULT FALSE,
    sbl_flag            BOOLEAN         DEFAULT FALSE,
    mrb_required        BOOLEAN         DEFAULT FALSE,
    mrb_result          VARCHAR(16),
    test_time           TIMESTAMPTZ     DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    UNIQUE (lot_id, wafer_id, program_id)
);

-- ── DOMAIN 4: SPC ──────────────────────────────────────────

CREATE TABLE spc_dim_parameter_config (
    config_sk           BIGSERIAL       PRIMARY KEY,
    config_id           VARCHAR(64)     NOT NULL UNIQUE,
    parameter_id        VARCHAR(64)     NOT NULL,
    parameter_source    VARCHAR(20)     DEFAULT 'WAT',
    product_id          VARCHAR(32),
    equipment_id        VARCHAR(32),
    step_id             VARCHAR(32),
    chart_type          VARCHAR(16)     DEFAULT 'XBAR_R',
    subgroup_size       SMALLINT        DEFAULT 1,
    ucl                 NUMERIC(20,10),
    cl                  NUMERIC(20,10),
    lcl                 NUMERIC(20,10),
    ucl_2sigma          NUMERIC(20,10),
    lcl_2sigma          NUMERIC(20,10),
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    target              NUMERIC(20,10),
    enabled_rules       SMALLINT        DEFAULT 255,
    alarm_mode          VARCHAR(16)     DEFAULT 'EMAIL',
    alarm_severity      VARCHAR(16)     DEFAULT 'MAJOR',
    is_virtual          BOOLEAN         DEFAULT FALSE,
    is_active           BOOLEAN         DEFAULT TRUE,
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE spc_fact_measurement (
    measurement_sk      BIGSERIAL       PRIMARY KEY,
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    subgroup_index      INTEGER,
    measured_value      NUMERIC(20,10)  NOT NULL,
    subgroup_mean       NUMERIC(20,10),
    subgroup_range      NUMERIC(20,10),
    subgroup_std        NUMERIC(20,10),
    ucl_at_time         NUMERIC(20,10),
    cl_at_time          NUMERIC(20,10),
    lcl_at_time         NUMERIC(20,10),
    usl_at_time         NUMERIC(20,10),
    lsl_at_time         NUMERIC(20,10),
    sigma_score         NUMERIC(10,6),
    violation_rule_1    BOOLEAN         DEFAULT FALSE,
    violation_rule_2    BOOLEAN         DEFAULT FALSE,
    violation_rule_3    BOOLEAN         DEFAULT FALSE,
    violation_rule_4    BOOLEAN         DEFAULT FALSE,
    violation_rule_5    BOOLEAN         DEFAULT FALSE,
    violation_rule_6    BOOLEAN         DEFAULT FALSE,
    violation_rule_7    BOOLEAN         DEFAULT FALSE,
    violation_rule_8    BOOLEAN         DEFAULT FALSE,
    any_violation       BOOLEAN         DEFAULT FALSE,
    violation_rules_list VARCHAR(32),
    alarm_triggered     BOOLEAN         DEFAULT FALSE,
    alarm_severity      VARCHAR(16),
    is_virtual          BOOLEAN         DEFAULT FALSE,
    vm_predicted_value  NUMERIC(20,10),
    vm_ci_lower         NUMERIC(20,10),
    vm_ci_upper         NUMERIC(20,10),
    measurement_time    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_spc_meas_config ON spc_fact_measurement(config_id, event_date);
CREATE INDEX idx_spc_meas_equip ON spc_fact_measurement(equipment_id, parameter_id, event_date);
CREATE INDEX idx_spc_violation ON spc_fact_measurement(any_violation, event_date) WHERE any_violation=TRUE;

CREATE TABLE spc_fact_violation (
    violation_sk        BIGSERIAL       PRIMARY KEY,
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32),
    rule_number         SMALLINT        NOT NULL,
    rule_description    VARCHAR(256),
    rule_severity       VARCHAR(16)     DEFAULT 'MAJOR',
    trigger_value       NUMERIC(20,10),
    trigger_lot_id      VARCHAR(32),
    trigger_wafer_id    VARCHAR(40),
    sigma_deviation     NUMERIC(10,6),
    acknowledged_by     VARCHAR(64),
    acknowledged_at     TIMESTAMPTZ,
    resolution_code     VARCHAR(32),
    resolution_note     TEXT,
    lots_affected_count INTEGER         DEFAULT 0,
    yield_impact_pct    NUMERIC(6,3),
    agent_rca_session_id VARCHAR(64),
    agent_rca_summary   TEXT,
    violation_time      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE spc_agg_capability (
    capability_sk       BIGSERIAL       PRIMARY KEY,
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32),
    product_id          VARCHAR(32),
    period_type         VARCHAR(16)     DEFAULT 'MONTHLY',
    period_start        DATE            NOT NULL,
    period_end          DATE            NOT NULL,
    n_observations      INTEGER,
    cp                  NUMERIC(10,6),
    cpk                 NUMERIC(10,6),
    cpm                 NUMERIC(10,6),
    pp                  NUMERIC(10,6),
    ppk                 NUMERIC(10,6),
    mean_value          NUMERIC(20,10),
    std_dev_within      NUMERIC(20,10),
    total_violations    INTEGER         DEFAULT 0,
    violations_r1       SMALLINT        DEFAULT 0,
    violations_r2       SMALLINT        DEFAULT 0,
    violations_r3       SMALLINT        DEFAULT 0,
    violations_r4       SMALLINT        DEFAULT 0,
    violations_r5       SMALLINT        DEFAULT 0,
    computed_at         TIMESTAMPTZ     DEFAULT NOW(),
    UNIQUE (config_id, period_type, period_start, equipment_id)
);

-- ── DOMAIN 5: EQP + FDC ────────────────────────────────────

CREATE TABLE eqp_dim_equipment (
    equipment_sk        BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL UNIQUE,
    equipment_name      VARCHAR(128),
    equipment_type      VARCHAR(32)     NOT NULL,
    equipment_subtype   VARCHAR(32),
    oem_vendor          VARCHAR(32),
    oem_model           VARCHAR(64),
    fab_id              VARCHAR(16)     DEFAULT 'FAB-12',
    bay_id              VARCHAR(16),
    area_id             VARCHAR(32),
    chamber_count       SMALLINT        DEFAULT 1,
    is_multi_chamber    BOOLEAN         DEFAULT FALSE,
    equipment_status    VARCHAR(24)     DEFAULT 'PRODUCTION',
    is_golden_tool      BOOLEAN         DEFAULT FALSE,
    health_score        NUMERIC(5,2)    DEFAULT 100.0,
    health_tier         VARCHAR(16)     DEFAULT 'HEALTHY',
    utilization_pct     NUMERIC(5,2),
    throughput_wph      NUMERIC(8,2),
    alarm_count_24h     INTEGER         DEFAULT 0,
    last_pm_date        DATE,
    next_pm_date        DATE,
    pm_interval_days    INTEGER         DEFAULT 90,
    z_score_component   NUMERIC(5,3),
    gof_component       NUMERIC(5,3),
    cv_stability_component NUMERIC(5,3),
    volume_component    NUMERIC(5,3),
    is_current          BOOLEAN         DEFAULT TRUE,
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE fdc_dim_sensor (
    sensor_sk           BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL,
    sensor_alias        VARCHAR(128)    NOT NULL,
    sensor_type         VARCHAR(32),
    measurement_units   VARCHAR(32),
    sampling_rate_hz    NUMERIC(10,4),
    is_fdc_monitored    BOOLEAN         DEFAULT TRUE,
    baseline_sigma_limit NUMERIC(6,2)   DEFAULT 6.0,
    UNIQUE (equipment_id, sensor_alias)
);

CREATE TABLE fdc_fact_trace_run (
    run_sk              BIGSERIAL       PRIMARY KEY,
    run_id              UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    step_id             VARCHAR(32),
    run_start_time      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    run_end_time        TIMESTAMPTZ,
    run_duration_sec    NUMERIC(10,4),
    run_result          VARCHAR(16)     DEFAULT 'NORMAL',
    alarm_count         SMALLINT        DEFAULT 0,
    composite_anomaly_score NUMERIC(6,4) DEFAULT 0.0,
    interval_anomaly_score  NUMERIC(6,4) DEFAULT 0.0,
    amplitude_anomaly_score NUMERIC(6,4) DEFAULT 0.0,
    shape_anomaly_score     NUMERIC(6,4) DEFAULT 0.0,
    alarm_sensor_list   TEXT,
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_fdc_run_equip ON fdc_fact_trace_run(equipment_id, event_date);
CREATE INDEX idx_fdc_run_lot ON fdc_fact_trace_run(lot_id);

CREATE TABLE fdc_fact_trace_data (
    trace_sk            BIGSERIAL       PRIMARY KEY,
    run_id              UUID            NOT NULL,
    sensor_alias        VARCHAR(128)    NOT NULL,
    time_offset_ms      INTEGER         NOT NULL,
    value               NUMERIC(20,10)  NOT NULL,
    is_anomaly_point    BOOLEAN         DEFAULT FALSE,
    baseline_mean       NUMERIC(20,10),
    baseline_std        NUMERIC(20,10)
);
CREATE INDEX idx_fdc_trace_run ON fdc_fact_trace_data(run_id, sensor_alias);

CREATE TABLE fdc_fact_pm_event (
    pm_sk               BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    pm_type             VARCHAR(32)     NOT NULL,
    pm_start_time       TIMESTAMPTZ     NOT NULL,
    pm_end_time         TIMESTAMPTZ,
    pm_duration_hr      NUMERIC(8,2),
    pre_pm_health_score  NUMERIC(5,2),
    post_pm_health_score NUMERIC(5,2),
    health_improvement  NUMERIC(5,2),
    qualification_passed BOOLEAN,
    wafers_impacted     INTEGER         DEFAULT 0,
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

-- ── DOMAIN 6: DEF ──────────────────────────────────────────

CREATE TABLE def_fact_defect (
    defect_sk           BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    inspection_tool_id  VARCHAR(32)     NOT NULL,
    inspection_layer    VARCHAR(32),
    inspection_step_id  VARCHAR(32),
    defect_x_um         NUMERIC(12,4),
    defect_y_um         NUMERIC(12,4),
    die_x               SMALLINT,
    die_y               SMALLINT,
    defect_size_nm      NUMERIC(12,4),
    defect_area_nm2     NUMERIC(16,4),
    rough_class         VARCHAR(32),
    adc_class           VARCHAR(32),
    adc_confidence      NUMERIC(6,4),
    is_adc_auto         BOOLEAN         DEFAULT FALSE,
    final_class         VARCHAR(32),
    class_category      VARCHAR(32),
    is_killer           BOOLEAN,
    kill_probability    NUMERIC(8,6),
    sem_reviewed        BOOLEAN         DEFAULT FALSE,
    sem_image_path      VARCHAR(256),
    inspection_time     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_def_class ON def_fact_defect(final_class, event_date);
CREATE INDEX idx_def_tool ON def_fact_defect(inspection_tool_id, event_date);

CREATE TABLE def_fact_wafer_defect_summary (
    def_summary_sk      BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    inspection_tool_id  VARCHAR(32),
    inspection_step_id  VARCHAR(32),
    inspection_layer    VARCHAR(32),
    total_defects       INTEGER         DEFAULT 0,
    killer_defects      INTEGER         DEFAULT 0,
    defect_density_cm2  NUMERIC(14,8),
    killer_density_cm2  NUMERIC(14,8),
    class_counts_json   TEXT,
    pattern_class       VARCHAR(32)     DEFAULT 'NORMAL',
    pattern_confidence  NUMERIC(6,4),
    suspected_step_id   VARCHAR(32),
    suspected_equipment_id VARCHAR(32),
    hypothesis_confidence NUMERIC(6,4),
    predicted_yield_loss_pct NUMERIC(7,4),
    inspection_time     TIMESTAMPTZ,
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    UNIQUE (lot_id, wafer_id, inspection_tool_id, inspection_step_id)
);

-- ── DOMAIN 7: YLD ──────────────────────────────────────────

CREATE TABLE yld_fact_excursion (
    excursion_sk        BIGSERIAL       PRIMARY KEY,
    excursion_id        UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    excursion_type      VARCHAR(24)     NOT NULL DEFAULT 'YIELD',
    excursion_source    VARCHAR(24)     DEFAULT 'SYSTEM',
    severity            VARCHAR(16)     NOT NULL DEFAULT 'MAJOR',
    trigger_lot_id      VARCHAR(32),
    affected_lot_ids    TEXT,
    affected_lot_count  INTEGER,
    affected_wafer_count INTEGER,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    trigger_step_id     VARCHAR(32),
    trigger_equipment_id VARCHAR(32),
    yield_before_pct    NUMERIC(7,4),
    yield_after_pct     NUMERIC(7,4),
    yield_delta_pct     NUMERIC(7,4),
    financial_impact_usd NUMERIC(14,2),
    excursion_status    VARCHAR(20)     DEFAULT 'OPEN',
    rca_status          VARCHAR(20)     DEFAULT 'PENDING',
    root_cause_summary  TEXT,
    corrective_action   TEXT,
    excursion_time      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE yld_fact_rca_knowledge (
    rca_sk              BIGSERIAL       PRIMARY KEY,
    rca_id              UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    symptom_category    VARCHAR(32)     NOT NULL,
    symptom_description TEXT,
    root_cause_category VARCHAR(32),
    root_cause_description TEXT,
    physical_mechanism  TEXT,
    corrective_action   TEXT,
    corrective_action_type VARCHAR(32),
    yield_recovery_pct  NUMERIC(6,3),
    confidence_score    NUMERIC(6,4)    DEFAULT 0.8,
    occurrence_count    INTEGER         DEFAULT 1,
    success_rate        NUMERIC(6,4),
    equipment_ids       TEXT,
    parameter_ids       TEXT,
    step_ids            TEXT,
    confirmed_by        VARCHAR(64),
    confirmed_at        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     DEFAULT NOW()
);

-- ── DOMAIN 8: MSC R&R ──────────────────────────────────────

CREATE TABLE msc_fact_rr_result (
    rr_sk               BIGSERIAL       PRIMARY KEY,
    study_id            VARCHAR(64)     NOT NULL,
    test_name           VARCHAR(128)    NOT NULL,
    unit                VARCHAR(16),
    system_1_id         VARCHAR(32),
    system_2_id         VARCHAR(32),
    q2                  NUMERIC(20,10),
    lpl                 NUMERIC(20,10),
    upl                 NUMERIC(20,10),
    rr_pct              NUMERIC(8,4),
    repro_pct           NUMERIC(8,4),
    repeat_pct          NUMERIC(8,4),
    cpk_n               NUMERIC(10,6),
    rr_threshold        NUMERIC(8,4)    DEFAULT 10.0,
    is_acceptable       BOOLEAN,
    study_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    product_id          VARCHAR(32),
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

-- ── DOMAIN 9: REL / DPPM ───────────────────────────────────

CREATE TABLE rel_fact_dppm_model (
    dppm_sk             BIGSERIAL       PRIMARY KEY,
    model_id            VARCHAR(64),
    product_id          VARCHAR(32)     NOT NULL,
    technology_id       VARCHAR(32),
    model_type          VARCHAR(16)     NOT NULL,
    burnin_pct          NUMERIC(6,3),
    dppm_value          NUMERIC(12,6),
    model_a             NUMERIC(16,8),
    model_b             NUMERIC(16,8),
    model_r_squared     NUMERIC(10,8),
    yield_gain_pct      NUMERIC(6,3),
    excursion_reduction_pct NUMERIC(6,3),
    computed_date       DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

-- ── DOMAIN 10: AGT (Agent / AI) ────────────────────────────

CREATE TABLE agt_fact_session (
    session_sk          BIGSERIAL       PRIMARY KEY,
    session_id          UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    initiated_by        VARCHAR(24)     DEFAULT 'ENGINEER',
    user_id             VARCHAR(64),
    question_text       TEXT,
    context_lot_ids     TEXT,
    context_equipment_ids TEXT,
    final_state         VARCHAR(24)     DEFAULT 'COMPLETE',
    rca_generated       BOOLEAN         DEFAULT FALSE,
    confidence_score    NUMERIC(6,4),
    action_plan_json    TEXT,
    total_tool_calls    SMALLINT        DEFAULT 0,
    auto_actions_taken  SMALLINT        DEFAULT 0,
    human_approvals_needed SMALLINT     DEFAULT 0,
    total_duration_sec  NUMERIC(10,4),
    llm_tokens_in       INTEGER,
    llm_tokens_out      INTEGER,
    engineer_feedback   VARCHAR(16),
    knowledge_updated   BOOLEAN         DEFAULT FALSE,
    session_start       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    session_end         TIMESTAMPTZ,
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);

CREATE TABLE agt_fact_robot_action (
    action_sk           BIGSERIAL       PRIMARY KEY,
    action_id           UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    session_id          UUID,
    action_type         VARCHAR(32)     NOT NULL,
    action_target_type  VARCHAR(24),
    action_target_id    VARCHAR(64),
    action_params_json  TEXT,
    confidence_score    NUMERIC(6,4),
    authorization_level VARCHAR(24)     DEFAULT 'ENGINEER_APPROVED',
    approved_by         VARCHAR(64),
    approved_at         TIMESTAMPTZ,
    execution_status    VARCHAR(20)     DEFAULT 'PENDING',
    system_called       VARCHAR(32),
    action_result       VARCHAR(20),
    error_message       TEXT,
    lots_affected       INTEGER,
    wafers_saved        INTEGER,
    estimated_value_usd NUMERIC(14,2),
    action_time         TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    event_date          DATE            NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMPTZ     DEFAULT NOW()
);
CREATE INDEX idx_agt_action_type ON agt_fact_robot_action(action_type, event_date);
CREATE INDEX idx_agt_action_status ON agt_fact_robot_action(execution_status);

-- ── REAL-TIME TABLES (Oracle RT equivalent in PostgreSQL) ──

CREATE TABLE rt_live_alarm (
    alarm_id            BIGSERIAL       PRIMARY KEY,
    alarm_uuid          UUID            DEFAULT uuid_generate_v4() NOT NULL,
    alarm_source        VARCHAR(20)     NOT NULL DEFAULT 'FDC',
    alarm_type          VARCHAR(32)     NOT NULL,
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    step_id             VARCHAR(32),
    parameter_id        VARCHAR(64),
    severity            VARCHAR(16)     NOT NULL DEFAULT 'MAJOR',
    alarm_code          VARCHAR(32),
    alarm_message       VARCHAR(512),
    measured_value      NUMERIC(20,10),
    threshold_value     NUMERIC(20,10),
    sigma_deviation     NUMERIC(10,6),
    status              VARCHAR(20)     DEFAULT 'OPEN',
    acknowledged_by     VARCHAR(64),
    acknowledged_at     TIMESTAMPTZ,
    resolved_at         TIMESTAMPTZ,
    resolution_code     VARCHAR(32),
    agent_session_id    VARCHAR(36),
    agent_rca_summary   VARCHAR(2000),
    auto_action_taken   VARCHAR(256),
    alarm_time          TIMESTAMPTZ     DEFAULT NOW() NOT NULL,
    CONSTRAINT chk_severity CHECK (severity IN ('CRITICAL','MAJOR','MINOR','INFO')),
    CONSTRAINT chk_status CHECK (status IN ('OPEN','ACK','INVESTIGATING','RESOLVED','FALSE_ALARM'))
);
CREATE INDEX idx_rt_alarm_time ON rt_live_alarm(alarm_time DESC);
CREATE INDEX idx_rt_alarm_equip ON rt_live_alarm(equipment_id, status, alarm_time DESC);
CREATE INDEX idx_rt_alarm_sev ON rt_live_alarm(severity, status, alarm_time DESC);

-- ── USERS & AUTH ───────────────────────────────────────────

CREATE TABLE users (
    user_sk             BIGSERIAL       PRIMARY KEY,
    user_id             UUID            DEFAULT uuid_generate_v4() NOT NULL UNIQUE,
    username            VARCHAR(64)     NOT NULL UNIQUE,
    email               VARCHAR(320)    NOT NULL UNIQUE,
    password_hash       VARCHAR(256)    NOT NULL,
    full_name           VARCHAR(128),
    role                VARCHAR(32)     NOT NULL DEFAULT 'PROCESS_ENGINEER',
    department          VARCHAR(64),
    fab_id              VARCHAR(16)     DEFAULT 'FAB-12',
    is_active           BOOLEAN         DEFAULT TRUE,
    last_login          TIMESTAMPTZ,
    created_at          TIMESTAMPTZ     DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     DEFAULT NOW(),
    CONSTRAINT chk_role CHECK (role IN ('FAB_OPERATOR','PROCESS_ENGINEER','SENIOR_ENGINEER','MANAGER','ADMIN'))
);

-- ── CROSS-DOMAIN VIEWS ─────────────────────────────────────

CREATE OR REPLACE VIEW v_yield_dashboard AS
SELECT
    l.lot_id,
    l.lot_type,
    l.lot_priority,
    l.product_id,
    l.process_node,
    l.customer_id,
    l.lot_status,
    l.syl_pct,
    l.sbl_pct,
    l.lot_start_date,
    l.lot_target_date,
    ws.gross_yield_pct,
    ws.net_yield_pct,
    ws.first_pass_yield,
    ws.total_die,
    ws.pass_die,
    ws.fail_die,
    ws.bin_counts_json,
    ws.pattern_class_generic,
    ws.syl_flag,
    ws.sbl_flag,
    ws.mrb_required,
    ws.mrb_result,
    ws.tester_id,
    ws.event_date AS last_test_date,
    ws.test_time  AS last_test_time,
    (ws.gross_yield_pct - l.target_yield_pct) AS yield_delta_pct,
    CASE
        WHEN ws.sbl_flag THEN 'CRITICAL'
        WHEN ws.syl_flag THEN 'WARNING'
        WHEN ws.gross_yield_pct IS NULL THEN 'NO_DATA'
        ELSE 'NORMAL'
    END AS risk_level
FROM mes_dim_lot l
LEFT JOIN LATERAL (
    SELECT * FROM cp_fact_wafer_summary cws
    WHERE cws.lot_id = l.lot_id
    ORDER BY cws.test_time DESC
    LIMIT 1
) ws ON TRUE
WHERE l.is_current = TRUE
  AND l.lot_status IN ('ACTIVE', 'HOLD');

CREATE OR REPLACE VIEW v_mrb_consolidation AS
SELECT
    ws.lot_id,
    ws.wafer_id,
    ws.slot_number,
    l.product_id,
    l.process_node,
    l.customer_id,
    ws.gross_yield_pct,
    ws.net_yield_pct,
    ws.first_pass_yield,
    ws.bin_counts_json,
    ws.pattern_class_generic,
    ws.pattern_confidence,
    ws.syl_flag,
    ws.sbl_flag,
    ws.tester_id,
    ws.offline_retest_rate,
    ws.retest_count,
    CASE
        WHEN ws.sbl_flag = TRUE THEN 'REJECT'
        WHEN ws.syl_flag = TRUE AND ws.mrb_required = TRUE THEN 'REJECT'
        WHEN ws.pattern_class_generic NOT IN ('NORMAL') AND ws.pattern_confidence > 0.85 THEN 'REVIEW'
        ELSE 'PASS'
    END AS mrb_decision,
    ws.event_date,
    ws.test_time
FROM cp_fact_wafer_summary ws
LEFT JOIN mes_dim_lot l ON l.lot_id = ws.lot_id AND l.is_current = TRUE
WHERE ws.mrb_required = TRUE OR ws.syl_flag = TRUE;

CREATE OR REPLACE VIEW v_equipment_health AS
SELECT
    e.equipment_id,
    e.equipment_name,
    e.equipment_type,
    e.equipment_status,
    e.health_score,
    e.health_tier,
    e.utilization_pct,
    e.throughput_wph,
    e.alarm_count_24h,
    e.last_pm_date,
    e.next_pm_date,
    e.bay_id,
    e.area_id,
    e.oem_vendor,
    e.oem_model,
    e.chamber_count,
    (SELECT COUNT(*) FROM fdc_fact_trace_run r
     WHERE r.equipment_id = e.equipment_id
       AND r.run_result = 'ANOMALY'
       AND r.event_date >= CURRENT_DATE - 7) AS anomaly_runs_7d,
    e.updated_at
FROM eqp_dim_equipment e
WHERE e.is_current = TRUE;

COMMENT ON TABLE mes_dim_lot IS 'Lot master dimension with SCD Type 2 support';
COMMENT ON TABLE wat_fact_result IS 'WAT parametric test results - core analytical fact table';
COMMENT ON TABLE spc_fact_measurement IS 'SPC measurement stream with all 8 Western Electric rule flags';
COMMENT ON TABLE agt_fact_robot_action IS 'Immutable robot action audit trail - no UPDATE allowed';
