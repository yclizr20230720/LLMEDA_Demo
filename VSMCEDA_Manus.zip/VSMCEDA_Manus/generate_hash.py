import bcrypt

password = "Admin@2025"
hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(12)).decode()
print(f"Password: {password}")
print(f"Hash: {hash}")
