UPDATE users SET password_hash = '$2b$12$FDrUkITsyeSO3h0DiFj3LuuOl4F2UwhnsziOZcdFsokdjdxpG4iD.' WHERE username = 'admin';
SELECT username, length(password_hash) as hash_len FROM users WHERE username = 'admin';
