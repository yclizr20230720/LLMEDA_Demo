-- Update all user passwords to use the correct hash for 'Admin@2025'
UPDATE users SET password_hash = '$2b$12$FDrUkITsyeSO3h0DiFj3LuuOl4F2UwhnsziOZcdFsokdjdxpG4iD.' WHERE username IN ('admin', 'chen_wei', 'li_ming', 'wang_fang', 'fab_op1');
SELECT username, role, length(password_hash) as hash_len FROM users ORDER BY role;
