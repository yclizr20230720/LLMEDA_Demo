"""SEMFAB·IQ Flask Application Entry Point."""
import os
from app import create_app, socketio
from app.config import config_map

env = os.environ.get("FLASK_ENV", "development")
config = config_map.get(env, config_map["default"])
app = create_app(config)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    socketio.run(app, host="0.0.0.0", port=port, debug=app.config.get("DEBUG", False))
