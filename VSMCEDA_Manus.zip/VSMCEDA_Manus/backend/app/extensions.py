"""Flask extensions and database helpers."""
from flask_sqlalchemy import SQLAlchemy
import redis
import os
from loguru import logger

db = SQLAlchemy()

# Redis client (lazy init)
_redis_client = None


def get_redis():
    global _redis_client
    if _redis_client is None:
        try:
            _redis_client = redis.from_url(
                os.environ.get("REDIS_URL", "redis://localhost:6379/0"),
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5
            )
            _redis_client.ping()
        except Exception as e:
            logger.warning(f"Redis unavailable: {e}. Caching disabled.")
            _redis_client = None
    return _redis_client


# Alias for backward compatibility
redis_client = get_redis
