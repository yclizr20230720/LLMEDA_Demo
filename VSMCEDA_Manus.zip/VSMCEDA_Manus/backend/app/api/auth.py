"""Authentication API — JWT-based login/logout/refresh."""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from ..utils.db_utils import execute_query, execute_write, serialize_rows
import bcrypt
from datetime import datetime
from loguru import logger

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """Authenticate user and return JWT tokens."""
    data = request.get_json()
    if not data or not data.get("username") or not data.get("password"):
        return jsonify({"error": "Username and password required"}), 400

    rows = execute_query(
        "SELECT * FROM users WHERE username = :username AND is_active = TRUE",
        {"username": data["username"]}
    )
    if not rows:
        return jsonify({"error": "Invalid credentials"}), 401

    user = rows[0]
    try:
        if not bcrypt.checkpw(data["password"].encode(), user["password_hash"].encode()):
            return jsonify({"error": "Invalid credentials"}), 401
    except Exception:
        return jsonify({"error": "Invalid credentials"}), 401

    # Update last login
    execute_write(
        "UPDATE users SET last_login = :now WHERE user_sk = :sk",
        {"now": datetime.utcnow(), "sk": user["user_sk"]}
    )

    identity = str(user["user_id"])
    additional_claims = {
        "username": user["username"],
        "role": user["role"],
        "full_name": user["full_name"],
        "fab_id": user["fab_id"]
    }

    access_token = create_access_token(identity=identity, additional_claims=additional_claims)
    refresh_token = create_refresh_token(identity=identity)

    logger.info(f"User {user['username']} logged in successfully")
    return jsonify({
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user": {
            "user_id": str(user["user_id"]),
            "username": user["username"],
            "full_name": user["full_name"],
            "role": user["role"],
            "department": user["department"],
            "fab_id": user["fab_id"]
        }
    })


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    """Refresh access token."""
    identity = get_jwt_identity()
    rows = execute_query(
        "SELECT * FROM users WHERE user_id = :uid AND is_active = TRUE",
        {"uid": identity}
    )
    if not rows:
        return jsonify({"error": "User not found"}), 404
    user = rows[0]
    additional_claims = {
        "username": user["username"],
        "role": user["role"],
        "full_name": user["full_name"],
        "fab_id": user["fab_id"]
    }
    access_token = create_access_token(identity=identity, additional_claims=additional_claims)
    return jsonify({"access_token": access_token})


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    """Get current user profile."""
    identity = get_jwt_identity()
    claims = get_jwt()
    rows = execute_query(
        "SELECT user_id, username, full_name, role, department, fab_id, last_login, created_at FROM users WHERE user_id = :uid",
        {"uid": identity}
    )
    if not rows:
        return jsonify({"error": "User not found"}), 404
    user = rows[0]
    return jsonify({
        "user_id": str(user["user_id"]),
        "username": user["username"],
        "full_name": user["full_name"],
        "role": user["role"],
        "department": user["department"],
        "fab_id": user["fab_id"],
        "last_login": user["last_login"].isoformat() if user["last_login"] else None
    })


@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    """Logout (client should discard tokens)."""
    claims = get_jwt()
    logger.info(f"User {claims.get('username')} logged out")
    return jsonify({"message": "Logged out successfully"})


@auth_bp.route("/change-password", methods=["POST"])
@jwt_required()
def change_password():
    """Change user password."""
    identity = get_jwt_identity()
    data = request.get_json()
    if not data or not data.get("current_password") or not data.get("new_password"):
        return jsonify({"error": "Current and new password required"}), 400

    rows = execute_query("SELECT * FROM users WHERE user_id = :uid", {"uid": identity})
    if not rows:
        return jsonify({"error": "User not found"}), 404
    user = rows[0]

    if not bcrypt.checkpw(data["current_password"].encode(), user["password_hash"].encode()):
        return jsonify({"error": "Current password incorrect"}), 401

    new_hash = bcrypt.hashpw(data["new_password"].encode(), bcrypt.gensalt(12)).decode()
    execute_write(
        "UPDATE users SET password_hash = :hash, updated_at = NOW() WHERE user_id = :uid",
        {"hash": new_hash, "uid": identity}
    )
    return jsonify({"message": "Password changed successfully"})
