"""FDC Monitor API — Fault detection, trace analysis, PM events."""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from ..utils.db_utils import execute_query, serialize_rows
import random, math, numpy as np
from datetime import datetime, timedelta

fdc_bp = Blueprint("fdc", __name__)

SENSORS = ["Bottom_RF_Forward_Power","Bottom_RF_Reflected_Power","Chamber_Pressure",
           "Gas_Ar_Flow","Gas_CF4_Flow","ESC_Temperature","Bias_Voltage","Endpoint_Signal","Helium_Backpressure"]


def gen_trace(sensor: str, n: int = 200, anomaly: bool = False):
    """Generate synthetic sensor trace."""
    base = random.uniform(50, 300)
    sigma = base * 0.03
    data = []
    for i in range(n):
        val = base + math.sin(i / 20) * sigma * 2 + random.gauss(0, sigma)
        if anomaly and 130 <= i <= 160:
            val += sigma * (3 + random.random() * 2)
        data.append({"time_offset_ms": i * 50, "value": round(val, 4), "is_anomaly_point": anomaly and 130 <= i <= 160})
    return data


@fdc_bp.route("/equipment/<equipment_id>/runs", methods=["GET"])
@jwt_required(optional=True)
def get_runs(equipment_id):
    """Get recent trace runs for equipment."""
    limit = int(request.args.get("limit", 20))
    try:
        rows = execute_query("""
            SELECT run_id::text, lot_id, wafer_id, equipment_id, chamber_id, recipe_id,
                   run_start_time, run_end_time, run_duration_sec, run_result,
                   alarm_count, composite_anomaly_score, event_date
            FROM fdc_fact_trace_run
            WHERE equipment_id = :equip
            ORDER BY run_start_time DESC LIMIT :limit
        """, {"equip": equipment_id, "limit": limit})
        if rows:
            return jsonify([{k: str(v) if hasattr(v,'isoformat') else v for k, v in r.items()} for r in rows])
    except Exception:
        pass
    runs = []
    for i in range(min(limit, 10)):
        anomaly = random.random() < 0.15
        runs.append({
            "run_id": f"RUN-{equipment_id}-{i:04d}",
            "lot_id": f"M90000{random.randint(1,8)}",
            "equipment_id": equipment_id,
            "run_start_time": (datetime.utcnow() - timedelta(hours=i*2)).isoformat(),
            "run_result": "ANOMALY" if anomaly else "NORMAL",
            "alarm_count": random.randint(1, 5) if anomaly else 0,
            "composite_anomaly_score": round(random.uniform(0.7, 0.99) if anomaly else random.uniform(0.0, 0.3), 4)
        })
    return jsonify(runs)


@fdc_bp.route("/runs/<run_id>/trace", methods=["GET"])
@jwt_required(optional=True)
def get_trace(run_id):
    """Get sensor trace data for a run."""
    sensors = request.args.getlist("sensors") or SENSORS[:5]
    try:
        rows = execute_query("""
            SELECT sensor_alias, time_offset_ms, value, is_anomaly_point, baseline_mean, baseline_std
            FROM fdc_fact_trace_data
            WHERE run_id = :run_id::uuid AND sensor_alias = ANY(:sensors)
            ORDER BY sensor_alias, time_offset_ms
        """, {"run_id": run_id, "sensors": sensors})
        if rows:
            result = {}
            for r in rows:
                s = r["sensor_alias"]
                if s not in result:
                    result[s] = []
                result[s].append({"time_offset_ms": r["time_offset_ms"], "value": float(r["value"]), "is_anomaly_point": r["is_anomaly_point"]})
            return jsonify(result)
    except Exception:
        pass
    result = {}
    anomaly = random.random() < 0.3
    for s in sensors:
        result[s] = gen_trace(s, 200, anomaly and s == sensors[0])
    return jsonify(result)


@fdc_bp.route("/equipment/<equipment_id>/anomaly-score", methods=["GET"])
@jwt_required(optional=True)
def get_anomaly_score(equipment_id):
    """Get composite anomaly score time series."""
    n = int(request.args.get("n", 50))
    data = []
    base = 0.15
    for i in range(n):
        score = base + math.sin(i / 8) * 0.1 + random.gauss(0, 0.05)
        if 35 <= i <= 40:
            score += 0.6 + random.gauss(0, 0.1)
        data.append({"index": i, "score": round(max(0, min(1, score)), 4), "threshold": 0.95})
    return jsonify({"data": data, "equipment_id": equipment_id, "threshold": 0.95})


@fdc_bp.route("/equipment/<equipment_id>/feature-spc", methods=["GET"])
@jwt_required(optional=True)
def get_feature_spc(equipment_id):
    """Get FDC Feature SPC indicator data."""
    indicators = [
        {"indicator_id": "Bottom_RF_Forward_Power_MEAN", "priority": "HIGH", "sensor": "Bottom_RF_Forward_Power"},
        {"indicator_id": "Chamber_Pressure_MAX", "priority": "HIGH", "sensor": "Chamber_Pressure"},
        {"indicator_id": "Gas_Ar_Flow_MEAN", "priority": "MEDIUM", "sensor": "Gas_Ar_Flow"},
        {"indicator_id": "ESC_Temperature_MEAN", "priority": "MEDIUM", "sensor": "ESC_Temperature"},
        {"indicator_id": "Bias_Voltage_MEAN", "priority": "LOW", "sensor": "Bias_Voltage"},
    ]
    result = []
    for ind in indicators:
        base = random.uniform(100, 300)
        sigma = base * 0.04
        cl = base
        ucl = cl + 3 * sigma
        lcl = cl - 3 * sigma
        points = []
        for i in range(40):
            val = cl + math.sin(i/10) * sigma + random.gauss(0, sigma * 0.5)
            if i == 35:
                val += sigma * 3.5
            points.append({"index": i, "value": round(val, 3), "violation": abs(val - cl) > 3 * sigma})
        result.append({**ind, "cl": round(cl, 3), "ucl": round(ucl, 3), "lcl": round(lcl, 3),
                       "points": points, "alarm_count": sum(1 for p in points if p["violation"])})
    return jsonify(result)


@fdc_bp.route("/equipment/<equipment_id>/pm-events", methods=["GET"])
@jwt_required(optional=True)
def get_pm_events(equipment_id):
    """Get PM event history."""
    try:
        rows = execute_query("""
            SELECT equipment_id, chamber_id, pm_type, pm_start_time, pm_end_time,
                   pm_duration_hr, pre_pm_health_score, post_pm_health_score,
                   health_improvement, qualification_passed, wafers_impacted, event_date
            FROM fdc_fact_pm_event WHERE equipment_id = :equip ORDER BY pm_start_time DESC LIMIT 10
        """, {"equip": equipment_id})
        if rows:
            return jsonify([{k: str(v) if hasattr(v,'isoformat') else v for k, v in r.items()} for r in rows])
    except Exception:
        pass
    events = []
    for i in range(4):
        pre = round(random.uniform(55, 75), 1)
        post = round(random.uniform(85, 98), 1)
        events.append({
            "equipment_id": equipment_id,
            "pm_type": random.choice(["FULL_PM", "CHAMBER_CLEAN", "PAD_CHANGE", "QUAL_RUN"]),
            "pm_start_time": (datetime.utcnow() - timedelta(days=i*25)).isoformat(),
            "pm_duration_hr": round(random.uniform(2, 8), 1),
            "pre_pm_health_score": pre, "post_pm_health_score": post,
            "health_improvement": round(post - pre, 1),
            "qualification_passed": True, "wafers_impacted": random.randint(5, 25)
        })
    return jsonify(events)
