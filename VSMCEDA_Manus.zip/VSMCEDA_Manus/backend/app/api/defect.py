"""Defect Analysis API — DMS, ADC, WPA, defect pareto."""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from ..utils.db_utils import execute_query, serialize_rows
import random, math
from datetime import datetime, timedelta

defect_bp = Blueprint("defect", __name__)

DEFECT_CLASSES = ["Active_Bridging","Active_Micromask","Ball_Defects","Blocked_Etch",
                  "C_Residue","Colour_Variation","Cu_Crater","Cu_Hillock","Cu_Missing",
                  "Cu_Residue","Cu_Surface_Erosion","Defocus","Embedded_Big_Particles",
                  "Embedded_Small_Particles","Film_Bump","Flake","Killer_Scratch",
                  "Micro_Scratch","Missing_Holes","Optical_Visible_Defect"]

PATTERNS = ["NORMAL","EDGE","RING","CLUSTER","SCRATCH","LINEAR"]
COLORS = ["#00E5C4","#FF4F6A","#8B5CF6","#F59E0B","#38BDF8","#84CC16",
          "#EC4899","#22C55E","#EAB308","#F97316","#06B6D4","#A855F7",
          "#EF4444","#10B981","#6366F1","#F43F5E","#14B8A6","#FB923C","#8B5CF6","#D946EF"]


@defect_bp.route("/pareto", methods=["GET"])
@jwt_required(optional=True)
def get_defect_pareto():
    """Get defect count pareto by process steps."""
    limit = int(request.args.get("limit", 20))
    try:
        rows = execute_query("""
            SELECT d.lot_id, d.wafer_id, d.final_class, COUNT(*) AS defect_count,
                   ws.gross_yield_pct
            FROM def_fact_defect d
            LEFT JOIN cp_fact_wafer_summary ws ON ws.lot_id = d.lot_id AND ws.wafer_id = d.wafer_id
            WHERE d.event_date >= CURRENT_DATE - INTERVAL '30 days'
            GROUP BY d.lot_id, d.wafer_id, d.final_class, ws.gross_yield_pct
            ORDER BY d.lot_id, defect_count DESC
            LIMIT :limit
        """, {"limit": limit})
        if rows:
            return jsonify([{k: v for k, v in r.items()} for r in rows])
    except Exception:
        pass
    # Synthetic pareto
    wafer_ids = [f"L4095{i:04d}_{j}" for i in range(1000, 1020) for j in [20, 25]][:20]
    data = []
    for wid in wafer_ids:
        defects = {}
        total = random.randint(50, 500)
        remaining = total
        for cls in random.sample(DEFECT_CLASSES, random.randint(3, 8)):
            count = random.randint(5, remaining // 2)
            defects[cls] = count
            remaining -= count
            if remaining <= 0:
                break
        yield_pct = round(max(40, 95 - total * 0.08 + random.gauss(0, 2)), 2)
        data.append({"wafer_id": wid, "defects": defects, "total_defects": total, "yield_pct": yield_pct})
    return jsonify({"wafers": data, "classes": DEFECT_CLASSES, "colors": COLORS})


@defect_bp.route("/wafer-map", methods=["GET"])
@jwt_required(optional=True)
def get_wafer_map():
    """Get defect wafer map for a specific wafer."""
    lot_id = request.args.get("lot_id", "M900001")
    wafer_id = request.args.get("wafer_id", "M900001_W01")
    pattern = request.args.get("pattern", "NORMAL")

    try:
        rows = execute_query("""
            SELECT defect_x_um, defect_y_um, die_x, die_y, defect_size_nm,
                   final_class, adc_class, adc_confidence, is_killer, kill_probability
            FROM def_fact_defect
            WHERE lot_id = :lot_id AND wafer_id = :wafer_id
            ORDER BY defect_size_nm DESC LIMIT 500
        """, {"lot_id": lot_id, "wafer_id": wafer_id})
        if rows:
            return jsonify({"defects": [{k: float(v) if isinstance(v,(int,float)) and v is not None else v for k, v in r.items()} for r in rows], "pattern": pattern})
    except Exception:
        pass
    # Generate synthetic defect map
    defects = []
    n = random.randint(50, 300)
    radius = 145  # mm
    for _ in range(n):
        if pattern == "EDGE":
            r = random.uniform(radius * 0.8, radius * 0.98)
            theta = random.uniform(0, 2 * math.pi)
        elif pattern == "RING":
            r = random.uniform(radius * 0.55, radius * 0.75)
            theta = random.uniform(0, 2 * math.pi)
        elif pattern == "CLUSTER":
            cx, cy = random.uniform(-50, 50), random.uniform(-50, 50)
            r_local = random.gauss(0, 20)
            theta_local = random.uniform(0, 2 * math.pi)
            x = cx + r_local * math.cos(theta_local)
            y = cy + r_local * math.sin(theta_local)
            defects.append({"x": round(x, 2), "y": round(y, 2), "size_nm": round(random.uniform(50, 500), 1),
                            "class": random.choice(DEFECT_CLASSES[:8]), "is_killer": random.random() < 0.1})
            continue
        else:
            r = random.uniform(0, radius * 0.95)
            theta = random.uniform(0, 2 * math.pi)
        x = r * math.cos(theta)
        y = r * math.sin(theta)
        defects.append({"x": round(x, 2), "y": round(y, 2), "size_nm": round(random.uniform(50, 800), 1),
                        "class": random.choice(DEFECT_CLASSES), "is_killer": random.random() < 0.08})
    return jsonify({"defects": defects, "pattern": pattern, "total": len(defects),
                    "killer_count": sum(1 for d in defects if d["is_killer"])})


@defect_bp.route("/adc-gallery", methods=["GET"])
@jwt_required(optional=True)
def get_adc_gallery():
    """Get ADC classification image gallery."""
    classes = ["PARTICLE", "SCRATCH", "CRYSTAL", "BRIDGE", "VOID", "BUMP"]
    images = []
    for cls in classes:
        for i in range(random.randint(4, 8)):
            images.append({
                "id": f"{cls}_{i:03d}",
                "defect_class": cls,
                "adc_confidence": round(random.uniform(0.75, 0.99), 3),
                "defect_size_nm": round(random.uniform(80, 600), 1),
                "layer": random.choice(["M1", "VIA1", "PO", "CT", "GO"]),
                "lot_id": f"M90000{random.randint(1,8)}",
                "image_url": f"/api/defect/images/{cls.lower()}_{i:03d}.png"
            })
    return jsonify({"images": images, "classes": classes})


@defect_bp.route("/wpa-patterns", methods=["GET"])
@jwt_required(optional=True)
def get_wpa_patterns():
    """Get WPA spatial pattern analysis results."""
    lots = [f"M90000{i}" for i in range(1, 9)]
    results = []
    for lot in lots:
        pattern = random.choice(PATTERNS)
        results.append({
            "lot_id": lot,
            "wafer_id": f"{lot}_W01",
            "pattern_type": pattern,
            "confidence": round(random.uniform(0.72, 0.98), 3),
            "defect_count": random.randint(50, 400),
            "yield_impact_pct": round(random.uniform(0.5, 8.5), 2),
            "suspected_equipment": random.choice(["CMP-01", "CMP-02", "CMP-03", "ETCH-01", "ETCH-02"]),
            "hypothesis_confidence": round(random.uniform(0.6, 0.95), 3)
        })
    return jsonify(results)
