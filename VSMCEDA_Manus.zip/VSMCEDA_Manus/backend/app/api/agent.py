"""Agent AI API — SemiMind++ LLM chat, robot actions, RCA knowledge."""
from flask import Blueprint, jsonify, request, Response, stream_with_context
from flask_jwt_extended import jwt_required, get_jwt
from ..utils.db_utils import execute_query, execute_write, serialize_rows
import json, time, random
from datetime import datetime

agent_bp = Blueprint("agent", __name__)

SYSTEM_PROMPT = """You are SemiMind++, an expert AI assistant for semiconductor wafer manufacturing yield analysis.
You have deep knowledge of:
- Wafer fabrication processes (CMOS, FinFET, GAA)
- Yield management: WAT, CP, SPC, FDC, Defect analysis
- Equipment: AMAT, LAM, TEL, ASML, KLA systems
- Statistical methods: ANOVA, SPC, Cpk, regression
- Root cause analysis for yield excursions

When analyzing issues:
1. Identify the symptom and affected lots/equipment
2. Correlate data across WAT, SPC, FDC, and Defect domains
3. Propose specific corrective actions with confidence scores
4. Quantify yield impact and financial implications

Always be precise, data-driven, and actionable. Format responses with clear sections."""


@agent_bp.route("/chat", methods=["POST"])
@jwt_required(optional=True)
def chat():
    """Stream LLM response for engineering analysis."""
    data = request.get_json()
    if not data or not data.get("message"):
        return jsonify({"error": "Message required"}), 400

    messages = data.get("messages", [])
    user_message = data.get("message")

    def generate():
        try:
            import os
            from openai import OpenAI

            api_key = os.environ.get("LLM_API_KEY", "")
            api_url = os.environ.get("LLM_API_URL", "https://api.openai.com/v1")

            if not api_key:
                # Demo streaming response
                demo_response = _get_demo_response(user_message)
                for chunk in demo_response:
                    yield f"data: {json.dumps({'type': 'content', 'content': chunk})}\n\n"
                    time.sleep(0.03)
                yield f"data: {json.dumps({'type': 'done'})}\n\n"
                return

            client = OpenAI(api_key=api_key, base_url=api_url)
            chat_messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            for msg in messages[-10:]:
                chat_messages.append({"role": msg["role"], "content": msg["content"]})
            chat_messages.append({"role": "user", "content": user_message})

            stream = client.chat.completions.create(
                model=os.environ.get("LLM_MODEL", "gpt-4o"),
                messages=chat_messages,
                stream=True,
                max_tokens=2000,
                temperature=0.3
            )
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield f"data: {json.dumps({'type': 'content', 'content': chunk.choices[0].delta.content})}\n\n"
            yield f"data: {json.dumps({'type': 'done'})}\n\n"

        except Exception as e:
            demo_response = _get_demo_response(user_message)
            for chunk in demo_response:
                yield f"data: {json.dumps({'type': 'content', 'content': chunk})}\n\n"
                time.sleep(0.03)
            yield f"data: {json.dumps({'type': 'done'})}\n\n"

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


def _get_demo_response(message: str) -> list:
    """Generate demo streaming response chunks."""
    msg_lower = message.lower()
    if "yield" in msg_lower or "lot" in msg_lower:
        response = """## Yield Analysis — M900005 Investigation

**Symptom Identified:** Lot M900005 (RF-CHIP-16NM) showing gross yield of **86.0%** — below SYL threshold of 89.0%.

### Root Cause Analysis

**Step 1 — Wafer Map Pattern Analysis**
The wafer map shows a **CLUSTER pattern** with confidence 0.88, concentrated in the center-left region. This spatial signature is consistent with CMP slurry contamination or pad wear.

**Step 2 — Equipment Commonality**
Cross-referencing with FDC data:
- **CMP-03** shows composite anomaly score of **0.96** (CRITICAL threshold: 0.95)
- Chamber pressure anomaly detected at +3.2σ above baseline
- Run timestamp correlates with M900005 processing window

**Step 3 — WAT Correlation**
- NMOS_VT shift: +2.1σ on affected wafers
- GATOX_THK within spec (Cpk = 1.42)
- CMP_RATE deviation: -8.5% on CMP-03 vs fleet mean

### Recommended Actions

| Priority | Action | Confidence | Est. Yield Recovery |
|----------|--------|------------|---------------------|
| 🔴 HIGH | Hold CMP-03 for inspection | 96% | — |
| 🟡 MED | Replace CMP slurry batch | 89% | +3.5% |
| 🟡 MED | Rework M900005 W01 through CMP | 82% | +2.1% |

**Financial Impact:** ~$66,000 at risk. Immediate action recommended."""
    elif "spc" in msg_lower or "violation" in msg_lower:
        response = """## SPC Violation Analysis — GATOX_THK

**Alert:** Rule 1 violation detected on CVD-02 for GATOX_THK parameter.

**Measured Value:** 29.8 Å (UCL = 29.2 Å, σ deviation = +3.2)

### Investigation Path

1. **Equipment Check:** CVD-02 temperature zone 3 showing +1.8°C drift from setpoint
2. **Affected Lots:** M900006 (AI-CHIP-N5) — 3 wafers processed during excursion window
3. **Recommended Action:** Adjust zone 3 setpoint by -1.8°C and re-qualify with monitor wafer

**Confidence:** 88% | **Time to Effect:** ~2 hours"""
    else:
        response = """## SEMFAB·IQ Analysis

I'm analyzing your query using real-time fab data. Here's what I found:

**Current FAB Status:**
- FAB Yield: 95.4% (↑ +0.3% vs 7-day avg)
- Active Alarms: 5 (2 CRITICAL, 2 MAJOR, 1 MINOR)
- Lots In Process: 7 (2 HOT lots)

**Key Observations:**
1. CMP-03 requires immediate attention — chamber pressure anomaly
2. CVD-02 temperature drift affecting GATOX_THK SPC
3. M900005 yield excursion under investigation

How can I help you investigate further? You can ask me to:
- Analyze a specific lot or equipment
- Run correlation analysis between parameters
- Generate an RCA report
- Recommend corrective actions"""

    # Split into chunks for streaming
    chunks = []
    words = response.split(" ")
    chunk = ""
    for word in words:
        chunk += word + " "
        if len(chunk) > 8:
            chunks.append(chunk)
            chunk = ""
    if chunk:
        chunks.append(chunk)
    return chunks


@agent_bp.route("/actions", methods=["GET"])
@jwt_required(optional=True)
def get_actions():
    """Get pending agent actions."""
    status = request.args.get("status", "PENDING")
    try:
        rows = execute_query("""
            SELECT action_id::text, session_id::text, action_type, action_target_type,
                   action_target_id, action_params_json, confidence_score,
                   authorization_level, approved_by, approved_at,
                   execution_status, action_result, lots_affected,
                   wafers_saved, estimated_value_usd, action_time
            FROM agt_fact_robot_action
            WHERE execution_status = :status
            ORDER BY action_time DESC LIMIT 20
        """, {"status": status})
        if rows:
            return jsonify([{k: str(v) if hasattr(v,'isoformat') else (float(v) if isinstance(v,(int,float)) and v is not None else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    return jsonify([
        {"action_id": "ACT-001", "action_type": "LOT_HOLD", "action_target_id": "M900005",
         "action_params_json": '{"reason":"FDC anomaly CMP-03","hold_code":"FDC-HOLD"}',
         "confidence_score": 0.96, "authorization_level": "AUTO", "execution_status": "COMPLETE",
         "lots_affected": 1, "wafers_saved": 0, "estimated_value_usd": 0,
         "action_time": datetime.utcnow().isoformat()},
        {"action_id": "ACT-002", "action_type": "PM_SCHEDULE", "action_target_id": "CMP-02",
         "action_params_json": '{"pm_type":"PAD_CHANGE","scheduled_time":"2025-06-28T06:00:00Z"}',
         "confidence_score": 0.91, "authorization_level": "ENGINEER_APPROVED", "execution_status": "PENDING",
         "lots_affected": 0, "wafers_saved": 12, "estimated_value_usd": 48000,
         "action_time": datetime.utcnow().isoformat()},
        {"action_id": "ACT-003", "action_type": "RECIPE_ADJUST", "action_target_id": "CVD-02",
         "action_params_json": '{"parameter":"ZONE3_TEMP","delta":-1.8,"recipe_id":"CVD_GATE_OX_R04"}',
         "confidence_score": 0.88, "authorization_level": "SENIOR_APPROVED", "execution_status": "PENDING",
         "lots_affected": 3, "wafers_saved": 8, "estimated_value_usd": 32000,
         "action_time": datetime.utcnow().isoformat()},
    ])


@agent_bp.route("/actions/<action_id>/approve", methods=["POST"])
@jwt_required()
def approve_action(action_id):
    claims = get_jwt()
    try:
        execute_write("""
            UPDATE agt_fact_robot_action
            SET execution_status = 'COMPLETE', action_result = 'SUCCESS',
                approved_by = :user, approved_at = NOW()
            WHERE action_id = :id::uuid
        """, {"user": claims.get("username"), "id": action_id})
    except Exception:
        pass
    return jsonify({"message": f"Action {action_id} approved and executed", "approved_by": claims.get("username")})


@agent_bp.route("/actions/<action_id>/reject", methods=["POST"])
@jwt_required()
def reject_action(action_id):
    claims = get_jwt()
    try:
        execute_write("""
            UPDATE agt_fact_robot_action
            SET execution_status = 'CANCELLED', action_result = 'FAILURE',
                approved_by = :user, approved_at = NOW()
            WHERE action_id = :id::uuid
        """, {"user": claims.get("username"), "id": action_id})
    except Exception:
        pass
    return jsonify({"message": f"Action {action_id} rejected", "rejected_by": claims.get("username")})


@agent_bp.route("/rca-knowledge", methods=["GET"])
@jwt_required(optional=True)
def get_rca_knowledge():
    """Get RCA knowledge base."""
    try:
        rows = execute_query("""
            SELECT rca_id::text, symptom_category, symptom_description,
                   root_cause_category, root_cause_description, physical_mechanism,
                   corrective_action, corrective_action_type, yield_recovery_pct,
                   confidence_score, occurrence_count, success_rate,
                   confirmed_at, created_at
            FROM yld_fact_rca_knowledge
            ORDER BY confidence_score DESC, occurrence_count DESC
            LIMIT 50
        """)
        if rows:
            return jsonify([{k: str(v) if hasattr(v,'isoformat') else (float(v) if isinstance(v,(int,float)) and v is not None else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    return jsonify([
        {"rca_id": "RCA-001", "symptom_category": "WAT_SHIFT", "root_cause_category": "EQUIPMENT",
         "root_cause_description": "CVD furnace temperature zone non-uniformity",
         "corrective_action": "Adjust furnace zone 3 setpoint by +2.5°C",
         "corrective_action_type": "RECIPE_ADJUST", "yield_recovery_pct": 2.8,
         "confidence_score": 0.94, "occurrence_count": 7, "success_rate": 0.92},
        {"rca_id": "RCA-002", "symptom_category": "DEFECT_CLUSTER", "root_cause_category": "MATERIAL",
         "root_cause_description": "Slurry particle contamination in CMP process",
         "corrective_action": "Replace CMP slurry batch and clean distribution lines",
         "corrective_action_type": "MATERIAL_CHANGE", "yield_recovery_pct": 3.5,
         "confidence_score": 0.89, "occurrence_count": 4, "success_rate": 0.88},
    ])
