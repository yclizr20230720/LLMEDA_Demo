"""Advanced Analytics API — MSC R&R, DPPM, Process Timeline, Smart Sampling."""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from ..utils.db_utils import execute_query
import random, math
from datetime import datetime, timedelta

advanced_bp = Blueprint("advanced", __name__)


@advanced_bp.route("/msc-rr", methods=["GET"])
@jwt_required(optional=True)
def get_msc_rr():
    """Get MSC R&R analysis results."""
    study_id = request.args.get("study_id", "MSC_2025_Q2")
    try:
        rows = execute_query("""
            SELECT study_id, test_name, unit, system_1_id, system_2_id,
                   q2, lpl, upl, rr_pct, repro_pct, repeat_pct, cpk_n,
                   rr_threshold, is_acceptable, study_date, product_id
            FROM msc_fact_rr_result WHERE study_id = :study_id ORDER BY test_name
        """, {"study_id": study_id})
        if rows:
            return jsonify([{k: float(v) if isinstance(v,(int,float)) and v is not None and k not in ['study_id','test_name','unit','system_1_id','system_2_id','product_id'] else (str(v) if hasattr(v,'isoformat') else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    tests = ["VC_14","VC_52","VC_DD","ISBH","VSU","NMOS_VT","PMOS_VT","GATOX_THK","POLY_CD","CMP_RATE"]
    return jsonify([{
        "test_name": t, "unit": random.choice(["V","UA","A","nm","Ohm"]),
        "system_1_id": "WAT-01", "system_2_id": "WAT-02",
        "q2": round(random.uniform(-5, 5), 3),
        "lpl": round(random.uniform(-6, -4), 3),
        "upl": round(random.uniform(4, 6) if random.random() > 0.2 else random.uniform(-15, -8), 3),
        "rr_pct": round(random.uniform(5, 110), 2),
        "repro_pct": round(random.uniform(3, 105), 2),
        "repeat_pct": round(random.uniform(2, 50), 2),
        "cpk_n": round(random.uniform(0.3, 2.5), 3),
        "rr_threshold": 10.0,
        "is_acceptable": random.random() > 0.4
    } for t in tests])


@advanced_bp.route("/dppm", methods=["GET"])
@jwt_required(optional=True)
def get_dppm():
    """Get DPPM vs burn-in model data."""
    product_id = request.args.get("product_id", "AI-CHIP-N5")
    try:
        rows = execute_query("""
            SELECT product_id, model_type, burnin_pct, dppm_value,
                   yield_gain_pct, excursion_reduction_pct, computed_date
            FROM rel_fact_dppm_model WHERE product_id = :product_id ORDER BY model_type, burnin_pct
        """, {"product_id": product_id})
        if rows:
            return jsonify([{k: float(v) if isinstance(v,(int,float)) and v is not None and k not in ['product_id','model_type'] else (str(v) if hasattr(v,'isoformat') else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    data = {"BEST": [], "AVERAGE": [], "WORST": []}
    params = {"BEST": (8, 0.08), "AVERAGE": (12, 0.06), "WORST": (18, 0.04)}
    for model, (a, b) in params.items():
        for i in range(21):
            burnin = i * 5
            dppm = max(0.3, a * math.exp(-burnin * b) + random.gauss(0, 0.3))
            data[model].append({"burnin_pct": burnin, "dppm_value": round(dppm, 3)})
    return jsonify({
        "models": data, "product_id": product_id,
        "optimal_burnin_pct": 65,
        "yield_gain_pct": 8.0,
        "excursion_reduction_pct": 40.0
    })


@advanced_bp.route("/process-timeline", methods=["GET"])
@jwt_required(optional=True)
def get_process_timeline():
    """Get equipment process timeline (Gantt) data."""
    equipment_type = request.args.get("equipment_type", "CVD")
    equipment_list = {
        "CVD": [("ULKCVD-01", "#EC4899"), ("ULKCVD-03", "#22C55E"), ("ULKCVD-04", "#EAB308"), ("ULKCVD-06", "#F97316")],
        "ETCH": [("ETCH-01", "#00E5C4"), ("ETCH-02", "#8B5CF6"), ("ETCH-03", "#FF4F6A")],
        "CMP": [("CMP-01", "#38BDF8"), ("CMP-02", "#F59E0B"), ("CMP-03", "#84CC16")],
    }
    equips = equipment_list.get(equipment_type, equipment_list["CVD"])
    steps = ["PURGE", "DEPO", "COOL", "UNLOAD"]
    result = []
    for eq_id, color in equips:
        timeline = []
        start = random.randint(0, 5)
        for step in steps:
            dur = {"PURGE": random.randint(10, 20), "DEPO": random.randint(40, 55),
                   "COOL": random.randint(15, 25), "UNLOAD": random.randint(8, 14)}[step]
            timeline.append({"step": step, "start": start, "duration": dur, "end": start + dur})
            start += dur + random.randint(2, 5)
        result.append({"equipment_id": eq_id, "color": color, "steps": timeline,
                       "total_duration": sum(s["duration"] for s in timeline)})
    return jsonify(result)


@advanced_bp.route("/smart-sampling", methods=["GET"])
@jwt_required(optional=True)
def get_smart_sampling():
    """Get smart sampling / prober optimization data."""
    product_id = request.args.get("product_id", "AI-CHIP-N5")
    return jsonify({
        "product_id": product_id,
        "original_touchdowns": 150,
        "optimized_touchdowns": 138,
        "reduction_pct": 8.0,
        "time_savings_min": 12,
        "yield_impact_pct": 0.05,
        "smart_sampling_active": True,
        "algorithm": "SPATIAL_CLUSTER_SKIP",
        "die_grid": {"rows": 20, "cols": 20, "radius": 145},
        "skip_zones": ["EDGE_3MM", "NOTCH_ZONE"],
        "skip_count": 12
    })


@advanced_bp.route("/anomaly-traces", methods=["GET"])
@jwt_required(optional=True)
def get_anomaly_traces():
    """Get anomaly vs reference trace comparison."""
    equipment_id = request.args.get("equipment_id", "ETCH-01")
    sensor = request.args.get("sensor", "Gas_Ar (sccm)_4_5")

    features = [
        {"name": "Gas_Ar (sccm)_4_5", "anom_count": 38, "ref_count": 90},
        {"name": "Max", "anom_count": 38, "ref_count": 95},
        {"name": "None", "anom_count": 38, "ref_count": 96},
        {"name": "Shape", "anom_count": 38, "ref_count": 95},
        {"name": "Mean", "anom_count": 38, "ref_count": 97},
    ]

    n = 100
    base = 100
    sigma = 15
    traces = {"reference": [], "anomaly": []}
    for i in range(n):
        ref_val = base + 20 * math.sin(i / 10 * math.pi) + random.gauss(0, sigma * 0.3)
        anom_val = ref_val + (25 + random.gauss(0, 5) if 60 <= i <= 80 else random.gauss(0, sigma * 0.2))
        traces["reference"].append({"t": i, "value": round(ref_val, 2)})
        traces["anomaly"].append({"t": i, "value": round(anom_val, 2)})

    return jsonify({
        "equipment_id": equipment_id,
        "selected_sensor": sensor,
        "features": features,
        "traces": traces,
        "anomaly_count": 429,
        "reference_count": 1071
    })
