"""YMS Dashboard API — KPIs, yield trend, alarms, wafer gallery."""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt
from ..utils.db_utils import execute_query, execute_scalar, serialize_rows, cached
from datetime import datetime, timedelta
import random
import math

dashboard_bp = Blueprint("dashboard", __name__)


def _require_role(*roles):
    """Check if current user has required role."""
    claims = get_jwt()
    return claims.get("role") in roles


@dashboard_bp.route("/kpis", methods=["GET"])
@jwt_required(optional=True)
def get_kpis():
    """Get fab-wide KPI metrics."""
    try:
        # Active alarms count
        active_alarms = execute_scalar(
            "SELECT COUNT(*) FROM rt_live_alarm WHERE status = 'OPEN'"
        ) or 0

        # Lots in process
        active_lots = execute_scalar(
            "SELECT COUNT(*) FROM mes_dim_lot WHERE lot_status = 'ACTIVE' AND is_current = TRUE"
        ) or 0

        # Average yield from recent wafer summaries
        fab_yield = execute_scalar("""
            SELECT ROUND(AVG(gross_yield_pct)::numeric, 1)
            FROM cp_fact_wafer_summary
            WHERE event_date >= CURRENT_DATE - INTERVAL '7 days'
        """)

        # Equipment OEE
        oee = execute_scalar("""
            SELECT ROUND(AVG(utilization_pct)::numeric, 1)
            FROM eqp_dim_equipment
            WHERE is_current = TRUE AND equipment_status = 'PRODUCTION'
        """)

        # Tools down
        tools_down = execute_scalar(
            "SELECT COUNT(*) FROM eqp_dim_equipment WHERE equipment_status = 'DOWN' AND is_current = TRUE"
        ) or 0

        # Agent actions today
        agent_actions = execute_scalar(
            "SELECT COUNT(*) FROM agt_fact_robot_action WHERE event_date = CURRENT_DATE"
        ) or 0

        return jsonify({
            "fabYield": str(fab_yield or "94.7"),
            "activeAlarms": int(active_alarms),
            "activeLots": int(active_lots),
            "oee": str(oee or "88.4"),
            "toolsDown": int(tools_down),
            "agentActions24h": int(agent_actions),
            "dppmFallout": "4.2",
            "timestamp": datetime.utcnow().isoformat()
        })
    except Exception as e:
        # Return demo data if DB not available
        return jsonify({
            "fabYield": "95.4",
            "activeAlarms": 5,
            "activeLots": 7,
            "oee": "69.3",
            "toolsDown": 1,
            "agentActions24h": 12,
            "dppmFallout": "4.2",
            "timestamp": datetime.utcnow().isoformat()
        })


@dashboard_bp.route("/yield-trend", methods=["GET"])
@jwt_required(optional=True)
def get_yield_trend():
    """Get 30-day yield trend data."""
    days = int(request.args.get("days", 30))
    product_id = request.args.get("product_id")

    try:
        sql = """
            SELECT
                event_date::text AS date,
                ROUND(AVG(gross_yield_pct)::numeric, 2) AS yield,
                COUNT(*) AS wafer_count
            FROM cp_fact_wafer_summary
            WHERE event_date >= CURRENT_DATE - INTERVAL ':days days'
            {product_filter}
            GROUP BY event_date
            ORDER BY event_date
        """.replace(":days days", f"{days} days")

        if product_id:
            sql = sql.replace("{product_filter}", "AND product_id = :product_id")
            rows = execute_query(sql, {"product_id": product_id})
        else:
            sql = sql.replace("{product_filter}", "")
            rows = execute_query(sql)

        if not rows:
            raise ValueError("No data")

        return jsonify([serialize_row(r) for r in rows])
    except Exception:
        # Generate synthetic trend
        base_date = datetime.now() - timedelta(days=days)
        trend = []
        base_yield = 94.5
        for i in range(days):
            date = (base_date + timedelta(days=i)).strftime("%Y-%m-%d")
            noise = random.gauss(0, 0.8)
            drift = math.sin(i / 8) * 0.6
            excursion = -4.5 if 18 <= i <= 22 else 0
            y = round(base_yield + noise + drift + excursion, 2)
            trend.append({
                "date": date,
                "yield": max(80.0, min(100.0, y)),
                "ucl": 97.5,
                "lcl": 90.0,
                "cl": 94.2,
                "wafer_count": random.randint(15, 30)
            })
        return jsonify(trend)


def serialize_row(row):
    result = {}
    for k, v in row.items():
        if hasattr(v, 'isoformat'):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result


@dashboard_bp.route("/alarms", methods=["GET"])
@jwt_required(optional=True)
def get_alarms():
    """Get active alarm feed."""
    limit = int(request.args.get("limit", 20))
    severity = request.args.get("severity")

    try:
        sql = """
            SELECT alarm_id, alarm_uuid::text, alarm_source, alarm_type,
                   equipment_id, lot_id, step_id, parameter_id,
                   severity, alarm_code, alarm_message,
                   measured_value, threshold_value, sigma_deviation,
                   status, acknowledged_by, acknowledged_at,
                   agent_rca_summary, auto_action_taken,
                   alarm_time
            FROM rt_live_alarm
            WHERE status IN ('OPEN', 'ACK', 'INVESTIGATING')
            {sev_filter}
            ORDER BY
                CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'MAJOR' THEN 2 WHEN 'MINOR' THEN 3 ELSE 4 END,
                alarm_time DESC
            LIMIT :limit
        """
        if severity:
            sql = sql.replace("{sev_filter}", "AND severity = :severity")
            rows = execute_query(sql, {"limit": limit, "severity": severity})
        else:
            sql = sql.replace("{sev_filter}", "")
            rows = execute_query(sql, {"limit": limit})

        return jsonify([serialize_row(r) for r in rows])
    except Exception:
        return jsonify([
            {"alarm_id": 1, "severity": "CRITICAL", "alarm_source": "FDC", "equipment_id": "CMP-03",
             "alarm_code": "FDC-E001", "alarm_message": "Chamber pressure anomaly detected - 3.2σ above baseline",
             "lot_id": "M900005", "status": "OPEN", "alarm_time": datetime.utcnow().isoformat()},
            {"alarm_id": 2, "severity": "CRITICAL", "alarm_source": "FDC", "equipment_id": "ETCH-03",
             "alarm_code": "FDC-E002", "alarm_message": "RF power reflected exceeds threshold - potential match failure",
             "lot_id": "M900002", "status": "OPEN", "alarm_time": (datetime.utcnow() - timedelta(minutes=5)).isoformat()},
            {"alarm_id": 3, "severity": "MAJOR", "alarm_source": "FDC", "equipment_id": "CMP-02",
             "alarm_code": "PM-W001", "alarm_message": "Polishing pad wear indicator at 87% - schedule PM",
             "lot_id": "M900005", "status": "OPEN", "alarm_time": (datetime.utcnow() - timedelta(minutes=15)).isoformat()},
            {"alarm_id": 4, "severity": "MAJOR", "alarm_source": "SPC", "equipment_id": "CVD-02",
             "alarm_code": "SPC-R005", "alarm_message": "Temperature zone 3 drifting +1.8°C from setpoint",
             "lot_id": "M900006", "status": "OPEN", "alarm_time": (datetime.utcnow() - timedelta(minutes=30)).isoformat()},
            {"alarm_id": 5, "severity": "MINOR", "alarm_source": "FDC", "equipment_id": "INSP-01",
             "alarm_code": "FDC-I001", "alarm_message": "Defect density spike on lot M900004 - edge ring pattern",
             "lot_id": "M900004", "status": "OPEN", "alarm_time": (datetime.utcnow() - timedelta(hours=1)).isoformat()},
        ])


@dashboard_bp.route("/alarms/<int:alarm_id>/ack", methods=["POST"])
@jwt_required()
def ack_alarm(alarm_id):
    """Acknowledge an alarm."""
    claims = get_jwt()
    from ..utils.db_utils import execute_write
    try:
        execute_write(
            """UPDATE rt_live_alarm
               SET status = 'ACK', acknowledged_by = :user, acknowledged_at = NOW()
               WHERE alarm_id = :id""",
            {"user": claims.get("username"), "id": alarm_id}
        )
        return jsonify({"message": f"Alarm {alarm_id} acknowledged"})
    except Exception as e:
        return jsonify({"message": f"Alarm {alarm_id} acknowledged (demo mode)"}), 200


@dashboard_bp.route("/wafer-gallery", methods=["GET"])
@jwt_required(optional=True)
def get_wafer_gallery():
    """Get active lot wafer gallery data."""
    try:
        lots_sql = """
            SELECT l.lot_id, l.product_id, l.process_node, l.lot_status,
                   l.lot_subtype, l.customer_id,
                   CASE WHEN l.lot_subtype = 'HOT_LOT' THEN TRUE ELSE FALSE END AS is_hot
            FROM mes_dim_lot l
            WHERE l.lot_status = 'ACTIVE' AND l.is_current = TRUE
            ORDER BY l.lot_priority ASC, l.lot_start_date DESC
            LIMIT 8
        """
        lots = execute_query(lots_sql)
        if not lots:
            raise ValueError("No lots")

        gallery = []
        patterns = ["NORMAL", "EDGE", "RING", "CLUSTER", "SCRATCH"]
        for lot in lots:
            wafers_sql = """
                SELECT wafer_id, slot_number, gross_yield_pct, pattern_class_generic
                FROM cp_fact_wafer_summary
                WHERE lot_id = :lot_id
                ORDER BY slot_number
                LIMIT 6
            """
            wafers = execute_query(wafers_sql, {"lot_id": lot["lot_id"]})
            gallery.append({
                "lot_id": lot["lot_id"],
                "product_id": lot["product_id"],
                "process_node": lot["process_node"],
                "priority": "HOT" if lot.get("is_hot") else "NORMAL",
                "current_step": "M1-LITHO",
                "wafers": [
                    {
                        "waferId": w["wafer_id"],
                        "yield": float(w["gross_yield_pct"]) if w["gross_yield_pct"] else None,
                        "pattern": w.get("pattern_class_generic", "NORMAL")
                    } for w in wafers
                ] if wafers else [
                    {"waferId": f"{lot['lot_id']}_W{str(i+1).zfill(2)}", "yield": round(random.uniform(91, 98), 1), "pattern": random.choice(patterns)}
                    for i in range(6)
                ]
            })
        return jsonify(gallery)
    except Exception:
        # Demo data
        demo_lots = [
            {"lot_id": "M900001", "product_id": "AI-CHIP-N5", "process_node": "N5", "priority": "HOT", "current_step": "GATE-OX"},
            {"lot_id": "M900002", "product_id": "CPU-N3", "process_node": "N3", "priority": "HOT", "current_step": "M1-LITHO"},
            {"lot_id": "M900003", "product_id": "GPU-N5", "process_node": "N5", "priority": "NORMAL", "current_step": "CMP-ILD"},
        ]
        patterns = ["NORMAL", "EDGE", "RING", "CLUSTER", "SCRATCH"]
        for lot in demo_lots:
            lot["wafers"] = [
                {"waferId": f"{lot['lot_id']}_W{str(i+1).zfill(2)}", "yield": round(random.uniform(88, 98), 1), "pattern": random.choice(patterns)}
                for i in range(6)
            ]
        return jsonify(demo_lots)


@dashboard_bp.route("/score-card", methods=["GET"])
@jwt_required(optional=True)
def get_score_card():
    """Get lot-level score card data."""
    product_id = request.args.get("product_id")
    limit = int(request.args.get("limit", 20))

    try:
        sql = """
            SELECT
                ws.lot_id, l.product_id, l.process_node, l.customer_id,
                ws.tester_id, ws.gross_yield_pct, ws.net_yield_pct,
                ws.first_pass_yield, ws.offline_retest_rate,
                ws.total_die, ws.pass_die, ws.fail_die,
                ws.pattern_class_generic, ws.syl_flag, ws.sbl_flag,
                ws.mrb_required, ws.mrb_result,
                ws.event_date
            FROM cp_fact_wafer_summary ws
            JOIN mes_dim_lot l ON l.lot_id = ws.lot_id AND l.is_current = TRUE
            {product_filter}
            ORDER BY ws.event_date DESC, ws.lot_id
            LIMIT :limit
        """
        if product_id:
            sql = sql.replace("{product_filter}", "WHERE l.product_id = :product_id")
            rows = execute_query(sql, {"limit": limit, "product_id": product_id})
        else:
            sql = sql.replace("{product_filter}", "")
            rows = execute_query(sql, {"limit": limit})

        return jsonify([serialize_row(r) for r in rows])
    except Exception:
        return jsonify([
            {"lot_id": "M900001", "product_id": "AI-CHIP-N5", "tester_id": "WAT-01", "gross_yield_pct": 95.00, "first_pass_yield": 94.12, "offline_retest_rate": 9.54, "total_die": 8500, "syl_flag": False, "sbl_flag": False, "event_date": "2025-06-26"},
            {"lot_id": "M900002", "product_id": "CPU-N3", "tester_id": "WAT-02", "gross_yield_pct": 94.00, "first_pass_yield": 93.15, "offline_retest_rate": 10.93, "total_die": 9200, "syl_flag": False, "sbl_flag": False, "event_date": "2025-06-25"},
            {"lot_id": "M900005", "product_id": "RF-CHIP-16NM", "tester_id": "WAT-01", "gross_yield_pct": 86.00, "first_pass_yield": 84.93, "offline_retest_rate": 50.00, "total_die": 8100, "syl_flag": True, "sbl_flag": True, "event_date": "2025-06-24"},
        ])
