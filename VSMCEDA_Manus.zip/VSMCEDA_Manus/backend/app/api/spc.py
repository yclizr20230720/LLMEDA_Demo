"""SPC Monitor API — Control charts, capability, violations."""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from ..utils.db_utils import execute_query, execute_scalar, serialize_rows
import random, math, numpy as np
from datetime import datetime, timedelta

spc_bp = Blueprint("spc", __name__)

PARAMS = {
    "NMOS_VT":   {"mean": 0.350, "sigma": 0.018, "usl": 0.42, "lsl": 0.28, "unit": "V"},
    "PMOS_VT":   {"mean": -0.350, "sigma": 0.018, "usl": -0.28, "lsl": -0.42, "unit": "V"},
    "GATOX_THK": {"mean": 28.0, "sigma": 0.4, "usl": 30.0, "lsl": 26.0, "unit": "Å"},
    "POLY_CD":   {"mean": 27.0, "sigma": 0.35, "usl": 28.5, "lsl": 25.5, "unit": "nm"},
    "CMP_RATE":  {"mean": 2800, "sigma": 120, "usl": 3200, "lsl": 2400, "unit": "Å/min"},
}


@spc_bp.route("/configs", methods=["GET"])
@jwt_required(optional=True)
def get_configs():
    """Get SPC parameter configurations."""
    try:
        rows = execute_query("SELECT * FROM spc_dim_parameter_config WHERE is_active = TRUE ORDER BY parameter_id")
        if rows:
            return jsonify([{k: float(v) if isinstance(v, (int, float)) and k not in ['config_id','parameter_id','product_id','equipment_id'] else (str(v) if hasattr(v,'isoformat') else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    return jsonify([
        {"config_id": f"SPC_{p}_ALL", "parameter_id": p, "chart_type": "XBAR_R",
         "ucl": round(info["mean"] + 3*info["sigma"], 4),
         "cl": info["mean"], "lcl": round(info["mean"] - 3*info["sigma"], 4),
         "usl": info["usl"], "lsl": info["lsl"], "target": info["mean"],
         "enabled_rules": 255, "is_active": True}
        for p, info in PARAMS.items()
    ])


@spc_bp.route("/chart-data", methods=["GET"])
@jwt_required(optional=True)
def get_chart_data():
    """Get SPC chart data with violation flags."""
    parameter_id = request.args.get("parameterId", "GATOX_THK")
    equipment_id = request.args.get("equipment_id")
    n_points = int(request.args.get("n", 60))

    info = PARAMS.get(parameter_id, PARAMS["GATOX_THK"])
    cl = info["mean"]
    sigma = info["sigma"]
    ucl = cl + 3 * sigma
    lcl = cl - 3 * sigma

    try:
        sql = """
            SELECT sm.measured_value, sm.subgroup_mean, sm.subgroup_range,
                   sm.ucl_at_time, sm.cl_at_time, sm.lcl_at_time,
                   sm.sigma_score, sm.any_violation, sm.violation_rules_list,
                   sm.lot_id, sm.equipment_id, sm.measurement_time,
                   sm.is_virtual, sm.vm_predicted_value
            FROM spc_fact_measurement sm
            JOIN spc_dim_parameter_config sc ON sc.config_id = sm.config_id
            WHERE sc.parameter_id = :param
            {equip_filter}
            ORDER BY sm.measurement_time DESC
            LIMIT :n
        """
        params = {"param": parameter_id, "n": n_points}
        if equipment_id:
            sql = sql.replace("{equip_filter}", "AND sm.equipment_id = :equip")
            params["equip"] = equipment_id
        else:
            sql = sql.replace("{equip_filter}", "")
        rows = execute_query(sql, params)
        if not rows:
            raise ValueError("No data")
        points = []
        for i, r in enumerate(reversed(rows)):
            points.append({
                "index": i,
                "value": float(r["measured_value"]),
                "mean": float(r["subgroup_mean"]) if r.get("subgroup_mean") else float(r["measured_value"]),
                "range": float(r["subgroup_range"]) if r.get("subgroup_range") else 0,
                "violation": r.get("violation_rules_list"),
                "lot_id": r.get("lot_id"),
                "equipment_id": r.get("equipment_id"),
                "sigma_score": float(r["sigma_score"]) if r.get("sigma_score") else None,
                "is_virtual": r.get("is_virtual", False),
                "vm_predicted": float(r["vm_predicted_value"]) if r.get("vm_predicted_value") else None
            })
    except Exception:
        points = []
        for i in range(n_points):
            noise = random.gauss(0, sigma)
            drift = math.sin(i / 15) * sigma * 0.3
            excursion = sigma * 3.8 if 45 <= i <= 48 else 0
            value = cl + noise + drift + excursion
            violation = None
            if abs(value - cl) > 3 * sigma:
                violation = "1"
            elif i > 8 and i % 9 == 0:
                violation = "2"
            points.append({
                "index": i, "value": round(value, 4),
                "mean": round(value, 4), "range": round(abs(noise) * 1.5, 4),
                "violation": violation, "sigma_score": round((value - cl) / sigma, 3)
            })

    cpk_val = round(min((info["usl"] - cl) / (3 * sigma), (cl - info["lsl"]) / (3 * sigma)), 3)
    cp_val = round((info["usl"] - info["lsl"]) / (6 * sigma), 3)
    violations = sum(1 for p in points if p.get("violation"))

    return jsonify({
        "points": points, "ucl": round(ucl, 4), "lcl": round(lcl, 4), "cl": round(cl, 4),
        "usl": info["usl"], "lsl": info["lsl"], "unit": info["unit"],
        "cpk": cpk_val, "cp": cp_val, "ppk": round(cpk_val * 0.95, 3),
        "violations": violations, "n": len(points)
    })


@spc_bp.route("/capability", methods=["GET"])
@jwt_required(optional=True)
def get_capability():
    """Get Cpk capability summary table."""
    try:
        rows = execute_query("""
            SELECT sc.config_id, sc.parameter_id, sc.product_id, sc.equipment_id,
                   sc.target, sc.usl, sc.lsl, sc.ucl, sc.lcl,
                   cap.cp, cap.cpk, cap.ppk, cap.mean_value, cap.std_dev_within,
                   cap.n_observations, cap.total_violations, cap.period_start, cap.period_end
            FROM spc_dim_parameter_config sc
            LEFT JOIN spc_agg_capability cap ON cap.config_id = sc.config_id
                AND cap.period_type = 'MONTHLY'
            WHERE sc.is_active = TRUE
            ORDER BY sc.parameter_id
        """)
        if rows:
            return jsonify([{k: float(v) if isinstance(v, (int,float)) and v is not None and k not in ['config_id','parameter_id','product_id','equipment_id'] else (str(v) if hasattr(v,'isoformat') else v) for k, v in r.items()} for r in rows])
    except Exception:
        pass
    return jsonify([
        {"parameter_id": p, "target": info["mean"], "usl": info["usl"], "lsl": info["lsl"],
         "cp": round(random.uniform(1.0, 2.2), 3), "cpk": round(random.uniform(0.9, 2.0), 3),
         "ppk": round(random.uniform(0.85, 1.9), 3), "mean_value": info["mean"],
         "n_observations": random.randint(200, 800), "total_violations": random.randint(0, 8)}
        for p, info in PARAMS.items()
    ])


@spc_bp.route("/alarm-summary", methods=["GET"])
@jwt_required(optional=True)
def get_alarm_summary():
    """Get SPC alarm summary by area and week."""
    areas = ["CMP", "DIFF", "ETCH", "LITHO", "TF"]
    weeks = [f"W{i:02d}" for i in range(9, 16)]
    data = []
    for week in weeks:
        row = {"week": week}
        total_count = 0
        for area in areas:
            count = random.randint(0, 15)
            row[area] = count
            total_count += count
        row["total"] = total_count
        row["alarm_ratio"] = round(total_count / random.randint(80, 120) * 100, 1)
        data.append(row)
    return jsonify({"weekly_data": data, "areas": areas})


@spc_bp.route("/violations", methods=["GET"])
@jwt_required(optional=True)
def get_violations():
    """Get recent SPC violations."""
    limit = int(request.args.get("limit", 20))
    try:
        rows = execute_query("""
            SELECT v.*, sc.parameter_id, sc.chart_type
            FROM spc_fact_violation v
            JOIN spc_dim_parameter_config sc ON sc.config_id = v.config_id
            ORDER BY v.violation_time DESC
            LIMIT :limit
        """, {"limit": limit})
        if rows:
            return jsonify([{k: str(v) if hasattr(v,'isoformat') else v for k, v in r.items()} for r in rows])
    except Exception:
        pass
    return jsonify([
        {"parameter_id": "GATOX_THK", "equipment_id": "CVD-02", "rule_number": 1,
         "rule_description": "1 point > 3σ from center line", "rule_severity": "CRITICAL",
         "trigger_value": 29.8, "sigma_deviation": 3.2, "trigger_lot_id": "M900006",
         "violation_time": datetime.utcnow().isoformat()},
        {"parameter_id": "NMOS_VT", "equipment_id": "WAT-01", "rule_number": 5,
         "rule_description": "2/3 points > 2σ same side", "rule_severity": "MAJOR",
         "trigger_value": 0.388, "sigma_deviation": 2.1, "trigger_lot_id": "M900001",
         "violation_time": (datetime.utcnow() - timedelta(hours=2)).isoformat()},
    ])
