"""Database utility functions for SEMFAB·IQ."""
from sqlalchemy import text
from ..extensions import db
from loguru import logger
import json
import functools
import hashlib
import time


def execute_query(sql: str, params: dict = None) -> list:
    """Execute a raw SQL query and return list of dicts."""
    try:
        with db.engine.connect() as conn:
            result = conn.execute(text(sql), params or {})
            columns = result.keys()
            rows = result.fetchall()
            return [dict(zip(columns, row)) for row in rows]
    except Exception as e:
        logger.error(f"Query error: {e}\nSQL: {sql[:200]}")
        raise


def execute_scalar(sql: str, params: dict = None):
    """Execute query and return single scalar value."""
    rows = execute_query(sql, params)
    if rows:
        return list(rows[0].values())[0]
    return None


def execute_write(sql: str, params: dict = None) -> int:
    """Execute INSERT/UPDATE/DELETE and return affected rows."""
    try:
        with db.engine.begin() as conn:
            result = conn.execute(text(sql), params or {})
            return result.rowcount
    except Exception as e:
        logger.error(f"Write error: {e}\nSQL: {sql[:200]}")
        raise


def paginate_query(sql: str, params: dict = None, page: int = 1, per_page: int = 50) -> dict:
    """Execute paginated query."""
    offset = (page - 1) * per_page
    count_sql = f"SELECT COUNT(*) FROM ({sql}) AS _count_query"
    total = execute_scalar(count_sql, params) or 0
    paginated_sql = f"{sql} LIMIT :_limit OFFSET :_offset"
    paginated_params = {**(params or {}), "_limit": per_page, "_offset": offset}
    items = execute_query(paginated_sql, paginated_params)
    return {
        "items": items,
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page
    }


def serialize_row(row: dict) -> dict:
    """Serialize a database row to JSON-safe dict."""
    result = {}
    for key, value in row.items():
        if hasattr(value, 'isoformat'):
            result[key] = value.isoformat()
        elif isinstance(value, (bytes, bytearray)):
            result[key] = value.decode('utf-8', errors='replace')
        else:
            result[key] = value
    return result


def serialize_rows(rows: list) -> list:
    """Serialize list of database rows."""
    return [serialize_row(row) for row in rows]


def cache_key(*args) -> str:
    """Generate a cache key from arguments."""
    key_str = ":".join(str(a) for a in args)
    return f"semfab:{hashlib.md5(key_str.encode()).hexdigest()[:12]}"


def cached(ttl: int = 300, key_prefix: str = ""):
    """Decorator for caching function results in Redis."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            from ..extensions import get_redis
            r = get_redis()
            if r is None:
                return func(*args, **kwargs)
            ck = f"semfab:{key_prefix}:{cache_key(*args, **kwargs)}"
            try:
                cached_val = r.get(ck)
                if cached_val:
                    return json.loads(cached_val)
            except Exception:
                pass
            result = func(*args, **kwargs)
            try:
                r.setex(ck, ttl, json.dumps(result, default=str))
            except Exception:
                pass
            return result
        return wrapper
    return decorator


def generate_synthetic_trend(base: float, sigma: float, n: int = 30,
                              excursion_at: int = None, excursion_delta: float = -5.0) -> list:
    """Generate synthetic trend data for demo purposes."""
    import random
    import math
    data = []
    for i in range(n):
        noise = random.gauss(0, sigma)
        drift = math.sin(i / 10) * sigma * 0.5
        value = base + noise + drift
        if excursion_at and i >= excursion_at:
            value += excursion_delta
        data.append(round(value, 4))
    return data
