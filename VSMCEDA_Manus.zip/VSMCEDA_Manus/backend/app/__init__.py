"""
SEMFAB·IQ — Flask Application Factory
Semiconductor Engineering Data Analytics Platform
"""
from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_socketio import SocketIO
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from .config import Config
from .extensions import db, redis_client
from loguru import logger
import sys

# SocketIO instance (shared across modules)
socketio = SocketIO()
jwt = JWTManager()
limiter = Limiter(key_func=get_remote_address)


def create_app(config_class=Config):
    """Application factory pattern."""
    app = Flask(__name__)
    app.config.from_object(config_class)

    # ── Logging ──────────────────────────────────────────────
    logger.remove()
    logger.add(sys.stdout, level=app.config.get("LOG_LEVEL", "INFO"),
               format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>")
    logger.add("logs/semfab_api.log", rotation="100 MB", retention="30 days", level="DEBUG")

    # ── Extensions ───────────────────────────────────────────
    db.init_app(app)
    jwt.init_app(app)
    limiter.init_app(app)

    CORS(app, resources={r"/api/*": {
        "origins": app.config.get("CORS_ORIGINS", "*").split(","),
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "supports_credentials": True
    }})

    socketio.init_app(
        app,
        cors_allowed_origins="*",
        async_mode="eventlet",
        logger=False,
        engineio_logger=False
    )

    # ── Register Blueprints ──────────────────────────────────
    from .api.auth import auth_bp
    from .api.dashboard import dashboard_bp
    from .api.lots import lots_bp
    from .api.equipment import equipment_bp
    from .api.wat import wat_bp
    from .api.spc import spc_bp
    from .api.fdc import fdc_bp
    from .api.defect import defect_bp
    from .api.agent import agent_bp
    from .api.advanced import advanced_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard")
    app.register_blueprint(lots_bp, url_prefix="/api/lots")
    app.register_blueprint(equipment_bp, url_prefix="/api/equipment")
    app.register_blueprint(wat_bp, url_prefix="/api/wat")
    app.register_blueprint(spc_bp, url_prefix="/api/spc")
    app.register_blueprint(fdc_bp, url_prefix="/api/fdc")
    app.register_blueprint(defect_bp, url_prefix="/api/defect")
    app.register_blueprint(agent_bp, url_prefix="/api/agent")
    app.register_blueprint(advanced_bp, url_prefix="/api/advanced")

    # ── Health Check ─────────────────────────────────────────
    @app.route("/api/health")
    def health():
        return jsonify({
            "status": "healthy",
            "service": "SEMFAB·IQ API",
            "version": "2.0.0"
        })

    # ── Error Handlers ───────────────────────────────────────
    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": "Bad Request", "message": str(e)}), 400

    @app.errorhandler(401)
    def unauthorized(e):
        return jsonify({"error": "Unauthorized", "message": "Authentication required"}), 401

    @app.errorhandler(403)
    def forbidden(e):
        return jsonify({"error": "Forbidden", "message": "Insufficient permissions"}), 403

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not Found", "message": str(e)}), 404

    @app.errorhandler(429)
    def rate_limit_exceeded(e):
        return jsonify({"error": "Rate Limit Exceeded", "message": str(e)}), 429

    @app.errorhandler(500)
    def internal_error(e):
        logger.error(f"Internal server error: {e}")
        return jsonify({"error": "Internal Server Error", "message": "An unexpected error occurred"}), 500

    logger.info("SEMFAB·IQ API initialized successfully")
    return app
