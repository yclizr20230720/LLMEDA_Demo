# SEMFAB·IQ — API Specifications
## Part 3: Microservice RESTful Endpoints & WebSocket Events

This document details the complete API contract for the SEMFAB·IQ microservices, ensuring seamless integration between the React frontend, Python Flask backend, and the Agentic AI orchestrator.

---

### 1. Standard API Envelope

All REST API responses follow a unified JSON envelope standard:

```json
{
  "status": "success",          // "success" or "error"
  "data": { ... },              // Payload (omitted on error)
  "meta": {                     // Pagination or context metadata
    "total_count": 142,
    "page": 1,
    "execution_time_ms": 45
  },
  "errors": null,               // Array of error objects (if status="error")
  "trace_id": "req-1234-abcd"   // For distributed tracing (Jaeger)
}
```

---

### 2. Core Analytics APIs

#### 2.1 Yield Service (`/api/v1/yield`)
Equivalent to DE-YMS functionalities.

| Method | Endpoint | Query Parameters / Body | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/summary` | `?lot_id=...&wafer_id=...&step=...` | Retrieves yield KPIs, bin breakdowns, and defect density for a specific lot or wafer. |
| `GET` | `/trend` | `?product=...&node=...&days=30` | Returns time-series yield data with control limits (sigma bands) for dashboard trending. |
| `GET` | `/excursions` | `?severity=CRITICAL&status=OPEN` | Lists active yield excursions requiring engineering attention. |
| `POST` | `/rca-drill` | `{ "lot_id": "M9001", "symptom": "BIN3" }` | Triggers a SAS Viya GLMSELECT job to rank contributing factors for a specific yield loss. |
| `GET` | `/compare` | `?baseline_lot=...&target_lot=...` | Returns a statistical comparison (T-test, F-test) between two lots. |
| `GET` | `/wafer-map` | `?lot_id=...&wafer_id=...&map_type=bin` | Returns a highly optimized die array (up to 684K dies) for the frontend Canvas renderer. |

#### 2.2 SPC / FDC Service (`/api/v1/spc`)
Equivalent to DE-SPC and DE-FDC functionalities.

| Method | Endpoint | Query Parameters / Body | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/charts` | `?parameter_id=...&equipment_id=...` | Returns Xbar-R / Xbar-S chart data points along with calculated UCL, LCL, and CL. |
| `GET` | `/violations` | `?rule=WECO_1&severity=MAJOR` | Lists recent SPC rule violations with context. |
| `GET` | `/capability` | `?parameter_id=...&equipment_id=...` | Returns Cpk, Cp, Ppk indices calculated via SAS PROC CAPABILITY. |
| `POST` | `/update-limits`| `{ "parameter_id": "...", "ucl": 4.5 }` | Updates control limits in Greenplum (requires SENIOR_ENGINEER role). |
| `GET` | `/virtual-metro`| `?equipment_id=...&next_lot_id=...` | Returns ML-predicted measurement values (Virtual Metrology) with confidence intervals. |

#### 2.3 Defect Service (`/api/v1/defect`)
Equivalent to DE-DMS, INF-ADC, and INF-WPA.

| Method | Endpoint | Query Parameters / Body | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/klarf/upload` | `multipart/form-data` | Uploads and parses KLA KLARF defect files into the staging area. |
| `GET` | `/classification`| `?wafer_id=...` | Returns INF-ADC classification results and confidence scores for defects on a wafer. |
| `GET` | `/patterns` | `?lot_id=...` | Returns INF-WPA spatial pattern classifications (e.g., RING, EDGE, SCRATCH). |
| `GET` | `/yield-impact` | `?layer=...&defect_class=...` | Calculates the yield kill ratio for specific defect types based on historical correlation. |

---

### 3. Agentic AI & Automation APIs

#### 3.1 Agent Service (`/api/v1/agent`)
Orchestrates the LangGraph state machine and LLM interactions.

| Method | Endpoint | Query Parameters / Body | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/query` | `{ "question": "Why is lot X low yield?", "context": {"lot_id": "X"} }` | Initiates an agentic reasoning session. Returns a `session_id`. |
| `GET` | `/stream/{id}` | *(Server-Sent Events)* | Streams the agent's thought process, tool calls, and final narrative to the UI in real-time. |
| `POST` | `/approve-action`| `{ "action_id": 123, "notes": "Approved" }` | Approves a pending robot action recommended by the AI. |
| `POST` | `/reject-action` | `{ "action_id": 123, "reason": "Incorrect" }` | Rejects an action and feeds the correction back to the Knowledge Graph. |
| `GET` | `/knowledge` | `?symptom=...&category=...` | Searches the Neo4j RCA Knowledge Base for historical solutions. |

#### 3.2 Robot Control Service (`/api/v1/robot`)
Interfaces with FAB MES and EAP systems.

| Method | Endpoint | Query Parameters / Body | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/lot-hold` | `{ "lot_id": "...", "reason": "..." }` | Sends a command to the MES to place a lot on engineering hold. |
| `POST` | `/recipe-adjust`| `{ "equipment_id": "...", "delta": 0.5 }` | Sends a Run-to-Run (APC) setpoint adjustment to the equipment via EAP. |
| `POST` | `/pm-schedule` | `{ "equipment_id": "...", "urgency": "HIGH" }` | Triggers a maintenance work order in the CMMS. |
| `GET` | `/action-log` | `?status=EXECUTED` | Retrieves the audit trail of all actions executed by the Software/Hardware robots. |

---

### 4. Real-Time WebSocket Events (`/ws/fab-events`)

The Flask-SocketIO server pushes real-time events to the React frontend. Clients do not need to poll.

| Event Name | Direction | Payload Example | Trigger Source |
| :--- | :--- | :--- | :--- |
| `alarm.critical` | Server → Client | `{"alarm_id": 99, "equipment_id": "CVD-01", "code": "E_PRESS", "severity": "CRITICAL"}` | Oracle Trigger on `LIVE_ALARM` insert |
| `yield.excursion`| Server → Client | `{"lot_id": "M9001", "current_yield": 82.5, "baseline": 98.0, "delta_pct": -15.5}` | Celery Beat (5-min interval) |
| `spc.violation` | Server → Client | `{"parameter_id": "P_THICK", "equipment_id": "CMP-02", "rule": "WECO_1", "value": 4.2}` | Oracle Trigger on SPC calculation |
| `equipment.status`| Server → Client | `{"equipment_id": "LITHO-05", "status": "DOWN", "health_score": 45}` | Oracle Trigger on status change |
| `agent.thinking` | Server → Client | `{"session_id": "s-123", "step": "TOOL_CALL", "content": "query_spc_violations(lot_id='M9001')"}` | LangGraph execution trace |
| `robot.action` | Server → Client | `{"action_id": 456, "type": "LOT_HOLD", "target": "M9001", "outcome": "SUCCESS"}` | `robot-ctrl-service` callback |
| `chat.message` | Client → Server | `{"session_id": "s-123", "message": "Execute the recommended action plan."}` | User input in UI |
