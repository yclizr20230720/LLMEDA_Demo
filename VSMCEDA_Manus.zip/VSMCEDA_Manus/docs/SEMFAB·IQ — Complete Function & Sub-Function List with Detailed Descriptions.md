# SEMFAB·IQ — Complete Function & Sub-Function List with Detailed Descriptions

> **Platform:** SEMFAB·IQ Semiconductor Engineering Data Analytics Platform  
> **Version:** v2.0  
> **Total Modules:** 13  
> **Architecture:** React + Vite (Frontend) · Node.js/tRPC (Backend) · MySQL (Database)

---

## Module 1 — YMS Dashboard (Yield Management System)

The central command center for fab-wide yield monitoring, providing real-time visibility into production health across all product lines and process nodes.

| Sub-Function | Description |
|---|---|
| **KPI Strip — FAB Yield %** | Displays the current fab-wide gross yield percentage aggregated across all completed lots. Compares against the 7-day rolling baseline with a color-coded delta indicator (green ↑ / red ↓). Data refreshes every 30 seconds from the database. |
| **KPI Strip — Active Alarms** | Shows the total count of unresolved alarms (OPEN status) across all equipment and process steps. Turns red with a pulsing animation when critical alarms are present. |
| **KPI Strip — Lots In Process** | Real-time count of lots currently in the IN_PROCESS state across all product lines, giving the shift supervisor an instant WIP (Work In Progress) snapshot. |
| **KPI Strip — Equipment OEE** | Displays the average Overall Equipment Effectiveness (utilization %) across all production tools, calculated from the equipment table. |
| **30-Day Yield Trend Chart** | Interactive Recharts line chart showing daily yield trend over the past 30 days. Includes UCL (Upper Control Limit = 97.5%), LCL (Lower Control Limit = 90.0%), and center line (CL = 94.2%) as reference lines. Excursion points are highlighted in red. |
| **Live Alarm Feed** | Real-time scrolling list of active alarms sorted by severity (CRITICAL → MAJOR → MINOR). Each entry shows equipment ID, alarm code, alarm message, and associated lot ID. Refreshes every 15 seconds. |
| **Active Lot Wafer Gallery** | Canvas-based wafer map gallery showing up to 8 active lots, each with up to 6 wafer thumbnails rendered using bitmap-blit strategy. HOT lots are flagged with an orange badge. Each wafer shows bin color coding (Pass=Teal, Fail=Red, Marginal=Orange). |

---

## Module 2 — Guided Analytics (GA-MA)

A step-by-step guided analysis wizard that walks engineers through a structured root cause investigation workflow, from yield impact ranking to equipment commonality identification.

| Sub-Function | Description |
|---|---|
| **Step 1 — Yield Impact Ranking** | Ranks all monitored WAT/CP parameters by their estimated yield impact (%). Each item shows severity level (Critical/Major/Minor), process step, Cpk value, and trend direction. Clicking any item initiates a drill-down investigation. |
| **Step 2 — Bin Pareto Analysis** | Displays the failure bin distribution as a horizontal bar chart with cumulative percentage overlay. Identifies the dominant failure mode (e.g., Bin 106 Functional Fail) to focus investigation efforts. |
| **Step 3 — Cpk Analysis** | Shows process capability index (Cpk and Cp) for all key parameters with color-coded status bars (Red < 1.0, Yellow 1.0–1.33, Green ≥ 1.33). Parameters below the 1.33 target are flagged with warning icons. |
| **Step 4 — Commonality Analysis** | Executes equipment commonality analysis using Chi-Square statistical testing. Ranks all equipment by suspicion score (%) with p-values. The highest-suspicion equipment (e.g., CMP-03 at 99.8%) is highlighted as the primary root cause candidate. |
| **Step 5 — Correlation Analysis** | Generates a scatter plot of the top yield-impacting WAT parameter versus lot yield %, with linear regression line and R² coefficient. Provides actionable recommendation (e.g., "Tighten NMOS_VT spec to reduce yield loss"). |
| **Step Navigator** | Progress bar showing all 5 steps with completion checkmarks. Engineers can navigate forward/backward freely. Completed steps are marked with green checkmarks. |

---

## Module 3 — DE-General Analysis Workbench

A comprehensive multi-chart analytical workbench modeled after the Semitronix DE-General platform, providing 17 distinct chart types for deep parametric data exploration.

| Sub-Function | Description |
|---|---|
| **Sheet List Sidebar** | Left-panel navigation listing all 17 chart types. Active chart is highlighted with teal accent. Clicking any chart type instantly switches the main view. |
| **LinePlot / Ids Trend by Design** | Multi-series line chart showing transistor current (Ids) vs. design parameters (N/NFin nodes). Displays N-type (teal) and P-type (red) curves simultaneously for direct comparison. |
| **WaferMap (HM) — Heat Map** | Full-wafer heat map visualization using a continuous color gradient (blue→green→yellow→red) to represent parameter value distribution across the wafer surface. Supports multiple wafers side-by-side with a shared color scale bar. |
| **WaferMap (WM) — Wafer Map** | Standard wafer map view showing die-level pass/fail results with bin color coding. |
| **Contour Plot** | 2D scatter plot with contour overlay showing the relationship between two parameters (e.g., Vts vs. Ids). Displays R² coefficient and linear regression line. Supports N-type and P-type split views. |
| **Histogram** | Overlapping histogram with configurable bin count, showing parameter value distribution for multiple groups (e.g., N-type vs. P-type). Supports KDE (Kernel Density Estimation) curve overlay. |
| **CDF / Q-Q Plot** | Cumulative Distribution Function and Quantile-Quantile plot for normality assessment. Displays multiple groups as colored scatter series against the theoretical normal distribution line. |
| **BoxPlot** | Box-and-whisker chart showing Q1, median, Q3, whiskers, and outliers for multiple design groups. Color-coded by device type (N-type = teal, P-type = red). |
| **Correlation Matrix (Cor_Wafermap)** | Interactive N×N heatmap showing Pearson correlation coefficients between all selected parameters. Color scale: teal (strong positive ≥0.7) → neutral → red (strong negative ≤-0.7). Clicking a cell opens the corresponding scatter plot. |
| **Regression** | Scatter plot with linear regression line, displaying the regression equation (y = a + b×x), R² coefficient, and standard error. Supports parameter selection for X and Y axes. |
| **ANOVA** | One-way Analysis of Variance table showing F-statistic, p-value, and eta-squared (η²) for each equipment group. Results sorted by eta-squared descending to identify the highest-variance equipment. |
| **CrossTab** | Pivot table showing alarm count and alarm ratio (%) cross-tabulated by Area (CMP/DIFF/ETCH/LITHO/TF) and Week. Color-coded cells (red/yellow/green) for instant status assessment. |
| **Dashboard View** | Combined multi-chart dashboard displaying LinePlot + WaferMap(HM) + Contour + Histogram + CDF simultaneously on a single canvas, providing a comprehensive overview of all key analytical views. |

---

## Module 4 — WAT Analytics Workbench

A five-tab analytical workbench for Wafer Acceptance Test (WAT) parametric data, providing deep statistical analysis of electrical test parameters.

| Sub-Function | Description |
|---|---|
| **Tab 1 — Distribution Analysis** | Histogram with configurable bin count showing parameter value distribution. Displays spec limits (USL/LSL) as vertical reference lines. Statistics panel shows Mean, Sigma, Cpk, Cp, N count. Bimodal detection indicator warns if distribution appears non-normal. |
| **Tab 2 — Correlation Matrix** | 6×6 Pearson correlation heatmap for selected WAT parameters. Significance filter dims non-significant correlations (p > 0.05). Color scale from red (strong negative) to teal (strong positive). |
| **Tab 3 — Equipment ANOVA** | Horizontal bar chart ranking equipment by eta-squared (η²) variance contribution. Color-coded by contribution level (red > 25%, orange > 15%, yellow > 8%, green otherwise). Shows equipment ID, eta-squared value, and sample count. |
| **Tab 4 — Parameter Trend** | Time-series line chart showing parameter values over sequential lot/wafer measurements. Includes UCL/LCL control limits and highlights violation points in red. Supports rolling average overlay. |
| **Tab 5 — 9-Site Wafer Uniformity Map** | SVG-based wafer diagram showing 9 measurement site positions (Center, TL, TC, TR, ML, MR, BL, BC, BR). Each site displays the measured value with color-coded intensity. Side panel shows site-by-site bar chart for uniformity comparison. |
| **Parameter Selector** | Searchable dropdown listing all 8 monitored WAT parameters (NMOS_VT, PMOS_VT, NMOS_IDSAT, GATOX_THK, POLY_CD, CMP_RATE, CONTACT_R, METAL_R) with units and current Cpk values. |

---

## Module 5 — SPC Monitor (Statistical Process Control)

A full-featured SPC platform with four operational tabs covering configuration, strategy management, real-time analysis, and alarm reporting.

| Sub-Function | Description |
|---|---|
| **Tab 1 — DC Config** | Configuration interface for SPC rule definitions, matching key templates, wafer map configuration, site map configuration, and parameter spec templates. Displays the current spec template table showing Target/USL/LSL/Cpk-Min for each parameter. |
| **Tab 2 — Strategy Builder** | Six-function management panel: Batch Strategy Build (auto-generate strategies from historical data), Virtual Parameter (computed parameters), Custom Chart, Rule Criteria (WECO rules + custom expressions), Alarm Notification (email/MES/Slack routing), and Hold Action (automatic lot hold on OOC/OOS trigger). Displays active strategy list with product/strategy/rule count/alarm status. |
| **Tab 3 — Data Analyzer** | Primary SPC analysis view with Cpk arc gauge, Cp/Ppk statistics cards, and Xbar control chart. Control chart shows 50 data points with UCL/LCL/CL reference lines. Violation points rendered as red glowing dots. Supports chart type switching (Xbar-R, Xbar-S, I-MR). |
| **Tab 4 — Alarm Viewer** | Weekly alarm trend as stacked bar chart (by area: CMP/DIFF/ETCH/LITHO/TF) with alarm ratio percentage line overlay. Cross-table below shows AlarmCount + AlarmRatio per Area × Week with red/yellow/green color coding. |
| **Tab 5 — Cpk Summary** | Tabular summary showing ProductID × StrategyName with Target/USL/LSL/Std/Mean/Count/Cp/K/Cpk for each monitored parameter. Cpk values color-coded: red (< 1.0), yellow (1.0–1.33), green (≥ 1.33). Includes lot-level Cpk boxplot chart below. |
| **Equipment Health Fleet** | Compact fleet view showing all 16 equipment with health score progress bars, utilization %, and status badges (PROD/PM/DOWN/QUAL). Sorted worst-first by health score. |

---

## Module 6 — FDC Monitor (Fault Detection & Classification)

A real-time equipment monitoring platform providing four distinct views for trace data analysis, anomaly detection, and ML-based fab control.

| Sub-Function | Description |
|---|---|
| **Composite Anomaly Score Bar** | Real-time area chart showing the composite anomaly score (0–1.0) over time. A red reference line marks the critical threshold (0.95). When score exceeds threshold, a CRITICAL badge pulses in the header. |
| **Tab 1 — Feature SPC** | Strategy Builder interface with an indicator priority list (High/Medium/Low) on the left and an SPC trend chart on the right. Each indicator shows UCL/LCL/CL limits. Violation points highlighted in red. Supports multi-chamber color coding. |
| **Tab 2 — Trace Stack View** | Sensor selection panel on the left (9 sensors with color-coded toggles) and a multi-trace overlay chart on the right. Engineers can select/deselect individual sensors to focus on specific signals. Time axis shows elapsed seconds. |
| **Tab 3 — Virtual Sensor** | Dual-panel view comparing the Origin Sensor (raw measured signal) with the Virtual Sensor (ML-computed derived signal). Red vertical marker lines indicate event timestamps. Area chart fill shows signal envelope. |
| **Tab 4 — Trace Link View** | 8-panel grid showing the same sensor trace across 8 different process events (Event01–Event08) for direct comparison. Each panel uses a unique color for easy differentiation. Enables detection of recurring anomaly patterns. |
| **Fab Control (ML) Summary** | Four-card summary panel showing: Yield Source Identified (equipment name), Preventive Alarm status (ML model confidence), Virtual Metrology prediction (parameter value ± CI), and R2R Control status (APC setpoint adjustment). |

---

## Module 7 — Defect Analysis System (DMS)

A comprehensive defect management platform covering spatial pattern analysis, automated classification, stacked map analysis, and yield impact correlation.

| Sub-Function | Description |
|---|---|
| **Tab 1 — Defect Count Pareto by Process Steps** | Stacked bar chart showing defect count per wafer (up to 20 wafers), with each bar color-coded by defect class (19 categories including Active Bridging, Killer Scratch, Embedded Particles, etc.). A Median Yield line overlays the chart on the right Y-axis, showing the inverse relationship between defect count and yield. |
| **Tab 2 — Wafer Defect Map** | SVG-based wafer defect map viewer with lot/wafer selector. Defects rendered as colored circles scaled by defect size. Spatial pattern automatically classified (RING/EDGE/SCRATCH/CLUSTER/RANDOM) and displayed as a color-coded badge. Shows total defect count. |
| **Tab 3 — Stacked Map** | Multi-lot stacked wafer map showing cumulative failure rate per die position across 5 lots. Color gradient from teal (low fail rate) to red (high fail rate) reveals systematic hotspots. Supports reticle/shot overlay for lithography defect analysis. |
| **Tab 4 — ADC Gallery (Auto Defect Classification)** | Image gallery of defect thumbnails organized by classification category (PARTICLE/SCRATCH/CRYSTAL/BRIDGE/VOID/BUMP). Filter buttons at top allow class-specific browsing. Each thumbnail shows defect size, ADC confidence %, and process layer. |
| **Tab 5 — WPA Patterns (Wafer Pattern Analysis)** | Gallery of lot-level spatial pattern cards. Each card shows lot ID, pattern type badge (color-coded), confidence score progress bar, defect count, and estimated yield impact (%). Supports pattern-based lot grouping for systematic defect investigation. |
| **Defect Class Legend** | Color-coded legend panel listing all 19 defect classes with their assigned colors for consistent visual reference across all defect views. |

---

## Module 8 — RF Analysis (S-Parameter)

A dedicated RF device characterization module for analyzing S-parameter data from Touchstone (.s2p) format files, providing Smith Chart and frequency response visualization.

| Sub-Function | Description |
|---|---|
| **Smith Chart (3 Devices)** | Three side-by-side Smith Chart displays (one per device: GLW1234_device1/3/4). Each chart renders the S11 impedance locus as a colored trace on the normalized impedance plane, with resistance circles and the center cross reference. S22 is shown as a dashed circle overlay. |
| **S11 Frequency Response — Per Device** | Three individual frequency response charts showing S11 Magnitude (dB) and Phase (°) vs. frequency (GHz) for each device. Enables device-to-device comparison of RF performance. |
| **Combined S11 Response** | Single overlay chart showing S11 magnitude for all three devices simultaneously, with each device in a distinct color. Allows direct visual comparison of device-to-device variation across the 1–4 GHz frequency range. |
| **File Format Support** | Processes Touchstone .s2p format files. Displays filename as chart title. Supports batch processing of multiple devices from the same lot. |

---

## Module 9 — Die Traceability

An end-to-end assembly and test traceability module enabling single-die tracking from wafer sort through final test and packaging, supporting automotive and medical quality requirements.

| Sub-Function | Description |
|---|---|
| **BinCode per Tray Pareto** | Horizontal bar chart showing die count per bin code (Bin 1 FT Pass, Bin 106 Functional Fail, Bin 107 Parametric Fail, Bin 108 Leakage Fail, Bin 0 Singulate Fail) across all trays. Color-coded by bin type. |
| **Tray Yield Summary** | Scrollable list showing yield percentage for each of the 10 trays (SiPLot1SimpleTray_1 through _10) with color-coded progress bars (green > 90%, yellow > 80%, red otherwise). |
| **Individual Tray Bin Maps** | 10-panel grid showing the physical die layout for each tray (8 rows × 12 columns = 96 dies per tray). Each die is color-coded by status: FT_PASS (teal), FT_FAIL (red), SINGULATE_FAIL (violet), UNKNOWN (gray). Yield % shown per tray. |
| **Die Status Legend** | Color-coded legend explaining all four die status categories with their associated colors and descriptions. Includes a note about single die traceability without ECID via Assembly Operations mapping. |

---

## Module 10 — SemiMind++ AI Agent

An LLM-powered conversational AI assistant for semiconductor yield analysis, capable of autonomous root cause investigation and actionable recommendations.

| Sub-Function | Description |
|---|---|
| **Chat Interface** | Split-panel layout with conversation on the left and pending actions on the right. Supports markdown rendering via Streamdown. Messages show timestamps and role icons (user = teal, agent = violet). |
| **Suggested Prompts** | Three rotating prompt cards below the input box for common analysis scenarios (e.g., "Why is lot M900004 showing low yield?", "Analyze CMP-03 pressure anomaly"). |
| **Tool Call Cards** | Collapsible cards showing each API tool call the agent executed (e.g., query_yield_data, search_knowledge_base, run_ml_inference). Shows tool name, execution status (running/complete), and result summary. |
| **RCA Hypothesis Cards** | Structured hypothesis cards showing the agent's root cause conclusions with confidence score progress bar, physical mechanism explanation, and supporting evidence. Multiple hypotheses ranked by confidence. |
| **Action Proposal Cards** | Actionable recommendation cards proposing specific corrective actions (LOT_HOLD, RECIPE_ADJ, PM_SCHEDULE). Shows action type, target entity, description, and confidence score. Engineers can Approve or Reject with one click. |
| **Pending Actions Panel** | Right-side panel listing all pending agent actions from the database. Each action shows type badge, target lot/equipment, description, confidence %, and Approve/Reject buttons. |
| **Streaming Response** | Real-time character-by-character text rendering as the LLM generates its response, with a pulsing "analyzing..." indicator during processing. |

---

## Module 11 — FAB Control Dashboard

A mission-control-style operations dashboard providing real-time visibility into the entire fab floor, equipment status, and AI-driven action queue.

| Sub-Function | Description |
|---|---|
| **AI Shift Summary** | Auto-generated three-panel summary showing Critical Events (equipment anomalies, lot holds), AI Actions Taken (auto-approved actions, recipe adjustments), and Production Status (active lots, HOT lots, fab yield). Timestamp shows generation time. |
| **Equipment Fleet Grid** | Full equipment fleet organized by area (ETCH/CVD/LITHO/CMP/WAT/INSPECT). Each equipment card shows: ID, name, status badge (PROD/PM/DOWN/QUAL), health score bar, utilization % bar, WPH throughput, and 24h alarm count. Color-coded borders by status. |
| **Pending Approvals Queue** | Right-panel list of agent actions awaiting engineer approval. Each action shows type badge (color-coded), target entity, description, RCA summary excerpt, confidence score, and Approve & Execute / Reject buttons. Badge counter shows total pending count. |
| **Hot Lots & Holds Panel** | List of lots with HOT priority or HOLD status. Each entry shows lot ID, product ID, current step, and a Release Hold button for HOLD lots. |
| **KPI Header Strip** | Three summary cards showing Lots In Process, Active Alarms, and Tools Down counts for instant fab health assessment. |

---

## Module 12 — Equipment Fleet

A dedicated equipment health monitoring page providing detailed health metrics, utilization tracking, and alarm history for all 16 production tools.

| Sub-Function | Description |
|---|---|
| **Equipment Health Cards** | 16 cards (2-column grid) each showing: equipment ID, full name, status badge, health score progress bar with color-coded fill (green ≥ 90, yellow ≥ 70, orange ≥ 50, red < 50), utilization % bar, WPH throughput, tool type, area, and 24h alarm count. |
| **Fleet Status Summary** | Header strip showing counts per status category (PROD/PM/DOWN/QUAL) with color-coded dot indicators for instant fleet health overview. |
| **Hover Interaction** | Cards scale up slightly on hover (scale 1.01) with smooth transition for interactive feel. |

---

## Module 13 — Database & Data Architecture

The underlying data infrastructure supporting all analytical modules with persistent storage and real-time data access.

| Sub-Function | Description |
|---|---|
| **Equipment Table** | Stores 16 equipment records with fields: equipment_id, equipment_name, tool_type (ETCH/CVD/LITHO/CMP/WAT/INSPECT/IMPLANT/ANNEAL), chamber_id, area, status, health_score, utilization_pct, throughput_wph, alarm_count_24h. |
| **Lots Table** | Tracks 10 production lots with fields: lot_id, product_id, process_node, lot_type, priority (HOT/NORMAL/LOW), status (IN_PROCESS/COMPLETE/HOLD/SCRAP), current_step, total_wafers, gross_yield_pct, net_yield_pct, customer_id. |
| **WAT Results Table** | Stores parametric test results with fields: lot_id, wafer_id, site_number, parameter_id, parameter_name, measured_value, spec_high, spec_low, target_value, is_pass, z_score, equipment_id, test_time. |
| **CP Results Table** | Stores circuit probe die-level results with fields: lot_id, wafer_id, die_x, die_y, bin_code, bin_description, is_pass, tester_id. |
| **Defect Maps Table** | Stores defect inspection data with fields: lot_id, wafer_id, defect_x/y coordinates, defect_size_um2, defect_class, adc_class, adc_confidence, layer_name, spatial_pattern (RING/EDGE/SCRATCH/CLUSTER/RANDOM). |
| **SPC Violations Table** | Records SPC rule breaches with fields: parameter_id, equipment_id, lot_id, rule_violated (WECO_1 through WECO_8), measured_value, ucl, lcl, center_line, severity (CRITICAL/MAJOR/MINOR), status (OPEN/ACK/RESOLVED). |
| **Alarms Table** | Stores equipment and process alarms with fields: equipment_id, alarm_code, alarm_category (FDC/SPC/YIELD/SYSTEM), severity, alarm_message, lot_id, process_step, status, ack_by, ack_time. |
| **Agent Actions Table** | Logs all AI agent actions with fields: session_id, action_type (LOT_HOLD/RECIPE_ADJ/PM_SCHEDULE/NOTIFY/ESCALATE/RCA), target_entity, action_description, confidence_score, trigger_source, status (PENDING/APPROVED/REJECTED/EXECUTED/FAILED), rca_summary. |
| **Yield Summaries Table** | Aggregated yield metrics with fields: lot_id, wafer_id, product_id, process_step, gross_yield_pct, net_yield_pct, total_die, pass_die, fail_die, yield_category (NORMAL/LOW/EXCURSION). |

---

## RBAC — Role-Based Access Control

| Role | Access Level | Description |
|---|---|---|
| **FAB_OPERATOR** | Read-only | View dashboards and alarm feeds. Cannot modify data or approve agent actions. |
| **PROCESS_ENGINEER** | Standard | Full analytics access. Can acknowledge alarms and view all analysis modules. |
| **SENIOR_ENGINEER** | Advanced | Can approve/reject agent actions with confidence < 90%. Access to all modules. |
| **MANAGER** | Management | Access to all modules plus management reports and cross-fab benchmarking. |
| **ADMIN** | Full | Complete system access including user management, configuration, and all operations. |

---

*Document: SEMFAB·IQ v2.0 Complete Function Reference*  
*Total: 13 Modules · 80+ Sub-Functions · 9 Database Tables · 5 RBAC Roles*
