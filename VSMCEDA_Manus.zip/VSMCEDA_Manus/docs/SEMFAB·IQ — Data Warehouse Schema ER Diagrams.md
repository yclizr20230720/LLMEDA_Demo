# SEMFAB·IQ — Data Warehouse Schema ER Diagrams
## Part 2: Greenplum, Oracle, and Neo4j Database Designs

This document provides the complete Entity-Relationship (ER) diagrams for the three core databases in the SEMFAB·IQ platform.

---

### 1. Greenplum EDW (Enterprise Data Warehouse) — Historical Analytics

Greenplum stores petabytes of historical data using a Star Schema design. Fact tables are distributed by `lot_id` or `wafer_id` to maximize MPP parallel query performance and partitioned by date.

```mermaid
erDiagram
    %% Dimensions
    DIM_LOT {
        varchar lot_id PK "Natural key from MES"
        varchar product_id FK
        varchar process_node "e.g., 28nm, 5nm"
        varchar lot_type "PROD / ENG / QUAL"
        varchar priority "HOT / NORMAL"
        timestamp start_date
        varchar customer_id
        int total_wafers
        varchar current_status
    }

    DIM_EQUIPMENT {
        varchar equipment_id PK
        varchar equipment_name
        varchar tool_type "ETCH / CVD / LITHO / WAT"
        varchar chamber_id
        varchar fab_id
        varchar vendor
        int pm_interval_days
        timestamp last_pm_date
        varchar status "PROD / DOWN / PM"
    }

    DIM_PARAMETER {
        varchar parameter_id PK
        varchar parameter_name
        varchar category "MOSFET / BJT / CAP / RES"
        varchar unit
        float spec_high
        float spec_low
        float target_value
        varchar test_method
    }

    DIM_PRODUCT {
        varchar product_id PK
        varchar product_name
        varchar process_node
        int die_per_wafer
        float target_yield_pct
        varchar wafer_size
    }

    %% Facts
    FACT_WAT_RESULT {
        bigserial result_id PK
        varchar lot_id FK
        varchar wafer_id FK
        int site_number
        varchar parameter_id FK
        varchar equipment_id FK
        float measured_value
        float spec_high
        float spec_low
        boolean is_pass
        float z_score
        date test_date "Partition Key"
        timestamp test_time
    }

    FACT_CP_RESULT {
        bigserial result_id PK
        varchar lot_id FK
        varchar wafer_id FK
        smallint die_x
        smallint die_y
        smallint bin_code
        boolean is_pass
        varchar tester_id FK
        date test_date "Partition Key"
        timestamp test_time
    }

    FACT_DEFECT_MAP {
        bigserial defect_id PK
        varchar lot_id FK
        varchar wafer_id FK
        float defect_x_um
        float defect_y_um
        float defect_size_um2
        varchar defect_class_adc
        float adc_confidence
        varchar layer_name
        varchar inspection_tool_id FK
        date inspect_date "Partition Key"
        varchar spatial_pattern
    }

    FACT_INLINE_METRO {
        bigserial metro_id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar step_id
        varchar equipment_id FK
        varchar measurement_type
        float measured_value
        boolean spc_violation
        date measure_date "Partition Key"
    }

    FACT_YIELD_SUMMARY {
        bigserial summary_id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar product_id FK
        float gross_yield_pct
        float net_yield_pct
        int pass_die
        int fail_die
        date summary_date "Partition Key"
        varchar yield_category
    }

    %% Relationships
    DIM_LOT ||--o{ FACT_WAT_RESULT : "1:N"
    DIM_LOT ||--o{ FACT_CP_RESULT : "1:N"
    DIM_LOT ||--o{ FACT_DEFECT_MAP : "1:N"
    DIM_LOT ||--o{ FACT_INLINE_METRO : "1:N"
    DIM_LOT ||--o{ FACT_YIELD_SUMMARY : "1:1"
    
    DIM_EQUIPMENT ||--o{ FACT_WAT_RESULT : "1:N"
    DIM_EQUIPMENT ||--o{ FACT_INLINE_METRO : "1:N"
    
    DIM_PARAMETER ||--o{ FACT_WAT_RESULT : "1:N"
    DIM_PRODUCT ||--o{ FACT_YIELD_SUMMARY : "1:N"
```

---

### 2. Oracle ODS (Operational Data Store) — Real-Time Operations

Oracle handles sub-second latency operations, including live alarms, WIP tracking, and Run-to-Run control feedback loops.

```mermaid
erDiagram
    LIVE_ALARM {
        number alarm_id PK "Sequence"
        varchar2 equipment_id FK
        varchar2 alarm_code
        varchar2 alarm_category "FDC / SPC / YIELD"
        varchar2 severity "CRITICAL / MAJOR / MINOR"
        clob alarm_message
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 process_step
        timestamp alarm_time
        varchar2 status "OPEN / ACK / RESOLVED"
        varchar2 ack_by
        timestamp ack_time
        varchar2 agent_action_id "FK to Agent Log"
    }

    EQUIPMENT_STATUS_RT {
        varchar2 equipment_id PK
        varchar2 status "PROD / PM / DOWN / IDLE"
        number utilization_pct
        number throughput_wph
        number health_score
        varchar2 current_lot_id
        varchar2 current_recipe
        number alarm_count_24h
        timestamp last_update
    }

    WIP_TRACKING {
        number wip_id PK "Sequence"
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 current_step
        varchar2 equipment_id FK
        varchar2 status "QUEUED / PROCESSING / HOLD"
        timestamp step_start_time
        number priority
        varchar2 hold_reason
        varchar2 hold_by
    }

    RUN_TO_RUN_CTRL {
        number ctrl_id PK "Sequence"
        varchar2 equipment_id FK
        varchar2 parameter_name
        number target_value
        number current_setpoint
        number correction_delta
        varchar2 ctrl_algorithm "EWMA / PID / MODEL"
        timestamp ctrl_time
        varchar2 lot_id
    }

    AGENT_ACTION_LOG {
        number action_id PK "Sequence"
        varchar2 session_id
        varchar2 action_type "LOT_HOLD / RECIPE_ADJ / PM_SCHEDULE"
        varchar2 target_entity_id
        clob action_payload "JSON"
        number confidence_score
        varchar2 trigger_source "ALARM / YIELD_DROP"
        varchar2 status "PENDING / APPROVED / EXECUTED"
        varchar2 approved_by
        timestamp executed_time
        varchar2 outcome "SUCCESS / FAILED"
    }

    EQUIPMENT_STATUS_RT ||--o{ LIVE_ALARM : "1:N"
    EQUIPMENT_STATUS_RT ||--o{ WIP_TRACKING : "1:N"
    EQUIPMENT_STATUS_RT ||--o{ RUN_TO_RUN_CTRL : "1:N"
    LIVE_ALARM ||--o{ AGENT_ACTION_LOG : "Triggers"
```

---

### 3. Neo4j Knowledge Graph — RCA Wisdom Engine

The Neo4j graph database stores the "Wisdom" accumulated by the Agentic AI. It maps the relationships between equipment, process parameters, defect patterns, root causes, and corrective actions.

```mermaid
graph TB
    subgraph NEO4J_SCHEMA["Neo4j Knowledge Graph Schema"]
        subgraph NODES["Node Types"]
            N1["(:Equipment)\nid, type, chamber\nhealth_score"]
            N2["(:Parameter)\nid, name, unit\ncriticality"]
            N3["(:ProcessStep)\nid, layer, tool_type"]
            N4["(:DefectPattern)\nid, spatial_class"]
            N5["(:RootCause)\nid, category, mechanism\nconfidence, occurrences"]
            N6["(:CorrectiveAction)\nid, type, description\nsuccess_rate"]
            N7["(:LotEvent)\nid, lot_id, symptom\noutcome"]
        end

        subgraph RELS["Relationship Types"]
            R1["(:Equipment)-[:PROCESSES]->(:ProcessStep)"]
            R2["(:ProcessStep)-[:MEASURES]->(:Parameter)"]
            R3["(:Parameter)-[:CAUSES_WHEN_OOC]->(:RootCause)"]
            R4["(:DefectPattern)-[:INDICATES]->(:RootCause)"]
            R5["(:RootCause)-[:FIXED_BY]->(:CorrectiveAction)"]
            R6["(:LotEvent)-[:RESOLVED_BY]->(:CorrectiveAction)"]
            R7["(:RootCause)-[:SIMILAR_TO {similarity_score}]->(:RootCause)"]
        end
        
        %% Visual layout connections (not actual graph edges)
        N1 -.-> R1
        N3 -.-> R2
        N2 -.-> R3
        N4 -.-> R4
        N5 -.-> R5
        N7 -.-> R6
        N5 -.-> R7
    end
```
