# SEMFAB·IQ — Full-Stack Implementation Thinking
## Semiconductor Engineering Data Analytics Platform
### Complete Architecture Thinking: Data Warehouse · Web Application · API Services · Docker/K8s

> **Document Type:** Full-Stack Implementation Design Thinking  
> **Scope:** Data Warehouse Schema · Datamart Design · Web Application · API Services · Docker/K8s HA Deployment  
> **Reference:** SEMFAB·IQ Architecture Design Report v1.0 + Semitronix Yield Ecosystem Function Map  
> **Design Philosophy:** Production-grade · High Availability · Super High Performance · Fab-Scale Engineering Data

---

## Table of Contents

1. [Implementation Philosophy & Core Thinking](#1-implementation-philosophy--core-thinking)
2. [Data Architecture: Warehouse & Datamart Schema Design](#2-data-architecture-warehouse--datamart-schema-design)
3. [Web Application Architecture Design](#3-web-application-architecture-design)
4. [API Service Design](#4-api-service-design)
5. [Docker Containerization Strategy](#5-docker-containerization-strategy)
6. [Kubernetes High-Availability Deployment](#6-kubernetes-high-availability-deployment)
7. [Performance Engineering for Fab-Scale Data](#7-performance-engineering-for-fab-scale-data)
8. [Implementation Execution Roadmap](#8-implementation-execution-roadmap)

---

## 1. Implementation Philosophy & Core Thinking

### 1.1 The Fundamental Challenge

A semiconductor wafer FAB generates data at a scale that dwarfs most enterprise systems. A single 300mm fab running 24/7 produces:

| Data Source | Volume | Frequency |
|---|---|---|
| WAT parametric measurements | ~200 parameters × 100K sites/day | Continuous |
| FDC equipment trace signals | ~500 sensors × 1K samples/sec/tool × 200 tools | Real-time streaming |
| Defect inspection maps | ~50MB per wafer × 1,000 wafers/day | Batch per inspection |
| CP test results (STDF) | ~500MB per lot × 50 lots/day | Batch per lot |
| Inline metrology | ~50 measurements per wafer per step | Per process step |

This means the system must handle **>100K events/second** at peak ingestion, serve **sub-200ms API responses** for interactive dashboards, and simultaneously run **complex statistical models** via SAS Viya that may take minutes to compute. The architecture must never let these three workloads interfere with each other.

The core design principle is therefore **workload isolation through layered architecture**: real-time OLTP in Oracle, historical analytical workloads in Greenplum, heavy statistical computation offloaded to SAS Viya CAS, and hot/frequently-accessed data cached in Redis — each layer optimized for its specific access pattern.

### 1.2 The Three-Database Strategy Rationale

```mermaid
graph LR
    subgraph WHY["Why Three Databases?"]
        ORA_WHY["Oracle RAC\n─────────────\nSub-second writes\nACID transactions\nLive alarms & WIP\nRun-to-run control\nEquipment status"]
        GP_WHY["Greenplum MPP\n─────────────\nPetabyte-scale reads\nColumnar compression\nParallel query (MPP)\nHistorical analytics\nML feature store"]
        SAS_WHY["SAS Viya CAS\n─────────────\nCertified statistics\nIn-memory compute\nRegulatory compliance\nSPC/ANOVA/DOE\nModel training"]
    end

    ORA_WHY -->|"ETL nightly\nbatch sync"| GP_WHY
    GP_WHY -->|"Bulk load\nhot tables"| SAS_WHY
    SAS_WHY -->|"Write results\nback"| GP_WHY
```

Oracle is chosen for real-time operations because its RAC (Real Application Clusters) architecture provides the ACID compliance and sub-millisecond write latency required for alarm management and WIP tracking — where data consistency is non-negotiable. Greenplum's MPP columnar architecture is the correct choice for analytical queries spanning billions of rows of historical WAT and CP data, where Oracle would be cost-prohibitive and slow. SAS Viya is not a general-purpose database but a **certified statistical computation engine** — its role is to provide ISO 9001 and IATF 16949-compliant statistical outputs that raw Python scipy cannot match for automotive and advanced-node customers.

---

## 2. Data Architecture: Warehouse & Datamart Schema Design

### 2.1 Overall Data Architecture: Three-Zone Model

```mermaid
graph TB
    subgraph ZONE1["Zone 1 — Raw Staging (Greenplum: schema raw_*)"]
        R1[raw.wat_stdf_staging\nRaw STDF parsed rows]
        R2[raw.cp_stdf_staging\nRaw CP test data]
        R3[raw.defect_klarf_staging\nRaw KLARF defect data]
        R4[raw.inline_metro_staging\nRaw metrology XML]
        R5[raw.fdc_trace_staging\nRaw equipment traces]
    end

    subgraph ZONE2["Zone 2 — Enterprise Data Warehouse (Greenplum: schema dw_*)"]
        subgraph DIM["Dimension Tables — Slowly Changing"]
            D1[dw.dim_lot\nLot master + product info]
            D2[dw.dim_wafer\nWafer identity + position]
            D3[dw.dim_equipment\nTool master + chamber]
            D4[dw.dim_parameter\nTest parameter dictionary]
            D5[dw.dim_process_step\nProcess flow definition]
            D6[dw.dim_product\nProduct + node + spec]
            D7[dw.dim_recipe\nRecipe version history]
            D8[dw.dim_date\nCalendar dimension]
        end
        subgraph FACT["Fact Tables — Partitioned + Distributed"]
            F1[dw.fact_wat_result\nPartitioned by test_date\nDistributed by lot_id]
            F2[dw.fact_cp_result\nPartitioned by test_date\nDistributed by lot_id]
            F3[dw.fact_defect_map\nPartitioned by inspect_date\nDistributed by wafer_id]
            F4[dw.fact_inline_metro\nPartitioned by measure_date\nDistributed by lot_id]
            F5[dw.fact_yield_summary\nPartitioned by summary_date\nDistributed by product_id]
            F6[dw.fact_fdc_alarm\nPartitioned by alarm_date\nDistributed by equipment_id]
        end
    end

    subgraph ZONE3["Zone 3 — Subject-Area Datamarts (Greenplum: schema dm_*)"]
        DM1[dm.yield_mart\nYield KPIs by product/node/step]
        DM2[dm.equipment_health_mart\nEquipment performance metrics]
        DM3[dm.defect_analytics_mart\nDefect density + pattern stats]
        DM4[dm.spc_control_mart\nSPC limits + violation history]
        DM5[dm.rca_knowledge_mart\nRCA case + resolution history]
        DM6[dm.ml_feature_mart\nPre-computed ML feature vectors]
    end

    ZONE1 -->|"ETL: validate\nclean, enrich"| ZONE2
    ZONE2 -->|"Aggregation\nMaterialized views"| ZONE3
```

### 2.2 Greenplum Data Warehouse — Complete Schema Design

The Greenplum schema uses a **star schema** design optimized for MPP columnar analytics. All fact tables are **range-partitioned by date** and **hash-distributed by the primary analytical key** to maximize parallel query performance.

#### 2.2.1 Core Dimension Tables

```mermaid
erDiagram
    DIM_LOT {
        varchar lot_id PK "Natural key from MES"
        varchar product_id FK
        varchar process_node "e.g. 28nm, 7nm"
        varchar lot_type "PROD / QUAL / ENG"
        varchar priority "HOT / NORMAL / LOW"
        date start_date
        date target_complete_date
        varchar customer_id
        varchar foundry_id
        int total_wafers
        varchar current_status
        timestamp created_at
        timestamp updated_at
        int scd_version "SCD Type 2"
        boolean is_current
    }

    DIM_EQUIPMENT {
        varchar equipment_id PK "Tool ID from MES"
        varchar equipment_name
        varchar tool_type "ETCH / CVD / LITHO / CMP / WAT"
        varchar chamber_id
        varchar area_id
        varchar fab_id
        varchar vendor
        varchar model_number
        date install_date
        int pm_interval_days
        date last_pm_date
        date next_pm_date
        float baseline_health_score
        varchar status "PROD / PM / DOWN / QUAL"
        timestamp updated_at
    }

    DIM_PARAMETER {
        varchar parameter_id PK "Unique param code"
        varchar parameter_name
        varchar parameter_category "MOSFET / BJT / RESISTOR / CAP / RELIABILITY"
        varchar unit
        float spec_high_default
        float spec_low_default
        float target_value
        varchar test_method "DC / AC / CV / RF"
        varchar criticality "CRITICAL / MAJOR / MINOR"
        boolean is_active
        varchar process_node_applicability
    }

    DIM_PROCESS_STEP {
        varchar step_id PK
        varchar step_name
        varchar layer_name "M1 / POLY / ACTIVE"
        varchar step_type "LITHO / ETCH / DEP / IMP / CMP / ANNEAL"
        int step_sequence
        varchar process_flow_id FK
        float nominal_cd_nm
        float nominal_thickness_nm
        varchar equipment_type_required
    }

    DIM_PRODUCT {
        varchar product_id PK
        varchar product_name
        varchar process_node
        varchar product_family
        varchar customer
        int die_per_wafer
        float die_size_mm2
        float target_yield_pct
        varchar wafer_size "200mm / 300mm"
        varchar technology_type "LOGIC / MEMORY / ANALOG / RF"
    }
```

#### 2.2.2 Core Fact Tables — WAT and CP

```mermaid
erDiagram
    FACT_WAT_RESULT {
        bigserial result_id PK
        varchar lot_id FK
        varchar wafer_id FK
        int site_number
        varchar parameter_id FK
        varchar equipment_id FK
        varchar recipe_id FK
        varchar step_id FK
        float measured_value
        float spec_high
        float spec_low
        float target_value
        boolean is_pass
        float z_score "Normalized deviation"
        float percentile_rank
        varchar outlier_flag "NONE / SOFT / HARD"
        timestamp test_time
        date test_date "Partition key"
        varchar process_node
        varchar product_id FK
        varchar tester_module_id
        float temperature_c
        float humidity_pct
    }

    FACT_CP_RESULT {
        bigserial result_id PK
        varchar lot_id FK
        varchar wafer_id FK
        smallint die_x
        smallint die_y
        smallint bin_code
        varchar bin_description
        boolean is_pass
        varchar test_program_id
        varchar tester_id FK
        timestamp test_time
        date test_date "Partition key"
        varchar product_id FK
        varchar process_node
        float x_coord_mm
        float y_coord_mm
        int site_row
        int site_col
    }

    FACT_DEFECT_MAP {
        bigserial defect_id PK
        varchar lot_id FK
        varchar wafer_id FK
        float defect_x_um
        float defect_y_um
        float defect_size_um2
        varchar defect_class_raw "From inspection tool"
        varchar defect_class_adc "AI-classified"
        float adc_confidence
        varchar layer_name FK
        varchar inspection_tool_id FK
        varchar inspection_recipe
        timestamp inspect_time
        date inspect_date "Partition key"
        varchar klarf_file_path "MinIO path"
        varchar sem_image_path "MinIO path"
        float roughness_score
        varchar spatial_pattern "RING / EDGE / SCRATCH / CLUSTER / RANDOM"
    }

    FACT_INLINE_METRO {
        bigserial metro_id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar step_id FK
        varchar equipment_id FK
        varchar measurement_type "CD / OVL / THICKNESS / ROUGHNESS"
        float measured_value
        float target_value
        float ucl
        float lcl
        float sigma_level
        boolean spc_violation
        varchar spc_rule_violated
        int site_number
        float x_coord_mm
        float y_coord_mm
        timestamp measure_time
        date measure_date "Partition key"
        varchar recipe_id FK
    }

    FACT_YIELD_SUMMARY {
        bigserial summary_id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar product_id FK
        varchar process_step FK
        float gross_yield_pct
        float net_yield_pct
        int total_die
        int pass_die
        int fail_die
        int bin1_count
        int bin2_count
        int bin3_count
        int bin_other_count
        date summary_date "Partition key"
        varchar yield_category "NORMAL / LOW / EXCURSION"
        float yield_deviation_sigma
    }
```

#### 2.2.3 Greenplum Physical Design Directives

```mermaid
graph TB
    subgraph PHYSICAL["Greenplum Physical Design — Performance Engineering"]
        subgraph PARTITION["Partitioning Strategy"]
            P1["fact_wat_result\nRANGE PARTITION BY test_date\nMonthly partitions × 5 years\n= 60 partitions\nEach partition ~50GB"]
            P2["fact_cp_result\nRANGE PARTITION BY test_date\nMonthly partitions × 5 years\nEach partition ~200GB"]
            P3["fact_defect_map\nRANGE PARTITION BY inspect_date\nMonthly partitions × 5 years\nEach partition ~100GB"]
        end

        subgraph DISTRIBUTION["Distribution Keys — Minimize Data Motion"]
            DK1["fact_wat_result\nDISTRIBUTED BY (lot_id)\nEnsures lot queries hit 1 segment"]
            DK2["fact_cp_result\nDISTRIBUTED BY (lot_id, wafer_id)\nJoins with WAT on lot_id are local"]
            DK3["fact_defect_map\nDISTRIBUTED BY (wafer_id)\nWafer-level spatial analysis is local"]
            DK4["dim_equipment\nDISTRIBUTED REPLICATED\nSmall table — replicate to all segments"]
        end

        subgraph INDEX["Index Strategy"]
            I1["Bitmap index on:\nproduct_id, process_node, equipment_id\nHigh-cardinality filter columns"]
            I2["B-tree index on:\nlot_id, wafer_id, test_date\nPoint lookup and range scans"]
            I3["NO index on measured_value\nFull column scan is faster in MPP"]
        end

        subgraph COMPRESS["Compression — Columnar Storage"]
            C1["ENCODING (measured_value ENCODING (RLE_TYPE))\nFloat columns: delta + RLE compression\nTypically 5-8× compression ratio"]
            C2["ENCODING (lot_id ENCODING (ZLIB))\nString columns: ZLIB level 1\nFast decompression for hot queries"]
        end
    end
```

### 2.3 Subject-Area Datamart Design

Datamarts are **pre-aggregated materialized views** refreshed on a schedule, designed to serve dashboard queries in under 200ms without hitting raw fact tables.

```mermaid
erDiagram
    DM_YIELD_MART {
        varchar product_id PK
        varchar process_node PK
        varchar process_step PK
        date summary_date PK
        float avg_gross_yield_pct
        float avg_net_yield_pct
        float yield_stddev
        float yield_p5
        float yield_p25
        float yield_p50
        float yield_p75
        float yield_p95
        int lot_count
        int wafer_count
        int excursion_count
        float excursion_rate_pct
        varchar top_fail_bin
        float top_fail_bin_pct
        timestamp last_refreshed
    }

    DM_EQUIPMENT_HEALTH_MART {
        varchar equipment_id PK
        date health_date PK
        float health_score_composite
        float parameter_z_score_avg
        float spc_violation_rate_pct
        int alarm_count_24h
        int critical_alarm_count
        float utilization_pct
        float throughput_wph
        int days_since_last_pm
        float pm_overdue_risk_score
        varchar health_status "HEALTHY / WATCH / DEGRADED / CRITICAL"
        timestamp last_refreshed
    }

    DM_DEFECT_ANALYTICS_MART {
        varchar product_id PK
        varchar layer_name PK
        varchar defect_class PK
        date inspect_date PK
        float defect_density_per_cm2
        int total_defect_count
        float avg_defect_size_um2
        float yield_impact_pct
        varchar dominant_spatial_pattern
        float pattern_confidence
        varchar suspected_process_step
        varchar suspected_equipment_id
        timestamp last_refreshed
    }

    DM_SPC_CONTROL_MART {
        varchar parameter_id PK
        varchar equipment_id PK
        date control_date PK
        float ucl
        float lcl
        float center_line
        float cpk
        float cp
        float ppk
        int violation_count
        int rule1_violations "1pt > 3sigma"
        int rule2_violations "9pts same side"
        int rule3_violations "6pts trend"
        float sigma_level
        boolean is_in_control
        timestamp last_refreshed
    }

    DM_RCA_KNOWLEDGE_MART {
        varchar rca_case_id PK
        varchar symptom_signature
        varchar root_cause_category
        varchar root_cause_detail
        varchar corrective_action
        float confidence_score
        int occurrence_count
        float avg_resolution_hours
        float success_rate_pct
        varchar validated_by
        timestamp first_seen
        timestamp last_seen
        boolean is_active
    }
```

### 2.4 Oracle Real-Time OLTP Schema — Complete Design

Oracle handles all sub-second latency operations. The schema is designed for **high-frequency writes** and **immediate reads** with minimal join complexity.

```mermaid
erDiagram
    LIVE_ALARM {
        number alarm_id PK "SEQUENCE"
        varchar2 equipment_id FK
        varchar2 alarm_code
        varchar2 alarm_category "FDC / SPC / YIELD / SYSTEM"
        varchar2 severity "CRITICAL / MAJOR / MINOR / INFO"
        clob alarm_message
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 process_step
        varchar2 parameter_name
        number measured_value
        number spec_limit
        timestamp alarm_time
        varchar2 status "OPEN / ACK / RESOLVED / SUPPRESSED"
        varchar2 ack_by
        timestamp ack_time
        clob action_taken
        varchar2 agent_rca_id "FK to agent action"
        number auto_resolved "0/1"
    }

    EQUIPMENT_STATUS_RT {
        varchar2 equipment_id PK
        varchar2 status "PROD / PM / DOWN / QUAL / IDLE"
        number utilization_pct
        number throughput_wph
        number health_score
        varchar2 current_lot_id
        varchar2 current_recipe
        varchar2 current_step
        number alarm_count_1h
        number alarm_count_24h
        number wafers_processed_today
        timestamp last_update
        varchar2 last_alarm_code
        timestamp last_pm_date
        number pm_overdue_days
    }

    WIP_TRACKING {
        number wip_id PK "SEQUENCE"
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 current_step FK
        varchar2 equipment_id FK
        varchar2 status "QUEUED / PROCESSING / COMPLETE / HOLD / SCRAP"
        timestamp step_start_time
        timestamp step_end_time
        number priority
        varchar2 hold_reason
        varchar2 hold_by
        timestamp hold_time
        varchar2 release_by
        timestamp release_time
        number cycle_time_minutes
        varchar2 agent_action_id "If held by AI agent"
    }

    RUN_TO_RUN_CTRL {
        number ctrl_id PK "SEQUENCE"
        varchar2 equipment_id FK
        varchar2 parameter_name
        varchar2 process_step FK
        number target_value
        number current_setpoint
        number previous_setpoint
        number measured_output
        number correction_delta
        number correction_pct
        varchar2 model_name
        varchar2 ctrl_algorithm "EWMA / PID / MODEL_BASED"
        number model_confidence
        timestamp ctrl_time
        varchar2 lot_id
        varchar2 applied_by "SYSTEM / ENGINEER"
        boolean approved
    }

    AGENT_ACTION_LOG {
        number action_id PK "SEQUENCE"
        varchar2 session_id
        varchar2 action_type "LOT_HOLD / RECIPE_ADJ / PM_SCHEDULE / NOTIFY / ESCALATE"
        varchar2 target_entity_type "LOT / EQUIPMENT / STEP"
        varchar2 target_entity_id
        clob action_description
        clob action_payload "JSON"
        number confidence_score
        varchar2 trigger_source "ALARM / YIELD_DROP / FDC / MANUAL"
        varchar2 trigger_id FK
        varchar2 status "PENDING / APPROVED / REJECTED / EXECUTED / FAILED"
        varchar2 approved_by
        timestamp approved_time
        timestamp executed_time
        clob execution_result "JSON"
        varchar2 outcome "SUCCESS / PARTIAL / FAILED"
        boolean knowledge_updated
    }

    LIVE_ALARM ||--o{ WIP_TRACKING : "lot_id"
    EQUIPMENT_STATUS_RT ||--o{ LIVE_ALARM : "equipment_id"
    EQUIPMENT_STATUS_RT ||--o{ RUN_TO_RUN_CTRL : "equipment_id"
    LIVE_ALARM ||--o{ AGENT_ACTION_LOG : "trigger_id"
```

---

## 3. Web Application Architecture Design

### 3.1 Frontend Module Map — React + Vite

The frontend is designed with a **GUI-first philosophy**: every module is designed around the engineer's workflow, not the data model. The application shell loads in under 1 second, with all feature modules lazy-loaded on demand.

```mermaid
graph TB
    subgraph SHELL["Application Shell — Always Loaded"]
        NAV["Global Navigation Bar\n• Module switcher\n• Live alarm badge counter\n• Equipment health strip\n• User profile + settings\n• Dark/Light mode toggle"]
        NOTIF["Notification Center\n• Real-time alarm feed (WebSocket)\n• Agent activity stream\n• SPC violation alerts"]
        AUTH_CTX["Auth Context\n• JWT token management\n• Role-based UI rendering\n• Session refresh"]
    end

    subgraph MODULES["Feature Modules — Lazy Loaded via React.lazy()"]
        M1["📊 YMS Dashboard\nYield Management System\n─────────────────────\n• Fab-wide yield KPI strip\n• Rolling yield trend chart\n• Active excursion list\n• Low-yield lot drill-down\n• Wafer map gallery\n• Bin pareto chart"]

        M2["🔬 WAT Analytics\nParametric Analysis\n─────────────────────\n• Parameter distribution viewer\n• Multi-lot comparison\n• Equipment factor analysis\n• Correlation matrix heatmap\n• DOE result visualization\n• RF Smith chart viewer"]

        M3["🗺️ CP Analytics\nBin Map + Yield\n─────────────────────\n• Canvas BinMap renderer\n• Die-level yield map\n• Bin trend over lots\n• Spatial cluster detection\n• Lot-to-lot comparison"]

        M4["📈 SPC / FDC\nProcess Control\n─────────────────────\n• Xbar-R / Xbar-S charts\n• Western Electric rule display\n• Cpk / Ppk capability cards\n• Equipment trace viewer\n• INF-TPC anomaly timeline\n• Virtual metrology forecast"]

        M5["🔍 Defect Analysis\nDMS + ADC + WPA\n─────────────────────\n• KLARF defect map viewer\n• ADC classification results\n• WPA pattern gallery\n• Defect-to-yield correlation\n• Cross-layer defect overlay\n• SEM image viewer"]

        M6["🏗️ DFM Suite\nLayout + CMP + Yield\n─────────────────────\n• GDS layout viewer\n• PatternScan hotspot map\n• CMPEXP planarity sim\n• Virtual Yield predictor\n• LayoutInsight geometry stats"]

        M7["🧪 DFT Suite\nQuanTest + YAD\n─────────────────────\n• ATPG coverage dashboard\n• Scan chain health view\n• YAD diagnosis results\n• Failure localization map\n• ISO 26262 IST status"]

        M8["🤖 AI Console\nML + Inference\n─────────────────────\n• Model performance dashboard\n• Yield prediction vs actual\n• Anomaly detection timeline\n• SHAP feature importance\n• Model drift monitor"]

        M9["💬 Agent Interface\nWisdom AI Chat\n─────────────────────\n• SemiMind++ NL chat\n• Streaming SSE response\n• RCA evidence cards\n• Action approval panel\n• Knowledge search\n• Agent history log"]

        M10["🏭 FAB Control\nRobot Dashboard\n─────────────────────\n• Equipment fleet status\n• Active robot actions\n• Pending approval queue\n• Action execution log\n• Emergency stop button\n• Autonomy level selector"]

        M11["📋 Reports\nAuto Generation\n─────────────────────\n• Yield report builder\n• SPC periodic reports\n• RCA case reports\n• Equipment health reports\n• PDF / Excel export"]

        M12["⚙️ Admin\nConfig + Users\n─────────────────────\n• User management + RBAC\n• Alarm threshold config\n• SPC limit management\n• Agent skill repository\n• System health monitor"]
    end

    SHELL --> MODULES
```

### 3.2 Key UI Component Design

The following shared components are the most technically demanding and must be engineered for performance:

```mermaid
graph LR
    subgraph COMPONENTS["High-Performance Shared Components"]
        subgraph WAFER["WaferBinMap — Canvas Renderer"]
            WB1["Input: die array up to 684K entries\nUint8Array color index buffer"]
            WB2["Render path decision:\n> 200K dies → Canvas bitmap-blit ~1.6ms\n≤ 200K dies → SVG rect with hover tooltip"]
            WB3["Interactions:\nClick die → drill to parametric\nHover → die coordinate + bin\nZoom/pan via transform matrix\nLasso select for region analysis"]
        end

        subgraph SPC_CHART["SPCChart — Real-time Recharts"]
            SC1["Data: rolling window 200 points\nWebSocket push appends new points\nOld points evicted from left"]
            SC2["Overlays:\nUCL / LCL / CL reference lines\nViolation point color coding\nRule annotation markers\nCpk badge in top-right corner"]
        end

        subgraph AGENT_CHAT["AgentChat — SSE Streaming"]
            AC1["POST /agent/query → get session_id\nGET /agent/stream/{session_id} SSE"]
            AC2["Render: token-by-token streaming\nMarkdown rendering via react-markdown\nCode blocks with syntax highlight\nChart injection from agent response"]
            AC3["Action cards: [Accept] [Modify] [Escalate]\nApproval triggers POST /robot/action"]
        end

        subgraph CORR["CorrelationMatrix — D3 Heatmap"]
            CM1["Input: N×N parameter correlation matrix\nN can be 200+ WAT parameters"]
            CM2["Render: D3 scaleBand + color scale\nClick cell → scatter plot drill\nHover → Pearson r + p-value tooltip\nSort by absolute correlation to target"]
        end
    end
```

### 3.3 State Management Architecture

```mermaid
graph TB
    subgraph ZUSTAND["Zustand Store Architecture"]
        subgraph AUTH_STORE["authStore"]
            AS1["user: { id, name, role, permissions }\ntoken: JWT string\nrefreshToken: string\nloginAction()\nlogoutAction()\nrefreshTokenAction()"]
        end

        subgraph FAB_STORE["fabStore — Real-time FAB State"]
            FS1["equipmentStatus: Map<equipmentId, StatusObj>\nalarms: Alarm[] — rolling 100 active\nyieldKPIs: { todayYield, activeLots, excursions }\nwipSummary: WIPSummary\nwebsocketConnected: boolean\nsubscribeToFab()\nunsubscribeFromFab()"]
        end

        subgraph ANALYSIS_STORE["analysisStore — Current Analysis Context"]
            ANS1["selectedLotId: string | null\nselectedWaferId: string | null\nselectedProduct: string | null\nselectedDateRange: DateRange\nselectedEquipment: string[]\nanalysisResults: Map<queryKey, Result>\nclearContext()\nsetLotContext(lotId)"]
        end

        subgraph AGENT_STORE["agentStore — AI Agent State"]
            AGS1["sessions: Map<sessionId, Session>\nactiveSession: string | null\npendingActions: AgentAction[]\nknowledgeSearchResults: KnowledgeItem[]\ncreateSession()\nsendQuery(sessionId, question)\napproveAction(actionId)\nrejectAction(actionId, reason)"]
        end
    end
```

---

## 4. API Service Design

### 4.1 Microservice Port Map and Responsibility Matrix

```mermaid
graph TB
    subgraph SERVICES["Microservice Registry"]
        subgraph CORE_SVCS["Core Analytics Services"]
            S1["yield-service :8002\nDE-YMS equivalent\n• Yield summary & trend\n• Excursion detection\n• Low-yield drill-down\n• Lot comparison\n• Alarm integration"]
            S2["wat-analytics-service :8003\nDE-G + WAT equivalent\n• Parametric stats\n• Equipment ANOVA\n• DOE analysis\n• RF data analysis\n• SAS Viya SWAT bridge"]
            S3["cp-analytics-service :8004\nCP Bin Map service\n• Bin yield calculation\n• Spatial die map\n• Bin trend analysis\n• STDF ingestion API"]
            S4["spc-fdc-service :8005\nDE-SPC + DE-FDC equivalent\n• SPC chart data\n• Violation detection\n• Cpk calculation\n• FDC trace analysis\n• INF-TPC integration"]
            S5["defect-service :8006\nDE-DMS + INF-ADC + INF-WPA\n• KLARF import\n• Defect classification\n• Pattern analysis\n• Yield impact calc"]
        end

        subgraph AI_SVCS["AI Intelligence Services"]
            S6["inference-service :8020\nML model serving\n• Yield prediction\n• Anomaly scoring\n• SHAP attribution\n• Triton server proxy"]
            S7["adc-service :8021\nAuto Defect Classification\n• Image classification\n• Confidence scoring\n• Human review queue\n• Model retraining trigger"]
            S8["wpa-service :8022\nWafer Pattern Analysis\n• Pattern classification\n• Batch processing\n• Pattern matching\n• Trend monitoring"]
            S9["tpc-service :8023\nTrace Pattern Control\n• Real-time trace monitor\n• Anomaly detection\n• Alert generation\n• Baseline management"]
            S10["agent-service :8030\nAgentic AI Orchestrator\n• LangGraph state machine\n• Tool call execution\n• Knowledge base query\n• SSE streaming\n• Action management"]
            S11["llm-service :8031\nWisdom Engine\n• LLM inference\n• RAG retrieval\n• Knowledge accumulation\n• Fine-tuning pipeline"]
        end

        subgraph INFRA_SVCS["Infrastructure Services"]
            S12["auth-service :8001\nAuthentication\n• JWT issuance\n• RBAC enforcement\n• LDAP integration\n• MFA management"]
            S13["alarm-service :8009\nDE-Alarm equivalent\n• Alarm routing\n• Escalation logic\n• MES integration\n• Notification dispatch"]
            S14["report-service :8010\nReport generation\n• PDF/Excel export\n• Scheduled reports\n• Template management"]
            S15["robot-ctrl-service :8040\nFAB Automation\n• MES API client\n• EAP recipe control\n• AMHS commands\n• Action audit log"]
        end
    end
```

### 4.2 Complete API Endpoint Specification

```mermaid
graph TB
    subgraph YIELD_ENDPOINTS["Yield Service — /api/v1/yield"]
        YE1["GET /summary\n?lot_id&wafer_id&step&product&date_from&date_to\nReturns: yield KPIs, bin breakdown, trend"]
        YE2["GET /trend\n?product&node&step&days&granularity=day|week\nReturns: time-series yield with sigma bands"]
        YE3["GET /excursions\n?severity&status&product&date_from\nReturns: active excursion list with context"]
        YE4["POST /rca-drill\nBody: {lot_id, symptom_type, parameters[]}\nReturns: SAS Viya GLMSELECT factor ranking"]
        YE5["GET /compare\n?baseline_lot&target_lot&parameters[]\nReturns: statistical comparison + delta"]
        YE6["GET /wafer-map\n?lot_id&wafer_id&map_type=bin|yield|defect\nReturns: die array for Canvas renderer"]
        YE7["GET /low-yield-lots\n?product&threshold&days&limit\nReturns: ranked low-yield lots with metadata"]
    end

    subgraph SPC_ENDPOINTS["SPC/FDC Service — /api/v1/spc"]
        SE1["GET /charts\n?parameter_id&equipment_id&period&chart_type\nReturns: SPC data points + UCL/LCL/CL"]
        SE2["GET /violations\n?rule&severity&equipment&date_range\nReturns: violation events with context"]
        SE3["GET /capability\n?parameter_id&lot_range&equipment_id\nReturns: Cpk/Cp/Ppk from SAS PROC CAPABILITY"]
        SE4["GET /equipment-comparison\n?parameter_id&equipment_ids[]&period\nReturns: tool-to-tool matching analysis"]
        SE5["POST /update-limits\nBody: {parameter_id, equipment_id, ucl, lcl, cl}\nAction: Update SPC limits in Greenplum"]
        SE6["GET /virtual-metro\n?equipment_id&next_lot_id\nReturns: ML-predicted measurement + CI"]
    end

    subgraph AGENT_ENDPOINTS["Agent Service — /api/v1/agent"]
        AE1["POST /query\nBody: {question, context: {lot_id?, equipment_id?, parameter_id?}}\nReturns: {session_id} — then stream via SSE"]
        AE2["GET /stream/{session_id}\nSSE stream: agent thinking tokens + tool calls + final answer"]
        AE3["POST /approve-action\nBody: {action_id, approver_notes}\nAction: Executes approved robot action"]
        AE4["POST /reject-action\nBody: {action_id, rejection_reason}\nAction: Cancels action, updates knowledge"]
        AE5["GET /knowledge-search\n?symptom&category&limit\nReturns: RCA knowledge base matches"]
        AE6["GET /pending-actions\nReturns: all actions awaiting human approval"]
        AE7["GET /history\n?session_id&limit&offset\nReturns: past agent sessions + outcomes"]
    end
```

### 4.3 WebSocket Real-Time Event Contract

The WebSocket server (Flask-SocketIO) maintains persistent connections for all dashboard clients. Events are pushed server-to-client without polling.

| Event | Direction | Payload Schema | Trigger |
|---|---|---|---|
| `alarm.critical` | S→C | `{alarm_id, equipment_id, code, severity, lot_id, message, time}` | Oracle trigger on LIVE_ALARM insert |
| `yield.excursion` | S→C | `{lot_id, product, current_yield, baseline, delta_pct, step}` | Celery beat every 5 min |
| `spc.violation` | S→C | `{parameter_id, equipment_id, rule, value, ucl, lcl, time}` | Oracle trigger on SPC violation |
| `equipment.status` | S→C | `{equipment_id, status, health_score, current_lot}` | Oracle trigger on status change |
| `agent.thinking` | S→C | `{session_id, step_type, content, tool_name?}` | SSE from agent-service |
| `agent.action.pending` | S→C | `{action_id, type, target, description, confidence}` | agent-service Kafka event |
| `robot.action.executed` | S→C | `{action_id, type, target, outcome, timestamp}` | robot-ctrl-service callback |
| `chat.message` | C→S | `{session_id, message, context}` | User sends query |

---

## 5. Docker Containerization Strategy

### 5.1 Docker Image Architecture

Every microservice follows a **multi-stage build** pattern to minimize image size and attack surface.

```mermaid
graph TB
    subgraph FLASK_IMAGE["Flask Microservice — Multi-Stage Dockerfile Pattern"]
        subgraph STAGE1["Stage 1: Builder"]
            B1["FROM python:3.11-slim AS builder\nRUN pip install --no-cache-dir -r requirements.txt\ninto /install prefix"]
        end
        subgraph STAGE2["Stage 2: Runtime"]
            R1["FROM python:3.11-slim AS runtime\nCOPY --from=builder /install /usr/local\nCOPY ./app /app\nRUN useradd -r -u 1001 appuser\nUSER appuser\nEXPOSE 8002\nCMD [gunicorn, -w 4, -k gevent, app:create_app()]"]
        end
        subgraph RESULT["Result"]
            RES1["Final image: ~180MB\nNo build tools in runtime\nNon-root user\nHealth check built-in"]
        end
    end

    subgraph REACT_IMAGE["React Frontend — Multi-Stage Dockerfile Pattern"]
        subgraph FE_STAGE1["Stage 1: Node Builder"]
            FB1["FROM node:20-alpine AS builder\nCOPY package.json pnpm-lock.yaml ./\nRUN pnpm install --frozen-lockfile\nCOPY . .\nRUN pnpm build"]
        end
        subgraph FE_STAGE2["Stage 2: Nginx Serve"]
            FR1["FROM nginx:alpine AS runtime\nCOPY --from=builder /app/dist /usr/share/nginx/html\nCOPY nginx.conf /etc/nginx/conf.d/default.conf\nEXPOSE 80\nFinal image: ~25MB"]
        end
    end

    subgraph AI_IMAGE["AI Service — GPU-Enabled Image"]
        AI1["FROM nvcr.io/nvidia/tritonserver:24.01-py3\nInstall PyTorch + transformers\nCopy model weights\nFinal image: ~8GB (model weights)"]
    end
```

### 5.2 Docker Compose — Local Development Stack

```mermaid
graph LR
    subgraph COMPOSE["docker-compose.yml — Local Dev Stack"]
        subgraph FRONTEND["Frontend"]
            FE[semfab-frontend:dev\nVite HMR on :5173]
        end
        subgraph BACKEND["Backend Services"]
            AUTH_C[auth-service:dev :8001]
            YIELD_C[yield-service:dev :8002]
            WAT_C[wat-analytics:dev :8003]
            SPC_C[spc-fdc:dev :8005]
            AGENT_C[agent-service:dev :8030]
        end
        subgraph INFRA["Infrastructure"]
            PG[postgres:16\nDev substitute for Oracle :5432]
            GP_DEV[greenplum-dev\nSingle-node GP :5433]
            REDIS_C[redis:7 :6379]
            KAFKA_C[kafka:3.7 :9092]
            ZK[zookeeper :2181]
            MINIO_C[minio :9000]
        end
        subgraph MOCK["Mock Services"]
            MOCK_SAS[mock-sas-viya\nFlask stub returning fixture data]
            MOCK_MES[mock-mes-api\nSimulates MES lot hold/release]
        end
    end

    FE --> AUTH_C
    FE --> YIELD_C
    YIELD_C --> GP_DEV
    YIELD_C --> REDIS_C
    AGENT_C --> KAFKA_C
```

---

## 6. Kubernetes High-Availability Deployment

### 6.1 Cluster Topology — Production K8s Design

```mermaid
graph TB
    subgraph K8S_CLUSTER["Kubernetes Production Cluster — 3 Availability Zones"]
        subgraph CONTROL["Control Plane — 3 Masters (HA etcd)"]
            M1[Master Node AZ-A\nkube-apiserver + etcd]
            M2[Master Node AZ-B\nkube-apiserver + etcd]
            M3[Master Node AZ-C\nkube-apiserver + etcd]
        end

        subgraph WORKER_POOLS["Worker Node Pools"]
            subgraph APP_POOL["App Pool — 12 nodes × 32 vCPU / 128GB"]
                APP1[app-node-01 AZ-A]
                APP2[app-node-02 AZ-B]
                APP3[app-node-03 AZ-C]
                APPn[... 9 more nodes]
            end

            subgraph AI_POOL["AI Pool — 4 nodes × 8× A100 GPU / 512GB"]
                AI1[gpu-node-01 AZ-A\nNVIDIA A100 × 8]
                AI2[gpu-node-02 AZ-B\nNVIDIA A100 × 8]
                AI3[gpu-node-03 AZ-A\nNVIDIA A100 × 8]
                AI4[gpu-node-04 AZ-C\nNVIDIA A100 × 8]
            end

            subgraph INFRA_POOL["Infra Pool — 6 nodes × 16 vCPU / 64GB"]
                INF1[infra-node-01\nKafka + Redis + MinIO]
                INF2[infra-node-02]
                INFn[... 4 more nodes]
            end
        end
    end
```

### 6.2 Namespace and Deployment Strategy

```mermaid
graph TB
    subgraph NAMESPACES["Kubernetes Namespaces"]
        subgraph NS_PROD["namespace: semfab-prod"]
            subgraph DEPLOYMENTS["Core Service Deployments"]
                DEP1["yield-service\nreplicas: 3\nresources: 2CPU/4GB\nHPA: 3-10 replicas\ntarget CPU: 70%"]
                DEP2["wat-analytics-service\nreplicas: 3\nresources: 4CPU/8GB\nHPA: 3-8 replicas\ntarget CPU: 60%"]
                DEP3["spc-fdc-service\nreplicas: 3\nresources: 2CPU/4GB\nHPA: 3-12 replicas\ntarget CPU: 70%"]
                DEP4["agent-service\nreplicas: 2\nresources: 4CPU/16GB\nHPA: 2-6 replicas\ntarget CPU: 50%"]
                DEP5["inference-service\nreplicas: 2\nnodeSelector: gpu-pool\nresources: 4CPU/32GB + 2×A100\nHPA: 2-4 replicas"]
                DEP6["frontend\nreplicas: 3\nresources: 0.5CPU/512MB\nHPA: 3-10 replicas"]
            end
        end

        subgraph NS_INFRA["namespace: semfab-infra"]
            KAFKA_K[Kafka StatefulSet\n3 brokers × 32GB\nPVC: 2TB per broker]
            REDIS_K[Redis Cluster\n3 masters + 3 replicas\nPVC: 100GB per node]
            MINIO_K[MinIO StatefulSet\n4 nodes × 10TB\nErasure coding 2+2]
        end

        subgraph NS_MONITOR["namespace: semfab-monitoring"]
            PROM[Prometheus\nMetrics scraping]
            GRAFANA[Grafana\nDashboards]
            JAEGER[Jaeger\nDistributed tracing]
            ELK[ELK Stack\nLog aggregation]
        end
    end
```

### 6.3 High Availability Patterns

```mermaid
graph TB
    subgraph HA_PATTERNS["High Availability Engineering"]
        subgraph ZERO_DOWNTIME["Zero-Downtime Deployment"]
            ZD1["Rolling Update Strategy:\nmaxUnavailable: 0\nmaxSurge: 1\nMinimum 3 replicas always running\nHealth check gates rollout progression"]
            ZD2["PodDisruptionBudget:\nminAvailable: 2\nPrevents simultaneous eviction\nDuring node maintenance"]
        end

        subgraph CIRCUIT_BREAKER["Circuit Breaker Pattern"]
            CB1["Implemented in Flask services\nusing tenacity library:\n• Retry: 3 attempts with exponential backoff\n• Circuit open after 5 consecutive failures\n• Half-open probe every 30 seconds\n• Fallback: return cached data from Redis"]
        end

        subgraph DB_HA["Database High Availability"]
            DB1["Oracle RAC:\n2-node active-active cluster\nData Guard standby in DR site\nRTO: < 30 seconds\nRPO: < 5 seconds"]
            DB2["Greenplum:\n16-segment MPP cluster\nMirror segments on separate hosts\nMaster standby in hot-standby mode\nRTO: < 2 minutes"]
            DB3["Redis Cluster:\n3 masters + 3 replicas\nSentinel for automatic failover\nRTO: < 10 seconds"]
        end

        subgraph AUTOSCALING["Horizontal Pod Autoscaling"]
            HPA1["HPA triggers:\n• CPU > 70% → scale up\n• CPU < 30% for 5 min → scale down\n• Custom metric: Kafka consumer lag > 1000\n• Custom metric: SPC alarm queue depth > 50"]
            HPA2["KEDA (Kubernetes Event-Driven Autoscaling):\n• Scale inference-service based on\n  Kafka topic lag for ML inference queue\n• Scale to zero during off-hours\n  for non-critical batch services"]
        end
    end
```

### 6.4 Service Mesh and Observability

```mermaid
graph LR
    subgraph MESH["Service Mesh — Istio"]
        subgraph TRAFFIC["Traffic Management"]
            TM1["VirtualService:\nCanary deployments\n10% traffic to new version\nGradual rollout with metrics gate"]
            TM2["DestinationRule:\nmTLS between all services\nLoad balancing: LEAST_CONN\nConnection pool: max 100 pending"]
        end
        subgraph OBSERVE["Observability via Istio Sidecar"]
            OB1["Automatic distributed tracing\nAll inter-service calls traced\nNo code changes required"]
            OB2["Service-level metrics:\nLatency p50/p95/p99\nError rate\nRequest throughput"]
        end
    end

    subgraph OBS_STACK["Observability Stack"]
        PROM2[Prometheus\nMetrics store]
        GRAF[Grafana\nDashboards + Alerts]
        JAE[Jaeger\nTrace visualization]
        ELK2[ELK Stack\nLog search + analysis]
        PD[PagerDuty\nOn-call alerting]

        PROM2 --> GRAF
        JAE --> GRAF
        ELK2 --> GRAF
        GRAF --> PD
    end
```

---

## 7. Performance Engineering for Fab-Scale Data

### 7.1 Query Performance Strategy

The most critical performance challenge is serving interactive dashboard queries against billions of rows of historical fab data in under 200ms. The strategy uses a **three-tier caching architecture**:

```mermaid
flowchart LR
    REQ[API Request\nGET /yield/summary\n?product=ABC&days=30]

    subgraph TIER1["Tier 1 — Redis Cache (< 1ms)"]
        R1{Cache hit?}
        R2[Return cached result\nTTL: 5 minutes for summaries\nTTL: 30 seconds for live alarms]
    end

    subgraph TIER2["Tier 2 — Datamart Query (< 50ms)"]
        DM[Query dm.yield_mart\nPre-aggregated materialized view\nGreenplum: single partition scan]
    end

    subgraph TIER3["Tier 3 — Full DW Query (< 5s)"]
        DW[Query dw.fact_yield_summary\nPartition pruning by date\nMPP parallel scan across 16 segments]
    end

    subgraph TIER4["Tier 4 — SAS Viya CAS (< 60s)"]
        CAS[Load to CAS in-memory\nRun PROC MIXED / GLMSELECT\nComplex statistical computation]
    end

    REQ --> R1
    R1 -->|Hit| R2
    R1 -->|Miss| DM
    DM -->|Simple aggregation| R2
    DM -->|Complex query| DW
    DW -->|Statistical analysis| CAS
    CAS --> R2
    R2 --> REQ
```

### 7.2 Data Ingestion Throughput Architecture

```mermaid
graph LR
    subgraph INGEST_PERF["High-Throughput Ingestion — 100K events/second target"]
        subgraph KAFKA_CONFIG["Kafka Tuning"]
            K1["3 brokers × 32 partitions per topic\nReplication factor: 3\nbatch.size: 1MB\nlinger.ms: 5ms\ncompression: lz4"]
        end

        subgraph SPARK_CONFIG["Spark Structured Streaming"]
            SP1["8 Spark executors × 8 cores\nmicrobatch interval: 10 seconds\nGreenplum JDBC bulk copy\n100K rows per batch write\nCheckpoint to MinIO"]
        end

        subgraph GP_WRITE["Greenplum Write Optimization"]
            GP1["gpfdist external table\nParallel load across all 16 segments\nBypasses coordinator bottleneck\nAchieved: 500K rows/second sustained"]
        end
    end
```

---

## 8. Implementation Execution Roadmap

### 8.1 Sprint-Level Execution Plan

```mermaid
gantt
    title SEMFAB·IQ — Full-Stack Implementation Roadmap
    dateFormat YYYY-MM-DD
    axisFormat %b %Y

    section Foundation Infrastructure
    K8s Cluster Setup + Namespaces       :f1, 2025-07-01, 14d
    Greenplum DW Schema Deploy           :f2, 2025-07-01, 21d
    Oracle OLTP Schema Deploy            :f3, 2025-07-08, 14d
    Kafka + Redis + MinIO Setup          :f4, 2025-07-08, 14d
    Kong API Gateway + Auth Service      :f5, 2025-07-15, 14d
    CI/CD Pipeline (GitLab + ArgoCD)     :f6, 2025-07-01, 21d

    section Data Pipeline
    Kafka ETL: WAT/CP STDF Ingestion     :d1, 2025-07-22, 21d
    Kafka ETL: Defect KLARF Ingestion    :d2, 2025-08-05, 14d
    Kafka ETL: FDC Trace Ingestion       :d3, 2025-08-05, 21d
    Datamart Refresh Jobs (Celery Beat)  :d4, 2025-08-19, 14d
    SAS Viya CAS Connector               :d5, 2025-08-12, 21d

    section Core Analytics Services
    yield-service + React YMS Dashboard  :a1, 2025-08-26, 28d
    wat-analytics-service + WAT UI       :a2, 2025-09-02, 28d
    spc-fdc-service + SPC Charts UI      :a3, 2025-09-09, 28d
    defect-service + DMS UI              :a4, 2025-09-23, 28d
    cp-analytics-service + BinMap UI     :a5, 2025-09-30, 21d

    section AI Intelligence Layer
    inference-service + ML Models        :ai1, 2025-10-21, 28d
    adc-service + INF-ADC UI             :ai2, 2025-10-28, 21d
    wpa-service + WPA Pattern UI         :ai3, 2025-11-04, 21d
    tpc-service + Trace Anomaly UI       :ai4, 2025-11-11, 21d

    section Agentic AI & Automation
    llm-service + Knowledge Base         :ag1, 2025-11-25, 35d
    agent-service + LangGraph            :ag2, 2025-12-09, 35d
    SemiMind++ Chat Interface            :ag3, 2026-01-06, 21d
    robot-ctrl-service + MES Integration :ag4, 2026-01-20, 28d
    FAB Control Dashboard                :ag5, 2026-02-03, 21d

    section Production Hardening
    Load Testing + Performance Tuning    :p1, 2026-02-17, 21d
    Security Audit + Pen Test            :p2, 2026-02-24, 14d
    Disaster Recovery Drill              :p3, 2026-03-03, 7d
    Production Go-Live                   :milestone, 2026-03-10, 0d
```

### 8.2 Key Performance Targets Summary

| KPI | Target | Measurement Method | Critical Path |
|---|---|---|---|
| Wafer BinMap render (684K die) | < 2ms | Canvas benchmark | Canvas bitmap-blit algorithm |
| API response P95 latency | < 200ms | Prometheus histogram | Redis cache + datamart queries |
| SPC alarm to notification | < 30 seconds | End-to-end trace | Oracle trigger → Kafka → WebSocket |
| LLM RCA response (streaming) | First token < 2s | SSE latency | LLM inference service warm cache |
| Autonomous RCA accuracy | > 90% | vs engineer gold standard | LLM fine-tuning + RAG quality |
| INF-TPC anomaly detection | > 95% accuracy | FAB benchmark | Unsupervised model quality |
| Greenplum query (1B rows) | < 5 seconds | Execution plan | Partition pruning + MPP parallelism |
| System availability | 99.95% (< 4.4h/year) | Uptime monitor | K8s HA + Oracle RAC + GP mirrors |
| Data ingestion throughput | > 100K events/second | Kafka consumer lag | Kafka partitioning + Spark streaming |
| ML inference throughput | > 1,000 predictions/second | Triton server metrics | GPU batching + model optimization |

---

*SEMFAB·IQ Full-Stack Implementation Thinking — Production Design Document*  
*Integrates: SEMFAB·IQ Architecture Design Report v1.0 + Semitronix Yield Ecosystem Function Map*  
*© 2025 SEMFAB·IQ Engineering Team. Commercial Confidential.*
