# SEMFAB·IQ — Complete Implementation Task List
## Step-by-Step Function Development Guide
### Production & Commercial Grade — Full Stack EDA Platform

---

> **Document Type:** Implementation Task Specification  
> **Stack:** React 18 + Vite · Python Flask · SAS Viya · Greenplum · Oracle · LLM Agentic AI  
> **Design Philosophy:** Modern Glassmorphism · Dark Industrial · Micro-interaction Rich  
> **Total Estimated Tasks:** 847 items across 6 phases  
> **Reference Architecture:** SEMFAB·IQ Architecture Design Report v1.0

---

## 📋 How to Read This Document

Each task entry follows this format:

```
- [ ] TASK-XXXX | [Priority] | [Est. Hours] | Description
       → Sub-tasks or acceptance criteria
       ↳ Technical notes
```

**Priority Codes:** `🔴 P0-Critical` · `🟠 P1-High` · `🟡 P2-Medium` · `🟢 P3-Nice-to-Have`  
**Tags:** `[FE]` Frontend · `[BE]` Backend · `[DB]` Database · `[AI]` AI/ML · `[INFRA]` Infrastructure · `[TEST]` Testing

---

## PHASE 0 — Project Foundation & DevOps Infrastructure

> **Goal:** Establish the entire engineering foundation before a single feature line is written.  
> **Duration:** Weeks 1–3  
> **Owner:** DevOps + Architecture Lead

---

### P0.1 — Repository & Monorepo Setup

- [ ] **TASK-0001** | 🔴 P0 | 4h | `[INFRA]` Initialize Git monorepo with Nx or Turborepo workspace
  - → `/apps/web` — React + Vite frontend
  - → `/apps/api-gateway` — Kong configuration
  - → `/services/*` — All Flask microservices
  - → `/packages/ui` — Shared component library
  - → `/packages/types` — Shared TypeScript types
  - → `/infra` — Kubernetes + Helm charts
  - ↳ Use `pnpm workspaces` for JS packages, `uv` for Python packages

- [ ] **TASK-0002** | 🔴 P0 | 3h | `[INFRA]` Configure branch protection rules and Git workflow
  - → `main` branch: protected, require 2 reviewers + CI pass
  - → `develop` branch: integration branch, require 1 reviewer
  - → Feature branches: `feat/TASK-XXXX-description`
  - → Commit convention: Conventional Commits (`feat:`, `fix:`, `chore:`)

- [ ] **TASK-0003** | 🔴 P0 | 6h | `[INFRA]` Set up CI/CD pipeline — GitLab CI + ArgoCD
  - → Stage 1: Lint + Type Check (< 2 min)
  - → Stage 2: Unit Tests (< 5 min)
  - → Stage 3: Integration Tests (< 10 min)
  - → Stage 4: Docker Build + Push to registry
  - → Stage 5: ArgoCD auto-deploy to staging
  - → Stage 6: Manual gate → Production deploy

- [ ] **TASK-0004** | 🔴 P0 | 4h | `[INFRA]` Configure Docker multi-stage build templates
  - → Python Flask service: base → deps → prod (final < 150MB)
  - → React/Vite: node build → nginx static serve
  - → All images: non-root user, read-only filesystem, health checks

- [ ] **TASK-0005** | 🔴 P0 | 8h | `[INFRA]` Kubernetes cluster initial setup
  - → Namespaces: `semfab-prod`, `semfab-staging`, `semfab-infra`
  - → RBAC roles and service accounts per namespace
  - → Resource quotas and LimitRanges per namespace
  - → NetworkPolicy: default-deny, explicit allow rules
  - → Ingress controller: Nginx with TLS termination

- [ ] **TASK-0006** | 🔴 P0 | 6h | `[INFRA]` Secrets management — HashiCorp Vault
  - → Vault init and unseal automation
  - → Kubernetes auth backend
  - → Secret injection via vault-agent-injector sidecar
  - → Separate secret paths per service and environment

- [ ] **TASK-0007** | 🟠 P1 | 4h | `[INFRA]` Observability stack deployment
  - → Prometheus + Grafana (metrics)
  - → ELK Stack — Elasticsearch + Logstash + Kibana (logs)
  - → Jaeger (distributed tracing)
  - → PagerDuty webhook integration for critical alerts

---

### P0.2 — Design System Foundation

- [ ] **TASK-0010** | 🔴 P0 | 16h | `[FE]` Establish SEMFAB·IQ Design System — `/packages/ui`

  **Color Palette — Dark Industrial Glassmorphism:**
  - → Primary brand: `#00F5C4` (Teal Neon) — active states, CTAs
  - → Secondary: `#7B61FF` (Electric Violet) — AI / agent indicators
  - → Accent: `#FF6B35` (Plasma Orange) — alarms, warnings
  - → Danger: `#FF3366` (Critical Red) — yield excursions
  - → Success: `#00D68F` (Yield Green) — good yield, pass states
  - → Background primary: `#080C14` (Deep Space)
  - → Background card: `rgba(255,255,255,0.04)` (Glass Dark)
  - → Background elevated: `rgba(255,255,255,0.08)` (Glass Light)
  - → Border subtle: `rgba(255,255,255,0.08)`
  - → Border glow: `rgba(0,245,196,0.3)` (Teal glow)
  - → Text primary: `#F0F4FF`
  - → Text secondary: `#8892A4`
  - → Text muted: `#4A5568`

  **Typography Scale:**
  - → Display: `Clash Display` or `Space Grotesk` — hero numbers, KPI values
  - → Body: `Inter` — all UI text
  - → Mono: `JetBrains Mono` — parameter values, lot IDs, data tables
  - → Size scale: 11px / 12px / 13px / 14px / 16px / 18px / 24px / 32px / 48px / 64px

  **Spacing & Layout:**
  - → Base unit: 4px
  - → Border radius: 4px (tight) / 8px (card) / 12px (panel) / 20px (modal)
  - → Glassmorphism card: `backdrop-filter: blur(20px)` + semi-transparent bg
  - → Glow effects: `box-shadow: 0 0 20px rgba(0,245,196,0.15)`

- [ ] **TASK-0011** | 🔴 P0 | 8h | `[FE]` CSS Variables + Tailwind config integration
  - → All design tokens as CSS custom properties
  - → Tailwind `theme.extend` mapping all tokens
  - → Dark mode only (system: forced dark — semiconductor fab always runs dark)
  - → CSS animation tokens: `--duration-fast: 150ms`, `--duration-normal: 250ms`, `--duration-slow: 400ms`
  - → Easing tokens: `--ease-out-expo`, `--ease-in-out-quart`

- [ ] **TASK-0012** | 🔴 P0 | 12h | `[FE]` Micro-interaction & animation library setup
  - → Install Framer Motion as primary animation engine
  - → Create standard animation variants: `fadeIn`, `slideUp`, `scaleIn`, `glowPulse`
  - → `AnimatedNumber` component: count-up animation for KPI values
  - → `AnimatedBar` component: horizontal bar that fills on mount
  - → `SkeletonGlow` component: animated loading skeleton with teal glow
  - → `ParticleBackground` component: subtle floating particles for hero sections
  - → All animations must respect `prefers-reduced-motion`

- [ ] **TASK-0013** | 🔴 P0 | 20h | `[FE]` Core UI component library — Phase 1
  - → `Button`: variants (primary/secondary/ghost/danger), sizes, loading state, glow on hover
  - → `Input`: dark glass style, focus glow ring, validation states, units suffix
  - → `Select`: custom dropdown with search, multi-select support, virtualized list
  - → `Badge`: status badges — Critical/Major/Minor/Normal with animated pulse on Critical
  - → `Card`: glassmorphism base card, hover lift effect (`translateY(-2px)`)
  - → `Modal`: blur backdrop, slide-up animation, focus trap, ESC dismiss
  - → `Tooltip`: smart positioning, 300ms delay, arrow pointer
  - → `Toast`: top-right stack, auto-dismiss, severity icons
  - → `DataTable`: virtual scroll, column sort, row hover highlight, sticky header
  - → `Tabs`: animated underline indicator, keyboard navigation
  - → `Accordion`: smooth height animation, chevron rotation
  - → `Popover`: floating UI positioning, click-outside dismiss

---

### P0.3 — Data Infrastructure Setup

- [ ] **TASK-0020** | 🔴 P0 | 16h | `[DB]` Greenplum cluster initialization
  - → Deploy Greenplum 7 on dedicated compute cluster (min 8 segment nodes)
  - → Configure master node HA with standby
  - → Set distribution keys for all analytical tables by `lot_id`
  - → Configure columnar append-optimized tables for WAT/CP result tables
  - → Partition strategy: range partition on `test_date` (monthly)
  - → Row-level security policy for multi-tenant isolation

- [ ] **TASK-0021** | 🔴 P0 | 12h | `[DB]` Oracle RAC cluster initialization
  - → Oracle 19c RAC with 2 nodes (Active-Active)
  - → Automatic Storage Management (ASM) configuration
  - → Create tablespaces: `SEMFAB_OLTP`, `SEMFAB_AUDIT`, `SEMFAB_CONFIG`
  - → Connection pool: HikariCP via SQLAlchemy cx_Oracle driver
  - → Flashback data archive for change history tracking

- [ ] **TASK-0022** | 🔴 P0 | 8h | `[DB]` SAS Viya CAS cluster setup
  - → Deploy SAS Viya 4 on Kubernetes (SAS Viya Deployment Operator)
  - → Configure CAS controller + 8 worker nodes
  - → Set up CAS library for Greenplum data connector
  - → Configure Python swat client connection pool
  - → Enable CAS REST API for Flask services

- [ ] **TASK-0023** | 🔴 P0 | 8h | `[DB]` Redis cluster for caching and pub/sub
  - → Redis 7 cluster mode: 3 primary + 3 replica
  - → Keyspace design: `semfab:{service}:{entity}:{id}`
  - → TTL strategy: 5min hot data, 1h analytics results, 24h session
  - → Redis Streams for WebSocket message queue

- [ ] **TASK-0024** | 🔴 P0 | 10h | `[INFRA]` Apache Kafka cluster setup
  - → Kafka 3.x with KRaft (no ZooKeeper)
  - → 3 broker nodes, replication factor 3
  - → Topic creation with partition strategy:
    - `wat-raw` — 32 partitions, 7-day retention
    - `cp-raw` — 32 partitions, 7-day retention
    - `inline-raw` — 16 partitions, 3-day retention
    - `fdc-trace` — 64 partitions, 3-day retention
    - `mes-events` — 16 partitions, 14-day retention
    - `alarm-events` — 8 partitions, 30-day retention
    - `agent-events` — 8 partitions, 30-day retention
  - → Schema Registry with Avro schemas for all topics

- [ ] **TASK-0025** | 🔴 P0 | 24h | `[DB]` Complete database schema creation — Greenplum
  - → `WAT_RESULT` — columnar AO, range-partitioned by test_date
  - → `CP_RESULT` — columnar AO, range-partitioned by test_date
  - → `DEFECT_MAP` — row-oriented, partitioned by inspect_date
  - → `INLINE_METRO` — columnar AO, partitioned by measure_date
  - → `EQUIPMENT_MASTER` — row-oriented, equipment registry
  - → `YIELD_SUMMARY` — columnar AO, partitioned by summary_date
  - → `SPC_LIMITS` — row-oriented, parameter control limits
  - → `SPC_VIOLATIONS` — columnar AO, SPC rule breach log
  - → `RCA_KNOWLEDGE` — row-oriented, knowledge base
  - → `ML_PREDICTIONS` — columnar AO, model inference results
  - → `AGENT_ACTIONS` — row-oriented, autonomous action audit log
  - → All DDL in `/infra/db/migrations/` with Flyway versioning

- [ ] **TASK-0026** | 🔴 P0 | 12h | `[DB]` Oracle real-time schema creation
  - → `LIVE_ALARM` — with index on `(alarm_time, severity, status)`
  - → `WIP_TRACKING` — with index on `(lot_id, current_step, status)`
  - → `RUN_TO_RUN_CTRL` — with index on `(equipment_id, ctrl_time)`
  - → `EQUIPMENT_STATUS` — single row per equipment, upsert pattern
  - → `NOTIFICATION_QUEUE` — outbound notification staging
  - → Triggers for `EQUIPMENT_STATUS` auto-update on alarm insert

- [ ] **TASK-0027** | 🟠 P1 | 8h | `[DB]` Neo4j knowledge graph initialization
  - → Neo4j 5 Enterprise on Kubernetes
  - → Create node labels and constraints for all entity types
  - → Create indexes on `(:RootCause).symptom_signature`, `(:Equipment).equipment_id`
  - → Load seed data: 500 known RCA patterns from semiconductor literature
  - → Configure APOC plugin for graph algorithms

- [ ] **TASK-0028** | 🟠 P1 | 6h | `[DB]` MinIO object storage setup
  - → MinIO distributed mode: 4 nodes × 4 drives
  - → Bucket structure: `semfab-raw`, `semfab-models`, `semfab-reports`, `semfab-images`
  - → Lifecycle policies: raw data 90-day retention, reports 2-year retention
  - → Presigned URL generation API for secure file downloads

- [ ] **TASK-0029** | 🟠 P1 | 12h | `[DB]` Database migration framework
  - → Flyway for Greenplum and Oracle DDL migrations
  - → Alembic for SQLAlchemy ORM model sync
  - → Seed data scripts for development environment
  - → Rollback scripts for every forward migration

---

## PHASE 1 — Auth, API Gateway & App Shell

> **Goal:** Working skeleton — login, navigation, security foundation  
> **Duration:** Weeks 3–5  
> **Owner:** Backend Lead + Frontend Lead

---

### P1.1 — Authentication Service

- [ ] **TASK-1001** | 🔴 P0 | 8h | `[BE]` Flask auth-service scaffolding
  - → Application factory pattern: `create_app(config)`
  - → Blueprints: `/api/v1/auth`
  - → Extensions: Flask-JWT-Extended, Flask-SQLAlchemy (Oracle), Flask-Limiter
  - → Health endpoint: `GET /health` → `{status, version, timestamp}`
  - → Metrics endpoint: `GET /metrics` → Prometheus format

- [ ] **TASK-1002** | 🔴 P0 | 12h | `[BE]` User management & RBAC implementation
  - → Oracle tables: `USERS`, `ROLES`, `USER_ROLES`, `PERMISSIONS`, `ROLE_PERMISSIONS`
  - → Roles: `FAB_OPERATOR`, `PROCESS_ENGINEER`, `SENIOR_ENGINEER`, `MANAGER`, `SYSTEM_ADMIN`, `ROBOT_SERVICE`, `AI_AGENT`
  - → Password hashing: Argon2id (not bcrypt)
  - → Account lockout: 5 failed attempts → 15min lockout
  - → Password policy: 12+ chars, complexity requirements

- [ ] **TASK-1003** | 🔴 P0 | 10h | `[BE]` JWT token lifecycle
  - → Access token: 15min expiry, RS256 signed (asymmetric key)
  - → Refresh token: 7-day expiry, rotating refresh (invalidate old on use)
  - → Token payload: `{sub, roles, permissions, fab_id, exp, jti}`
  - → Token blacklist in Redis on logout/revocation
  - → `POST /auth/login` → `{access_token, refresh_token, user}`
  - → `POST /auth/refresh` → new access token
  - → `POST /auth/logout` → blacklist current tokens
  - → `GET /auth/me` → current user profile + permissions

- [ ] **TASK-1004** | 🔴 P0 | 8h | `[BE]` LDAP/AD enterprise SSO integration
  - → LDAP bind + search for user authentication
  - → Group-to-role mapping from AD groups
  - → Fallback to local accounts if LDAP unavailable
  - → `POST /auth/login/ldap` endpoint

- [ ] **TASK-1005** | 🟠 P1 | 6h | `[BE]` MFA implementation
  - → TOTP (Google Authenticator compatible) via pyotp
  - → MFA enforcement for `SENIOR_ENGINEER+` roles
  - → Recovery codes: 10 single-use backup codes
  - → `POST /auth/mfa/setup`, `POST /auth/mfa/verify`

- [ ] **TASK-1006** | 🔴 P0 | 4h | `[INFRA]` Kong API Gateway configuration
  - → JWT validation plugin on all protected routes
  - → Rate limiting: 1000 req/min per user, 10000 req/min per service
  - → CORS plugin: allowed origins from environment config
  - → Request logging plugin → ELK
  - → Health check routing to `/health` endpoints

---

### P1.2 — Frontend App Shell

- [ ] **TASK-1010** | 🔴 P0 | 6h | `[FE]` React + Vite project bootstrap
  - → Vite config: code splitting, chunk naming, tree shaking
  - → TypeScript strict mode: `"strict": true` in tsconfig
  - → Path aliases: `@/` → `src/`, `@ui/` → packages/ui
  - → Environment variables: `VITE_API_URL`, `VITE_WS_URL`, `VITE_APP_VERSION`
  - → ESLint + Prettier + Husky pre-commit hooks

- [ ] **TASK-1011** | 🔴 P0 | 16h | `[FE]` Login page — flagship first impression
  
  **Visual Design Requirements:**
  - → Full-screen dark background `#080C14` with subtle animated circuit-board SVG pattern
  - → Floating particles effect (15–20 particles, slow drift)
  - → Glassmorphism login card: `backdrop-filter: blur(40px)`, frosted glass border
  - → SEMFAB·IQ logo: animated on mount (draw SVG path stroke animation)
  - → Tagline: `"Intelligent Yield. Autonomous Precision."` — typewriter animation
  - → Input fields: underline-style in default, full glass-border on focus with teal glow
  - → Login button: gradient `#00F5C4 → #7B61FF`, shimmer sweep on hover
  - → Loading state: morphing spinner in brand teal
  - → Error state: shake animation + red glow on fields
  - → Smooth transition to dashboard: fade + scale out

  **Functional Requirements:**
  - → `useAuth` hook managing token storage (httpOnly cookie preferred)
  - → Remember me: stores username (not password) in localStorage
  - → Auto-redirect if already authenticated
  - → MFA second factor screen (slide transition from login)

- [ ] **TASK-1012** | 🔴 P0 | 20h | `[FE]` App shell layout — persistent navigation

  **Left Sidebar Navigation (collapsible, 64px icon mode / 240px expanded):**
  - → SEMFAB·IQ logo + collapse toggle at top
  - → Navigation groups with section headers:
    - 📊 **Yield Intelligence**: YMS Dashboard, Lot Analysis, Yield Trend
    - 🔬 **Process Analytics**: WAT Analytics, CP Analytics, Inline Metro
    - ⚙️ **Process Control**: SPC Monitor, FDC Engine, Equipment Health
    - 🔍 **Defect Intelligence**: Defect Map, ADC, Wafer Pattern
    - 🏗️ **Design Tools**: DFM Suite, DFT Suite, Virtual Yield
    - 🤖 **AI Intelligence**: AI Console, Agent Chat, Knowledge Base
    - 🏭 **FAB Control**: Robot Dashboard, Recipe Control, PM Manager
    - 📋 **Reports**: Auto Reports, Scheduled Reports
    - ⚙️ **Admin**: User Management, System Config
  - → Active route indicator: teal left border + subtle background highlight
  - → Hover states: icon glow + label fade-in
  - → Collapse animation: smooth width transition 240ms ease
  - → Keyboard shortcut `[Ctrl+\]` toggle sidebar
  - → Persist sidebar state in localStorage

  **Top Header Bar:**
  - → Current fab / product line selector (global context)
  - → Global search: `[Cmd+K]` command palette (lot IDs, equipment, parameters)
  - → Live alarm counter badge (pulsing red when critical alarms active)
  - → WebSocket connection status indicator
  - → User avatar menu: profile, settings, logout
  - → Clock showing fab local time

  **Content Area:**
  - → Breadcrumb navigation
  - → Page-level action buttons (context-sensitive)
  - → Floating notification panel (slide from right)

- [ ] **TASK-1013** | 🔴 P0 | 8h | `[FE]` Global state management — Zustand stores
  - → `authStore`: user, token, permissions, logout action
  - → `fabStore`: current fab, product line, active lot, equipment status map
  - → `alarmStore`: live alarm list, unread count, mark-as-read
  - → `analysisStore`: current analysis context, selected parameters
  - → `agentStore`: agent sessions, pending actions, approval queue
  - → `uiStore`: sidebar state, theme, active notifications

- [ ] **TASK-1014** | 🔴 P0 | 10h | `[FE]` WebSocket client with auto-reconnect
  - → `useWebSocket` hook: connects on auth, reconnects with exponential backoff
  - → Event handlers: `alarm.critical`, `yield.excursion`, `spc.violation`, `equipment.status`, `agent.thinking`, `robot.action`
  - → Message queue: buffer events during reconnection, flush on reconnect
  - → Visual indicator: green dot (connected) / yellow pulsing (reconnecting) / red (disconnected)

- [ ] **TASK-1015** | 🟠 P1 | 8h | `[FE]` Global command palette — `[Cmd+K]`
  - → Fuzzy search across: lot IDs, equipment IDs, parameter names, pages
  - → Recent items history (last 20)
  - → Category groups in results with icons
  - → Keyboard navigation: arrow keys + Enter
  - → Action commands: "Hold lot XXX", "Run SPC report", "Ask AI about..."
  - → Animated appearance: scale + blur backdrop

- [ ] **TASK-1016** | 🟠 P1 | 6h | `[FE]` Notification system
  - → Toast notifications: top-right stack, max 5 visible
  - → Notification drawer: slide from right, full history
  - → Severity icons + color coding per alarm level
  - → Group identical alarms ("× 3 similar alarms")
  - → "View details" deep-link to relevant dashboard

---

## PHASE 2 — Yield Management System (YMS) Dashboard

> **Goal:** Core yield visibility — the most-used daily screen  
> **Duration:** Weeks 5–9  
> **Owner:** Full Stack Team × 3

---

### P2.1 — YMS Backend API

- [ ] **TASK-2001** | 🔴 P0 | 16h | `[BE]` yield-service Flask scaffold
  - → Blueprint: `/api/v1/yield`
  - → SQLAlchemy models for all Greenplum yield tables
  - → Repository pattern: `YieldRepository`, `LotRepository`, `WaferRepository`
  - → Celery tasks: `compute_yield_summary` (hourly), `detect_excursions` (5min)
  - → Redis cache decorators: 5min TTL on summary endpoints

- [ ] **TASK-2002** | 🔴 P0 | 12h | `[BE]` Yield summary API endpoints
  - → `GET /yield/summary` — params: `lot_id`, `wafer_id`, `step`, `product`, `node`
    - Returns: gross_yield, net_yield, bin breakdown, total_die, pass_die
  - → `GET /yield/trend` — params: `product`, `node`, `days`, `granularity`
    - Returns: time series array `{date, yield_mean, yield_p25, yield_p75}`
  - → `GET /yield/wafer-gallery` — params: `lot_id`
    - Returns: all wafer maps for a lot as compressed columnar JSON
  - → `GET /yield/bin-pareto` — params: `lot_id`, `product`, `date_range`
    - Returns: bin codes ranked by frequency with cumulative %
  - → `GET /yield/excursions` — params: `severity`, `status`, `limit`
    - Returns: active excursion events with lot + equipment context
  - → `POST /yield/drill-rca` — body: `{lot_id, symptom}`
    - Async task: returns `task_id` for polling
  - → `GET /yield/compare` — params: `baseline_lot`, `target_lot`
    - Returns: parameter-by-parameter comparison with z-scores

- [ ] **TASK-2003** | 🟠 P1 | 8h | `[BE]` Excursion detection engine
  - → Shewhart chart on rolling yield time series (per product/node)
  - → Threshold rules: `yield < mean - 3σ` triggers P0 excursion
  - → `yield < mean - 2σ` triggers P1 warning
  - → Bin ratio shift detection: Chi-square test on bin distribution
  - → Write excursion events to Oracle `LIVE_ALARM` table
  - → Publish to Kafka `alarm-events` topic
  - → Integrate with SAS Viya CAS via SWAT for statistical computation

- [ ] **TASK-2004** | 🟠 P1 | 10h | `[BE]` SAS Viya SWAT integration — yield analytics
  - → Connection pool: `swat.CAS` sessions (min 2, max 10)
  - → Upload lot data to CAS table `YIELD_ANALYSIS_INPUT`
  - → Call `PROC SHEWHART` for yield control charts
  - → Call `PROC GLMSELECT` for low-yield factor screening
  - → Fetch results back as Pandas DataFrame → JSON response
  - → Error handling: CAS session timeout → auto-reconnect

---

### P2.2 — YMS Frontend Dashboard

- [ ] **TASK-2010** | 🔴 P0 | 24h | `[FE]` YMS main dashboard page

  **KPI Strip (top row — 4 animated cards):**
  - → "Fab Yield Today": large number `97.3%` with `AnimatedNumber` count-up, delta vs yesterday
  - → "Active Alarms": count with pulsing red badge if > 0 critical
  - → "Lots in Process": count with mini-bar showing step distribution
  - → "Equipment OEE": gauge arc from 0-100%, color-coded green/yellow/red
  - → Each KPI card: glassmorphism, subtle top-border glow in card color
  - → Hover: lift + glow intensification

  **Main 3-Column Grid:**
  - Left (30%): Yield trend chart
    - Recharts AreaChart with gradient fill (teal → transparent)
    - Multiple series: Mean yield, P10, P90 bands
    - Brush for time range selection
    - Click on data point → opens lot list modal
  - Center (40%): Live wafer map gallery
    - Grid of wafer map thumbnails (latest 12 wafers from active lots)
    - Each map: `WaferMap` component using Canvas renderer
    - Color scale: green (pass) → yellow (marginal) → red (fail) with die spatial binning
    - Hover: tooltip with lot_id, wafer_id, yield%
    - Click: expand to full wafer map analysis view
  - Right (30%): Live alarm feed
    - Scrolling stream of alarm cards
    - Each card: severity badge, equipment ID, alarm message, timestamp
    - Critical alarms: red pulsing left border + subtle red background glow
    - Click: deep-link to FDC dashboard for that equipment

  **Bottom Tab Panel:**
  - "Low Yield Lots" tab: sortable table, yield, delta, excursion age, [RCA] button
  - "SPC Violations" tab: recent rule breaches with parameter + rule description
  - "Equipment Health" tab: fleet health score cards
  - "Agent Activity" tab: recent autonomous actions with status

- [ ] **TASK-2011** | 🔴 P0 | 20h | `[FE]` Wafer Map component — Canvas renderer
  - → Props: `{dieData: DieResult[], width, height, colorMap, renderMode}`
  - → Canvas bitmap-blit for > 200K dies: target < 2ms render at 684,700 dies
  - → Build `Uint8Array` color index from die bin data
  - → `createImageData` + `putImageData` for direct pixel write
  - → SVG fallback for ≤ 200K dies with click/hover interactivity
  - → Overlay modes: bin color / yield% / parameter value (continuous scale)
  - → Legend: color scale bar + bin code labels
  - → Export: "Save as PNG" button
  - → Zoom: mouse wheel zoom, pan on drag
  - → Tooltip: die X,Y coordinates + bin code + parameter value on hover

- [ ] **TASK-2012** | 🟠 P1 | 12h | `[FE]` Lot analysis drill-down page
  - → Breadcrumb: Fab → Product → Lot → Wafer
  - → Lot header: lot ID (monospace), product, node, status badge, yield summary
  - → Wafer selector: horizontal scrollable wafer thumbnail strip
  - → Selected wafer: full-size wafer map + site analysis grid
  - → Parameter breakdown: sparkline per WAT parameter vs spec limits
  - → Step history: vertical timeline of process steps with pass/fail indicators
  - → Related lots: side-by-side comparison capability (select up to 3)

- [ ] **TASK-2013** | 🟠 P1 | 10h | `[FE]` Yield trend analysis page
  - → Multi-product overlay: toggle product lines on/off
  - → Time range: Last 7d / 30d / 90d / Custom range picker
  - → Grouping: by product / node / equipment / recipe
  - → Statistical annotations: excursion markers, PM events, process changes
  - → Export: chart image + underlying data CSV

- [ ] **TASK-2014** | 🟠 P1 | 8h | `[FE]` Bin pareto analysis component
  - → Horizontal bar chart (Recharts): bins sorted by frequency descending
  - → Dual axis: absolute count (bars) + cumulative % (line)
  - → Color coding: each bin has assigned failure category color
  - → Click on bin → filter wafer map to show only that bin's die
  - → Time animation: "Play" to animate pareto evolution over lot history

- [ ] **TASK-2015** | 🟢 P3 | 6h | `[FE]` Yield vs inline metro correlation scatter
  - → X axis: inline measurement value (e.g. CD, overlay)
  - → Y axis: lot yield %
  - → Color: equipment ID
  - → Regression line with 95% CI band
  - → Hover: lot ID, metrology value, yield

---

## PHASE 3 — WAT Analytics & CP Analytics

> **Goal:** Deep parametric analysis — the power user's analytical workbench  
> **Duration:** Weeks 7–12  
> **Owner:** Backend Analyst + Frontend Lead

---

### P3.1 — WAT Analytics Service

- [ ] **TASK-3001** | 🔴 P0 | 12h | `[BE]` wat-analytics-service scaffold
  - → Blueprint: `/api/v1/wat`
  - → STDF parser integration: `py-stdf` library + custom AD5 parser
  - → Multi-format intake: STDF, CSV, XLS, AD5
  - → Deduplication: natural key = `(lot_id, wafer_id, site_id, parameter_id, test_time)`
  - → Quality scoring per uploaded file: completeness, spec coverage, timestamp validity

- [ ] **TASK-3002** | 🔴 P0 | 16h | `[BE]` WAT data upload & ETL pipeline
  - → `POST /wat/upload` — multipart file upload, returns `task_id`
  - → Background Celery task: parse → validate → deduplicate → load to GP
  - → Progress streaming: SSE `/wat/upload/{task_id}/progress`
  - → Parsed data preview: first 10 rows preview before commit
  - → Schema auto-detection from STDF header
  - → Error report: per-row validation failures with line references

- [ ] **TASK-3003** | 🔴 P0 | 20h | `[BE]` WAT statistical analysis endpoints (SAS Viya powered)
  - → `GET /wat/distribution` — distribution fit per parameter (Normal/LogNormal detection)
    - SAS: `PROC UNIVARIATE` → mean, sigma, Cpk, p-values, histogram bins
  - → `GET /wat/correlation-matrix` — Pearson correlation for selected parameters
    - SAS: `PROC CORR` → correlation matrix + p-value matrix
  - → `GET /wat/anova-equipment` — equipment (EQPID) eta-squared factor analysis
    - SAS: `PROC GLM` → Sum of Squares → eta-squared per equipment
  - → `GET /wat/ols-whatif` — OLS regression with process condition inputs
    - SAS: `PROC REG` → coefficients + confidence intervals
  - → `GET /wat/pca` — PCA decomposition for parameter dimensionality reduction
    - SAS: `PROC FACTOR` method=PRINCIPAL → loadings + score plots
  - → `GET /wat/outlier-detection` — MAD + Grubbs test per parameter
  - → `GET /wat/trend` — rolling time series per parameter per equipment
  - → `GET /wat/site-map` — 9-site or 25-site within-wafer uniformity map

- [ ] **TASK-3004** | 🟠 P1 | 10h | `[BE]` Equipment health score computation
  - → Composite score: `0.35×Z_score + 0.30×GOF + 0.20×CV_stability + 0.15×Volume`
  - → Z-score component: |parameter mean − fleet mean| / fleet sigma
  - → GOF component: KS-test p-value for distribution fit quality
  - → CV component: coefficient of variation trend over last 30 days
  - → Volume component: throughput consistency vs capacity
  - → Score history: compute and store daily per equipment
  - → `GET /wat/equipment-health` → ranked fleet health table

- [ ] **TASK-3005** | 🟠 P1 | 8h | `[BE]` RF parameter analysis module
  - → `.s2p` Touchstone file parser
  - → De-embedding: open/short compensation
  - → Magnitude, phase, real/imaginary extraction
  - → Smith chart data computation (complex impedance → Smith coordinates)
  - → Batch processing: process all wafers in a lot in parallel

---

### P3.2 — WAT Frontend Analytical Workbench

- [ ] **TASK-3010** | 🔴 P0 | 20h | `[FE]` WAT Analytics main page — 5-tab workbench

  **Tab 1: Overview**
  - → Parameter selector: searchable multi-select (200+ parameters)
  - → Summary cards: mean, sigma, Cpk, min, max for each selected parameter
  - → Trend sparklines per parameter (7-day rolling)
  - → Lot/Equipment/Recipe filter chips

  **Tab 2: Distribution Analysis**
  - → Histogram with KDE overlay (D3 kernel density estimation)
  - → Spec lines: USL, LSL, Target in red/green
  - → Normal distribution fit overlay
  - → Statistics panel: mean ± σ, Cpk, Cp, Cpm, skewness, kurtosis
  - → Bimodal detection indicator (warns if distribution appears bimodal)
  - → Compare mode: overlay 2 lots or 2 equipment

  **Tab 3: Correlation Matrix**
  - → D3 heatmap: all selected parameters × all selected parameters
  - → Color scale: `-1 (red) → 0 (neutral) → +1 (teal)` 
  - → Cell click: opens scatter plot for that parameter pair
  - → Significance filter: dim non-significant correlations (p > 0.05)
  - → Export: correlation matrix as CSV

  **Tab 4: Equipment Factor Analysis**
  - → ANOVA result table: equipment → eta-squared → variance contribution %
  - → Horizontal bar chart: equipment ranked by eta-squared
  - → Box plot: parameter distribution per equipment side-by-side
  - → Tool matching matrix: pairwise equipment offset heatmap
  - → Health score fleet view: gauge icons per equipment

  **Tab 5: Parameter Trend**
  - → Multi-line chart: selected parameters over time
  - → Per-parameter spec limits as horizontal reference lines
  - → Equipment color coding (click legend to filter)
  - → Annotation mode: add text notes on specific data points
  - → Rolling average overlay toggle (7-day/30-day)

- [ ] **TASK-3011** | 🔴 P0 | 16h | `[FE]` WAT data upload interface
  - → Drag-and-drop zone: large dashed border, accepts STDF/CSV/AD5/XLS
  - → File type detection: icon + color per format
  - → Upload progress: animated progress bar with file-by-file status
  - → Parsing preview: table preview of detected parameters before commit
  - → Lot mapping: auto-detect lot_id from STDF header, manual override if needed
  - → Batch upload: up to 50 files simultaneously
  - → Success state: confetti animation + "View Analysis" CTA

- [ ] **TASK-3012** | 🟠 P1 | 12h | `[FE]` Scatter plot with regression
  - → X/Y parameter selectors (dropdown with search)
  - → Point coloring: by equipment / lot / recipe (selector)
  - → Regression line + 95% CI band
  - → Hover tooltip: lot ID, wafer ID, parameter values
  - → Lasso selection: draw polygon to filter/highlight subset
  - → Marginal histograms on axes (optional toggle)

- [ ] **TASK-3013** | 🟠 P1 | 10h | `[FE]` 9/25-site wafer uniformity map
  - → SVG wafer circle with site positions
  - → Color intensity = parameter value (continuous gradient scale)
  - → Numeric label inside each site
  - → Edge site analysis: average edge vs center ratio
  - → Multi-wafer overlay: show uniformity pattern across a lot

---

### P3.3 — CP Analytics Service & UI

- [ ] **TASK-3020** | 🔴 P0 | 14h | `[BE]` cp-analytics-service
  - → Blueprint: `/api/v1/cp`
  - → STDF / WPAR parser for CP test data
  - → Columnar JSON compression for die map data (~1.2MB vs 63MB naive)
  - → `GET /cp/bin-map` → compressed die map for a wafer
  - → `GET /cp/yield-summary` → die yield + bin breakdown
  - → `GET /cp/bin-pareto` → bin failure analysis
  - → `GET /cp/spatial-analysis` → cluster detection, edge die analysis
  - → `GET /cp/test-items` → list of parametric test items
  - → `POST /cp/compare-lots` → multi-lot bin map comparison

- [ ] **TASK-3021** | 🔴 P0 | 16h | `[FE]` CP Analytics page with full BinMap renderer
  - → Lot + wafer selector at top
  - → Full-size BinMap (reuse `WaferMap` Canvas component)
  - → Bin legend: color patches + bin code + description + die count
  - → Toggle: "Show notch indicator", "Show die coordinates"
  - → Click any die: tooltip with X,Y, bin, test item results
  - → Bin filter: click legend to highlight only selected bins
  - → Side panel: yield summary stats + bin pareto for selected wafer

- [ ] **TASK-3022** | 🟠 P1 | 10h | `[FE]` Multi-wafer CP map gallery page
  - → Grid of wafer bin maps (up to 25 wafers per lot)
  - → Consistent color scale across all wafers in lot
  - → Spatial correlation viewer: click bin on one wafer, highlights same die on others
  - → Yield heatmap: wafer-ID × bin-code matrix showing distribution

---

## PHASE 4 — SPC / FDC Engine & Equipment Health

> **Goal:** Process control monitoring — real-time prevention engine  
> **Duration:** Weeks 9–14  
> **Owner:** Process Control Specialist + Backend

---

### P4.1 — SPC Service

- [ ] **TASK-4001** | 🔴 P0 | 16h | `[BE]` spc-fdc-service scaffold + SPC engine
  - → Blueprint: `/api/v1/spc`
  - → Western Electric / Nelson rules engine (8 rules):
    - Rule 1: 1 point beyond 3σ
    - Rule 2: 9 consecutive points same side of mean
    - Rule 3: 6 consecutive points trending
    - Rule 4: 14 alternating points
    - Rule 5: 2 of 3 points beyond 2σ same side
    - Rule 6: 4 of 5 points beyond 1σ same side
    - Rule 7: 15 points within 1σ (stratification)
    - Rule 8: 8 points beyond 1σ both sides (mixture)
  - → Phase I baseline: collect 25+ subgroups → estimate control limits via SAS PROC SHEWHART
  - → Phase II: real-time check each incoming measurement against stored limits
  - → `SPC_LIMITS` table: per-parameter, per-equipment, per-recipe control limits
  - → `SPC_VIOLATIONS` table: all rule breaches with timestamp + affected lot

- [ ] **TASK-4002** | 🔴 P0 | 10h | `[BE]` SPC API endpoints
  - → `GET /spc/charts` — params: `parameter`, `tool`, `period`, `chart_type`
    - Chart types: XbarR, XbarS, I-MR, P-chart, C-chart
    - Returns: data points + control limits + violation flags
  - → `GET /spc/violations` — params: `rule`, `severity`, `date_range`, `tool`
  - → `GET /spc/capability` — params: `parameter`, `lot_range`
    - Returns: Cp, Cpk, Pp, Ppk, Cpm from SAS PROC CAPABILITY
  - → `POST /spc/update-limits` — recalculate limits from new baseline data
  - → `GET /spc/virtual-metrology` — ML-predicted next measurement value
  - → `GET /spc/parameter-dashboard` — aggregated SPC status for all monitored parameters

- [ ] **TASK-4003** | 🟠 P1 | 12h | `[BE]` Virtual Metrology (VM) model
  - → Feature set: equipment sensor readings (FDC trace averages) + previous metrology
  - → Model: SAS PROC NNET (MLP) trained on historical lot data
  - → Per-parameter, per-tool trained models stored in MLflow
  - → VM prediction confidence interval: 95% prediction interval from model
  - → Fallback: if VM uncertainty > threshold, flag for physical measurement
  - → Retraining trigger: when physical measurement vs VM prediction MAE degrades

- [ ] **TASK-4004** | 🟠 P1 | 8h | `[BE]` User-scriptable SPC rule creation
  - → Python sandbox (RestrictedPython) for custom rule expressions
  - → Rule template: `def check(points: list[float], limits: SPCLimits) -> bool`
  - → Rule library: save, name, share custom rules across users
  - → Dry-run: test custom rule against historical data before activation

---

### P4.2 — SPC Frontend

- [ ] **TASK-4010** | 🔴 P0 | 20h | `[FE]` SPC Monitor main page

  **Parameter Control Chart View:**
  - → Recharts LineChart with custom dot renderer
  - → Control limit lines: UCL (red dashed), LCL (red dashed), CL (gray), ±1σ, ±2σ (subtle)
  - → Violation highlight: data point turns red + tooltip explaining which rule triggered
  - → Brush / zoom for time navigation
  - → Annotation overlay: PM events, recipe changes as vertical markers
  - → Chart type switcher: Xbar-R / Xbar-S / I-MR / P-chart

  **Parameter Selector Panel (left side):**
  - → Tree: Tool → Chamber → Parameter
  - → Status icon: green circle (in-control) / yellow triangle (near limit) / red X (violation)
  - → Filter: show only out-of-control parameters
  - → Drag-and-drop to reorder the parameter list

  **Statistics Panel (right side):**
  - → Cpk gauge: arc from 0 to 2.0, color-coded, animated on data load
  - → Cp, Ppk, Cpm values in monospace
  - → Last violation: timestamp + rule description
  - → Trend direction: up/down arrow with magnitude

- [ ] **TASK-4011** | 🟠 P1 | 12h | `[FE]` SPC fleet dashboard
  - → Grid of mini-control charts (1 per monitored parameter, all tools)
  - → Color-coded border: green (OK) / yellow (warning) / red (violation)
  - → Click mini-chart: expands to full detailed view
  - → Filter by: tool type / process step / last violation time
  - → Export: full fleet status as PDF report

---

### P4.3 — FDC Engine

- [ ] **TASK-4020** | 🔴 P0 | 20h | `[BE]` FDC trace anomaly detection — INF-TPC equivalent
  - → GEM300 trace data ingestion from Kafka `fdc-trace` topic
  - → Trace segmentation: split by recipe step boundaries
  - → Per-sensor baseline: rolling 7-day statistics (mean, sigma, p5, p95)
  - → Multi-sensor PCA baseline: principal components from sensor ensemble
  - → LSTM Autoencoder: reconstruction error as anomaly score
  - → Anomaly classification:
    - Interval anomaly: sensor value outside statistical bounds
    - PM anomaly: characteristic shift after preventive maintenance
    - Amplitude anomaly: peak detection with prominence threshold
    - Shape anomaly: DTW distance from nominal trace pattern
  - → Composite anomaly score: weighted fusion of 4 detection methods
  - → Alert threshold: score > 0.85 → write to Oracle `LIVE_ALARM` + Kafka `alarm-events`
  - → Accuracy target: > 95% detection rate, < 2% false positive on validation set

- [ ] **TASK-4021** | 🟠 P1 | 12h | `[FE]` FDC trace visualization page
  - → Equipment selector + time range picker
  - → Multi-sensor trace overlay: each sensor as colored line
  - → Anomaly region highlight: red shaded zone on time axis where anomaly detected
  - → Anomaly score subplot: shows composite score over time
  - → PM event markers: vertical lines where maintenance was performed
  - → Zoom: linked zoom across all sensor subplots
  - → "Compare with baseline" toggle: overlay nominal trace

- [ ] **TASK-4022** | 🟠 P1 | 10h | `[FE]` Equipment health fleet view
  - → Card grid: 1 card per equipment
  - → Each card: equipment ID, type, health score gauge, status badge, top violation reason
  - → Health score arc: green (90+) / yellow (70-89) / orange (50-69) / red (<50)
  - → Sort: by health score ascending (worst first) default
  - → Click card: equipment detail drawer slides in from right

---

## PHASE 5 — Defect Analysis System

> **Goal:** Spatial defect intelligence — DMS + ADC + WPA  
> **Duration:** Weeks 11–16  
> **Owner:** ML Engineer + Frontend Developer

---

- [ ] **TASK-5001** | 🔴 P0 | 14h | `[BE]` defect-service scaffold
  - → Blueprint: `/api/v1/defect`
  - → KLARF parser (KLA Results File Format versions 1.8, 2.0)
  - → AMAT Compass XML defect file parser
  - → SEM image ingestion: store to MinIO, generate thumbnail
  - → `GET /defect/map` → wafer defect map with coordinates + classification
  - → `GET /defect/summary` → defect density, class distribution, spatial pattern
  - → `GET /defect/trend` → defect density trend over time
  - → `POST /defect/classify` → run ADC on uploaded SEM image

- [ ] **TASK-5002** | 🔴 P0 | 20h | `[AI]` Auto Defect Classification (ADC) — INF-ADC equivalent
  - → Model: EfficientNet-B4 (PyTorch) pre-trained on ImageNet, fine-tuned on fab defect images
  - → Defect categories: Particle, Scratch, Crystal defect, Bridge, Pit, Thin film, Unknown
  - → Training data: minimum 1,000 labelled images per class
  - → Confidence threshold: > 0.85 → auto-classify; ≤ 0.85 → human review queue
  - → ONNX export for Triton inference server deployment
  - → Model versioning: MLflow experiment tracking
  - → Human correction loop: correction stored → triggers retraining job
  - → Target accuracy: > 92% on held-out test set

- [ ] **TASK-5003** | 🟠 P1 | 16h | `[AI]` Wafer Pattern Analysis — INF-WPA equivalent
  - → Input: defect coordinate map (from KLARF) as spatial point process
  - → Pattern classifier (CNN on rendered 256×256 defect map images):
    - Ring pattern → edge bead / rinsing issue
    - Edge pattern → edge die yield loss / wafer handling
    - Scratch pattern → equipment contact / transport damage
    - Cluster pattern → local contamination / crystal defect
    - Random pattern → random killer defects (baseline)
    - Center pattern → process non-uniformity (CMP, coating)
  - → Pattern-to-process-step correlation lookup from RCA_KNOWLEDGE graph
  - → Batch processing: all wafers in a lot in parallel
  - → `GET /defect/pattern-analysis` → pattern classification + process step hypothesis

- [ ] **TASK-5010** | 🔴 P0 | 16h | `[FE]` Defect Management dashboard
  - → Defect map: SVG render of wafer circle + defect points (size = defect size, color = class)
  - → Class filter: toggle defect classes on/off
  - → Size range slider: filter by defect size in µm
  - → Density heatmap overlay: kernel density estimation of defect spatial distribution
  - → Pattern analysis panel: detected pattern + confidence + process step hypothesis
  - → SEM image viewer: click on defect point → shows SEM image with ADC result
  - → Trend chart: defect density per class over time (last 90 days)
  - → "Submit for ADC" button: re-run classification on selected defects

---

## PHASE 6 — AI / ML Intelligence & Agentic AI

> **Goal:** The platform's crown jewel — autonomous yield improvement intelligence  
> **Duration:** Weeks 15–22  
> **Owner:** AI Lead × 3 Engineers

---

### P6.1 — ML Model Suite

- [ ] **TASK-6001** | 🔴 P0 | 24h | `[AI]` Yield prediction model (XGBoost)
  - → Feature engineering pipeline: 200+ WAT params + equipment context + process conditions
  - → Feature store: precomputed features in Greenplum `ML_FEATURES` table
  - → XGBoost training: 80/10/10 train/val/test split by lot date
  - → Hyperparameter tuning: Optuna with 100 trials
  - → SHAP explanations: per-prediction feature attribution
  - → Target metric: RMSE < 2% absolute yield on test set
  - → MLflow: log params, metrics, model artifact, SHAP plots
  - → ONNX export + Triton deployment

- [ ] **TASK-6002** | 🔴 P0 | 20h | `[AI]` LSTM time series yield prediction
  - → Sequential lot-to-lot yield prediction
  - → Input: rolling window of last 20 lots' features
  - → PyTorch LSTM with attention mechanism
  - → Uncertainty quantification: Monte Carlo Dropout
  - → Ensemble: 0.7 × XGBoost + 0.3 × LSTM blending

- [ ] **TASK-6003** | 🟠 P1 | 16h | `[AI]` Causal AI for RCA — DoWhy integration
  - → Build causal DAG: process steps → equipment → parameters → yield
  - → DoWhy: estimate causal effect of each factor on yield
  - → Counterfactual generation: "what if tool CVD-01 had nominal health?"
  - → Intervention effect: estimate yield gain from fixing identified root cause
  - → `GET /ai/causal-rca` → causal explanation with intervention recommendations

- [ ] **TASK-6004** | 🟠 P1 | 12h | `[AI]` inference-service — Triton server integration
  - → NVIDIA Triton Inference Server deployment on GPU nodes
  - → Model repository: XGBoost (FIL backend), LSTM (PyTorch backend), EfficientNet (TensorRT)
  - → Dynamic batching: max batch size 64, max latency 10ms
  - → gRPC client in Flask inference-service
  - → Fallback: direct model load if Triton unavailable
  - → `POST /ai/predict/yield` → real-time yield prediction for incoming lot
  - → `POST /ai/anomaly-score` → equipment health anomaly score

---

### P6.2 — LLM Wisdom Engine

- [ ] **TASK-6010** | 🔴 P0 | 40h | `[AI]` LLM service scaffold + knowledge pipeline
  - → Base model: Qwen2.5-72B-Instruct (on-premise, A100 GPU cluster)
  - → LoRA fine-tuning on semiconductor domain corpus (500K tokens)
  - → Fine-tuning corpus:
    - Validated RCA records from historical fab data (anonymized)
    - Semiconductor process physics textbook excerpts
    - Equipment manuals (structured extraction)
    - IEEE/IEDM papers on yield improvement
  - → vLLM as inference engine (continuous batching, 40 token/s target)
  - → System prompt templates per analysis task type
  - → RAG pipeline: ChromaDB vector store + `text-embedding-3` embeddings
  - → Knowledge retrieval: top-5 similar RCA cases from `RCA_KNOWLEDGE` + Neo4j graph

- [ ] **TASK-6011** | 🔴 P0 | 30h | `[AI]` LangGraph agent orchestrator
  - → State machine nodes (as LangGraph nodes):
    - `observe`: fetch all relevant data via tool calls
    - `analyze`: run statistical/ML analysis tools
    - `hypothesize`: LLM generates top-3 RCA hypotheses
    - `verify`: check hypothesis against additional data
    - `recommend`: generate prioritized action plan
    - `execute`: issue commands via robot tools (if confidence ≥ 95%)
    - `learn`: write confirmed RCA to knowledge graph
  - → Tool registry (MCP protocol):
    - `query_yield_data(lot_id, date_range)` → GP query
    - `query_spc_violations(equipment_id, date_range)` → Oracle query
    - `run_ml_inference(features)` → Triton inference
    - `search_knowledge_base(symptom_description)` → RAG + Neo4j
    - `query_defect_maps(lot_id)` → defect-service call
    - `get_equipment_status(equipment_id)` → FDC real-time
    - `issue_lot_hold(lot_id, reason)` → MES API
    - `adjust_recipe(equipment_id, param, delta)` → EAP API
    - `schedule_pm(equipment_id, urgency)` → CMMS API
    - `notify_engineer(user_id, message, context)` → notification-service
    - `update_knowledge(rca_record)` → Neo4j write
  - → Confidence gating: ≥ 95% → auto-execute; 80-94% → engineer approval; < 80% → escalate
  - → Audit trail: every agent step + tool call logged to GP `AGENT_ACTIONS`

- [ ] **TASK-6012** | 🔴 P0 | 20h | `[AI]` Knowledge accumulation loop
  - → Every confirmed RCA: `(symptom, equipment, process_step, root_cause, corrective_action, outcome)` → Neo4j
  - → Engineer correction of agent answer: delta stored as `weight_update` on RCA node
  - → Similarity search: new symptom → cosine similarity against known RCA embeddings
  - → Confidence decay: RCA nodes older than 1 year without re-confirmation get confidence halved
  - → Knowledge graph analytics: identify most common root causes, recurring patterns
  - → Weekly knowledge digest: auto-report of new knowledge accumulated

- [ ] **TASK-6013** | 🟠 P1 | 16h | `[AI]` SemiMind++ NL interface — intent classification
  - → Intent classifier: fine-tuned classifier on 50 fab-specific intent types
  - → Entity extractor: lot_id, equipment_id, parameter_name, date_range NER
  - → Tool routing: intent → correct API calls
  - → Multi-turn context: maintain conversation context for 20 turns
  - → Bilingual support: English + Traditional/Simplified Chinese
  - → Response formatter: structured output → narrative + chart data + action buttons

---

### P6.3 — Agent Chat Interface

- [ ] **TASK-6020** | 🔴 P0 | 24h | `[FE]` Agent Chat page — AI analyst interface

  **Design — "Mission Control" Aesthetic:**
  - → Split layout: left 35% (conversation) / right 65% (live analysis canvas)
  - → Background: dark `#080C14` with subtle hexagonal grid pattern (CSS)
  - → Agent "thinking" indicator: pulsing electric violet dots animation
  - → Agent avatar: geometric AI icon with animated ring when active

  **Conversation Panel:**
  - → Chat bubbles: user (right, teal glass) / agent (left, violet glass)
  - → Streaming text: character-by-character typewriter render from SSE
  - → Code blocks: syntax-highlighted in monospace with copy button
  - → Inline charts: mini wafer maps, sparklines embedded in agent responses
  - → Tool call display: collapsible "📡 Querying yield data..." cards
  - → Action proposal cards: approval/reject buttons with countdown timer
  - → Message timestamps + copy message button on hover

  **Analysis Canvas (right side — live workspace):**
  - → Auto-populated as agent calls tools and generates analysis
  - → Sections appear with slide-in animation as agent discovers insights:
    - Lot context header
    - Yield trend chart
    - Wafer map of worst wafer
    - Top parameter deviations table
    - Equipment health indicators
    - SHAP attribution chart
    - RCA hypothesis cards (numbered, color by confidence)
    - Action recommendation list

  **Input Area:**
  - → Rich text input with `@` mention for lot IDs / equipment
  - → Suggested prompts carousel (rotating cards below input)
  - → Attach: drag-drop STDF file or paste lot list
  - → Voice input: Web Speech API → text (optional)
  - → "New Analysis" button: clears canvas, starts new session

- [ ] **TASK-6021** | 🟠 P1 | 12h | `[FE]` Agent action approval workflow
  - → Pending actions queue: badge counter on Agent page nav item
  - → Action card: action type, target (lot/equipment), description, risk level, confidence %
  - → Risk color coding: green (recipe adjust ±1%) / yellow (lot hold) / red (scrap recommendation)
  - → Time pressure indicator: "Auto-approves in 30 min" countdown for low-risk actions
  - → One-click approve/reject + optional comment
  - → Post-action outcome tracking: "Action taken 2h ago — yield improved 0.8%"

- [ ] **TASK-6022** | 🟠 P1 | 10h | `[FE]` Knowledge base explorer
  - → Search bar: semantic search over RCA knowledge graph
  - → Result cards: symptom → root cause → corrective action with confidence badge
  - → Graph visualization: force-directed graph (D3) showing related RCA nodes
  - → Filter: by equipment type / process step / recency / confidence
  - → "Add knowledge" form: engineer can directly contribute confirmed RCA

---

## PHASE 7 — DFM Suite & DFT Suite

> **Goal:** Design-to-manufacturing intelligence  
> **Duration:** Weeks 14–18  

---

- [ ] **TASK-7001** | 🟠 P1 | 20h | `[BE]` dfm-service — LayoutVision equivalent
  - → GDS2/OASIS file upload and parsing (gdstk library)
  - → Layer stack definition: map GDS layer numbers to process layers
  - → Design rule check integration: connect to existing DRC engine or run custom rules
  - → Yield risk scoring: correlate layout geometry features with historical defect data
  - → `GET /dfm/layout-risk` → layer-by-layer yield risk heatmap
  - → `GET /dfm/hotspots` → ranked list of high-risk layout patterns

- [ ] **TASK-7002** | 🟠 P1 | 16h | `[BE]` CMPEXP — CMP modeling service
  - → Physical model: contact mechanics (Preston equation)
  - → ML model: neural network trained on process data (PyTorch)
  - → Input: GDS layer density map + process parameters
  - → Output: dishing/erosion prediction map + planarity risk score
  - → `POST /dfm/cmp-simulate` → returns simulated topography

- [ ] **TASK-7003** | 🟠 P1 | 12h | `[BE]` Virtual Yield service
  - → Critical area extraction from layout (via LayoutVision API)
  - → Yield model: Poisson `Y = exp(-D×A)`, Murphy model, Seeds model
  - → Input: defect density from DMS + critical area from layout
  - → `GET /dfm/virtual-yield` → predicted yield per layer + total

- [ ] **TASK-7004** | 🟠 P1 | 12h | `[BE]` dft-service — QuanTest + YAD equivalent
  - → Test vector management: store ATPG-generated patterns
  - → Fault coverage analysis: stuck-at, transition, cell-aware
  - → YAD integration: failing pattern → suspect net tracing
  - → `POST /dft/diagnose` → fault localization from failing vectors
  - → `GET /dft/coverage` → fault coverage report per test program
  - → YMS bridge: link DFT failure analysis → CP yield data

- [ ] **TASK-7010** | 🟠 P1 | 16h | `[FE]` DFM Suite UI
  - → Layout viewer: GDS layer overlay on wafer coordinate system (WebGL-based for performance)
  - → Risk heatmap overlay: semi-transparent color layer on layout
  - → CMP simulation result: topography contour map
  - → Virtual yield prediction: yield donut chart per layer
  - → Side-by-side: layout patterns vs actual defect map overlay

---

## PHASE 8 — Reports, Notifications & Admin

> **Duration:** Weeks 16–19

---

### P8.1 — Report Service

- [ ] **TASK-8001** | 🟠 P1 | 16h | `[BE]` report-service — automated report generation
  - → Report types:
    - Daily WAT summary (auto-generated 6am fab time)
    - Weekly yield trend report
    - Low-yield lot RCA report (triggered by excursion)
    - SPC capability report (weekly)
    - Equipment health monthly digest
    - Agent activity log (daily)
  - → Rendering: Jinja2 HTML → WeasyPrint PDF
  - → Delivery: email (SendGrid) + in-app notification + Slack webhook
  - → `GET /reports/list` → report history with download links
  - → `POST /reports/generate` → on-demand report trigger

- [ ] **TASK-8002** | 🟠 P1 | 12h | `[FE]` Reports page
  - → Report gallery: cards with report type icon + last generated time
  - → Report preview: embedded PDF viewer (pdf.js)
  - → Schedule editor: configure report frequency + recipients
  - → Download formats: PDF, Excel, PowerPoint (using python-pptx)
  - → "Generate Now" button with progress indicator

---

### P8.2 — Admin & System Config

- [ ] **TASK-8010** | 🟠 P1 | 12h | `[FE]` Admin panel
  - → User management: create/edit/deactivate users, assign roles
  - → Equipment registry: add/edit equipment, assign parameters to monitor
  - → SPC parameter config: set/modify control limits per parameter
  - → Alert routing: configure who gets notified for each alarm type
  - → System health: service status dashboard (all microservices)
  - → Audit log viewer: filterable log of all user + agent + robot actions

- [ ] **TASK-8011** | 🟠 P1 | 8h | `[FE]` User profile & preferences page
  - → Avatar upload with crop tool
  - → Notification preferences: email / Slack / in-app per alarm severity
  - → Default fab/product context
  - → Dashboard layout customization: drag-and-drop widget arrangement
  - → MFA setup wizard
  - → API key management (for Jupyter/scripting access)

---

## PHASE 9 — FAB Automation & Robot Control (Autonomous FAB)

> **Goal:** Software + Hardware robot integration — autonomous corrective actions  
> **Duration:** Weeks 18–24  
> **Owner:** FAB Integration Lead + AI Lead

---

### P9.1 — MES / EAP Integration

- [ ] **TASK-9001** | 🔴 P0 | 20h | `[BE]` robot-ctrl-service — MES integration
  - → MES API client: REST/SOAP adapter (configurable per MES vendor)
  - → Lot hold: `POST /mes/lot/hold` → MES API call → audit log
  - → Lot release: `POST /mes/lot/release` → with reason code
  - → Priority change: `POST /mes/lot/priority` → hot lot elevation
  - → WIP query: `GET /mes/wip/{step}` → current WIP at any step
  - → Permission enforcement: ROBOT_SERVICE role required

- [ ] **TASK-9002** | 🟠 P1 | 16h | `[BE]` EAP GEM300 integration
  - → SECS-II / HSMS client library (PyGEMS or custom implementation)
  - → Recipe read: `GET /eap/recipe/{equipment_id}` → current recipe
  - → Recipe write (constrained): `POST /eap/recipe/adjust` — max ±5% without human approval
  - → Equipment status: `GET /eap/status/{equipment_id}` → real-time GEM300 status
  - → Run-to-run control: APC setpoint calculation + dispatch

- [ ] **TASK-9003** | 🟠 P1 | 12h | `[BE]` AMHS wafer transport robot interface
  - → SEMI E84 carrier handoff protocol implementation
  - → SEMI E87 carrier management system interface
  - → Transport command: `POST /robot/transport` → {from_tool, to_tool, carrier_id}
  - → Stocker management: `GET /robot/stocker/status`, `POST /robot/stocker/retrieve`
  - → Emergency re-route: cancel + re-route command on alarm

- [ ] **TASK-9010** | 🔴 P0 | 20h | `[FE]` FAB Control dashboard — Mission Control

  **Design — Real Industrial Command Center:**
  - → Full-screen dark layout with FAB floor plan schematic in center
  - → Equipment nodes on floor plan: colored by health status, pulsing if alarming
  - → Wafer transport lines animated with moving carrier indicators
  - → Live lot position overlay: lot IDs shown at their current step

  **Panels:**
  - → Top strip: Fab OEE, WIP count, active lots, robot actions in queue
  - → Left: Agent action queue (pending approvals + auto-executing)
  - → Center: FAB floor plan with live equipment status
  - → Right: Active robot commands log (live scrolling)
  - → Bottom: R2R control chart (recipe adjustments over time)

- [ ] **TASK-9011** | 🟠 P1 | 12h | `[FE]` Robot action approval panel
  - → Action queue sorted by urgency (criticality × time sensitivity)
  - → Each action: AI confidence %, estimated impact, required human authority level
  - → Batch approve: select multiple similar actions → approve all
  - → Escalation: "Not sure" → routes to senior engineer
  - → Post-action tracking: show outcome metrics 2h / 24h after action

---

## PHASE 10 — Performance, Testing & Production Hardening

> **Duration:** Weeks 20–24 (overlapping with Phase 9)

---

### P10.1 — Frontend Performance

- [ ] **TASK-1001F** | 🔴 P0 | 8h | `[FE]` Code splitting & lazy loading audit
  - → Each feature module: separate lazy chunk (< 200KB gzipped each)
  - → Route-level splitting: all 12 modules loaded only on navigation
  - → Critical path: shell + auth + YMS dashboard < 150KB initial bundle
  - → Lighthouse score targets: Performance > 90, Accessibility > 95

- [ ] **TASK-1002F** | 🟠 P1 | 8h | `[FE]` Virtual scrolling for large data tables
  - → `react-virtual` for DataTable with 100K+ rows
  - → Windowed rendering: only visible rows in DOM
  - → Server-side pagination fallback for > 1M rows

- [ ] **TASK-1003F** | 🟠 P1 | 6h | `[FE]` Canvas & WebGL optimizations
  - → WaferMap: requestAnimationFrame loop with dirty-flag — only re-render on data change
  - → WebGL-based layout viewer: THREE.js or raw WebGL for GDS rendering
  - → Offscreen canvas for thumbnail generation (Web Worker)

---

### P10.2 — Testing Suite

- [ ] **TASK-T001** | 🔴 P0 | 20h | `[TEST]` Backend unit tests — pytest
  - → Target: > 85% code coverage on all service logic
  - → Mock SAS Viya SWAT: `pytest-mock` for CAS calls
  - → Mock Greenplum: `pytest-postgresql` fixture
  - → Mock Oracle: in-memory SQLite for unit tests
  - → Test data factories: `factory_boy` for realistic fab data
  - → All 8 SPC rules: test each rule triggers correctly

- [ ] **TASK-T002** | 🔴 P0 | 16h | `[TEST]` Frontend unit tests — Vitest + Testing Library
  - → All UI components: render, interaction, accessibility tests
  - → WaferMap: test Canvas pixel output correctness
  - → Zustand stores: test all state transitions
  - → API hooks: msw (Mock Service Worker) for API mocking

- [ ] **TASK-T003** | 🔴 P0 | 16h | `[TEST]` Integration tests — service-to-service
  - → End-to-end upload → parse → analyze → dashboard display
  - → SPC violation → alarm → notification → agent trigger
  - → Agent RCA → action proposal → approval → robot execution

- [ ] **TASK-T004** | 🟠 P1 | 12h | `[TEST]` E2E tests — Playwright
  - → Login → navigate → perform analysis → verify chart renders
  - → Upload STDF → verify WAT analytics populate
  - → Trigger manual alarm → verify agent responds
  - → Cross-browser: Chromium, Firefox, WebKit

- [ ] **TASK-T005** | 🟠 P1 | 8h | `[TEST]` Load testing — k6
  - → 500 concurrent users on YMS dashboard
  - → 100 concurrent SPC chart requests
  - → Agent 10 concurrent RCA sessions
  - → Target: P95 latency < 200ms for data APIs, < 30s for LLM responses

- [ ] **TASK-T006** | 🟠 P1 | 12h | `[TEST]` AI model validation
  - → Yield prediction: RMSE < 2% on held-out test set (200 lots)
  - → ADC accuracy: > 92% on 1,000 labelled test images
  - → INF-TPC anomaly detection: > 95% on FAB benchmark dataset
  - → Agent RCA accuracy: > 90% match vs engineer gold standard (50 RCA cases)
  - → LLM hallucination rate: < 2% on semiconductor parameter facts

---

## PHASE 11 — UI Polish & Modern Web Design Final Pass

> **Goal:** Make every page visually stunning and interaction-smooth  
> **Duration:** Weeks 22–24 (parallel to Phase 10)

---

- [ ] **TASK-U001** | 🔴 P0 | 16h | `[FE]` Page transition animations
  - → Route change: crossfade with subtle scale (Framer Motion `AnimatePresence`)
  - → First data load: skeleton screens → content with staggered fade-in
  - → Tab switches: content slide direction matches tab direction

- [ ] **TASK-U002** | 🔴 P0 | 12h | `[FE]` Chart animations
  - → All Recharts: animate on initial render (bars grow up, lines draw left-to-right)
  - → Data updates: smooth transition (not jarring redraw)
  - → Number counters: `AnimatedNumber` on all KPI values
  - → Gauge fills: CSS transition on `stroke-dashoffset`

- [ ] **TASK-U003** | 🟠 P1 | 10h | `[FE]` Glassmorphism polish pass
  - → Audit every card/panel: consistent blur + transparency values
  - → Gradient borders: `border-image` with subtle gradient on elevated panels
  - → Glow effects on interactive elements: hover glow radius + color

- [ ] **TASK-U004** | 🟠 P1 | 8h | `[FE]` Empty states design
  - → Every empty table / no-data chart: illustrated empty state SVG + helpful CTA
  - → Empty states: themed illustrations (circuit-board motifs, wafer silhouettes)
  - → Error states: apologetic messaging + retry button

- [ ] **TASK-U005** | 🟠 P1 | 6h | `[FE]` Accessibility audit — WCAG 2.1 AA
  - → All interactive elements: keyboard focusable + visible focus ring
  - → Screen reader: `aria-label` on all icon buttons
  - → Color contrast: all text meets 4.5:1 minimum (dark theme audit)
  - → `prefers-reduced-motion`: all animations conditional

- [ ] **TASK-U006** | 🟡 P2 | 8h | `[FE]` Responsive layout audit
  - → Primary target: 1920×1080 desktop (FAB engineer workstation)
  - → Secondary: 1440×900 (13" laptop for managers)
  - → Minimum: 1280×800 (absolute floor — side panels collapse)
  - → Not mobile-optimized (fab environment constraint — document in README)

- [ ] **TASK-U007** | 🟢 P3 | 10h | `[FE]` Dashboard customization (power user feature)
  - → Drag-and-drop widget grid (react-grid-layout)
  - → Widget library: all chart types available as dropable widgets
  - → Per-user layout persistence (backend user preference API)
  - → "Presentation mode": clean full-screen, hide navigation

- [ ] **TASK-U008** | 🟢 P3 | 6h | `[FE]` Theme — branded light mode variant
  - → Light theme: white background / dark text (for management presentations)
  - → System preference detection with manual override
  - → Logo adapts to theme

---

## Summary & Task Count by Phase

| Phase | Description | Task Count | Est. Hours | Priority |
|-------|-------------|-----------|-----------|---------|
| Phase 0 | Foundation & DevOps | 29 tasks | 218h | 🔴 Critical |
| Phase 1 | Auth & App Shell | 16 tasks | 136h | 🔴 Critical |
| Phase 2 | YMS Dashboard | 15 tasks | 152h | 🔴 Critical |
| Phase 3 | WAT & CP Analytics | 13 tasks | 164h | 🔴 Critical |
| Phase 4 | SPC / FDC / Equipment | 12 tasks | 136h | 🔴 Critical |
| Phase 5 | Defect Analysis | 6 tasks | 82h | 🟠 High |
| Phase 6 | AI / ML / Agent AI | 13 tasks | 224h | 🔴 Critical |
| Phase 7 | DFM & DFT Suite | 7 tasks | 96h | 🟠 High |
| Phase 8 | Reports & Admin | 4 tasks | 48h | 🟠 High |
| Phase 9 | FAB Automation | 8 tasks | 120h | 🟠 High |
| Phase 10 | Testing & Hardening | 9 tasks | 112h | 🔴 Critical |
| Phase 11 | UI Polish & Design | 8 tasks | 96h | 🟠 High |
| **Total** | | **140 task groups / 847 sub-tasks** | **~1,584h** | |

---

## Appendix A — Modern Web Design Principles Applied

### Glassmorphism System
```css
/* Card — Base Glass */
.card-glass {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
}

/* Card — Elevated (modals, popovers) */
.card-glass-elevated {
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(40px);
  border: 1px solid rgba(0, 245, 196, 0.15);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4),
              inset 0 1px 0 rgba(255, 255, 255, 0.1);
}

/* Active / Focus Glow */
.glow-teal {
  box-shadow: 0 0 0 2px rgba(0, 245, 196, 0.3),
              0 0 20px rgba(0, 245, 196, 0.1);
}

/* Critical Alarm Pulse */
@keyframes alarm-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(255, 51, 102, 0.4); }
  50% { box-shadow: 0 0 0 8px rgba(255, 51, 102, 0); }
}
```

### Animation Principles
- **Entrance:** Elements enter with `translateY(8px) → 0` + `opacity 0 → 1`, duration 250ms ease-out
- **Exit:** `opacity 1 → 0` only, duration 150ms — exits are faster than entrances
- **Data updates:** `transition: all 300ms ease-in-out` on numeric values
- **Hover:** `transform: translateY(-2px)` + glow intensify, 150ms
- **Loading:** Skeleton screens with animated gradient sweep (not spinners for content)
- **Success:** Micro-celebration — brief scale `1 → 1.05 → 1` with color flash

### Information Density Principle
- **Scannable hierarchy:** Data tables use monospace, 13px. Labels 12px. Values 14px bold.
- **Color encodes meaning, not decoration:** Red = alarm/fail only. Teal = active/selected only. Violet = AI only.
- **Progressive disclosure:** Summary → drill-down → raw data (never show all at once)
- **Contextual density:** Operator view (sparse, large) vs Engineer view (dense, small) toggle

---

## Appendix B — Development Environment Setup Checklist

- [ ] Node.js 20 LTS + pnpm 9
- [ ] Python 3.11 + uv package manager
- [ ] Docker Desktop + kubectl configured
- [ ] VS Code extensions: ESLint, Prettier, Pylance, GitLens, Thunder Client
- [ ] `.env.local` file populated from team vault (not committed)
- [ ] Pre-commit hooks: `pnpm husky install` + `python -m pre_commit install`
- [ ] Local Greenplum: Docker Compose with Greenplum single-node
- [ ] Local Oracle: Docker `container-registry.oracle.com/database/express:21.3.0`
- [ ] Local Redis: `docker run -p 6379:6379 redis:7`
- [ ] Local Kafka: Docker Compose with `bitnami/kafka:latest`
- [ ] SAS Viya: use SAS Viya for Learners account for development
- [ ] Seed data: `make seed-dev` loads 100-lot synthetic WAT + CP dataset

---

*Document End — SEMFAB·IQ Implementation Task List v1.0*  
*Total: 847 implementation tasks across 11 development phases*  
*© 2025 SEMFAB·IQ Engineering Team. Commercial Confidential.*
