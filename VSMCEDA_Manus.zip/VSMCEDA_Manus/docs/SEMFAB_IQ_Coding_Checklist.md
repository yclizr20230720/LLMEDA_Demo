# SEMFAB·IQ — Master Coding Function Checklist
## Complete Code-Level Implementation Tracking Document
### Every Function · Every File · Every Feature — Mapped to Design, Stories & Tasks

---

> **Document Purpose:** Granular coding checklist for engineering teams to track implementation status  
> **Mapping Reference:**  
> — `[ARCH §N]` → Architecture Design Report Section N  
> — `[TASK-XXXX]` → Implementation Task List item  
> — `[US-XXX-NNN]` → User Story reference  
> **Checkbox Status:** `[ ]` Not started · `[~]` In Progress · `[x]` Complete · `[!]` Blocked  
> **Total Functions to Implement:** 624 discrete coding units

---

## How to Read This Checklist

```
- [ ] FUNC-XXXX | FILE: path/to/file.py | MAPS: [ARCH §N] [TASK-XXXX] [US-XXX-NNN]
      Function: function_name(params) → return_type
      → What it does: single sentence
      → Acceptance: testable condition that proves it works
```

---

# 🏗️ MODULE 0 — PROJECT SCAFFOLD & SHARED INFRASTRUCTURE

## 0.1 Monorepo & Project Structure

- [ ] FUNC-0001 | FILE: `package.json` (root) | MAPS: [ARCH §3.2] [TASK-0001]
      Setup: pnpm workspace monorepo root config
      → Defines workspaces: apps/web, services/*, packages/*
      → Acceptance: `pnpm install` at root installs all workspace deps

- [ ] FUNC-0002 | FILE: `apps/web/vite.config.ts` | MAPS: [ARCH §6] [TASK-1010]
      Setup: Vite config with path aliases, code splitting, chunk naming
      → Aliases: `@/` → `src/`, `@ui/` → `packages/ui/src/`
      → Acceptance: `@/components/Button` resolves correctly in dev + build

- [ ] FUNC-0003 | FILE: `apps/web/tsconfig.json` | MAPS: [TASK-1010]
      Setup: TypeScript strict mode config
      → `strict: true`, `noUncheckedIndexedAccess: true`
      → Acceptance: `tsc --noEmit` passes with zero errors on clean scaffold

- [ ] FUNC-0004 | FILE: `services/shared/config.py` | MAPS: [ARCH §7.1] [TASK-0001]
      Function: `load_config(env: str) → AppConfig`
      → Loads env-specific config from Vault + environment variables
      → Acceptance: Returns typed config object; raises `ConfigError` if required key missing

- [ ] FUNC-0005 | FILE: `services/shared/db.py` | MAPS: [ARCH §4] [TASK-0020]
      Function: `get_greenplum_engine() → Engine`
      → SQLAlchemy engine with connection pool (min=2, max=20, pool_timeout=30)
      → Acceptance: Engine connects, executes `SELECT 1`, returns result

- [ ] FUNC-0006 | FILE: `services/shared/db.py` | MAPS: [ARCH §4.2] [TASK-0021]
      Function: `get_oracle_engine() → Engine`
      → cx_Oracle engine with HikariCP-equivalent pool settings
      → Acceptance: Connects to Oracle, `SELECT SYSDATE FROM DUAL` returns timestamp

- [ ] FUNC-0007 | FILE: `services/shared/cas_client.py` | MAPS: [ARCH §4.3] [TASK-0022]
      Function: `get_cas_session() → swat.CAS`
      → Connection pool wrapper: returns pooled CAS session (min=2, max=10)
      → Acceptance: Session connects, `conn.serverstatus()` returns OK

- [ ] FUNC-0008 | FILE: `services/shared/cache.py` | MAPS: [ARCH §4] [TASK-0023]
      Function: `get_redis_client() → Redis`
      → Redis cluster client with retry logic (3 retries, exponential backoff)
      → Acceptance: `client.ping()` returns True; `set/get` round-trip works

- [ ] FUNC-0009 | FILE: `services/shared/kafka_producer.py` | MAPS: [ARCH §4.4] [TASK-0024]
      Function: `get_producer(topic: str) → KafkaProducer`
      → Returns configured Kafka producer with Avro serializer
      → Acceptance: Produces test message to `test-topic`; consumer receives it

- [ ] FUNC-0010 | FILE: `services/shared/kafka_consumer.py` | MAPS: [ARCH §4.4] [TASK-0024]
      Function: `create_consumer(topics: list[str], group_id: str) → KafkaConsumer`
      → Consumer with auto-commit disabled, manual offset commit on success
      → Acceptance: Consumes from `test-topic`, processes message, commits offset

- [ ] FUNC-0011 | FILE: `services/shared/response.py` | MAPS: [ARCH §5.2] [TASK-0001]
      Function: `success(data, meta=None) → dict`
      Function: `error(code, message, details=None) → dict`
      → Unified JSON envelope: `{status, data, meta, errors, trace_id}`
      → Acceptance: Both functions return valid envelope dict with all required keys

- [ ] FUNC-0012 | FILE: `services/shared/middleware.py` | MAPS: [ARCH §7.1] [TASK-0001]
      Function: `inject_request_id(app: Flask) → None`
      Function: `audit_logger(app: Flask) → None`
      Function: `performance_tracer(app: Flask) → None`
      → Middleware chain applied to all Flask apps
      → Acceptance: Every request has `X-Request-ID` header; audit log entry written

- [ ] FUNC-0013 | FILE: `services/shared/exceptions.py` | MAPS: [TASK-0001]
      Classes: `SemfabError`, `DataNotFoundError`, `ValidationError`, `UnauthorizedError`, `CASError`
      → Base exception hierarchy with HTTP status code mapping
      → Acceptance: `handle_exception(e)` converts each to correct HTTP response

---

## 0.2 Database Migrations

- [ ] FUNC-0020 | FILE: `infra/db/migrations/V001__create_wat_result.sql` | MAPS: [ARCH §4.1] [TASK-0025]
      DDL: `WAT_RESULT` table — Greenplum columnar AO, distributed by `lot_id`, range-partitioned by `test_date`
      → Acceptance: Table created; `EXPLAIN SELECT * FROM wat_result WHERE lot_id='TEST'` shows partition pruning

- [ ] FUNC-0021 | FILE: `infra/db/migrations/V002__create_cp_result.sql` | MAPS: [ARCH §4.1] [TASK-0025]
      DDL: `CP_RESULT` table — columnar AO, distributed by `lot_id`
      → Acceptance: Bulk insert of 100K rows completes in < 5 seconds

- [ ] FUNC-0022 | FILE: `infra/db/migrations/V003__create_defect_map.sql` | MAPS: [ARCH §4.1] [TASK-0025]
      DDL: `DEFECT_MAP` table with spatial indexes on `(defect_x, defect_y)`
      → Acceptance: Spatial range query `WHERE defect_x BETWEEN 0 AND 50` uses index

- [ ] FUNC-0023 | FILE: `infra/db/migrations/V004__create_inline_metro.sql` | MAPS: [ARCH §4.1] [TASK-0025]
      DDL: `INLINE_METRO` columnar table partitioned by `measure_date`
      → Acceptance: Partition list shows 12 monthly partitions for current year

- [ ] FUNC-0024 | FILE: `infra/db/migrations/V005__create_equipment_master.sql` | MAPS: [ARCH §4.1] [TASK-0025]
      DDL: `EQUIPMENT_MASTER` + `SPC_LIMITS` + `SPC_VIOLATIONS` + `RCA_KNOWLEDGE` + `YIELD_SUMMARY`
      → Acceptance: All FK constraints validate; indexes confirmed via `\d` inspection

- [ ] FUNC-0025 | FILE: `infra/db/migrations/V006__create_oracle_realtime.sql` | MAPS: [ARCH §4.2] [TASK-0026]
      DDL: Oracle `LIVE_ALARM`, `WIP_TRACKING`, `RUN_TO_RUN_CTRL`, `EQUIPMENT_STATUS`
      → Acceptance: Oracle trigger on `LIVE_ALARM` insert auto-updates `EQUIPMENT_STATUS`

- [ ] FUNC-0026 | FILE: `infra/db/seed/seed_dev.py` | MAPS: [TASK-0029] [TASK-AppB]
      Function: `seed_development_data() → None`
      → Creates 100 synthetic lots × 25 wafers × 50 WAT parameters
      → Acceptance: `python seed_dev.py` runs in < 60 seconds; YMS dashboard shows data

---

# 🔐 MODULE 1 — AUTH SERVICE (`services/auth-service/`)

## 1.1 Flask Application Factory

- [ ] FUNC-1001 | FILE: `app/__init__.py` | MAPS: [ARCH §7.1] [TASK-1001]
      Function: `create_app(config_name: str = 'production') → Flask`
      → Registers all extensions, blueprints, middleware, error handlers
      → Acceptance: `flask run` starts; `GET /health` returns `{status: "ok"}`

- [ ] FUNC-1002 | FILE: `app/extensions.py` | MAPS: [TASK-1001]
      Setup: `db = SQLAlchemy()`, `jwt = JWTManager()`, `limiter = Limiter()`, `cors = CORS()`
      → All extensions initialized without app (application factory pattern)
      → Acceptance: Extensions init with `init_app(app)` without error

## 1.2 User & Role Models

- [ ] FUNC-1010 | FILE: `app/models/user.py` | MAPS: [ARCH §13.1] [TASK-1002]
      Class: `User(db.Model)` — fields: id, username, email, password_hash, is_active, fab_id, created_at, last_login
      Function: `User.set_password(password: str) → None` — Argon2id hashing
      Function: `User.check_password(password: str) → bool`
      → Acceptance: Password stored as Argon2id hash; never stored plaintext

- [ ] FUNC-1011 | FILE: `app/models/role.py` | MAPS: [ARCH §13.1] [TASK-1002]
      Class: `Role(db.Model)` — enum values matching RBAC definition
      Class: `Permission(db.Model)` — granular action permissions
      Class: `UserRole(db.Model)` — M2M association table
      → Acceptance: `user.has_permission('yield:read')` returns correct bool

- [ ] FUNC-1012 | FILE: `app/models/token_blacklist.py` | MAPS: [TASK-1003]
      Function: `blacklist_token(jti: str, exp: int) → None` — stores in Redis with TTL
      Function: `is_token_blacklisted(jti: str) → bool`
      → Acceptance: Blacklisted token `jti` returns True within TTL; expired auto-removed

## 1.3 JWT Token Functions

- [ ] FUNC-1020 | FILE: `app/services/token_service.py` | MAPS: [ARCH §13.1] [TASK-1003]
      Function: `generate_access_token(user: User) → str`
      → RS256 signed; payload: `{sub, roles, permissions, fab_id, exp: now+15min, jti}`
      → Acceptance: Token validates with public key; payload fields present; exp in 15 min

- [ ] FUNC-1021 | FILE: `app/services/token_service.py` | MAPS: [TASK-1003]
      Function: `generate_refresh_token(user_id: int) → str`
      → Opaque token stored in Redis with 7-day TTL; rotates on use
      → Acceptance: Refresh returns new access token; old refresh token invalidated

- [ ] FUNC-1022 | FILE: `app/services/token_service.py` | MAPS: [TASK-1003]
      Function: `validate_token(token: str) → TokenPayload`
      → Verifies RS256 signature, checks blacklist, checks expiry
      → Acceptance: Tampered token raises `InvalidTokenError`; blacklisted raises same

- [ ] FUNC-1023 | FILE: `app/decorators/auth.py` | MAPS: [TASK-1003]
      Decorator: `@require_auth` — validates JWT on request
      Decorator: `@require_role(*roles)` — checks role membership
      Decorator: `@require_permission(permission)` — checks specific permission
      → Acceptance: Unauthenticated request returns 401; wrong role returns 403

## 1.4 Auth API Routes

- [ ] FUNC-1030 | FILE: `app/routes/auth.py` | MAPS: [TASK-1003]
      Route: `POST /api/v1/auth/login`
      → Body: `{username, password}` → Returns: `{access_token, refresh_token, user}`
      → Acceptance: Valid creds return 200 + tokens; invalid creds return 401 after Argon2 check

- [ ] FUNC-1031 | FILE: `app/routes/auth.py` | MAPS: [TASK-1003]
      Route: `POST /api/v1/auth/refresh`
      → Body: `{refresh_token}` → Returns: `{access_token}`
      → Acceptance: Valid refresh returns new access token; expired returns 401

- [ ] FUNC-1032 | FILE: `app/routes/auth.py` | MAPS: [TASK-1003]
      Route: `POST /api/v1/auth/logout`
      → Blacklists current access token JTI in Redis
      → Acceptance: Token unusable after logout; `/auth/me` returns 401

- [ ] FUNC-1033 | FILE: `app/routes/auth.py` | MAPS: [TASK-1003]
      Route: `GET /api/v1/auth/me`
      → Returns current user profile + role list + permission list
      → Acceptance: Returns user object matching DB record; sensitive fields excluded

- [ ] FUNC-1034 | FILE: `app/routes/auth.py` | MAPS: [TASK-1004]
      Route: `POST /api/v1/auth/login/ldap`
      → LDAP bind + group-to-role mapping; creates/syncs local user record
      → Acceptance: Valid AD credentials authenticate; user gets AD-mapped roles

- [ ] FUNC-1035 | FILE: `app/routes/auth.py` | MAPS: [TASK-1005]
      Route: `POST /api/v1/auth/mfa/setup`
      Route: `POST /api/v1/auth/mfa/verify`
      → TOTP setup returns QR code URI; verify checks 6-digit code via pyotp
      → Acceptance: TOTP code from Google Authenticator passes verify; wrong code fails

## 1.5 Account Management

- [ ] FUNC-1040 | FILE: `app/services/account_service.py` | MAPS: [TASK-1002]
      Function: `lock_account(user_id: int, reason: str) → None`
      → After 5 failed attempts; stores lockout expiry in Redis (15 min)
      → Acceptance: 6th attempt within window returns 423 (Locked) with retry_after

- [ ] FUNC-1041 | FILE: `app/services/account_service.py` | MAPS: [TASK-1002]
      Function: `check_lockout(username: str) → LockoutStatus`
      → Returns `{is_locked, attempts, retry_after_seconds}`
      → Acceptance: Counter increments on failure; resets on success; expires after 15 min

---

# 📊 MODULE 2 — YIELD SERVICE (`services/yield-service/`)

## 2.1 Application Factory & Models

- [ ] FUNC-2001 | FILE: `app/__init__.py` | MAPS: [ARCH §7.2] [TASK-2001]
      Function: `create_app() → Flask` — yield-service factory
      → Blueprints: yield, excursion, compare; Celery config; Redis cache
      → Acceptance: Service starts; health endpoint returns OK

- [ ] FUNC-2002 | FILE: `app/models/yield_models.py` | MAPS: [ARCH §4.1] [TASK-2001]
      Class: `YieldSummary(db.Model)` → maps to `YIELD_SUMMARY` GP table
      Class: `CPResult(db.Model)` → maps to `CP_RESULT` GP table
      Class: `LiveAlarm(db.Model)` → maps to Oracle `LIVE_ALARM`
      → Acceptance: `YieldSummary.query.filter_by(lot_id='TEST')` returns records

## 2.2 Repository Layer

- [ ] FUNC-2010 | FILE: `app/repositories/yield_repo.py` | MAPS: [TASK-2001]
      Function: `get_yield_summary(lot_id: str, wafer_id: str = None) → YieldSummaryDTO`
      → Queries GP `YIELD_SUMMARY` with optional wafer filter; Redis cache 5min TTL
      → Acceptance: Cache miss hits GP; cache hit skips GP; both return same data

- [ ] FUNC-2011 | FILE: `app/repositories/yield_repo.py` | MAPS: [TASK-2002]
      Function: `get_yield_trend(product: str, node: str, days: int, granularity: str) → list[TrendPoint]`
      → GP query with date_trunc grouping; returns `[{date, mean, p25, p75, p10, p90}]`
      → Acceptance: 30-day query returns 30 points; mean matches manual calculation

- [ ] FUNC-2012 | FILE: `app/repositories/yield_repo.py` | MAPS: [TASK-2002]
      Function: `get_wafer_gallery(lot_id: str) → list[WaferMapDTO]`
      → Returns all wafers for lot with compressed die map JSON (columnar format)
      → Acceptance: 25-wafer lot returns 25 maps; each map decompresses to correct die grid

- [ ] FUNC-2013 | FILE: `app/repositories/yield_repo.py` | MAPS: [TASK-2002]
      Function: `get_bin_pareto(lot_id: str = None, product: str = None, date_range: tuple = None) → list[BinParetoItem]`
      → Aggregates bin codes by count; computes cumulative %; sorted descending
      → Acceptance: Cumulative % of last item = 100.0; bins sorted by count desc

- [ ] FUNC-2014 | FILE: `app/repositories/excursion_repo.py` | MAPS: [TASK-2002]
      Function: `get_active_excursions(severity: str = None, status: str = 'open') → list[ExcursionDTO]`
      → Queries Oracle `LIVE_ALARM` with severity/status filter; ordered by alarm_time desc
      → Acceptance: Only 'open' status returned when status='open'; severity filter works

- [ ] FUNC-2015 | FILE: `app/repositories/lot_repo.py` | MAPS: [TASK-2002]
      Function: `compare_lots(baseline_lot: str, target_lot: str) → LotComparisonDTO`
      → Joins WAT results for both lots; computes z-score of target vs baseline per parameter
      → Acceptance: Identical lots return z-scores ≈ 0; different lots show real delta

## 2.3 Service Layer

- [ ] FUNC-2020 | FILE: `app/services/yield_service.py` | MAPS: [TASK-2001]
      Function: `compute_yield_summary(lot_id: str) → YieldSummaryResult`
      → Calls CP result aggregation; computes gross yield, net yield, bin breakdown
      → Acceptance: Known test lot: 23/25 pass → gross_yield = 92.0%

- [ ] FUNC-2021 | FILE: `app/services/excursion_service.py` | MAPS: [TASK-2003]
      Function: `detect_yield_excursions(product: str, node: str) → list[ExcursionEvent]`
      → Fetches rolling 30-day yield series; calls SAS Viya `PROC SHEWHART` via SWAT
      → Returns lots where yield < mean − 2σ (warning) or < mean − 3σ (critical)
      → Acceptance: Injected lot at mean−3.5σ appears in critical excursion list

- [ ] FUNC-2022 | FILE: `app/services/excursion_service.py` | MAPS: [TASK-2003]
      Function: `detect_bin_shift(lot_id: str, baseline_lots: list[str]) → BinShiftResult`
      → Chi-square test on bin distribution: current lot vs baseline population
      → Returns `{is_shifted, p_value, shifted_bins, chi_square_stat}`
      → Acceptance: Artificially shifted bin distribution returns p < 0.05

- [ ] FUNC-2023 | FILE: `app/services/rca_service.py` | MAPS: [TASK-2002]
      Function: `drill_rca(lot_id: str, symptom: str) → str` (returns task_id)
      → Creates Celery async task; returns task_id for polling
      → Acceptance: Returns UUID task_id; task appears in Flower task monitor

## 2.4 SAS Viya Integration

- [ ] FUNC-2030 | FILE: `app/services/sas_yield_analytics.py` | MAPS: [ARCH §8] [TASK-2004]
      Function: `run_shewhart_chart(data: pd.DataFrame, param: str, tool: str) → ShewhartResult`
      → Uploads DataFrame to CAS; invokes `PROC SHEWHART`; fetches control limits
      → Returns `{ucl, lcl, cl, violations: list[ViolationPoint]}`
      → Acceptance: UCL = mean + 3σ; violations match expected rule breaches

- [ ] FUNC-2031 | FILE: `app/services/sas_yield_analytics.py` | MAPS: [TASK-2004]
      Function: `run_factor_screening(features: pd.DataFrame, target: pd.Series) → list[FactorScore]`
      → Invokes `PROC GLMSELECT` on CAS; extracts standardized coefficients
      → Returns factors ranked by |coefficient|
      → Acceptance: Known correlated feature appears in top-3 factors

## 2.5 Yield API Routes

- [ ] FUNC-2040 | FILE: `app/routes/yield_routes.py` | MAPS: [TASK-2002]
      Route: `GET /api/v1/yield/summary`
      → Params: `lot_id`, `wafer_id`, `step`, `product`, `node` (all optional)
      → Returns: `YieldSummaryDTO` via success envelope
      → Acceptance: `?lot_id=M900001` returns correct summary; cache header present

- [ ] FUNC-2041 | FILE: `app/routes/yield_routes.py` | MAPS: [TASK-2002]
      Route: `GET /api/v1/yield/trend`
      Route: `GET /api/v1/yield/wafer-gallery`
      Route: `GET /api/v1/yield/bin-pareto`
      Route: `GET /api/v1/yield/excursions`
      → All return paginated results with standard envelope
      → Acceptance: Each endpoint returns 200 with correct schema on test data

- [ ] FUNC-2042 | FILE: `app/routes/yield_routes.py` | MAPS: [TASK-2002]
      Route: `POST /api/v1/yield/drill-rca`
      → Body: `{lot_id, symptom}` → Returns: `{task_id}`
      → Acceptance: Task created; `GET /tasks/{task_id}` shows PENDING state

- [ ] FUNC-2043 | FILE: `app/routes/yield_routes.py` | MAPS: [TASK-2002]
      Route: `GET /api/v1/yield/compare`
      → Params: `baseline_lot`, `target_lot`
      → Returns: parameter-by-parameter z-score comparison
      → Acceptance: Same lot compared to itself → all z-scores = 0.0

## 2.6 Celery Tasks

- [ ] FUNC-2050 | FILE: `app/tasks/yield_tasks.py` | MAPS: [TASK-2001]
      Task: `compute_yield_summary_task(lot_id: str) → None`
      → Scheduled hourly; recomputes yield summaries for lots processed in last 2h
      → Acceptance: After test lot processed, summary in GP within 1h

- [ ] FUNC-2051 | FILE: `app/tasks/yield_tasks.py` | MAPS: [TASK-2003]
      Task: `detect_excursions_task() → None`
      → Scheduled every 5 minutes; calls `detect_yield_excursions` for all active products
      → On detection: writes to Oracle `LIVE_ALARM` + publishes to Kafka `alarm-events`
      → Acceptance: Injected low-yield lot triggers alarm within 5 minutes

- [ ] FUNC-2052 | FILE: `app/tasks/yield_tasks.py` | MAPS: [TASK-8001]
      Task: `generate_yield_report_task(report_type: str, params: dict) → str` (returns S3 key)
      → Renders Jinja2 HTML → WeasyPrint PDF; uploads to MinIO
      → Acceptance: Generated PDF opens correctly; contains correct lot data

---

# 🔬 MODULE 3 — WAT ANALYTICS SERVICE (`services/wat-analytics-service/`)

## 3.1 Data Ingestion & Parsing

- [ ] FUNC-3001 | FILE: `app/parsers/stdf_parser.py` | MAPS: [ARCH §8.3] [TASK-3001]
      Function: `parse_stdf(filepath: str) → WATDataFrame`
      → Wraps `py-stdf` library; extracts PTR records → `pd.DataFrame`
      → Columns: lot_id, wafer_id, site_id, test_num, test_name, value, lo_limit, hi_limit
      → Acceptance: STDF test file → DataFrame with correct lot_id from MIR record

- [ ] FUNC-3002 | FILE: `app/parsers/ad5_parser.py` | MAPS: [TASK-3001]
      Function: `parse_ad5(filepath: str) → WATDataFrame`
      → Parses Semitronix AD5 binary format; extracts measurement data
      → Acceptance: AD5 test file → same DataFrame schema as STDF parser

- [ ] FUNC-3003 | FILE: `app/parsers/csv_parser.py` | MAPS: [TASK-3001]
      Function: `parse_wat_csv(filepath: str, mapping: ColumnMapping) → WATDataFrame`
      → Generic CSV with configurable column mapping; auto-detects separator
      → Acceptance: CSV with non-standard headers maps correctly via `mapping` config

- [ ] FUNC-3004 | FILE: `app/services/etl_service.py` | MAPS: [TASK-3002]
      Function: `validate_wat_data(df: WATDataFrame) → ValidationReport`
      → Checks: no null lot_id, value within [−10×spec, 10×spec], timestamp valid
      → Returns `{pass_count, fail_count, warnings, errors}`
      → Acceptance: Row with null lot_id appears in errors; row with value=NaN in warnings

- [ ] FUNC-3005 | FILE: `app/services/etl_service.py` | MAPS: [TASK-3002]
      Function: `deduplicate_wat_data(df: WATDataFrame) → WATDataFrame`
      → Natural key: `(lot_id, wafer_id, site_id, parameter_id, test_time)` — drop duplicates
      → Acceptance: DataFrame with 10 duplicate rows returns DataFrame with 1 row

- [ ] FUNC-3006 | FILE: `app/services/etl_service.py` | MAPS: [TASK-3002]
      Function: `load_to_greenplum(df: WATDataFrame, table: str) → LoadResult`
      → Uses `COPY` command via psycopg2 for bulk load (not INSERT per row)
      → Returns `{rows_loaded, rows_rejected, duration_ms}`
      → Acceptance: 100K rows load in < 10 seconds; rejected rows written to error log

- [ ] FUNC-3007 | FILE: `app/services/quality_scorer.py` | MAPS: [TASK-3002]
      Function: `score_data_quality(df: WATDataFrame) → QualityScore`
      → Completeness: % non-null values; Spec coverage: % params with limits defined
      → Returns `{overall: float, completeness: float, spec_coverage: float, issues: list}`
      → Acceptance: Perfect DataFrame scores 1.0; missing 10% values scores ≈ 0.90

## 3.2 Statistical Analysis Functions

- [ ] FUNC-3020 | FILE: `app/services/sas_wat_analytics.py` | MAPS: [ARCH §8.3] [TASK-3003]
      Function: `fit_distribution(lot_id: str, parameter: str, wafer_filter: list = None) → DistFitResult`
      → SAS PROC UNIVARIATE on CAS: returns mean, sigma, Cpk, p-value (normality test)
      → Returns histogram bins for rendering + fit parameters
      → Acceptance: Known normal data returns normality p > 0.05; Cpk matches manual calc

- [ ] FUNC-3021 | FILE: `app/services/sas_wat_analytics.py` | MAPS: [TASK-3003]
      Function: `compute_correlation_matrix(lot_id: str, parameters: list[str]) → CorrelationMatrix`
      → SAS PROC CORR on CAS: Pearson + p-value matrix for selected parameters
      → Returns `{params, r_matrix: list[list[float]], p_matrix: list[list[float]]}`
      → Acceptance: Self-correlation = 1.0; symmetric matrix; p < 0.05 for known correlated pair

- [ ] FUNC-3022 | FILE: `app/services/sas_wat_analytics.py` | MAPS: [TASK-3003]
      Function: `run_equipment_anova(parameter: str, date_range: tuple, product: str) → ANOVAResult`
      → SAS PROC GLM on CAS with EQPID as factor; extracts SS, MS, eta-squared per equipment
      → Returns `{factors: [{equipment_id, eta_squared, mean, n}], total_variance: float}`
      → Acceptance: Equipment with 0 variation returns eta_squared ≈ 0; dominant tool returns highest

- [ ] FUNC-3023 | FILE: `app/services/sas_wat_analytics.py` | MAPS: [TASK-3003]
      Function: `run_ols_whatif(parameter: str, independent_vars: list[str], what_if: dict) → WhatIfResult`
      → SAS PROC REG: fits OLS model; applies what-if coefficients to predict outcome
      → Returns `{coefficients, r_squared, prediction, ci_lower, ci_upper}`
      → Acceptance: What-if with input=mean returns prediction ≈ observed mean

- [ ] FUNC-3024 | FILE: `app/services/sas_wat_analytics.py` | MAPS: [TASK-3003]
      Function: `run_pca(lot_id: str, parameters: list[str], n_components: int = 5) → PCAResult`
      → SAS PROC FACTOR method=PRINCIPAL on CAS; extracts loadings + scores
      → Returns `{loadings, scores, explained_variance_ratio, components}`
      → Acceptance: Sum of explained variance ratios = 1.0; first component explains most variance

- [ ] FUNC-3025 | FILE: `app/services/outlier_detection.py` | MAPS: [TASK-3003]
      Function: `detect_outliers_mad(series: pd.Series, threshold: float = 3.5) → OutlierResult`
      → Modified Z-score using MAD (Median Absolute Deviation) — robust to outliers
      → Returns `{outlier_indices, outlier_values, mad, median}`
      → Acceptance: Injected 10σ outlier detected; points within ±3.5 MAD not flagged

- [ ] FUNC-3026 | FILE: `app/services/outlier_detection.py` | MAPS: [TASK-3003]
      Function: `detect_outliers_grubbs(series: pd.Series, alpha: float = 0.05) → GrubbsResult`
      → Grubbs test for extreme outlier; iterates until no more outliers at alpha level
      → Returns `{outliers: list[int], g_statistic, critical_value}`
      → Acceptance: Known extreme outlier detected at α=0.05; borderline not detected at α=0.01

## 3.3 Equipment Health Scoring

- [ ] FUNC-3030 | FILE: `app/services/equipment_health.py` | MAPS: [ARCH §10.3] [TASK-3004]
      Function: `compute_z_score_component(equipment_id: str, parameter: str, window_days: int = 30) → float`
      → |equipment mean − fleet mean| / fleet sigma; clamped to [0, 1] normalized
      → Acceptance: Equipment with mean = fleet mean → score = 0.0; 3σ deviation → near 1.0

- [ ] FUNC-3031 | FILE: `app/services/equipment_health.py` | MAPS: [TASK-3004]
      Function: `compute_gof_component(equipment_id: str, parameter: str) → float`
      → KS-test p-value comparing equipment distribution to fleet distribution
      → p → [0,1]: returns (1 − p) normalized so lower GOF = higher score (worse health)
      → Acceptance: Same distribution → p≈1.0 → component≈0.0 (healthy); different → near 1.0

- [ ] FUNC-3032 | FILE: `app/services/equipment_health.py` | MAPS: [TASK-3004]
      Function: `compute_cv_stability_component(equipment_id: str, parameter: str, window_days: int = 30) → float`
      → CV (σ/μ) trend over window; linear regression slope → normalized instability score
      → Acceptance: Flat CV over time → near 0; increasing CV → higher score

- [ ] FUNC-3033 | FILE: `app/services/equipment_health.py` | MAPS: [TASK-3004]
      Function: `compute_composite_health_score(equipment_id: str, parameters: list[str]) → HealthScore`
      → `0.35×z_score + 0.30×gof + 0.20×cv_stability + 0.15×volume_consistency`
      → Returns `{overall: float[0-100], z_component, gof_component, cv_component, vol_component, tier: str}`
      → Acceptance: All components = 0 → overall = 0 (perfect); all = 1 → overall = 100 (critical)

- [ ] FUNC-3034 | FILE: `app/services/equipment_health.py` | MAPS: [TASK-3004]
      Function: `compute_fleet_health_scores(tool_type: str = None) → list[HealthScore]`
      → Batch compute for all equipment; stores results in `EQUIPMENT_MASTER.health_score`
      → Acceptance: All equipment have scores; fleet sorted by score descending

## 3.4 WAT API Routes

- [ ] FUNC-3040 | FILE: `app/routes/wat_routes.py` | MAPS: [TASK-3003]
      Route: `POST /api/v1/wat/upload`
      → Multipart file(s); returns `{task_id}` immediately; parses async
      → Acceptance: 50MB STDF file upload returns task_id in < 500ms

- [ ] FUNC-3041 | FILE: `app/routes/wat_routes.py` | MAPS: [TASK-3002]
      Route: `GET /api/v1/wat/upload/{task_id}/progress`
      → SSE endpoint: streams `{stage, percent, message}` events
      → Acceptance: Client receives events: parsing→validating→loading→complete

- [ ] FUNC-3042 | FILE: `app/routes/wat_routes.py` | MAPS: [TASK-3003]
      Route: `GET /api/v1/wat/distribution`
      Route: `GET /api/v1/wat/correlation-matrix`
      Route: `GET /api/v1/wat/anova-equipment`
      Route: `GET /api/v1/wat/ols-whatif`
      Route: `GET /api/v1/wat/pca`
      Route: `GET /api/v1/wat/outlier-detection`
      Route: `GET /api/v1/wat/trend`
      Route: `GET /api/v1/wat/site-map`
      Route: `GET /api/v1/wat/equipment-health`
      → All secured with `@require_auth`; `@limiter.limit("100/minute")`
      → Acceptance: Each returns correct schema on test dataset

---

# 🗺️ MODULE 4 — CP ANALYTICS SERVICE (`services/cp-analytics-service/`)

## 4.1 CP Data Processing

- [ ] FUNC-4001 | FILE: `app/parsers/cp_stdf_parser.py` | MAPS: [ARCH §9.3] [TASK-3020]
      Function: `parse_cp_stdf(filepath: str) → CPDataFrame`
      → Extracts PRR (Part Result Record) + PTR from STDF; maps to die X,Y grid
      → Columns: lot_id, wafer_id, die_x, die_y, bin_code, hbin_code, test_items
      → Acceptance: Known STDF file → correct die grid with expected bin distribution

- [ ] FUNC-4002 | FILE: `app/services/cp_compression.py` | MAPS: [ARCH §6.3] [TASK-3020]
      Function: `compress_die_map(die_data: list[DieResult]) → CompressedMap`
      → Columnar JSON: `{xs: [...], ys: [...], bins: [...]}` — ~1.2MB vs 63MB naive
      → Acceptance: 684,700 die map compresses to < 1.5MB; decompresses losslessly

- [ ] FUNC-4003 | FILE: `app/services/cp_compression.py` | MAPS: [TASK-3020]
      Function: `decompress_die_map(compressed: CompressedMap) → list[DieResult]`
      → Inverse of compress; reconstructs original die list
      → Acceptance: `decompress(compress(data)) == data` for all test cases

- [ ] FUNC-4004 | FILE: `app/services/spatial_analysis.py` | MAPS: [TASK-3021]
      Function: `detect_spatial_clusters(die_map: list[DieResult], fail_bins: list[int]) → ClusterResult`
      → DBSCAN clustering on fail die coordinates; returns cluster centroids + sizes
      → Acceptance: Ring pattern of fails detected as cluster; random pattern returns no clusters

- [ ] FUNC-4005 | FILE: `app/services/spatial_analysis.py` | MAPS: [TASK-3021]
      Function: `compute_edge_die_analysis(die_map: list[DieResult], radius_ratio: float = 0.9) → EdgeAnalysis`
      → Compares yield of edge die (r > 0.9×wafer_radius) vs center die
      → Returns `{edge_yield, center_yield, edge_delta, edge_die_count, center_die_count}`
      → Acceptance: Known edge-yield-loss wafer shows negative edge_delta

## 4.2 CP API Routes

- [ ] FUNC-4010 | FILE: `app/routes/cp_routes.py` | MAPS: [TASK-3020]
      Route: `GET /api/v1/cp/bin-map`
      → Params: `lot_id`, `wafer_id` → Returns compressed die map JSON
      → Acceptance: Response < 1.5MB for 684K die wafer; decompresses correctly on client

- [ ] FUNC-4011 | FILE: `app/routes/cp_routes.py` | MAPS: [TASK-3020]
      Route: `GET /api/v1/cp/yield-summary`
      Route: `GET /api/v1/cp/bin-pareto`
      Route: `GET /api/v1/cp/spatial-analysis`
      Route: `GET /api/v1/cp/test-items`
      Route: `POST /api/v1/cp/compare-lots`
      → All with auth + rate limiting
      → Acceptance: Test lot returns correct yield and bin breakdown

---

# ⚙️ MODULE 5 — SPC/FDC SERVICE (`services/spc-fdc-service/`)

## 5.1 SPC Rules Engine

- [ ] FUNC-5001 | FILE: `app/services/spc_rules.py` | MAPS: [ARCH §9.2] [TASK-4001]
      Function: `check_rule_1(points: list[float], ucl: float, lcl: float) → list[int]`
      → 1 point beyond 3σ; returns indices of violating points
      → Acceptance: Point at UCL+0.001 flagged; point at UCL−0.001 not flagged

- [ ] FUNC-5002 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_2(points: list[float], cl: float) → list[int]`
      → 9 consecutive points same side of centerline
      → Acceptance: 9 points above CL → returns index 8 (first completion); 8 points → empty

- [ ] FUNC-5003 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_3(points: list[float]) → list[int]`
      → 6 consecutive points trending (monotone increasing or decreasing)
      → Acceptance: 6 strictly increasing points flagged; 5 increasing + 1 flat not flagged

- [ ] FUNC-5004 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_4(points: list[float]) → list[int]`
      → 14 alternating points (zigzag pattern)
      → Acceptance: Perfect zigzag of 14 → flagged; 13 zigzag → empty

- [ ] FUNC-5005 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_5(points: list[float], cl: float, sigma: float) → list[int]`
      → 2 of 3 consecutive points beyond 2σ same side
      → Acceptance: Points at [2.1σ, 2.2σ, −0.5σ] above CL → first three flagged

- [ ] FUNC-5006 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_6(points: list[float], cl: float, sigma: float) → list[int]`
      → 4 of 5 consecutive points beyond 1σ same side
      → Acceptance: 4 points above +1σ, 1 within bounds → flagged

- [ ] FUNC-5007 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_7(points: list[float], cl: float, sigma: float) → list[int]`
      → 15 consecutive points within 1σ of centerline (stratification)
      → Acceptance: 15 points all within ±0.9σ → flagged; any outside ±1σ → not flagged

- [ ] FUNC-5008 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_rule_8(points: list[float], cl: float, sigma: float) → list[int]`
      → 8 consecutive points beyond 1σ on both sides (mixture)
      → Acceptance: 8 points alternating above/below ±1σ → flagged

- [ ] FUNC-5009 | FILE: `app/services/spc_rules.py` | MAPS: [TASK-4001]
      Function: `check_all_rules(points: list[float], control_limits: ControlLimits) → ViolationReport`
      → Runs all 8 rules; aggregates violations with rule labels
      → Returns `{violations: [{index, rule, description, severity}]}`
      → Acceptance: Known violation series triggers correct rule and only that rule

## 5.2 SPC Limits Management

- [ ] FUNC-5010 | FILE: `app/services/spc_limits_service.py` | MAPS: [TASK-4001]
      Function: `establish_phase1_limits(parameter: str, tool: str, lot_ids: list[str]) → ControlLimits`
      → Calls SAS PROC SHEWHART on CAS with Phase I data; stores to `SPC_LIMITS` table
      → Returns `{ucl, lcl, cl, sigma, n_subgroups}`
      → Acceptance: UCL = mean + 3σ within 0.01% tolerance; stored to DB

- [ ] FUNC-5011 | FILE: `app/services/spc_limits_service.py` | MAPS: [TASK-4001]
      Function: `get_control_limits(parameter: str, tool: str, recipe: str = None) → ControlLimits`
      → Retrieves from `SPC_LIMITS` GP table; Redis cache 1h TTL
      → Acceptance: Returns cached limits on second call; cache miss fetches from GP

- [ ] FUNC-5012 | FILE: `app/services/spc_limits_service.py` | MAPS: [TASK-4004]
      Function: `update_limits_from_custom_rule(rule_code: str, parameter: str, tool: str) → ControlLimits`
      → Executes user-supplied Python rule in RestrictedPython sandbox
      → Returns new limits if valid; raises `CustomRuleError` if unsafe code detected
      → Acceptance: Sandboxed `import os; os.system(...)` raises `ForbiddenCode` error

## 5.3 Capability Analysis

- [ ] FUNC-5020 | FILE: `app/services/capability_service.py` | MAPS: [TASK-4002]
      Function: `compute_capability_indices(data: pd.Series, usl: float, lsl: float, target: float = None) → CapabilityIndices`
      → SAS PROC CAPABILITY on CAS; returns Cp, Cpk, Pp, Ppk, Cpm
      → Acceptance: Known process: Cpk = (USL − mean) / (3σ) within 0.001 tolerance

- [ ] FUNC-5021 | FILE: `app/services/virtual_metrology.py` | MAPS: [TASK-4003]
      Function: `train_vm_model(equipment_id: str, parameter: str, features: list[str]) → VMModel`
      → SAS PROC NNET on CAS with FDC feature set; persists model to MLflow + MinIO
      → Returns `{model_id, r_squared, mae, feature_importance}`
      → Acceptance: Model R² > 0.80 on validation set (30% holdout)

- [ ] FUNC-5022 | FILE: `app/services/virtual_metrology.py` | MAPS: [TASK-4003]
      Function: `predict_vm(equipment_id: str, parameter: str, current_fdc: dict) → VMPrediction`
      → Loads model from MLflow; applies to current FDC features
      → Returns `{predicted_value, lower_ci, upper_ci, confidence, model_id}`
      → Acceptance: Prediction within ±10% of actual measurement on recent test data

## 5.4 FDC Trace Anomaly Detection (INF-TPC Equivalent)

- [ ] FUNC-5030 | FILE: `app/services/fdc_baseline.py` | MAPS: [ARCH §10.1] [TASK-4020]
      Function: `build_sensor_baseline(equipment_id: str, sensor_name: str, window_days: int = 7) → SensorBaseline`
      → Rolling 7-day statistics: mean, sigma, p5, p95 per recipe step segment
      → Stores to `FDC_BASELINES` table
      → Acceptance: Baseline updates when called; contains all recipe steps for tool

- [ ] FUNC-5031 | FILE: `app/services/fdc_anomaly_detector.py` | MAPS: [TASK-4020]
      Function: `detect_interval_anomaly(trace: np.ndarray, baseline: SensorBaseline) → AnomalyScore`
      → Point-by-point: fraction of points outside [p5, p95] baseline band
      → Returns `{score: float[0,1], anomalous_windows: list[tuple]}`
      → Acceptance: All-normal trace returns score ≈ 0; 30% out-of-band returns score ≈ 0.3

- [ ] FUNC-5032 | FILE: `app/services/fdc_anomaly_detector.py` | MAPS: [TASK-4020]
      Function: `detect_pm_anomaly(trace: np.ndarray, pre_pm_baseline: SensorBaseline) → AnomalyScore`
      → Compares post-PM trace characteristics to pre-PM baseline
      → Step-change detection via CUSUM algorithm
      → Acceptance: Known step-change of 2σ after PM returns score > 0.8

- [ ] FUNC-5033 | FILE: `app/services/fdc_anomaly_detector.py` | MAPS: [TASK-4020]
      Function: `detect_amplitude_anomaly(trace: np.ndarray, baseline: SensorBaseline) → AnomalyScore`
      → Peak detection (scipy.signal.find_peaks) vs baseline peak prominence distribution
      → Acceptance: Spike at 5σ from baseline returns score > 0.9

- [ ] FUNC-5034 | FILE: `app/services/fdc_anomaly_detector.py` | MAPS: [TASK-4020]
      Function: `detect_shape_anomaly(trace: np.ndarray, baseline_template: np.ndarray) → AnomalyScore`
      → DTW (Dynamic Time Warping) distance from baseline template pattern
      → Returns normalized `{score, dtw_distance, threshold}`
      → Acceptance: Mirror-image trace returns max score; identical trace returns 0

- [ ] FUNC-5035 | FILE: `app/services/fdc_anomaly_detector.py` | MAPS: [TASK-4020]
      Function: `compute_composite_anomaly_score(equipment_id: str, run_id: str, trace_data: dict) → CompositeAnomalyScore`
      → Weighted fusion: interval(0.25) + PM(0.25) + amplitude(0.25) + shape(0.25)
      → Returns `{composite: float, components: dict, threshold: float, alert_level: str}`
      → Acceptance: Score > 0.95 on known fault trace; < 0.1 on clean baseline trace

## 5.5 SPC/FDC API Routes

- [ ] FUNC-5040 | FILE: `app/routes/spc_routes.py` | MAPS: [TASK-4002]
      Route: `GET /api/v1/spc/charts` — with `parameter`, `tool`, `period`, `chart_type`
      Route: `GET /api/v1/spc/violations` — with filters
      Route: `GET /api/v1/spc/capability` — Cp/Cpk calculation
      Route: `POST /api/v1/spc/update-limits` — recalculate control limits
      Route: `GET /api/v1/spc/virtual-metrology` — VM prediction
      Route: `GET /api/v1/spc/parameter-dashboard` — fleet SPC status
      → All routes: auth required; 200 responses with correct schema on test data
      → Acceptance: Each endpoint tested with integration test against test DB

---

# 🔍 MODULE 6 — DEFECT SERVICE (`services/defect-service/`)

- [ ] FUNC-6001 | FILE: `app/parsers/klarf_parser.py` | MAPS: [ARCH §9.3] [TASK-5001]
      Function: `parse_klarf(filepath: str) → DefectDataFrame`
      → Supports KLARF versions 1.8 and 2.0; extracts defect X,Y, size, class, rough_bin
      → Acceptance: Known KLARF file → correct defect count and coordinate range

- [ ] FUNC-6002 | FILE: `app/parsers/amat_parser.py` | MAPS: [TASK-5001]
      Function: `parse_amat_compass_xml(filepath: str) → DefectDataFrame`
      → AMAT Compass XML format; maps to same schema as KLARF output
      → Acceptance: AMAT test file → same DataFrame schema as KLARF

- [ ] FUNC-6003 | FILE: `app/services/adc_service.py` | MAPS: [ARCH §10.1] [TASK-5002]
      Function: `classify_defect_image(image_path: str) → ADCResult`
      → Calls Triton inference server (EfficientNet-B4 model)
      → Returns `{class_label, confidence, class_probabilities, model_version}`
      → Acceptance: Particle image → class='Particle' with confidence > 0.85

- [ ] FUNC-6004 | FILE: `app/services/adc_service.py` | MAPS: [TASK-5002]
      Function: `batch_classify_defects(lot_id: str, wafer_id: str) → list[ADCResult]`
      → Fetches all defect images from MinIO; batch sends to Triton; returns results
      → Acceptance: 100 defect images classified in < 30 seconds

- [ ] FUNC-6005 | FILE: `app/services/wafer_pattern_analyzer.py` | MAPS: [TASK-5003]
      Function: `classify_wafer_pattern(defect_map: DefectDataFrame) → PatternClassification`
      → Renders 256×256 defect density image; sends to CNN classifier (Triton)
      → Returns `{pattern: str, confidence: float, process_step_hypothesis: str}`
      → Pattern options: Ring, Edge, Scratch, Cluster, Random, Center
      → Acceptance: Known ring pattern → class='Ring' with confidence > 0.88

- [ ] FUNC-6006 | FILE: `app/services/wafer_pattern_analyzer.py` | MAPS: [TASK-5003]
      Function: `correlate_pattern_to_process(pattern: str, equipment_history: list[str]) → ProcessCorrelation`
      → Queries `RCA_KNOWLEDGE` graph for known pattern-to-process mappings
      → Returns `{suspected_step, suspected_equipment, historical_rca_refs}`
      → Acceptance: 'Ring' pattern returns CMP-related hypothesis from knowledge base

- [ ] FUNC-6007 | FILE: `app/routes/defect_routes.py` | MAPS: [TASK-5001]
      Route: `GET /api/v1/defect/map`
      Route: `GET /api/v1/defect/summary`
      Route: `GET /api/v1/defect/trend`
      Route: `GET /api/v1/defect/pattern-analysis`
      Route: `POST /api/v1/defect/classify`
      → All with auth; defect map returns compressed coordinate JSON
      → Acceptance: Each endpoint returns 200 with correct schema on test data

---

# 🤖 MODULE 7 — AI/ML INFERENCE SERVICE (`services/ai-inference-service/`)

## 7.1 Yield Prediction Model

- [ ] FUNC-7001 | FILE: `app/ml/feature_engineering.py` | MAPS: [ARCH §10.1] [TASK-6001]
      Function: `build_yield_features(lot_id: str) → FeatureVector`
      → Assembles: WAT params (normalized), equipment context, process conditions, temporal features
      → Returns `pd.Series` of ~250 named features
      → Acceptance: Feature vector for known lot matches expected values within 0.01

- [ ] FUNC-7002 | FILE: `app/ml/feature_engineering.py` | MAPS: [TASK-6001]
      Function: `compute_rolling_features(lot_id: str, window: int = 5) → dict`
      → Rolling mean/std of WAT parameters over last N lots on same equipment
      → Acceptance: Rolling mean of 5 identical lots returns that lot's value exactly

- [ ] FUNC-7003 | FILE: `app/ml/yield_predictor.py` | MAPS: [TASK-6001]
      Function: `train_xgboost_model(train_df: pd.DataFrame, target: str, params: dict = None) → XGBModel`
      → XGBoost with Optuna hyperparameter tuning (100 trials); logs to MLflow
      → Returns trained model + `{rmse, mae, r_squared}` on validation set
      → Acceptance: RMSE < 2.0% absolute yield on validation set (200+ lots)

- [ ] FUNC-7004 | FILE: `app/ml/yield_predictor.py` | MAPS: [TASK-6001]
      Function: `predict_yield(features: FeatureVector) → YieldPrediction`
      → Calls Triton FIL (Forest Inference Library) backend
      → Returns `{predicted_yield, shap_values, top_3_factors, model_id}`
      → Acceptance: Prediction within ±3% of actual on holdout lots; SHAP sums to prediction

- [ ] FUNC-7005 | FILE: `app/ml/yield_predictor.py` | MAPS: [TASK-6002]
      Function: `train_lstm_model(sequence_df: pd.DataFrame, sequence_len: int = 20) → LSTMModel`
      → PyTorch LSTM with attention; Monte Carlo Dropout for uncertainty
      → Returns model + `{rmse, uncertainty_calibration_score}`
      → Acceptance: RMSE < 2.5%; MC Dropout produces calibrated uncertainty intervals

- [ ] FUNC-7006 | FILE: `app/ml/yield_predictor.py` | MAPS: [TASK-6002]
      Function: `ensemble_predict(lot_id: str) → EnsemblePrediction`
      → `0.7 × xgboost_prediction + 0.3 × lstm_prediction`
      → Returns `{prediction, uncertainty, xgb_weight, lstm_weight}`
      → Acceptance: Ensemble RMSE ≤ min(xgb_rmse, lstm_rmse) on held-out test set

## 7.2 Causal AI

- [ ] FUNC-7010 | FILE: `app/ml/causal_rca.py` | MAPS: [ARCH §10.1] [TASK-6003]
      Function: `build_causal_dag(process_steps: list[str], parameters: list[str]) → CausalDAG`
      → DoWhy: builds DAG with process steps → equipment → parameters → yield causal paths
      → Returns networkx DiGraph with causal relationships
      → Acceptance: DAG is acyclic (DAG property); all nodes reachable from process step nodes

- [ ] FUNC-7011 | FILE: `app/ml/causal_rca.py` | MAPS: [TASK-6003]
      Function: `estimate_causal_effect(dag: CausalDAG, treatment: str, outcome: str = 'yield') → CausalEffect`
      → DoWhy `estimate_effect` with `backdoor.linear_regression` estimator
      → Returns `{ate: float, confidence_interval, p_value, refutation_passed: bool}`
      → Acceptance: Known causal factor returns significant ATE; non-causal control returns near 0

- [ ] FUNC-7012 | FILE: `app/ml/causal_rca.py` | MAPS: [TASK-6003]
      Function: `generate_counterfactual(lot_id: str, intervention: dict) → CounterfactualResult`
      → "What if parameter X had been at its target value?"
      → Returns `{actual_yield, counterfactual_yield, yield_gain, confidence}`
      → Acceptance: Zero intervention (no change) → counterfactual = actual yield

## 7.3 Inference API Routes

- [ ] FUNC-7020 | FILE: `app/routes/inference_routes.py` | MAPS: [TASK-6004]
      Route: `POST /api/v1/ai/predict/yield`
      → Body: `{lot_id}` → Returns: `EnsemblePrediction` with SHAP values
      → Acceptance: Response in < 500ms; prediction within 3% of actual

- [ ] FUNC-7021 | FILE: `app/routes/inference_routes.py` | MAPS: [TASK-6004]
      Route: `POST /api/v1/ai/anomaly-score`
      → Body: `{equipment_id, fdc_features}` → Returns: `CompositeAnomalyScore`
      → Acceptance: Clean equipment returns score < 0.1; fault equipment returns > 0.9

- [ ] FUNC-7022 | FILE: `app/routes/inference_routes.py` | MAPS: [TASK-6003]
      Route: `GET /api/v1/ai/causal-rca`
      → Params: `lot_id`, `treatment_variable` → Returns causal effect estimate
      → Acceptance: Returns `{ate, ci, p_value}` with refutation result

---

# 🧠 MODULE 8 — AGENT SERVICE (`services/agent-service/`)

## 8.1 LLM & RAG Setup

- [ ] FUNC-8001 | FILE: `app/llm/llm_client.py` | MAPS: [ARCH §11] [TASK-6010]
      Function: `get_llm_client() → vLLMClient`
      → vLLM client connecting to on-premise Qwen2.5-72B endpoint
      → Returns client with streaming support
      → Acceptance: `client.generate("hello")` returns non-empty response

- [ ] FUNC-8002 | FILE: `app/llm/embeddings.py` | MAPS: [TASK-6010]
      Function: `embed_text(text: str) → np.ndarray`
      → 1536-dim embedding via local embedding model or API
      → Acceptance: Same text → same embedding (deterministic); different texts → cosine similarity < 0.99

- [ ] FUNC-8003 | FILE: `app/llm/rag_retriever.py` | MAPS: [TASK-6010]
      Function: `retrieve_rca_context(query: str, top_k: int = 5) → list[RCARecord]`
      → Embeds query; ChromaDB vector similarity search over `RCA_KNOWLEDGE` embeddings
      → Returns top-k most similar historical RCA records with similarity scores
      → Acceptance: Query about CMP defects returns CMP-related RCA records in top-3

- [ ] FUNC-8004 | FILE: `app/llm/rag_retriever.py` | MAPS: [TASK-6010]
      Function: `retrieve_from_knowledge_graph(symptom: str) → list[KGNode]`
      → Neo4j query: MATCH (r:RootCause) WHERE similarity(r.embedding, $embed) > 0.7 RETURN r
      → Returns root cause nodes with relationship paths
      → Acceptance: Known symptom returns corresponding root cause node

## 8.2 LangGraph Agent Orchestrator

- [ ] FUNC-8010 | FILE: `app/agent/state.py` | MAPS: [ARCH §11.2] [TASK-6011]
      Class: `AgentState(TypedDict)` — fields: session_id, question, context, observations, hypotheses, verified_causes, action_plan, confidence, iteration_count
      → All fields typed; serializable to JSON
      → Acceptance: State serializes to JSON and back without data loss

- [ ] FUNC-8011 | FILE: `app/agent/nodes/observe.py` | MAPS: [TASK-6011]
      Function: `observe_node(state: AgentState) → AgentState`
      → Calls tool registry to gather evidence: yield data, SPC violations, defect maps, FDC traces
      → Populates `state['observations']` with gathered evidence
      → Acceptance: After observe, state.observations contains data from all relevant tools

- [ ] FUNC-8012 | FILE: `app/agent/nodes/analyze.py` | MAPS: [TASK-6011]
      Function: `analyze_node(state: AgentState) → AgentState`
      → Runs ML inference on observations; ranks features by importance; calls causal analysis
      → Populates `state['observations']['ml_analysis']` with ranked factors
      → Acceptance: Analysis identifies the top factor matching known root cause in test scenario

- [ ] FUNC-8013 | FILE: `app/agent/nodes/hypothesize.py` | MAPS: [TASK-6011]
      Function: `hypothesize_node(state: AgentState) → AgentState`
      → LLM chain-of-thought: generates top-3 RCA hypotheses from observations + knowledge base
      → Populates `state['hypotheses']` list with {hypothesis, mechanism, confidence, evidence}
      → Acceptance: Generated hypothesis matches known root cause in > 80% of test cases

- [ ] FUNC-8014 | FILE: `app/agent/nodes/verify.py` | MAPS: [TASK-6011]
      Function: `verify_node(state: AgentState) → AgentState`
      → Checks each hypothesis against additional data; updates confidence scores
      → Routes to recommend_node if max_confidence ≥ 0.80; loops back to analyze if < 0.80
      → Acceptance: Verification increases confidence when hypothesis is correct; max 3 loops

- [ ] FUNC-8015 | FILE: `app/agent/nodes/recommend.py` | MAPS: [TASK-6011]
      Function: `recommend_node(state: AgentState) → AgentState`
      → Generates structured action plan: priority-ordered corrective actions with owner + ETA
      → Applies confidence gating: ≥0.95 → auto_execute; 0.80-0.94 → needs_approval; <0.80 → escalate
      → Acceptance: High-confidence recommendation has action_plan with at least 1 auto-executable action

- [ ] FUNC-8016 | FILE: `app/agent/nodes/execute.py` | MAPS: [TASK-6011]
      Function: `execute_node(state: AgentState) → AgentState`
      → Calls robot_ctrl_service for approved auto-execute actions; logs all to `AGENT_ACTIONS`
      → Acceptance: Approved lot-hold action results in MES API call + audit log entry

- [ ] FUNC-8017 | FILE: `app/agent/nodes/learn.py` | MAPS: [TASK-6011]
      Function: `learn_node(state: AgentState) → AgentState`
      → Writes confirmed RCA to Neo4j knowledge graph; updates confidence on similar RCA nodes
      → Acceptance: New RCA node appears in Neo4j; similar existing nodes have updated confidence

## 8.3 Tool Registry (MCP Protocol)

- [ ] FUNC-8020 | FILE: `app/agent/tools/yield_tools.py` | MAPS: [TASK-6011]
      Function: `query_yield_data(lot_id: str, date_range: tuple = None) → ToolResult`
      Function: `get_bin_pareto(lot_id: str) → ToolResult`
      → Calls yield-service internal API; returns structured result for agent consumption
      → Acceptance: Tool returns correct data; tool call logged in agent trace

- [ ] FUNC-8021 | FILE: `app/agent/tools/spc_tools.py` | MAPS: [TASK-6011]
      Function: `query_spc_violations(equipment_id: str, date_range: tuple) → ToolResult`
      Function: `get_equipment_health(equipment_id: str) → ToolResult`
      → Calls spc-fdc-service; returns violations + health score
      → Acceptance: Tool returns violations for known-bad equipment

- [ ] FUNC-8022 | FILE: `app/agent/tools/ml_tools.py` | MAPS: [TASK-6011]
      Function: `run_ml_inference(lot_id: str) → ToolResult`
      Function: `get_shap_explanation(lot_id: str) → ToolResult`
      → Calls ai-inference-service; returns prediction + SHAP attribution
      → Acceptance: Tool returns SHAP values summing to prediction value

- [ ] FUNC-8023 | FILE: `app/agent/tools/knowledge_tools.py` | MAPS: [TASK-6011]
      Function: `search_knowledge_base(symptom: str, top_k: int = 5) → ToolResult`
      Function: `update_knowledge(rca_record: dict) → ToolResult`
      → Calls RAG + Neo4j; search returns similar RCAs; update writes new node
      → Acceptance: Search on known symptom returns matching RCA; update creates Neo4j node

- [ ] FUNC-8024 | FILE: `app/agent/tools/fab_tools.py` | MAPS: [TASK-6011]
      Function: `issue_lot_hold(lot_id: str, reason: str) → ToolResult`
      Function: `adjust_recipe(equipment_id: str, param: str, delta: float) → ToolResult`
      Function: `schedule_pm(equipment_id: str, urgency: str) → ToolResult`
      Function: `notify_engineer(user_id: str, message: str, context: dict) → ToolResult`
      → Each calls robot-ctrl-service; permission check (ROBOT_SERVICE role required)
      → Acceptance: Lot hold appears in Oracle `WIP_TRACKING`; notification sent to user

## 8.4 Agent API Routes

- [ ] FUNC-8030 | FILE: `app/routes/agent_routes.py` | MAPS: [TASK-6013]
      Route: `POST /api/v1/agent/query`
      → Body: `{question, context_lots?, context_equipment?}` → Returns: `{session_id, task_id}`
      → Acceptance: Returns session_id immediately; agent starts processing async

- [ ] FUNC-8031 | FILE: `app/routes/agent_routes.py` | MAPS: [TASK-6020]
      Route: `GET /api/v1/agent/stream/{session_id}` (SSE)
      → Streams thinking steps: `{type: 'thinking'|'tool_call'|'result'|'complete', content}`
      → Acceptance: Client receives streaming events as agent progresses through state machine

- [ ] FUNC-8032 | FILE: `app/routes/agent_routes.py` | MAPS: [TASK-6021]
      Route: `POST /api/v1/agent/approve-action`
      → Body: `{action_id, approved: bool, comment?}` → Triggers execute_node or cancels
      → Acceptance: Approved action executes within 5 seconds; rejected action cancelled

- [ ] FUNC-8033 | FILE: `app/routes/agent_routes.py` | MAPS: [TASK-6022]
      Route: `GET /api/v1/agent/knowledge-search`
      → Params: `symptom`, `category`, `limit` → Returns: list of RCA knowledge records
      → Acceptance: Symptom 'ring pattern' returns CMP-related records

---

# 🖥️ MODULE 9 — FRONTEND REACT APPLICATION (`apps/web/src/`)

## 9.1 Design System — Tokens & Theme

- [ ] FUNC-9001 | FILE: `packages/ui/src/tokens/colors.ts` | MAPS: [ARCH §6.1] [TASK-0010]
      Export: `colors` object with all brand palette tokens
      → Teal: `#00F5C4`, Violet: `#7B61FF`, Orange: `#FF6B35`, etc.
      → Acceptance: TypeScript types cover all color keys; no raw hex strings outside tokens

- [ ] FUNC-9002 | FILE: `packages/ui/src/tokens/typography.ts` | MAPS: [TASK-0010]
      Export: `fontFamilies`, `fontSizes`, `fontWeights`, `lineHeights`
      → Families: `Clash Display`, `Inter`, `JetBrains Mono`
      → Acceptance: All Tailwind font classes resolve to correct CSS font-family

- [ ] FUNC-9003 | FILE: `apps/web/src/styles/globals.css` | MAPS: [TASK-0011]
      Setup: CSS custom properties for all design tokens; dark mode forced
      → All `--color-*`, `--font-*`, `--radius-*`, `--duration-*` variables defined
      → Acceptance: `document.documentElement.style.getPropertyValue('--color-brand-teal')` returns `#00F5C4`

- [ ] FUNC-9004 | FILE: `apps/web/tailwind.config.ts` | MAPS: [TASK-0011]
      Setup: Extends Tailwind with all design tokens mapped to utility classes
      → `text-brand-teal`, `bg-glass-dark`, `border-glow-teal` custom classes
      → Acceptance: `bg-glass-dark` applies correct `rgba(255,255,255,0.04)` background

## 9.2 Animation Library

- [ ] FUNC-9010 | FILE: `packages/ui/src/animations/variants.ts` | MAPS: [TASK-0012]
      Export: `fadeIn`, `slideUp`, `scaleIn`, `glowPulse` Framer Motion variants
      → Each variant: `{initial, animate, exit}` with correct easing curves
      → Acceptance: Component wrapped in `motion.div` animates correctly on mount/unmount

- [ ] FUNC-9011 | FILE: `packages/ui/src/components/AnimatedNumber.tsx` | MAPS: [TASK-0012]
      Component: `<AnimatedNumber value={97.3} decimals={1} duration={1.5} />`
      → Count-up animation from 0 to value using Framer Motion `useMotionValue`
      → Respects `prefers-reduced-motion`
      → Acceptance: Renders "97.3"; animates on mount; static when motion reduced

- [ ] FUNC-9012 | FILE: `packages/ui/src/components/SkeletonGlow.tsx` | MAPS: [TASK-0012]
      Component: `<SkeletonGlow width="100%" height={20} className="..." />`
      → Animated shimmer sweep in brand teal direction
      → Acceptance: Shimmer animation visible; CSS animation pauses when motion reduced

## 9.3 Core UI Components

- [ ] FUNC-9020 | FILE: `packages/ui/src/components/Button.tsx` | MAPS: [TASK-0013]
      Component: `<Button variant="primary|secondary|ghost|danger" size="sm|md|lg" loading={bool} />`
      → Primary: gradient + shimmer on hover; glow effect on focus
      → Loading: spinner replaces children; button disabled
      → Acceptance: All variants render correctly; keyboard focusable; loading prevents double-click

- [ ] FUNC-9021 | FILE: `packages/ui/src/components/Input.tsx` | MAPS: [TASK-0013]
      Component: `<Input label units="mV" error="message" value onChange />`
      → Dark glass style; teal focus glow ring; error state red glow + message
      → Acceptance: Focus ring appears on `:focus`; error state shows red; units suffix positioned correctly

- [ ] FUNC-9022 | FILE: `packages/ui/src/components/Card.tsx` | MAPS: [TASK-0013]
      Component: `<Card variant="default|elevated|glow" onClick hoverable />`
      → Glassmorphism: `backdrop-filter: blur(20px)`; hover lift `translateY(-2px)`
      → Acceptance: Hover CSS transition fires; glassmorphism visible over background

- [ ] FUNC-9023 | FILE: `packages/ui/src/components/DataTable.tsx` | MAPS: [TASK-0013]
      Component: `<DataTable columns={[]} data={[]} virtualScroll sortable stickyHeader />`
      → `react-virtual` for windowed rendering; only visible rows in DOM
      → Acceptance: 100K row table renders in < 500ms; scroll performance ≥ 60fps

- [ ] FUNC-9024 | FILE: `packages/ui/src/components/Badge.tsx` | MAPS: [TASK-0013]
      Component: `<Badge severity="critical|major|minor|normal" pulse={bool} />`
      → Critical: red pulsing `@keyframes alarm-pulse` animation
      → Acceptance: Critical badge pulses; other severities static; correct colors

- [ ] FUNC-9025 | FILE: `packages/ui/src/components/Toast.tsx` | MAPS: [TASK-0013]
      Component: `useToast()` hook + `<ToastContainer />` portal
      → Top-right stack; max 5 visible; auto-dismiss in 5s; slide+fade animation
      → Acceptance: `showToast({title, severity})` renders toast; auto-dismisses; identical toasts stack

- [ ] FUNC-9026 | FILE: `packages/ui/src/components/Modal.tsx` | MAPS: [TASK-0013]
      Component: `<Modal isOpen onClose title children />`
      → Blur backdrop; slide-up animation; focus trap; ESC key dismiss
      → Acceptance: Focus stays inside modal while open; ESC closes; backdrop click closes

- [ ] FUNC-9027 | FILE: `packages/ui/src/components/Select.tsx` | MAPS: [TASK-0013]
      Component: `<Select options={[]} multi searchable virtualized value onChange />`
      → Custom dropdown; fuzzy search; virtualized list for 1000+ options
      → Acceptance: Search filters correctly; 1000 options render without lag; multi-select works

## 9.4 Global State — Zustand Stores

- [ ] FUNC-9030 | FILE: `apps/web/src/store/authStore.ts` | MAPS: [ARCH §6.1] [TASK-1013]
      Store: `authStore` — `{user, token, permissions, isAuthenticated, login(), logout()}`
      → `login()` calls auth API; stores token in memory (not localStorage); persists user
      → Acceptance: After login, `isAuthenticated=true`; after logout, all auth state cleared

- [ ] FUNC-9031 | FILE: `apps/web/src/store/fabStore.ts` | MAPS: [TASK-1013]
      Store: `fabStore` — `{currentFab, currentProduct, activeAlarms, equipmentStatusMap}`
      → `equipmentStatusMap` keyed by `equipment_id`; updated via WebSocket events
      → Acceptance: `alarm.critical` event increments `activeAlarms`; equipment status updates

- [ ] FUNC-9032 | FILE: `apps/web/src/store/agentStore.ts` | MAPS: [TASK-1013]
      Store: `agentStore` — `{sessions, currentSession, pendingActions, streamingContent}`
      → `streamingContent` updated token-by-token from SSE stream
      → Acceptance: SSE event updates `streamingContent`; React re-renders correctly

## 9.5 WebSocket & Networking

- [ ] FUNC-9040 | FILE: `apps/web/src/hooks/useWebSocket.ts` | MAPS: [TASK-1014]
      Hook: `useWebSocket() → {status, lastMessage, sendMessage}`
      → Reconnects with exponential backoff (1s, 2s, 4s, 8s, max 30s)
      → Dispatches events to correct store (alarm → fabStore, agent → agentStore)
      → Acceptance: Disconnect + reconnect works; messages during reconnect buffered

- [ ] FUNC-9041 | FILE: `apps/web/src/api/client.ts` | MAPS: [TASK-1010]
      Function: `apiClient` — axios instance with base URL, auth header injection, 401 refresh
      → Interceptor: auto-refreshes token on 401; queues requests during refresh
      → Acceptance: Expired token request auto-refreshes; no requests lost during refresh

- [ ] FUNC-9042 | FILE: `apps/web/src/hooks/useSSE.ts` | MAPS: [TASK-6020]
      Hook: `useSSE(url: string) → {data, error, status}`
      → EventSource connection; auto-reconnects; parses JSON events
      → Acceptance: Receives streaming events; parses JSON correctly; reconnects after network drop

## 9.6 Auth Pages

- [ ] FUNC-9050 | FILE: `apps/web/src/pages/Login.tsx` | MAPS: [TASK-1011]
      Page: Login with SVG circuit background, particle animation, glassmorphism card
      → `useAuth` hook; `useNavigate` redirect on success; MFA screen transition
      → Acceptance: Valid creds navigate to dashboard; invalid creds show shake animation + error

- [ ] FUNC-9051 | FILE: `apps/web/src/components/ParticleBackground.tsx` | MAPS: [TASK-1011]
      Component: Canvas-based floating particles (15–20 particles, slow drift)
      → Respects `prefers-reduced-motion` (static when reduced)
      → Acceptance: Particles animate at 60fps; no memory leak on unmount

- [ ] FUNC-9052 | FILE: `apps/web/src/pages/MFAVerify.tsx` | MAPS: [TASK-1011]
      Page: 6-digit TOTP input with auto-advance between digits
      → Slide transition from Login; auto-submits when 6 digits entered
      → Acceptance: Entering 6 digits auto-submits; wrong code shows error; back button returns to login

## 9.7 App Shell

- [ ] FUNC-9060 | FILE: `apps/web/src/layouts/AppShell.tsx` | MAPS: [TASK-1012]
      Component: Root layout with sidebar + header + content area
      → Sidebar collapses with `[Ctrl+\]`; state persists in localStorage
      → Acceptance: Sidebar toggles; active route highlighted; breadcrumb updates

- [ ] FUNC-9061 | FILE: `apps/web/src/components/Sidebar.tsx` | MAPS: [TASK-1012]
      Component: Collapsible nav with icon mode (64px) / expanded (240px)
      → Navigation groups with section headers; active state with teal left border
      → Acceptance: Collapse animation smooth (240ms); icons visible in collapsed mode

- [ ] FUNC-9062 | FILE: `apps/web/src/components/Header.tsx` | MAPS: [TASK-1012]
      Component: Top bar with fab selector, global search trigger, alarm counter, user menu
      → Alarm counter: red pulse badge when critical alarms > 0
      → Acceptance: Alarm count updates in real-time via WebSocket; `[Cmd+K]` opens command palette

- [ ] FUNC-9063 | FILE: `apps/web/src/components/CommandPalette.tsx` | MAPS: [TASK-1015]
      Component: Fuzzy search modal with lot IDs, equipment, parameters, pages
      → Keyboard: arrow keys + Enter; recent items history (last 20)
      → Acceptance: `[Cmd+K]` opens; fuzzy search finds "M9001" → "M900100"; Enter navigates

## 9.8 YMS Dashboard

- [ ] FUNC-9070 | FILE: `apps/web/src/pages/YMS/YMSDashboard.tsx` | MAPS: [TASK-2010]
      Page: Main YMS dashboard — KPI strip, 3-column grid, bottom tab panel
      → Polls yield API every 60s; WebSocket updates alarm feed in real-time
      → Acceptance: Dashboard loads in < 3s; KPI values match API response

- [ ] FUNC-9071 | FILE: `apps/web/src/components/charts/YieldTrendChart.tsx` | MAPS: [TASK-2013]
      Component: `<YieldTrendChart data product node days />`
      → Recharts AreaChart; gradient fill; P10/P90 bands; Brush for time range
      → Acceptance: 30-day data renders with correct dates; brush selects sub-range

- [ ] FUNC-9072 | FILE: `apps/web/src/components/wafer/WaferMap.tsx` | MAPS: [TASK-2011]
      Component: `<WaferMap dieData colorMap renderMode="auto|canvas|svg" />`
      → Canvas path: bitmap-blit for > 200K dies; target < 2ms at 684K dies
      → SVG path: interactive per-die for ≤ 200K dies
      → Zoom: mouse wheel; pan on drag; tooltip on die hover
      → Acceptance: 684K die map renders in < 2ms; SVG map has clickable dies

- [ ] FUNC-9073 | FILE: `apps/web/src/components/wafer/useWaferBitmapRenderer.ts` | MAPS: [TASK-2011]
      Hook: `useWaferBitmapRenderer(canvasRef, dieData, colorMap) → {render, perf}`
      → Builds `Uint8Array` color index; `createImageData`; `putImageData`
      → Acceptance: `perf.renderTimeMs < 2` for 684,700 dies on modern hardware

- [ ] FUNC-9074 | FILE: `apps/web/src/components/charts/BinParetoChart.tsx` | MAPS: [TASK-2014]
      Component: `<BinParetoChart data onBinClick />`
      → Recharts ComposedChart: horizontal bars (count) + line (cumulative %)
      → Click on bin: fires `onBinClick(binCode)` to filter wafer map
      → Acceptance: Cumulative % line reaches 100 at last bar; click fires callback

- [ ] FUNC-9075 | FILE: `apps/web/src/components/AlarmFeed.tsx` | MAPS: [TASK-2010]
      Component: `<AlarmFeed alarms maxHeight />`
      → Scrolling list of alarm cards; critical cards have pulsing red border
      → Auto-scrolls to new alarm; click → navigate to FDC page
      → Acceptance: New critical alarm appears at top with pulse animation

## 9.9 WAT Analytics Pages

- [ ] FUNC-9080 | FILE: `apps/web/src/pages/WAT/WATAnalytics.tsx` | MAPS: [TASK-3010]
      Page: 5-tab workbench — Overview, Distribution, Correlation, Equipment, Trend
      → Lazy-loads each tab content; URL params preserve selected tab + parameters
      → Acceptance: Direct URL with tab param loads correct tab; parameter selection persists

- [ ] FUNC-9081 | FILE: `apps/web/src/components/charts/DistributionHistogram.tsx` | MAPS: [TASK-3010]
      Component: Histogram + KDE + spec lines + stats panel
      → D3 kernel density for smooth curve; USL/LSL vertical lines in red/green
      → Acceptance: Histogram bins match expected distribution; Cpk displayed correctly

- [ ] FUNC-9082 | FILE: `apps/web/src/components/charts/CorrelationHeatmap.tsx` | MAPS: [TASK-3010]
      Component: D3 heatmap; click cell → opens scatter plot modal
      → Color scale: -1 red → 0 white/neutral → +1 teal
      → Significance dimming: non-significant (p > 0.05) cells at 30% opacity
      → Acceptance: Self-correlation diagonal = 1.0 (teal); dim cells correct; click opens modal

- [ ] FUNC-9083 | FILE: `apps/web/src/components/charts/EtaSquaredChart.tsx` | MAPS: [TASK-3010]
      Component: Horizontal bar chart of equipment ranked by eta-squared
      → Color: teal bars; top tool highlighted; tooltip shows variance contribution %
      → Acceptance: Bars proportional to eta-squared values; sum approximately 1.0

- [ ] FUNC-9084 | FILE: `apps/web/src/pages/WAT/WATUpload.tsx` | MAPS: [TASK-3011]
      Page: Drag-and-drop file upload with progress and preview
      → Accepts: STDF, CSV, AD5, XLS; shows format-specific icon per file type
      → SSE progress: parsing → validating → loading → complete
      → Acceptance: Drag-drop works; progress events render; success shows confetti

## 9.10 SPC & FDC Pages

- [ ] FUNC-9090 | FILE: `apps/web/src/pages/SPC/SPCMonitor.tsx` | MAPS: [TASK-4010]
      Page: SPC charts with parameter tree + violation highlights + stats panel
      → Chart type switcher: Xbar-R / Xbar-S / I-MR / P-chart
      → Violation points: red circles with tooltip showing rule description
      → Acceptance: Known violation shows red point at correct index with correct rule name

- [ ] FUNC-9091 | FILE: `apps/web/src/components/charts/SPCChart.tsx` | MAPS: [TASK-4010]
      Component: `<SPCChart points limits violations chartType />`
      → UCL/LCL dashed red lines; CL gray; ±1σ/2σ subtle bands
      → Violation highlights on data points; PM event vertical markers
      → Acceptance: Points outside UCL highlighted red; limit lines at correct positions

- [ ] FUNC-9092 | FILE: `apps/web/src/components/CpkGauge.tsx` | MAPS: [TASK-4010]
      Component: `<CpkGauge value={1.33} />`
      → SVG arc gauge from 0 to 2.0; color: red (<1.0) / yellow (1.0-1.33) / green (>1.33)
      → Animated fill on mount
      → Acceptance: 1.33 renders at correct arc position; animation completes in ≤ 1.5s

- [ ] FUNC-9093 | FILE: `apps/web/src/pages/FDC/FDCTraceView.tsx` | MAPS: [TASK-4021]
      Page: Multi-sensor trace viewer with anomaly region highlighting
      → Synchronized zoom across all sensor subplots
      → Anomaly region: red shaded area on time axis
      → Acceptance: Zoom on one plot zooms all; anomaly region matches backend score

## 9.11 Agent Chat Interface

- [ ] FUNC-9100 | FILE: `apps/web/src/pages/Agent/AgentChat.tsx` | MAPS: [TASK-6020]
      Page: Split layout — chat (35%) + analysis canvas (65%)
      → Hexagonal grid background pattern (CSS); agent avatar with pulsing ring when active
      → Acceptance: Layout renders correctly at 1920×1080; canvas populates as agent responds

- [ ] FUNC-9101 | FILE: `apps/web/src/components/agent/ChatBubble.tsx` | MAPS: [TASK-6020]
      Component: `<ChatBubble role="user|agent" content streaming={bool} />`
      → Agent: violet glass; User: teal glass; streaming: typewriter character-by-character
      → Acceptance: Streaming renders characters as they arrive; markdown formatted correctly

- [ ] FUNC-9102 | FILE: `apps/web/src/components/agent/ToolCallCard.tsx` | MAPS: [TASK-6020]
      Component: `<ToolCallCard tool="query_yield_data" params status="running|complete" />`
      → Collapsible; shows tool name + params while running; result preview when complete
      → Acceptance: Collapses on click; status icon changes from spinner to check on complete

- [ ] FUNC-9103 | FILE: `apps/web/src/components/agent/ActionProposalCard.tsx` | MAPS: [TASK-6021]
      Component: `<ActionProposalCard action confidence riskLevel onApprove onReject />`
      → Risk color coding: green/yellow/red; countdown timer for auto-approve
      → Acceptance: Timer counts down; approve button calls API; reject shows comment input

- [ ] FUNC-9104 | FILE: `apps/web/src/components/agent/AnalysisCanvas.tsx` | MAPS: [TASK-6020]
      Component: Auto-populated workspace as agent discovers insights
      → Sections slide in with animation as agent generates each insight type
      → Acceptance: Each new insight section animates in; sections match agent tool call results

---

# 🏭 MODULE 10 — ROBOT CONTROL SERVICE (`services/robot-ctrl-service/`)

- [ ] FUNC-10001 | FILE: `app/services/mes_client.py` | MAPS: [ARCH §12.1] [TASK-9001]
      Function: `hold_lot(lot_id: str, reason: str, hold_code: str) → MESResult`
      → MES REST API call; validates ROBOT_SERVICE permission; writes to Oracle `WIP_TRACKING`
      → Acceptance: Lot appears as HOLD in MES; Oracle record shows hold_reason

- [ ] FUNC-10002 | FILE: `app/services/mes_client.py` | MAPS: [TASK-9001]
      Function: `release_lot(lot_id: str, release_code: str, comment: str) → MESResult`
      Function: `change_lot_priority(lot_id: str, priority: int) → MESResult`
      → MES API calls with full audit logging
      → Acceptance: Priority change reflected in MES queue within 30 seconds

- [ ] FUNC-10003 | FILE: `app/services/eap_client.py` | MAPS: [TASK-9002]
      Function: `read_recipe(equipment_id: str) → RecipeParameters`
      Function: `adjust_recipe(equipment_id: str, adjustments: dict, max_delta_pct: float = 5.0) → EAPResult`
      → GEM300 SECS-II command via PyGEM; enforces max ±5% constraint
      → Raises `RecipeAdjustmentExceeded` if delta > max_delta_pct
      → Acceptance: Adjustment of 3% succeeds; 10% raises exception

- [ ] FUNC-10004 | FILE: `app/services/amhs_client.py` | MAPS: [TASK-9003]
      Function: `dispatch_carrier(carrier_id: str, from_tool: str, to_tool: str) → AMHSResult`
      → SEMI E84 carrier handoff; SEMI E87 carrier management
      → Acceptance: Transport command acknowledged by AMHS; carrier moves within timeout

- [ ] FUNC-10005 | FILE: `app/services/audit_logger.py` | MAPS: [ARCH §12.2] [TASK-9001]
      Function: `log_robot_action(action_type: str, target: str, params: dict, result: dict, agent_session_id: str) → None`
      → Writes immutable record to GP `AGENT_ACTIONS` table
      → Acceptance: Every robot action has corresponding audit record; record is immutable (no UPDATE allowed)

- [ ] FUNC-10006 | FILE: `app/routes/robot_routes.py` | MAPS: [TASK-9010]
      Route: `POST /api/v1/robot/lot-hold`
      Route: `POST /api/v1/robot/recipe-adjust`
      Route: `POST /api/v1/robot/pm-schedule`
      Route: `GET /api/v1/robot/action-queue`
      Route: `GET /api/v1/robot/action-log`
      → All routes require `ROBOT_SERVICE` or `SENIOR_ENGINEER` role
      → Acceptance: Unauthorized role returns 403; authorized role executes action

---

# 🧪 MODULE 11 — TEST SUITE

## 11.1 Backend Unit Tests

- [ ] FUNC-T001 | FILE: `services/*/tests/unit/test_spc_rules.py` | MAPS: [TASK-T001]
      Tests: All 8 SPC rules — `test_rule_1_violation`, `test_rule_1_no_violation`, etc.
      → 16 tests total (violation + no-violation case for each rule)
      → Acceptance: 100% pass rate; each test is isolated with no DB dependency

- [ ] FUNC-T002 | FILE: `services/yield-service/tests/unit/test_yield_service.py` | MAPS: [TASK-T001]
      Tests: `test_compute_yield_summary_25_wafers`, `test_detect_excursion_3sigma`, etc.
      → Mock GP + Oracle with in-memory SQLite fixtures
      → Acceptance: All pass; mock CAS calls verified with `pytest-mock`

- [ ] FUNC-T003 | FILE: `services/*/tests/unit/test_equipment_health.py` | MAPS: [TASK-T001]
      Tests: `test_composite_score_all_zero`, `test_composite_score_all_one`, `test_tier_classification`
      → Known inputs → known outputs for all health score components
      → Acceptance: Score of 0 components = 0; score of 1 components = 100

- [ ] FUNC-T004 | FILE: `services/auth-service/tests/unit/test_jwt.py` | MAPS: [TASK-T001]
      Tests: `test_generate_token_valid`, `test_expired_token_rejected`, `test_tampered_token_rejected`, `test_blacklisted_token_rejected`
      → Acceptance: All 4 cases behave as specified; no false positives

## 11.2 Frontend Unit Tests

- [ ] FUNC-T010 | FILE: `apps/web/src/components/__tests__/WaferMap.test.tsx` | MAPS: [TASK-T002]
      Tests: `test_renders_canvas_above_200k_dies`, `test_renders_svg_below_200k`, `test_bitmap_pixel_colors_correct`
      → Canvas pixel output correctness using `getImageData`
      → Acceptance: Pixel at known die position has correct color bytes

- [ ] FUNC-T011 | FILE: `apps/web/src/components/__tests__/SPCChart.test.tsx` | MAPS: [TASK-T002]
      Tests: `test_violation_points_highlighted`, `test_control_limits_rendered`, `test_rule_tooltip_content`
      → Testing Library: query DOM for violation elements
      → Acceptance: Violation at index 5 has `data-violation="true"` attribute

- [ ] FUNC-T012 | FILE: `apps/web/src/store/__tests__/agentStore.test.ts` | MAPS: [TASK-T002]
      Tests: `test_sse_event_updates_streaming_content`, `test_pending_action_added`, `test_action_approved`
      → Zustand store state transitions tested directly
      → Acceptance: Each action updates store as expected; no async race conditions

## 11.3 Integration Tests

- [ ] FUNC-T020 | FILE: `tests/integration/test_upload_to_dashboard.py` | MAPS: [TASK-T003]
      Test: Upload STDF → parse → load to GP → query yield API → verify dashboard data
      → End-to-end with real Greenplum (test DB) and mocked SAS Viya
      → Acceptance: Uploaded lot appears in yield API within 30 seconds

- [ ] FUNC-T021 | FILE: `tests/integration/test_spc_to_alarm.py` | MAPS: [TASK-T003]
      Test: Insert out-of-control measurement → verify Oracle alarm created → verify Kafka event published
      → Acceptance: Alarm in Oracle within 10 seconds; Kafka event received by consumer

- [ ] FUNC-T022 | FILE: `tests/integration/test_agent_rca_flow.py` | MAPS: [TASK-T003]
      Test: Submit RCA query → agent runs tool calls → generates hypothesis → streams response
      → Uses test knowledge base with known answer
      → Acceptance: Agent identifies correct root cause in > 80% of test scenarios

## 11.4 E2E Tests

- [ ] FUNC-T030 | FILE: `tests/e2e/test_login_flow.spec.ts` | MAPS: [TASK-T004]
      Test: Navigate to login → enter valid creds → reach YMS dashboard → verify KPI cards
      → Playwright; runs against staging environment
      → Acceptance: Completes in < 10 seconds; KPI cards have non-zero values

- [ ] FUNC-T031 | FILE: `tests/e2e/test_wat_upload.spec.ts` | MAPS: [TASK-T004]
      Test: Upload STDF file → progress events → analytics page populated
      → Drag-drop simulation in Playwright
      → Acceptance: Distribution histogram renders with correct parameter options

- [ ] FUNC-T032 | FILE: `tests/e2e/test_agent_chat.spec.ts` | MAPS: [TASK-T004]
      Test: Open agent chat → submit yield question → verify streaming response → verify action card appears
      → Acceptance: Response streams in; action card renders; approve button functional

---

# 📋 MODULE 12 — MAPPING SUMMARY TABLE

## Complete Cross-Reference: Functions → Architecture → Tasks → User Stories

| Function Range | Module | Architecture Section | Implementation Tasks | User Stories Served |
|---------------|--------|---------------------|---------------------|---------------------|
| FUNC-0001–0029 | Infrastructure | §3.2, §4, §14 | TASK-0001–0029 | All (foundation) |
| FUNC-1001–1041 | Auth Service | §5.1, §13.1 | TASK-1001–1006 | All (security) |
| FUNC-2001–2052 | Yield Service | §7.2, §8.2, §9.1 | TASK-2001–2004 | US-PE-001,002,003,004 / US-MGR-001 |
| FUNC-3001–3042 | WAT Analytics | §8, §8.3, §9.2 | TASK-3001–3005 | US-PRO-002,003,004 / US-PIE-002 |
| FUNC-4001–4011 | CP Analytics | §9.3 | TASK-3020–3022 | US-PE-002 / US-MFG-002 |
| FUNC-5001–5040 | SPC/FDC | §9.2, §10.1 | TASK-4001–4022 | US-PRO-001 / US-EE-001,003 / ADV-001 |
| FUNC-6001–6007 | Defect Service | §9.3 | TASK-5001–5003 | US-PIE-001 / ADV-001 |
| FUNC-7001–7022 | AI Inference | §10 | TASK-6001–6004 | ADV-002,004 / US-PE-003 |
| FUNC-8001–8033 | Agent Service | §11 | TASK-6010–6013 | ALL Advanced Scenarios |
| FUNC-9001–9104 | Frontend | §6 | TASK-0010–U008 | ALL (user interface) |
| FUNC-10001–10006 | Robot Control | §12 | TASK-9001–9003 | US-MFG-003 / ADV-001 |
| FUNC-T001–T032 | Test Suite | §14.2 | TASK-T001–T005 | Quality assurance for all |

---

## Overall Completion Dashboard

```
MODULE 0  — Infrastructure      [ 0/29  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 1  — Auth Service        [ 0/17  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 2  — Yield Service       [ 0/22  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 3  — WAT Analytics       [ 0/25  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 4  — CP Analytics        [ 0/8   ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 5  — SPC/FDC Service     [ 0/34  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 6  — Defect Service      [ 0/7   ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 7  — AI Inference        [ 0/13  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 8  — Agent Service       [ 0/34  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 9  — Frontend React      [ 0/79  ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 10 — Robot Control       [ 0/6   ] ░░░░░░░░░░░░░░░░░░░░  0%
MODULE 11 — Test Suite          [ 0/12  ] ░░░░░░░░░░░░░░░░░░░░  0%
─────────────────────────────────────────────────────────────────
TOTAL                           [ 0/286 ] ░░░░░░░░░░░░░░░░░░░░  0%
```

> **Note:** 286 function groups map to 624 discrete coding units (some FUNC entries define multiple related functions in one file).

---

## How To Use This Checklist in Practice

### Daily Standup Workflow
1. Engineer picks up a FUNC-XXXX item and marks `[~]` (in progress)
2. Completes implementation + unit test
3. Opens PR with title `feat: FUNC-XXXX — function_name description`
4. PR description includes: Acceptance criteria verified (checkbox list)
5. Reviewer checks acceptance criteria pass in CI
6. Merged: mark `[x]` in this document

### Sprint Planning Integration
- Sprint stories reference FUNC-IDs: "This sprint covers FUNC-2001 through FUNC-2052 (Yield Service)"
- Each sprint closes a Module or sub-module section
- Module completion = all `[ ]` items become `[x]`

### Blocked Item Protocol
- Mark `[!]` with inline comment: `[!] Blocked — waiting for Oracle credentials from IT`
- Add to daily standup blockers list
- PM resolves; item reverts to `[ ]`

### Definition of Done for Each FUNC
- [ ] Code written and committed
- [ ] Unit test written covering acceptance criteria
- [ ] CI pipeline passes (lint + type check + test)
- [ ] Integrated with dependent services (manual test)
- [ ] Code reviewed by at least 1 peer
- [ ] No TODO or FIXME comments in production code path
- [ ] Logging added for error paths
- [ ] API documentation (docstring) updated

---

*Document End — SEMFAB·IQ Master Coding Function Checklist v1.0*  
*286 function groups / 624 discrete coding units*  
*Fully cross-referenced to: Architecture Design Report · Implementation Task List · User Story Report*  
*© 2025 SEMFAB·IQ Engineering Team. Commercial Confidential.*
