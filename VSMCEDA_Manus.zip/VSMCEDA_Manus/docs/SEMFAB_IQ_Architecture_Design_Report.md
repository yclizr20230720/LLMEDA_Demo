# SEMFAB·IQ — Semiconductor Engineering Data Analytics Platform
## Comprehensive System Architecture & Product Design Report
### Commercial Production-Grade EDA System

---

> **Document Classification:** Commercial Confidential — Architecture Design  
> **Version:** 1.0.0  
> **Technology Stack:** React 18 + Vite · Python Flask · SAS Viya · Greenplum · Oracle DB · LLM Agentic AI  
> **Reference Standard:** Semitronix DataExp Yield Ecosystem (Complete Function Parity)

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Product Vision & Market Positioning](#2-product-vision--market-positioning)
3. [System Architecture Overview](#3-system-architecture-overview)
4. [Data Infrastructure Layer](#4-data-infrastructure-layer)
5. [Microservice Architecture Design](#5-microservice-architecture-design)
6. [Frontend Architecture — React + Vite](#6-frontend-architecture--react--vite)
7. [Backend Architecture — Python Flask](#7-backend-architecture--python-flask)
8. [SAS Viya Integration — Statistical Processing Engine](#8-sas-viya-integration--statistical-processing-engine)
9. [Analytics Module Design](#9-analytics-module-design)
10. [AI / ML Intelligence Layer](#10-ai--ml-intelligence-layer)
11. [LLM Agentic AI — Knowledge Accumulation & Wisdom Engine](#11-llm-agentic-ai--knowledge-accumulation--wisdom-engine)
12. [Autonomous FAB Operation System](#12-autonomous-fab-operation-system)
13. [Security, Compliance & SEMI Standards](#13-security-compliance--semi-standards)
14. [Deployment Architecture](#14-deployment-architecture)
15. [API Design Reference](#15-api-design-reference)
16. [Data Schema Design](#16-data-schema-design)
17. [Implementation Roadmap](#17-implementation-roadmap)
18. [Commercial Licensing Model](#18-commercial-licensing-model)

---

## 1. Executive Summary

**SEMFAB·IQ** is a next-generation, full-stack Semiconductor Engineering Data Analytics (EDA) platform engineered to pursue the absolute goal of **100% wafer yield** through an integrated stack of statistical intelligence, machine learning, LLM-driven knowledge accumulation, and autonomous agentic AI capable of replacing or augmenting human engineers across the entire wafer fabrication lifecycle.

The platform is architected around four mutually reinforcing intelligence pillars:

| Pillar | Description | Primary Technology |
|--------|-------------|-------------------|
| **Statistical Intelligence** | SPC, FDC, WAT/CP/WLR parametric analytics at fab scale | SAS Viya + Greenplum |
| **Machine Learning Engine** | Yield prediction, defect classification, anomaly detection | Python ML stack on SAS Viya |
| **Real-Time Operations** | Live equipment monitoring, alarm routing, run-to-run control | Oracle DB + Flask Event Bus |
| **Agentic AI Wisdom** | LLM knowledge accumulation, autonomous RCA, robotic FAB control | LLM + MCP + Robot APIs |

The system provides **complete functional parity with the Semitronix DataExp yield ecosystem** — covering DE-G, DE-YMS, DE-DMS, DE-FDC, DE-SPC, INF-TPC, INF-ADC, INF-WPA, INF-AI, QuanTest-YAD, DFM tools (LayoutVision, PatternScan, CMPEXP, Virtual Yield), and hardware tester integration — while extending beyond into autonomous FAB operation through Software + Hardware Robot orchestration.

---

## 2. Product Vision & Market Positioning

### 2.1 Vision Statement

> *"Transform semiconductor wafer fabrication from a human-dependent engineering discipline into a self-learning, self-correcting, autonomously operating intelligent system — where AI accumulates institutional knowledge faster than any human team, and Software Robots + Hardware Robots execute corrective actions without latency."*

### 2.2 Product Differentiation Matrix

| Capability | Semitronix DataExp | KLA Klarity | PDF Solutions RELIANCE | **SEMFAB·IQ** |
|-----------|-------------------|-------------|----------------------|--------------|
| WAT/CP/Inline analytics | ✅ | Partial | ✅ | ✅ Full parity |
| SPC / FDC | ✅ | ✅ | ✅ | ✅ + R2R control |
| AI defect classification | ✅ INF-ADC | ✅ | Limited | ✅ + Custom LLM |
| LLM knowledge engine | SemiMind (basic) | ❌ | ❌ | ✅ **Deep Wisdom AI** |
| Agentic autonomous RCA | QuickRoot (limited) | ❌ | ❌ | ✅ **Full Agentic** |
| SW + HW Robot FAB control | ❌ | ❌ | ❌ | ✅ **Autonomous FAB** |
| Open microservice API | ❌ | ❌ | ❌ | ✅ Full REST/gRPC |
| Multi-tenancy SaaS | ❌ | Limited | Limited | ✅ Enterprise SaaS |

### 2.3 Target Customer Segments

```mermaid
graph TD
    A[SEMFAB·IQ Customer Segments] --> B[Tier-1 Foundries<br/>TSMC / Samsung / SMIC equivalent]
    A --> C[IDM Manufacturers<br/>Intel / Infineon / STMicro equivalent]
    A --> D[Advanced Packaging<br/>ASE / Amkor equivalent]
    A --> E[Fabless + Design Houses<br/>Yield learning partnerships]
    A --> F[R&D Institutes<br/>Process development nodes]

    B --> B1[Full autonomous FAB suite]
    C --> C1[Yield + reliability + DFM]
    D --> D1[CP + FT + packaging yield]
    E --> E1[DFT + YMS + design feedback]
    F --> F1[WAT characterization + DOE]
```

---

## 3. System Architecture Overview

### 3.1 Macro Architecture — Five-Layer Intelligence Stack

```mermaid
graph TB
    subgraph L5["Layer 5 — Autonomous FAB Control (Agentic AI)"]
        direction LR
        AG1[Wisdom Engine<br/>LLM Knowledge Base]
        AG2[Agentic Orchestrator<br/>LangGraph / CrewAI]
        AG3[SW Robot Controller<br/>MES / EAP / APC]
        AG4[HW Robot Interface<br/>Wafer Transport / Probers]
    end

    subgraph L4["Layer 4 — AI Intelligence (ML + LLM)"]
        direction LR
        ML1[Yield Prediction<br/>XGBoost / DNN]
        ML2[Defect Classification<br/>CNN / ViT]
        ML3[Anomaly Detection<br/>Unsupervised / INF-TPC]
        ML4[RCA Engine<br/>SHAP / Causal AI]
    end

    subgraph L3["Layer 3 — Analytics Engine (SAS Viya + Flask)"]
        direction LR
        AE1[SPC / FDC Engine<br/>SAS Viya Proc]
        AE2[WAT / CP Analytics<br/>Statistical Modeling]
        AE3[DFM / DFT Analysis<br/>Layout + Pattern]
        AE4[Real-time Monitor<br/>Oracle Streams]
    end

    subgraph L2["Layer 2 — Data Infrastructure"]
        direction LR
        DI1[Greenplum DW<br/>Historical + Batch]
        DI2[Oracle DB<br/>Real-time OLTP]
        DI3[SAS Viya CAS<br/>In-memory Compute]
        DI4[Redis Cache<br/>Session + Hot Data]
    end

    subgraph L1["Layer 1 — Data Ingestion"]
        direction LR
        IN1[WAT Testers<br/>STDF / CSV / AD5]
        IN2[Inline Metro<br/>KLA / AMAT sensors]
        IN3[CP / FT Testers<br/>STDF / WPAR]
        IN4[MES / EAP<br/>GEM300 / SECS-II]
    end

    subgraph L0["Frontend — React + Vite"]
        direction LR
        FE1[Engineer Dashboard]
        FE2[AI Chat Interface]
        FE3[FAB Automation Console]
        FE4[Management Reports]
    end

    L0 <--> L3
    L1 --> L2
    L2 <--> L3
    L3 <--> L4
    L4 <--> L5
    L5 --> IN4
```

### 3.2 Network Topology

```mermaid
graph LR
    subgraph DMZ["DMZ / API Gateway"]
        GW[Kong API Gateway<br/>+ OAuth2 / JWT]
        LB[Nginx Load Balancer]
    end

    subgraph APP["Application Tier — Kubernetes Cluster"]
        MS1[yield-svc]
        MS2[spc-fdc-svc]
        MS3[defect-svc]
        MS4[ai-inference-svc]
        MS5[agent-svc]
        MS6[report-svc]
        MS7[notification-svc]
        MS8[auth-svc]
    end

    subgraph DATA["Data Tier"]
        GP[(Greenplum<br/>Data Warehouse)]
        ORA[(Oracle DB<br/>Real-time)]
        CAS[SAS Viya CAS<br/>In-Memory Engine]
        REDIS[(Redis Cluster<br/>Cache)]
        KAFKA[Kafka<br/>Event Bus]
        MINIO[MinIO<br/>Object Storage]
    end

    subgraph FAB["FAB Equipment Network — Isolated VLAN"]
        PROBER[Wafer Probers<br/>GEM300]
        TESTER[WAT Testers<br/>Semitronix HW]
        METRO[Inline Metrology<br/>KLA / AMAT]
        MES[MES System<br/>Applied / Camstar]
    end

    Internet --> GW
    GW --> LB
    LB --> APP
    APP --> DATA
    FAB --> KAFKA
    KAFKA --> DATA
```

### 3.3 Complete Data Flow

```mermaid
sequenceDiagram
    participant FAB as FAB Equipment
    participant KAFKA as Kafka Bus
    participant ETL as ETL Service
    participant GP as Greenplum DW
    participant ORA as Oracle RT
    participant CAS as SAS Viya CAS
    participant ML as ML Engine
    participant LLM as Wisdom AI
    participant ENG as Engineer / Robot

    FAB->>KAFKA: Raw test data (STDF/GEM300)
    KAFKA->>ETL: Stream consume
    ETL->>ORA: Write real-time OLTP (alarms, WIP)
    ETL->>GP: Write to staging partitions
    GP->>CAS: Load to in-memory for analytics
    CAS->>CAS: SAS Viya: SPC / FDC / WAT stats
    CAS->>ML: Feature matrix for ML inference
    ML->>GP: Write predictions + SHAP explanations
    ML->>LLM: Push anomaly event + context
    LLM->>LLM: Accumulate to knowledge graph
    LLM->>ENG: Proactive RCA report + action plan
    ENG->>LLM: Engineer confirms / corrects
    LLM->>LLM: Update wisdom from correction
    LLM->>FAB: Issue corrective recipe via MES/EAP
```

---

## 4. Data Infrastructure Layer

### 4.1 Greenplum Data Warehouse — Schema Architecture

Greenplum serves as the **primary analytical data warehouse** for all historical fab data. All tables are **columnar-stored, distributed by wafer lot key**, and range-partitioned by process date for efficient time-series analytics.

```mermaid
erDiagram
    WAT_RESULT {
        bigint id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar site_id
        varchar parameter_id FK
        float measured_value
        float spec_high
        float spec_low
        varchar equipment_id FK
        varchar recipe_id FK
        timestamp test_time
        varchar process_node
        varchar product_id
    }

    CP_RESULT {
        bigint id PK
        varchar lot_id FK
        varchar wafer_id FK
        int die_x
        int die_y
        int bin_code
        varchar test_item
        float measured_value
        timestamp test_time
        varchar tester_id
        varchar program_id
    }

    DEFECT_MAP {
        bigint id PK
        varchar lot_id FK
        varchar wafer_id FK
        int defect_x
        int defect_y
        float defect_size
        varchar defect_class
        varchar layer_name
        varchar inspection_tool
        timestamp inspect_time
        varchar adc_class
        float adc_confidence
    }

    INLINE_METRO {
        bigint id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar step_id FK
        varchar measurement_type
        float measured_value
        float target_value
        float ucl
        float lcl
        varchar equipment_id FK
        timestamp measure_time
        int site_num
    }

    EQUIPMENT_MASTER {
        varchar equipment_id PK
        varchar equipment_name
        varchar tool_type
        varchar chamber_id
        varchar area
        varchar status
        float health_score
        timestamp last_pm_date
    }

    YIELD_SUMMARY {
        bigint id PK
        varchar lot_id FK
        varchar wafer_id FK
        varchar process_step
        float gross_yield
        float net_yield
        int total_die
        int pass_die
        int fail_die
        date summary_date
    }

    RCA_KNOWLEDGE {
        bigint id PK
        varchar symptom_signature
        varchar root_cause_category
        varchar root_cause_detail
        varchar corrective_action
        float confidence_score
        int occurrence_count
        timestamp first_seen
        timestamp last_seen
        varchar validated_by
    }

    WAT_RESULT ||--o{ CP_RESULT : "lot_id"
    WAT_RESULT ||--o{ DEFECT_MAP : "wafer_id"
    WAT_RESULT ||--o{ INLINE_METRO : "lot_id"
    EQUIPMENT_MASTER ||--o{ WAT_RESULT : "equipment_id"
    EQUIPMENT_MASTER ||--o{ INLINE_METRO : "equipment_id"
    WAT_RESULT ||--o{ YIELD_SUMMARY : "lot_id"
    YIELD_SUMMARY ||--o{ RCA_KNOWLEDGE : "symptom_signature"
```

### 4.2 Oracle DB — Real-Time OLTP Schema

Oracle handles **sub-second latency** operations: live alarms, WIP tracking, equipment status, and run-to-run control feedback loops.

```mermaid
erDiagram
    LIVE_ALARM {
        number alarm_id PK
        varchar2 equipment_id FK
        varchar2 alarm_code
        varchar2 severity
        varchar2 alarm_message
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 process_step
        timestamp alarm_time
        varchar2 status
        varchar2 ack_by
        timestamp ack_time
        varchar2 action_taken
    }

    WIP_TRACKING {
        number wip_id PK
        varchar2 lot_id
        varchar2 wafer_id
        varchar2 current_step
        varchar2 equipment_id FK
        varchar2 status
        timestamp start_time
        timestamp end_time
        number priority
        varchar2 hold_reason
    }

    RUN_TO_RUN_CTRL {
        number ctrl_id PK
        varchar2 equipment_id FK
        varchar2 parameter_name
        number target_value
        number current_setpoint
        number measured_output
        number correction_delta
        varchar2 model_name
        timestamp ctrl_time
        varchar2 lot_id
    }

    EQUIPMENT_STATUS {
        varchar2 equipment_id PK
        varchar2 status
        number utilization_pct
        number throughput_wph
        timestamp last_update
        varchar2 current_lot
        varchar2 current_recipe
        number alarm_count_24h
        number health_score
    }

    LIVE_ALARM ||--o{ WIP_TRACKING : "lot_id"
    EQUIPMENT_STATUS ||--o{ LIVE_ALARM : "equipment_id"
    EQUIPMENT_STATUS ||--o{ RUN_TO_RUN_CTRL : "equipment_id"
```

### 4.3 SAS Viya CAS — In-Memory Compute Architecture

```mermaid
graph TB
    subgraph CAS["SAS Viya Cloud Analytic Services — CAS Controller Cluster"]
        CTRL[CAS Controller<br/>Session Manager]

        subgraph WORKERS["CAS Worker Nodes — 16 Nodes × 512GB RAM"]
            W1[Worker 01<br/>WAT Analytics]
            W2[Worker 02<br/>SPC Engine]
            W3[Worker 03<br/>FDC Processing]
            W4[Worker 04<br/>ML Training]
            Wn[Worker N<br/>...]
        end

        subgraph TABLES["CAS In-Memory Tables"]
            T1[WAT_CURRENT<br/>Rolling 90-day]
            T2[SPC_CHARTS<br/>All parameters]
            T3[DEFECT_MATRIX<br/>Wafer maps]
            T4[YIELD_CUBE<br/>Multi-dim OLAP]
            T5[ML_FEATURES<br/>Live feature store]
        end

        subgraph PROCS["SAS Viya Analytical Procedures"]
            P1[PROC MIXED<br/>Mixed Effects Model]
            P2[PROC GLMSELECT<br/>Variable Selection]
            P3[PROC HPFOREST<br/>Random Forest]
            P4[PROC TSMODEL<br/>Time Series]
            P5[PROC CAUSL<br/>Causal Analysis]
            P6[Model Studio<br/>AutoML Pipeline]
        end
    end

    subgraph CONNECT["Data Connectors"]
        C1[Greenplum Connector<br/>Bulk Load]
        C2[Oracle Connector<br/>Real-time Feed]
        C3[Python swat Client<br/>Flask Services]
        C4[REST API<br/>External Consumers]
    end

    C1 --> CTRL
    C2 --> CTRL
    CTRL --> WORKERS
    WORKERS --> TABLES
    TABLES --> PROCS
    C3 --> CTRL
    C4 --> CTRL
```

### 4.4 Data Ingestion Pipeline

```mermaid
flowchart LR
    subgraph Sources["Data Sources"]
        S1[WAT Tester\nSTDF / CSV / AD5]
        S2[Inline Metro\nKLA / AMAT XML]
        S3[CP Tester\nSTDF / WPAR]
        S4[MES GEM300\nSECS-II / HSMS]
        S5[Defect Scanner\nKLA klarf format]
        S6[FDC Trace\nDynamic sensor logs]
    end

    subgraph Ingest["Ingestion Layer"]
        K1[Kafka Topic:\nwat-raw]
        K2[Kafka Topic:\ninline-raw]
        K3[Kafka Topic:\ncp-raw]
        K4[Kafka Topic:\nmes-events]
        K5[Kafka Topic:\ndefect-raw]
        K6[Kafka Topic:\nfdc-trace]
    end

    subgraph ETL["ETL / Streaming Layer — Spark Structured Streaming"]
        E1[STDF Parser\nPy-STDF]
        E2[Schema Validator\nGreat Expectations]
        E3[Deduplicator\nNatural Key Hash]
        E4[Enricher\nLot / Equipment join]
        E5[Quality Scorer\nData completeness]
    end

    subgraph Sink["Data Sinks"]
        GP[(Greenplum\nDW Tables)]
        ORA[(Oracle\nReal-time)]
        MINIO[(MinIO\nRaw Archive)]
        CAS[SAS Viya CAS\nHot Tables]
    end

    S1 --> K1
    S2 --> K2
    S3 --> K3
    S4 --> K4
    S5 --> K5
    S6 --> K6

    K1 --> E1
    K2 --> E1
    K3 --> E1
    K4 --> E1
    K5 --> E1
    K6 --> E1

    E1 --> E2 --> E3 --> E4 --> E5

    E5 --> GP
    E5 --> ORA
    E5 --> MINIO
    GP --> CAS
```

---

## 5. Microservice Architecture Design

### 5.1 Service Topology

```mermaid
graph TB
    subgraph CLIENT["Client Applications"]
        WEB[React + Vite SPA]
        MOBILE[Mobile App]
        BOT[Agent Bot Interface]
    end

    subgraph GATEWAY["API Gateway Layer"]
        KONG[Kong Gateway\nAuth / Rate Limit / Routing]
        WSS[WebSocket Server\nReal-time Push]
    end

    subgraph CORE["Core Microservices — Flask"]
        AUTH[auth-service\n:8001]
        YIELD[yield-service\n:8002]
        WAT[wat-analytics-service\n:8003]
        CP[cp-analytics-service\n:8004]
        SPC[spc-fdc-service\n:8005]
        DEFECT[defect-service\n:8006]
        DFM[dfm-service\n:8007]
        DFT[dft-service\n:8008]
        ALARM[alarm-service\n:8009]
        REPORT[report-service\n:8010]
    end

    subgraph AI_SVCS["AI / Intelligence Services"]
        INFER[inference-service\n:8020\nML Model Serving]
        ADC[adc-service\n:8021\nAuto Defect Class]
        WPA[wpa-service\n:8022\nWafer Pattern]
        TPC[tpc-service\n:8023\nTrace Anomaly]
        AGENT[agent-service\n:8030\nAgentic AI]
        LLM_SVC[llm-service\n:8031\nWisdom Engine]
        ROBOT[robot-ctrl-service\n:8040\nFAB Automation]
    end

    subgraph INFRA["Infrastructure Services"]
        NOTIF[notification-service\n:8050]
        AUDIT[audit-service\n:8051]
        CONFIG[config-service\n:8052]
        HEALTH[health-service\n:8053]
    end

    WEB --> KONG
    MOBILE --> KONG
    BOT --> KONG
    KONG --> AUTH
    KONG --> YIELD
    KONG --> WAT
    KONG --> CP
    KONG --> SPC
    KONG --> DEFECT
    KONG --> DFM
    KONG --> DFT
    KONG --> ALARM
    KONG --> REPORT
    KONG --> AGENT
    KONG --> LLM_SVC
    KONG --> ROBOT
    WSS --> WEB

    YIELD --> INFER
    DEFECT --> ADC
    DEFECT --> WPA
    SPC --> TPC
    AGENT --> LLM_SVC
    AGENT --> ROBOT
```

### 5.2 Service Contract Specification

Each microservice follows a **unified contract standard**:

```mermaid
graph LR
    subgraph CONTRACT["Service Contract Standard"]
        H[Health: GET /health]
        V[Version: GET /version]
        M[Metrics: GET /metrics]
        D[Docs: GET /docs Swagger]
    end

    subgraph STANDARD["API Response Envelope"]
        ENV["{ status, data, meta, errors, trace_id }"]
    end

    subgraph AUTH_FLOW["Auth Flow"]
        JWT[JWT Bearer Token\nfrom auth-service]
        SCOPE[Scope-based\nPermission Check]
        AUDIT2[Audit Trail\nAll mutations]
    end

    CONTRACT --> ENV
    ENV --> AUTH_FLOW
```

### 5.3 Service Communication Patterns

```mermaid
graph TB
    subgraph SYNC["Synchronous — REST / gRPC"]
        R1[User-facing queries\nDashboard data]
        R2[ML inference\nReal-time scoring]
        R3[Configuration reads]
    end

    subgraph ASYNC["Asynchronous — Kafka Events"]
        A1[alarm.triggered]
        A2[yield.excursion.detected]
        A3[ml.anomaly.found]
        A4[agent.action.dispatched]
        A5[robot.command.issued]
    end

    subgraph STREAM["Streaming — WebSocket / SSE"]
        WS1[Live equipment status]
        WS2[SPC chart updates]
        WS3[Agent thinking stream]
        WS4[Robot execution log]
    end

    SYNC --> KONG
    ASYNC --> KAFKA
    STREAM --> WSS
```

---

## 6. Frontend Architecture — React + Vite

### 6.1 Application Structure

```mermaid
graph TB
    subgraph APP["SEMFAB·IQ React Application"]
        subgraph SHELL["App Shell"]
            NAV[Global Navigation]
            THEME[Theme Provider\nDark Industrial]
            AUTH_CTX[Auth Context]
            WS_CTX[WebSocket Context]
        end

        subgraph MODULES["Feature Modules — Lazy Loaded"]
            M1[YMS Dashboard\nYield Management]
            M2[WAT Analytics\nParametric Analysis]
            M3[CP Analytics\nBin Map + Yield]
            M4[SPC / FDC\nProcess Control]
            M5[Defect Analysis\nDMS + ADC + WPA]
            M6[DFM Suite\nLayout + CMP]
            M7[DFT Suite\nQuanTest parity]
            M8[AI Console\nML + Inference]
            M9[Agent Interface\nWisdom AI Chat]
            M10[FAB Control\nRobot Dashboard]
            M11[Reports\nAuto Generation]
            M12[Admin\nConfig + Users]
        end

        subgraph SHARED["Shared Component Library"]
            C1[WaferMap\nCanvas renderer]
            C2[SPC Charts\nRecharts based]
            C3[CorrelationMatrix\nD3 heatmap]
            C4[BinMap\nBitmap blit 684K die]
            C5[TrendChart\nMulti-parameter]
            C6[RCATree\nCollapsible tree]
            C7[AgentChat\nStreaming SSE]
            C8[EquipmentGauge]
            C9[DataGrid\nVirtual scroll]
            C10[ParamSelector]
        end

        subgraph STATE["State Management — Zustand"]
            ST1[authStore]
            ST2[fabStore\nLive equipment]
            ST3[analysisStore]
            ST4[agentStore]
            ST5[notificationStore]
        end
    end

    SHELL --> MODULES
    MODULES --> SHARED
    MODULES --> STATE
```

### 6.2 Module: YMS Dashboard Layout

```mermaid
graph TB
    subgraph YMS["YMS Dashboard — Yield Management System"]
        subgraph TOP["Top Bar KPI Strip"]
            KPI1[Fab Yield Today\n97.3%]
            KPI2[Active Alarms\n3 Critical]
            KPI3[Lots in Process\n142]
            KPI4[Equipment OEE\n88.4%]
        end

        subgraph MAIN["Main Grid — 3 Column"]
            COL1["Left: Yield Trend\n• Rolling 30-day yield\n• Product/node selector\n• Bin pareto chart"]
            COL2["Center: Wafer Map Gallery\n• Active lot wafer maps\n• Click-to-drill CP bins\n• Spatial cluster highlight"]
            COL3["Right: Live Alerts\n• Alarm feed stream\n• Equipment status pills\n• Agent recommendations"]
        end

        subgraph BOTTOM["Bottom Panel"]
            TAB1[Low Yield Lots\nDrill-down RCA]
            TAB2[SPC Violations\nWestern Electric]
            TAB3[Equipment Health\nFleet view]
            TAB4[Agent Activity\nAutonomous actions]
        end
    end

    TOP --> MAIN --> BOTTOM
```

### 6.3 Wafer Bin Map Renderer — Technical Design

The BinMap component supports up to **684,700 dies** using a Canvas bitmap-blit strategy (identical to the existing CP Bin Map system), with dual-mode Canvas/SVG toggle and hard SVG limit at 200K dies.

```mermaid
graph LR
    subgraph BINMAP["BinMap Component Architecture"]
        PROPS[Props:\nlotId, waferId\ndieData, colorMap\nrenderMode]

        subgraph CANVAS_PATH["Canvas Path — > 200K dies"]
            CBM[Build ColorIndex\nUint8Array]
            BLT[createImageData\nbitmap blit]
            PERF[~1.6ms render\n684K die]
        end

        subgraph SVG_PATH["SVG Path — ≤ 200K dies"]
            SVG_R[SVG rect elements\nper die]
            SVG_INT[Interactive click\nhover tooltip]
        end

        THRESH{Die count\n> 200K?}
        PROPS --> THRESH
        THRESH -->|Yes| CANVAS_PATH
        THRESH -->|No| SVG_PATH
    end
```

### 6.4 Agent Chat Interface

```mermaid
sequenceDiagram
    participant ENG as Engineer
    participant UI as React AgentChat
    participant SSE as SSE Stream
    participant AGENT as agent-service
    participant LLM as Wisdom LLM
    participant TOOLS as Tool Call Layer

    ENG->>UI: "Why is lot M900123 showing low yield on M1 layer?"
    UI->>AGENT: POST /agent/query {lot_id, question, context}
    AGENT->>LLM: Compose system prompt + lot context
    LLM->>TOOLS: tool_call: query_yield_data(lot_id)
    TOOLS->>LLM: Yield data + wafer maps
    LLM->>TOOLS: tool_call: query_spc_violations(lot_id)
    TOOLS->>LLM: SPC rule violations
    LLM->>TOOLS: tool_call: search_rca_knowledge(symptom)
    TOOLS->>LLM: Historical RCA matches
    LLM->>SSE: Stream: "Analyzing M1 layer yield loss..."
    SSE->>UI: Render streaming text
    LLM->>SSE: Stream: "3 contributing factors identified..."
    LLM->>SSE: Stream: RCA markdown + action plan
    SSE->>UI: Final answer rendered
    UI->>ENG: Show RCA + [Accept] [Modify] [Escalate]
    ENG->>AGENT: Accept action plan
    AGENT->>LLM: Update knowledge base with confirmed RCA
```

---

## 7. Backend Architecture — Python Flask

### 7.1 Flask Application Factory Pattern

```mermaid
graph TB
    subgraph FACTORY["Flask Application Factory"]
        APP[create_app\nFactory Function]
        subgraph EXTS["Extensions"]
            E1[Flask-SQLAlchemy\nOracle + GP ORM]
            E2[Flask-JWT-Extended\nToken Auth]
            E3[Flask-Limiter\nRate Limiting]
            E4[Flask-CORS\nCORS Headers]
            E5[Flask-SocketIO\nWebSocket]
            E6[Celery\nAsync Tasks]
        end

        subgraph BLUEPRINTS["Blueprint Registration"]
            B1[/api/v1/auth]
            B2[/api/v1/yield]
            B3[/api/v1/wat]
            B4[/api/v1/cp]
            B5[/api/v1/spc]
            B6[/api/v1/defect]
            B7[/api/v1/dfm]
            B8[/api/v1/dft]
            B9[/api/v1/ai]
            B10[/api/v1/agent]
            B11[/api/v1/robot]
        end

        subgraph MIDDLEWARE["Middleware Stack"]
            MW1[Request ID Injection]
            MW2[Audit Logger]
            MW3[Performance Tracer\nOpenTelemetry]
            MW4[Error Handler]
        end
    end

    APP --> EXTS
    APP --> BLUEPRINTS
    APP --> MIDDLEWARE
```

### 7.2 Core Service Pattern — yield-service Example

```mermaid
graph TB
    subgraph YIELD_SVC["yield-service Blueprint Architecture"]
        subgraph ROUTES["Route Layer"]
            R1[GET /yield/summary\nLot / wafer / step]
            R2[GET /yield/trend\nTime series]
            R3[GET /yield/drill\nLow yield RCA drill]
            R4[POST /yield/compare\nLot comparison]
            R5[GET /yield/excursions\nActive excursions]
        end

        subgraph SERVICE["Service Layer"]
            S1[YieldService\nyield_service.py]
            S2[ExcursionDetector\nexcursion_detector.py]
            S3[YieldComparator\nyield_comparator.py]
        end

        subgraph REPO["Repository Layer"]
            GP_REPO[GreenplumRepo\nHistorical yield data]
            ORA_REPO[OracleRepo\nLive WIP + alarms]
            CAS_REPO[CASRepo\nSAS Viya analytics]
            CACHE[RedisCache\n5-min TTL on summaries]
        end

        subgraph TASKS["Celery Async Tasks"]
            T1[compute_yield_summary\nScheduled hourly]
            T2[detect_excursions\nScheduled 5-min]
            T3[generate_yield_report\nOn demand]
        end
    end

    ROUTES --> SERVICE
    SERVICE --> REPO
    SERVICE --> TASKS
```

### 7.3 SAS Viya Python SWAT Integration

```mermaid
graph LR
    subgraph FLASK["Flask Service"]
        API[API Request]
        SVC[Service Method]
    end

    subgraph SWAT["SWAT Client Layer"]
        CONN[CAS Connection Pool\nswat.CAS session]
        UPLOAD[cas.upload_frame\nPandas → CAS]
        PROC[cas.invoke\nSAS Procedure call]
        FETCH[fetch CAS Table\n→ Pandas DataFrame]
    end

    subgraph VIA["SAS Viya"]
        CAS_T[CAS In-Memory Table]
        SAS_P[SAS Analytical Proc\nSPC / Mixed / Forest]
        RESULT[Result Dataset]
    end

    API --> SVC
    SVC --> CONN
    CONN --> UPLOAD
    UPLOAD --> CAS_T
    CAS_T --> SAS_P
    SAS_P --> RESULT
    RESULT --> FETCH
    FETCH --> SVC
    SVC --> API
```

### 7.4 Celery Task Architecture

```mermaid
graph TB
    subgraph CELERY["Celery Distributed Task Queue"]
        subgraph QUEUES["Task Queues"]
            Q1[high-priority\nAlarms, Excursions]
            Q2[analytics\nSPC, ML Inference]
            Q3[batch\nReports, ETL]
            Q4[agent\nLLM Tasks]
        end

        subgraph WORKERS["Worker Pools"]
            W1[4 × High Priority Workers]
            W2[8 × Analytics Workers]
            W3[4 × Batch Workers]
            W4[2 × Agent Workers]
        end

        BEAT[Celery Beat\nScheduler]
        FLOWER[Flower\nMonitoring UI]
    end

    REDIS_BROKER[(Redis Broker)]
    GP_BACKEND[(Greenplum Result Backend)]

    BEAT --> Q1
    Q1 --> W1
    Q2 --> W2
    Q3 --> W3
    Q4 --> W4
    W1 --> REDIS_BROKER
    W2 --> GP_BACKEND
```

---

## 8. SAS Viya Integration — Statistical Processing Engine

### 8.1 SAS Viya Role Architecture

SAS Viya functions as the **certified statistical authority** of the platform. All results from SAS Viya carry statistical certification that raw Python scipy equivalents cannot match for regulatory compliance (ISO 9001, IATF 16949 automotive).

```mermaid
graph TB
    subgraph VIYA["SAS Viya Platform Roles"]
        subgraph STAT["Statistical Computation Authority"]
            ST1[PROC SHEWHART\nXbar-R / XbarS / P-charts]
            ST2[PROC CAPABILITY\nCpk / Cp / PPk / Cpm]
            ST3[PROC MIXED\nVariance Components\nEQPID eta-squared]
            ST4[PROC GLMSELECT\nVariable selection\nLasso / Elastic Net]
            ST5[PROC FACTOR\nPCA / Factor analysis]
            ST6[PROC CORRESP\nMultivariate association]
        end

        subgraph ML_VIYA["SAS Viya ML — Model Studio"]
            ML1[PROC HPFOREST\nRandom Forest yield RCA]
            ML2[PROC GRADBOOST\nXGBoost equivalent]
            ML3[PROC NNET\nNeural Network training]
            ML4[PROC TSMODEL\nWAT time series]
            ML5[PROC CAUSL\nCausal discovery]
            ML6[AutoML Pipeline\nAutomated model selection]
        end

        subgraph VISUAL["SAS Visual Analytics"]
            V1[SPC Control Charts\nInteractive drill]
            V2[Yield Cube OLAP\nPivot analytics]
            V3[Correlation Network\nParameter relationship]
            V4[Wafer Map Overlay\nSpatial yield]
        end
    end
```

### 8.2 SPC Engine Design — DE-SPC Equivalent

```mermaid
flowchart TB
    subgraph SPC_FLOW["SPC Engine — Full Western Electric + WECO Rules"]
        IN[Parameter Data\nWAT / Inline / Defect / CP]

        subgraph PHASE1["Phase 1: Baseline Establishment"]
            B1[Collect Phase-1 data\nmin 25 subgroups]
            B2[PROC SHEWHART\nEstimate sigma, mean]
            B3[Nelson / Western Electric\nRule sensitivity config]
            B4[Set UCL / LCL / CL\nStore to GP SPC_LIMITS table]
        end

        subgraph PHASE2["Phase 2: Real-time Monitoring"]
            M1[New measurement arrives\nOracle RT stream]
            M2[Compare vs stored limits]
            M3{SPC Rule\nViolation?}
            M4[Rule 1: 1pt > 3σ]
            M5[Rule 2: 9 pts same side]
            M6[Rule 3: 6 pts trend]
            M7[Rule 4: 14 pts alternating]
            M8[Rule 5: 2 of 3 > 2σ]
            M9[Rule 6: 4 of 5 > 1σ]
        end

        subgraph ACTION["Action Engine"]
            A1[Write alarm to Oracle]
            A2[Push Kafka alarm event]
            A3[Trigger ML correlation]
            A4[Notify agent-service]
            A5[SAS Viya: PROC CAPABILITY\nRecalculate Cpk]
        end

        subgraph CTRL["Virtual Metrology — ML-based Prediction"]
            VM1[SAS PROC NNET\nTrain on historical]
            VM2[Predict next measurement\nwithout physical measure]
            VM3[Confidence interval\naround prediction]
        end
    end

    IN --> PHASE1 --> PHASE2
    M3 -->|Yes| ACTION
    M3 -->|No| VM1
    VM1 --> VM2 --> VM3
```

### 8.3 WAT Analytics Engine — DE-YMS / DE-G Equivalent

```mermaid
graph TB
    subgraph WAT_ENGINE["WAT Analytics Engine — SAS Viya Powered"]
        subgraph INGEST["WAT Data Intake"]
            I1[STDF Parser → Parquet]
            I2[Parameter mapping\nto device dictionary]
            I3[Outlier pre-filter\nIQR / Z-score]
            I4[Load to GP WAT_RESULT\npartitioned by test_date]
        end

        subgraph STATS["Statistical Analysis Suite"]
            S1[Distribution fitting\nNormal / LogNormal / Bimodal]
            S2[Outlier detection\nMAD / Grubbs test via SAS]
            S3[Parameter correlation\nPearson / Spearman matrix]
            S4[ANOVA / Eta-squared\nEquipment factor analysis]
            S5[OLS What-if Regression\nProcess condition simulation]
            S6[PCA decomposition\nDimensionality reduction]
        end

        subgraph EQUIPMENT["Equipment Factor Analysis"]
            EF1[Multi-way ANOVA\nEQPID as primary factor]
            EF2[Eta-squared ranking\nVariance attribution]
            EF3[Pairwise tool matching\nSPC matching index]
            EF4[Chamber vs chamber\noffset quantification]
            EF5[Equipment health score\nComposite: Z + GOF + CV + Vol]
        end

        subgraph RF["RF Parameter Extensions"]
            RF1[S-parameter import\n.s2p format parsing]
            RF2[De-embedding\nOpen / Short correction]
            RF3[Smith chart generation\nMagnitude / Phase plots]
            RF4[Batch RF analytics\nWafer-level RF sweep]
        end
    end

    INGEST --> STATS
    STATS --> EQUIPMENT
    STATS --> RF
```

---

## 9. Analytics Module Design

### 9.1 YMS — Yield Management System (DE-YMS Equivalent)

```mermaid
graph TB
    subgraph YMS["Yield Management Service — Full DE-YMS Functional Parity"]
        subgraph INTAKE["Multi-Source Data Intake"]
            D1[CP Test Data\nBin map + parametric]
            D2[FT Final Test Data\nProduct-level yield]
            D3[WAT Process Monitor\nParametric + spec]
            D4[Inline Metrology\nCritical dimension + overlay]
            D5[Defect Inspection\nKLA / AMAT scan data]
            D6[WIP Tracking\nLot position in flow]
        end

        subgraph ANALYSIS["Yield Analysis Functions"]
            Y1[Gross / Net Yield calc\nper wafer / lot / step]
            Y2[Yield trend by\nproduct / node / tool]
            Y3[Bin pareto analysis\nfailure mode ranking]
            Y4[Wafer map spatial analysis\nCluster / edge / systematic]
            Y5[Lot comparison\nbaseline vs current]
            Y6[Process step correlation\nYield vs Inline metro]
        end

        subgraph DRILL["Low-Yield Drill-Down RCA"]
            LY1[Yield excursion detection\nShewhart on yield series]
            LY2[Suspect lot flagging\n> 2σ below baseline]
            LY3[Automated factor screening\nSAS PROC GLMSELECT]
            LY4[Equipment eta-squared\nvariance attribution]
            LY5[Defect overlay\nSpatial yield correlation]
            LY6[Agent handoff\nLLM RCA composition]
        end

        subgraph ALARM_SYS["Alarm & Notification System — DE-Alarm Equivalent"]
            AL1[Yield threshold alarm\nAbsolute + trend-based]
            AL2[Bin shift alarm\nBin ratio change detect]
            AL3[Risk lot pre-alert\nPredictive ML flag]
            AL4[Escalation routing\nEngineer → Manager → Robot]
            AL5[Multi-die stacked package\ntraceability alert]
        end
    end

    INTAKE --> ANALYSIS
    ANALYSIS --> DRILL
    DRILL --> ALARM_SYS
```

### 9.2 FDC Engine — DE-FDC / INF-TPC Equivalent

```mermaid
graph TB
    subgraph FDC_ENGINE["FDC Engine — Equipment Fault Detection & Classification"]
        subgraph COLLECT["Trace Data Collection — GEM300 / SECS-II"]
            TC1[Chamber pressure traces]
            TC2[RF power / reflected power]
            TC3[Gas flow MFC readings]
            TC4[Temperature zone profiles]
            TC5[Endpoint detector signals]
            TC6[Robot arm encoder traces]
        end

        subgraph BASELINE["Baseline Model — SAS Viya + INF-TPC Logic"]
            BL1[Segment trace by\nprocess recipe step]
            BL2[Statistical baseline:\nmean / sigma per sensor]
            BL3[Multivariate baseline:\nPCA on sensor ensemble]
            BL4[Unsupervised autoencoder\nReconstruction error baseline]
        end

        subgraph DETECT["Anomaly Detection — INF-TPC Equivalent"]
            AD1[Interval anomaly:\nsensor drift from baseline]
            AD2[PM anomaly:\npost-PM characteristic shift]
            AD3[Amplitude anomaly:\npeak / spike detection]
            AD4[Shape anomaly:\ntrace pattern deviation]
            AD5[Multi-sensor fusion\nComposite anomaly score]
            AD6[Accuracy target: > 95%]
        end

        subgraph CLASSIFY["FDC Classification"]
            FC1[Rule-based classifier\nKnown fault signatures]
            FC2[ML classifier\nSVM / Random Forest]
            FC3[LLM fault narrator\nHuman-readable explanation]
            FC4[Severity scoring:\nCritical / Major / Minor]
        end

        subgraph ACTION2["FDC Response Actions"]
            FA1[Lot on-hold trigger\nvia MES API]
            FA2[Equipment soft-hold\nvia EAP API]
            FA3[PM scheduling request\nvia CMMS API]
            FA4[Agent notification\nfor autonomous RCA]
        end
    end

    COLLECT --> BASELINE --> DETECT --> CLASSIFY --> ACTION2
```

### 9.3 Defect Management — DE-DMS + INF-ADC + INF-WPA

```mermaid
graph TB
    subgraph DEFECT_SYS["Defect Management System"]
        subgraph IMPORT["Defect Data Import"]
            DI1[KLA KLARF format parser]
            DI2[AMAT Compass XML parser]
            DI3[SEM image importer]
            DI4[ADC confidence scores]
        end

        subgraph ADC_MOD["Auto Defect Classification — INF-ADC Equivalent"]
            AC1[Defect image crop\nfrom SEM / optical]
            AC2[CNN / ViT classifier\nPyTorch inference]
            AC3[Defect category output:\nParticle / Scratch / Crystal / Bridge]
            AC4[Confidence score\nthreshold: 0.85]
            AC5[Low-confidence → human review queue]
            AC6[Human correction → retrain loop]
        end

        subgraph WPA_MOD["Wafer Pattern Analysis — INF-WPA Equivalent"]
            WP1[Wafer-level defect map\nfrom KLARF data]
            WP2[Spatial pattern classifier:\nRing / Edge / Scratch / Cluster / Random]
            WP3[Pattern to process-step\ncorrelation lookup]
            WP4[Batch processing:\nhigh-volume production scan]
            WP5[Pattern trend monitoring\nweek-over-week]
        end

        subgraph IMPACT["Yield Impact Analysis"]
            YI1[Defect overlay on\ndie yield map]
            YI2[Critical area analysis\ndefect × sensitivity]
            YI3[Kill ratio estimation]
            YI4[Defect-to-yield correlation\nPearson + regression]
        end
    end

    IMPORT --> ADC_MOD
    IMPORT --> WPA_MOD
    ADC_MOD --> IMPACT
    WPA_MOD --> IMPACT
```

### 9.4 DFM Suite — LayoutVision + PatternScan + CMPEXP + Virtual Yield

```mermaid
graph TB
    subgraph DFM_SUITE["DFM Suite — Design for Manufacturability"]
        subgraph LV["LayoutVision Service"]
            LV1[GDS2 / OASIS layout import]
            LV2[Cross-layer DRC integration]
            LV3[Yield risk scoring by layout region]
            LV4[Overlay with wafer test failure map]
            LV5[Hotspot density visualization]
            LV6[Node: 5nm - 180nm support]
        end

        subgraph PS["PatternScan Service"]
            PS1[Layout pattern extraction\nsliding window scan]
            PS2[Pattern → defect frequency\ncorrelation from DMS]
            PS3[Hotspot pattern ranking\nby yield impact]
            PS4[Design rule check\nfor known critical patterns]
            PS5[Pattern library management\nFoundry-specific rules]
        end

        subgraph CMPEXP_M["CMPEXP Service"]
            CE1[GDS layer stack import]
            CE2[Physical model: contact mechanics\nOxide CMP / Cu Damascene]
            CE3[ML model: neural network\nFitted to process data]
            CE4[Dishing / Erosion prediction\nper die location]
            CE5[Planarity risk map\noverlaid on layout]
            CE6[Recipe recommendation\nfor CMP parameter adjustment]
        end

        subgraph VY["Virtual Yield Service"]
            VY1[Defect density input\nfrom DMS historical]
            VY2[Critical area extraction\nfrom LayoutVision]
            VY3[Poisson yield model:\nY = exp -DA]
            VY4[Murphy / Seeds model\nalternatives]
            VY5[Yield prediction by layer]
            VY6[Design-phase sign-off report]
        end
    end

    LV --> PS
    PS --> VY
    LV --> CMPEXP_M
    CMPEXP_M --> VY
```

### 9.5 DFT Suite — QuanTest + YAD Equivalent

```mermaid
graph TB
    subgraph DFT_SUITE["DFT Suite — Design for Test & Yield-Aware Diagnosis"]
        subgraph QT["QuanTest Service"]
            QT1[ATPG: Automatic Test Pattern Generation]
            QT2[Scan chain insertion automation]
            QT3[Fault coverage analysis:\nStuck-at / Transition / Cell-aware]
            QT4[Test vector optimization:\nminimize test time]
            QT5[BIST: Built-in Self Test insertion]
            QT6[IST: In-System Test for automotive ISO 26262]
            QT7[Simulation & verification interface]
            QT8[MES test program auto-generation]
        end

        subgraph YAD["YAD — Yield-Aware Diagnosis Platform"]
            YD1[Full-volume DFT diagnosis\nno manual sampling]
            YD2[Failing pattern → suspect net/cell\nATPG chain tracing]
            YD3[AI-enhanced localization\nSHAP + pattern match]
            YD4[RCA compression:\nweeks → hours]
            YD5[YMS integration:\nfailure diagnosis ↔ yield management]
            YD6[Design-to-manufacturing\ndata bridge]
            YD7[Foundry mass-production\nvalidation certified]
        end

        subgraph LOOP["Closed-Loop Flow"]
            FL1[Design prevention\nQuanTest DFT insertion]
            FL2[Inline monitoring\nDE-SPC / DE-FDC]
            FL3[Failure diagnosis\nYAD analysis]
            FL4[Knowledge update\nLLM Wisdom Engine]
        end
    end

    QT --> YAD
    YAD --> LOOP
    LOOP --> FL1
```

---

## 10. AI / ML Intelligence Layer

### 10.1 ML Architecture Overview

```mermaid
graph TB
    subgraph ML_LAYER["ML Intelligence Layer"]
        subgraph FEATURE["Feature Engineering Pipeline"]
            FE1[WAT parameter features\n200+ parameters normalized]
            FE2[Equipment context features\nEQPID / chamber / PM age]
            FE3[Process condition features\nRecipe / layer / step]
            FE4[Temporal features\nRolling stats, lag features]
            FE5[Spatial features\nWafer site patterns]
            FE6[Defect features\nDensity / class / pattern]
            STORE[Feature Store\nGreenplum + Redis cache]
        end

        subgraph MODELS["Model Zoo"]
            subgraph YIELD_PRED["Yield Prediction"]
                YP1[XGBoost Yield Predictor\nMain production model]
                YP2[LSTM Time Series\nSequential lot prediction]
                YP3[Ensemble Blender\n0.7 XGB + 0.3 LSTM]
            end

            subgraph ANOMALY["Anomaly Detection"]
                AN1[Isolation Forest\nWAT outlier detection]
                AN2[LSTM Autoencoder\nFDC trace reconstruction]
                AN3[One-Class SVM\nParametric boundary]
                AN4[INF-TPC equivalent\nUnsupervised trace anomaly]
            end

            subgraph CLASSIFY["Classification Models"]
                CL1[Random Forest RCA\nRoot cause classification]
                CL2[CNN Defect Classifier\nINF-ADC equivalent]
                CL3[ViT Wafer Map\nPattern classification]
                CL4[GNN Equipment Graph\nTool-to-yield influence]
            end

            subgraph CAUSAL["Causal AI — Beyond Correlation"]
                CA1[DoWhy Causal Graph\nProcess → Yield DAG]
                CA2[SHAP Explainer\nFeature attribution]
                CA3[Counterfactual generator\nWhat-if scenarios]
                CA4[SAS PROC CAUSL\nStatistical causal discovery]
            end
        end

        subgraph MLOPS["MLOps Pipeline"]
            MO1[MLflow Experiment Tracking]
            MO2[Model Registry\nVersioning + Staging]
            MO3[A/B Model Testing\nShadow deployment]
            MO4[Drift Detection\nKS test on features]
            MO5[Auto-retrain trigger\nDrift threshold breach]
            MO6[SAS Model Manager\nCertified model governance]
        end
    end

    FEATURE --> MODELS
    MODELS --> MLOPS
```

### 10.2 Real-Time ML Inference Pipeline

```mermaid
sequenceDiagram
    participant FAB as FAB Data Stream
    participant KAFKA as Kafka
    participant ETL2 as ETL Worker
    participant FS as Feature Store
    participant TRITON as Triton Inference Server
    participant GP2 as Greenplum Results
    participant ALERT as Alert Engine
    participant AGENT2 as Agentic AI

    FAB->>KAFKA: New WAT measurement batch
    KAFKA->>ETL2: Consume & parse
    ETL2->>FS: Compute features (Redis cache)
    FS->>TRITON: Batch inference request
    TRITON->>TRITON: XGBoost yield prediction
    TRITON->>TRITON: Anomaly score computation
    TRITON->>TRITON: SHAP attribution
    TRITON->>GP2: Write predictions + explanations
    TRITON->>ALERT: High anomaly score → alert
    ALERT->>AGENT2: Context-rich anomaly event
    AGENT2->>AGENT2: LLM: compose RCA narrative
    AGENT2->>ALERT: Action recommendation
```

### 10.3 Equipment Health Scoring — Composite Model

The equipment health score is computed identically to the established composite formula used in the team's SPC Tool Health Intelligence module:

```mermaid
graph LR
    subgraph HEALTH["Equipment Health Score — Composite Model"]
        Z[Z-score component\n35% weight\nParameter mean deviation]
        GOF[GOF component\n30% weight\nDistribution fit quality]
        CV[CV Stability\n20% weight\nCoefficient of variation trend]
        VOL[Volume component\n15% weight\nTest throughput consistency]

        COMPOSITE[Composite Score\n0-100]

        Z -->|×0.35| COMPOSITE
        GOF -->|×0.30| COMPOSITE
        CV -->|×0.20| COMPOSITE
        VOL -->|×0.15| COMPOSITE

        COMPOSITE --> TIER{Score Tier}
        TIER -->|90-100| GREEN[Healthy]
        TIER -->|70-89| YELLOW[Watch]
        TIER -->|50-69| ORANGE[Degraded]
        TIER -->|< 50| RED[Critical — Action Required]
    end
```

---

## 11. LLM Agentic AI — Knowledge Accumulation & Wisdom Engine

### 11.1 Wisdom Engine Architecture

This is the most strategically differentiated component of SEMFAB·IQ. The Wisdom Engine transforms raw analytical results into **accumulated institutional knowledge** that grows smarter with every event, every engineer correction, and every autonomous action.

```mermaid
graph TB
    subgraph WISDOM["Wisdom Engine — LLM Knowledge Accumulation System"]
        subgraph INPUT["Knowledge Input Sources"]
            K1[ML Model Outputs\nPredictions + SHAP]
            K2[SAS Viya Results\nStatistical findings]
            K3[Engineer Actions\nConfirmed RCA decisions]
            K4[Historical RCA Records\nKnowledge base seed]
            K5[External Literature\nProcess physics papers]
            K6[Equipment Manuals\nTool knowledge]
            K7[Foundry Process Specs\nPDK documentation]
        end

        subgraph KG["Knowledge Graph — Neo4j"]
            NODE1[Equipment Nodes\nTool-specific knowledge]
            NODE2[Process Step Nodes\nStep-level cause-effect]
            NODE3[Parameter Nodes\nMetric relationship graph]
            NODE4[Defect Pattern Nodes\nSpatial signature library]
            NODE5[RCA Nodes\nConfirmed root causes]
            NODE6[Action Nodes\nCorrective action library]
            EDGE1[CAUSES relationship]
            EDGE2[CORRELATES_WITH relationship]
            EDGE3[RESOLVES relationship]
            EDGE4[SIMILAR_TO relationship]
        end

        subgraph LLM_CORE["LLM Core — Multi-Model Ensemble"]
            LLM1[Domain LLM\nFine-tuned on fab knowledge]
            LLM2[RAG Engine\nRetrieval + Generation]
            LLM3[Chain-of-Thought\nMulti-step reasoning]
            LLM4[Self-Critique\nHallucination check]
            EMBED[Embedding Store\nChromaDB / pgvector]
        end

        subgraph ACCUM["Knowledge Accumulation Loop"]
            AC1[Event occurs:\nYield drop detected]
            AC2[Agent queries\nknowledge graph + RAG]
            AC3[LLM generates\nRCA hypothesis]
            AC4[Engineer validates\nor corrects]
            AC5[Correction stored\nback to knowledge graph]
            AC6[Confidence updated\non related RCA nodes]
            AC7[Similar future events\nget better answers faster]
        end
    end

    INPUT --> KG
    KG --> LLM_CORE
    LLM_CORE --> ACCUM
    ACCUM --> KG
```

### 11.2 Agentic AI Orchestration — LangGraph Architecture

```mermaid
graph TB
    subgraph AGENT_ORCH["Agentic Orchestrator — LangGraph State Machine"]
        subgraph STATES["Agent States"]
            S_IDLE[IDLE\nWaiting for events]
            S_OBSERVE[OBSERVE\nData collection]
            S_ANALYZE[ANALYZE\nPattern recognition]
            S_HYPOTHESIZE[HYPOTHESIZE\nRCA generation]
            S_VERIFY[VERIFY\nHypothesis validation]
            S_RECOMMEND[RECOMMEND\nAction plan generation]
            S_EXECUTE[EXECUTE\nAutonomous action]
            S_LEARN[LEARN\nKnowledge update]
        end

        subgraph TRANSITIONS["State Transitions"]
            T1[Event trigger → OBSERVE]
            T2[Data complete → ANALYZE]
            T3[Pattern found → HYPOTHESIZE]
            T4[Hypothesis formed → VERIFY]
            T5[High confidence → RECOMMEND]
            T6[Approval received → EXECUTE]
            T7[Action complete → LEARN]
            T8[Low confidence → human escalation]
        end

        subgraph TOOLS["Agent Tool Registry — MCP Protocol"]
            TL1[query_yield_data\nGreenplum query]
            TL2[query_spc_violations\nOracle real-time]
            TL3[run_ml_inference\nTriton server]
            TL4[search_knowledge_base\nRAG + Neo4j]
            TL5[query_defect_maps\nDMS integration]
            TL6[get_equipment_status\nFDC real-time]
            TL7[issue_lot_hold\nMES API]
            TL8[adjust_recipe\nEAP API]
            TL9[schedule_pm\nCMMS API]
            TL10[notify_engineer\nSlack / Email / SMS]
            TL11[command_robot\nHW Robot API]
            TL12[update_knowledge\nKnowledge Graph write]
        end
    end

    S_IDLE --> S_OBSERVE
    S_OBSERVE --> S_ANALYZE
    S_ANALYZE --> S_HYPOTHESIZE
    S_HYPOTHESIZE --> S_VERIFY
    S_VERIFY -->|Confidence > 0.85| S_RECOMMEND
    S_VERIFY -->|Confidence < 0.85| S_ANALYZE
    S_RECOMMEND -->|Auto-approved| S_EXECUTE
    S_RECOMMEND -->|Needs approval| HUMAN_LOOP[Human Review]
    HUMAN_LOOP -->|Approved| S_EXECUTE
    HUMAN_LOOP -->|Rejected| S_LEARN
    S_EXECUTE --> S_LEARN
    S_LEARN --> S_IDLE
```

### 11.3 RCA Wisdom — Complete Flow

```mermaid
flowchart TD
    EV[Yield Excursion Event\nLot M900XXX — Yield drop 15%]

    subgraph GATHER["Phase 1: Evidence Gathering — Agent Autonomous"]
        G1[Fetch lot WAT data\nAll 200+ parameters]
        G2[Fetch CP bin map\nSpatial die yield pattern]
        G3[Fetch inline metro data\nLast 5 process steps]
        G4[Fetch defect maps\nKLA inspection results]
        G5[Fetch FDC traces\nEquipment sensor data]
        G6[Fetch equipment history\nPM records / alarm log]
    end

    subgraph REASON["Phase 2: Multi-Layer Reasoning — LLM Chain-of-Thought"]
        R1[Layer 1: Statistical screening\nSAS PROC GLMSELECT feature ranking]
        R2[Layer 2: ML attribution\nSHAP values per factor]
        R3[Layer 3: Causal graph query\nDoWhy DAG inference]
        R4[Layer 4: Knowledge graph lookup\nSimilar historical RCAs]
        R5[Layer 5: LLM synthesis\nNarrative hypothesis generation]
        R6[Layer 6: Self-critique\nHallucination & consistency check]
    end

    subgraph OUTPUT["Phase 3: RCA Output"]
        O1[Primary Root Cause\nConfidence: 94%]
        O2[Contributing Factors\nRanked by eta-squared]
        O3[Physical Mechanism\nProcess physics explanation]
        O4[Falsifiable Verification Steps\nWhat to measure/check]
        O5[Corrective Action Plan\nPrioritized recommendations]
        O6[Similar Historical Cases\nLinked from knowledge graph]
    end

    EV --> GATHER
    GATHER --> REASON
    REASON --> OUTPUT
```

### 11.4 LLM Fine-Tuning Strategy

```mermaid
graph TB
    subgraph FINETUNE["LLM Fine-Tuning Pipeline"]
        subgraph BASE["Base Model Selection"]
            BM1[Llama-3 70B\nOpen-weight base]
            BM2[Qwen2.5 72B\nChinese + English bilingual]
            BM3[Domain Selector\nby deployment region]
        end

        subgraph DATA["Training Data Curation"]
            TD1[Historical RCA records\nEngineer-validated only]
            TD2[Process physics literature\nParsed + chunked]
            TD3[Equipment manuals\nStructured extraction]
            TD4[SPC investigation reports\nFab-internal documents]
            TD5[Synthetic data generation\nEdge case augmentation]
        end

        subgraph TUNE["Fine-Tuning Approach"]
            FT1[LoRA / QLoRA\nParameter-efficient fine-tuning]
            FT2[Domain vocabulary\nSemiconductor term injection]
            FT3[Instruction tuning\nRCA task format]
            FT4[RLHF\nEngineer feedback rewards]
            FT5[Constitutional AI\nSafety + accuracy constraints]
        end

        subgraph EVAL["Evaluation — Fab Domain Benchmarks"]
            EV1[RCA accuracy\nvs engineer gold standard]
            EV2[Hallucination rate\non process parameters]
            EV3[Response latency\n< 5s for 95th percentile]
            EV4[Bilingual quality\nEng + Chinese Technical]
        end
    end

    BASE --> DATA
    DATA --> TUNE
    TUNE --> EVAL
    EVAL -->|Pass| DEPLOY[Deploy to inference-service]
    EVAL -->|Fail| DATA
```

### 11.5 SemiMind++ — Natural Language Analytics Interface

SEMFAB·IQ extends the Semitronix SemiMind concept into a full-capability **Natural Language Analytics** interface:

```mermaid
graph TB
    subgraph NL_INTERFACE["SemiMind++ — NL Analytics Interface"]
        subgraph CAPABILITIES["Supported Natural Language Commands"]
            NL1["'Show me the yield trend for product ABC\nin the last 30 days'"]
            NL2["'Which equipment has the highest impact\non GOF parameter degradation?'"]
            NL3["'Compare lot M900123 WAT results\nto the product baseline'"]
            NL4["'What is the most likely root cause\nof the M1 layer yield loss?'"]
            NL5["'Generate SPC report for\nall critical parameters on tool CVD-01'"]
            NL6["'Put lot M900456 on hold\nand notify the process engineer'"]
            NL7["'Schedule PM for equipment Etch-03\nbased on current health score'"]
            NL8["'Run what-if simulation:\nif NBL Drive-in temp increases 2°C'"]
        end

        subgraph PIPELINE["Processing Pipeline"]
            NLP1[Intent Classification\nQuery / Analysis / Action]
            NLP2[Entity Extraction\nLot / Equipment / Parameter / Date]
            NLP3[Tool Selection\nRight API to call]
            NLP4[Result Formatting\nChart / Table / Narrative]
            NLP5[Action Confirmation\nfor write operations]
        end

        subgraph OUTPUT2["Output Modalities"]
            OP1[Streaming text narrative\nSSE to UI]
            OP2[Auto-generated charts\nRendered in chat]
            OP3[Downloadable reports\nPDF / Excel]
            OP4[Action execution\nWith audit trail]
        end
    end
```

---

## 12. Autonomous FAB Operation System

### 12.1 Software Robot — FAB Process Automation

```mermaid
graph TB
    subgraph SW_ROBOT["Software Robot Controller — FAB Automation"]
        subgraph MES_CTRL["MES Integration — Lot & WIP Control"]
            MES1[Lot creation / traveler]
            MES2[Lot hold / release\nwith reason code]
            MES3[Recipe dispatch\nstep-by-step]
            MES4[WIP priority adjustment\nhot lot management]
            MES5[Scrap authorization\nwith yield prediction]
        end

        subgraph EAP_CTRL["EAP Integration — Equipment Recipe Control"]
            EAP1[Recipe parameter\nread / write via GEM300]
            EAP2[Run-to-run controller\nAPC setpoint adjustment]
            EAP3[Equipment reservation\nfor priority lots]
            EAP4[Process abort\nif FDC critical alarm]
            EAP5[SECS-II command\ndirect equipment instruction]
        end

        subgraph APC["Advanced Process Control — Run-to-Run"]
            APC1[EWMA controller\nExponentially weighted]
            APC2[Model-based controller\nSAS PROC prediction]
            APC3[Die-to-die control\nSpatial uniformity]
            APC4[Lot-to-lot feedback\nprocess drift correction]
            APC5[Feed-forward control\nincoming metrology]
        end

        subgraph CMMS["CMMS Integration — Maintenance Automation"]
            CM1[PM scheduling\nbased on health score]
            CM2[Spare parts ordering\nauto-trigger on degradation]
            CM3[Maintenance work order\nauto-generation]
            CM4[Post-PM qualification\nrequirements dispatch]
        end
    end
```

### 12.2 Hardware Robot Integration

```mermaid
graph TB
    subgraph HW_ROBOT["Hardware Robot Interface — Physical FAB Automation"]
        subgraph WAFER_TRANSPORT["Wafer Transport Robots — AMHS Integration"]
            WT1[OHT / OHS / AGV control\nMaterial handling commands]
            WT2[Lot dispatch commands\ntool → tool routing]
            WT3[Emergency re-route\nif tool alarm triggers]
            WT4[Stocker management\nwafer cassette control]
            WT5[SEMI E84 / E87 / E40 protocol]
        end

        subgraph PROBER_ROBOT["Automated Prober Control"]
            PR1[Prober recipe load\nGEM300 command]
            PR2[Wafer alignment\npre-probe auto-alignment]
            PR3[Needle contact\nforce calibration]
            PR4[Die skip map\nload from CP results]
            PR5[Auto-unload on alarm\nresult: fail-safe]
        end

        subgraph INSPECTION_ROBOT["Automated Inspection Dispatch"]
            IR1[KLA / AMAT tool\nautomated job dispatch]
            IR2[Recipe selection\nbased on process step]
            IR3[Sampling plan\nAQL-based auto-selection]
            IR4[Result upload\nauto-push to defect DB]
        end

        subgraph SAFETY["Robot Safety Framework"]
            SF1[Collision avoidance\nSense-and-stop]
            SF2[Human detection\nLiDAR + camera fusion]
            SF3[Emergency stop\nE-stop network]
            SF4[Audit trail\nAll robot actions logged]
            SF5[Human override\nalways takes priority]
        end
    end
```

### 12.3 Autonomous FAB Loop — Complete Cycle

```mermaid
flowchart LR
    subgraph SENSE["Sense"]
        S1[Equipment sensors\nReal-time FDC]
        S2[Metrology data\nInline measurements]
        S3[Test results\nWAT / CP / FT]
    end

    subgraph THINK["Think — AI Layer"]
        T1[SAS Viya:\nStatistical analysis]
        T2[ML Models:\nPrediction + anomaly]
        T3[LLM Agent:\nRCA + action plan]
    end

    subgraph DECIDE["Decide — Confidence-Gated"]
        D1{Confidence\n≥ 95%?}
        D2[Auto-execute\nNo human needed]
        D3{Confidence\n80-94%?}
        D4[Recommend\nEngineer approves]
        D5{Confidence\n< 80%?}
        D6[Escalate\nMandatory human review]
    end

    subgraph ACT["Act — Robot Execution"]
        A1[SW Robot:\nMES / EAP / APC commands]
        A2[HW Robot:\nTransport / Prober / Inspection]
        A3[Notify:\nEngineer / Slack / Dashboard]
    end

    subgraph LEARN2["Learn"]
        L1[Log outcome to GP]
        L2[Update knowledge graph]
        L3[Retrain ML if needed]
        L4[Improve confidence\non similar future events]
    end

    SENSE --> THINK
    THINK --> DECIDE
    D1 -->|Yes| D2
    D1 -->|No| D3
    D3 -->|Yes| D4
    D3 -->|No| D5
    D5 -->|Yes| D6
    D2 --> ACT
    D4 --> ACT
    D6 --> ACT
    ACT --> LEARN2
    LEARN2 --> SENSE
```

### 12.4 Human-Robot Collaboration Model

```mermaid
graph TB
    subgraph COLLAB["Human-AI-Robot Collaboration Framework"]
        subgraph LEVELS["Automation Levels — Progressive Autonomy"]
            LVL1["Level 1 — Assisted\nAI suggests, engineer decides and acts"]
            LVL2["Level 2 — Semi-Autonomous\nAI decides, engineer approves, SW robot acts"]
            LVL3["Level 3 — Supervised Autonomous\nAI decides and acts, engineer monitors\nAny engineer can override"]
            LVL4["Level 4 — Full Autonomous\nAI + SW + HW Robots operate FAB\nEngineers manage exceptions only"]
        end

        subgraph GUARDRAILS["Safety Guardrails — Non-Negotiable"]
            G1[Human always can override any robot action]
            G2[Scrap decisions always require human sign-off]
            G3[Recipe changes > 5% require engineer approval]
            G4[All autonomous actions audit-logged]
            G5[Emergency stop accessible from any UI]
            G6[AI explains every recommendation in plain language]
        end

        subgraph METRICS["Autonomy KPIs"]
            KP1[Mean Time to Respond MTTR\nAlarm → Corrective Action]
            KP2[Autonomous Resolution Rate\n% issues resolved without human]
            KP3[AI Accuracy Rate\n% autonomous actions confirmed correct]
            KP4[Engineer Productive Hours\nFree from routine monitoring]
        end
    end
```

---

## 13. Security, Compliance & SEMI Standards

### 13.1 Security Architecture

```mermaid
graph TB
    subgraph SECURITY["Security Architecture"]
        subgraph IDENTITY["Identity & Access"]
            ID1[LDAP / Active Directory\nEnterprise SSO]
            ID2[OAuth 2.0 / OIDC\nToken-based auth]
            ID3[JWT with short expiry\n15-min access tokens]
            ID4[RBAC\nRole-based permission model]
            ID5[MFA enforcement\nfor privileged actions]
        end

        subgraph RBAC_DEF["RBAC Role Definitions"]
            R_OPS[FAB_OPERATOR\nRead-only dashboards]
            R_ENG[PROCESS_ENGINEER\nAnalytics + recommendations]
            R_SR[SENIOR_ENGINEER\nAnalytics + approve actions]
            R_MGR[MANAGER\nAll analytics + reports]
            R_ADMIN[SYSTEM_ADMIN\nFull system access]
            R_ROBOT[ROBOT_SERVICE\nAction execution only]
            R_AI[AI_AGENT\nTool calls within scope]
        end

        subgraph NETWORK["Network Security"]
            NW1[FAB equipment VLAN\nisolated from IT network]
            NW2[Data diode\nFAB → Analytics one-way]
            NW3[TLS 1.3 everywhere\nall service communication]
            NW4[mTLS between\nmicroservices]
            NW5[WAF on API gateway\nOWASP rule set]
        end

        subgraph DATA_SEC["Data Security"]
            DS1[Encryption at rest\nGreenplum AES-256]
            DS2[Column-level masking\nPII / IP fields]
            DS3[Audit log immutable\nall data access logged]
            DS4[Data residency control\nregion-locked tenants]
        end
    end
```

### 13.2 SEMI Standards Compliance

| Standard | Purpose | Implementation |
|----------|---------|----------------|
| **SEMI E5** | SECS-II Message protocol | GEM300 adapter in ETL service |
| **SEMI E30** | Generic Equipment Model (GEM) | EAP integration layer |
| **SEMI E37** | HSMS communications | Kafka HSMS bridge |
| **SEMI E40** | Process job management | SW Robot MES commands |
| **SEMI E58** | Automated reliability, availability, and maintainability | Equipment health service |
| **SEMI E84** | Enhanced carrier handoff | AMHS robot controller |
| **SEMI E87** | Carrier management | Stocker integration |
| **SEMI E116** | Equipment performance tracking | OEE calculation service |
| **SEMI E142** | Substrate mapping | CP bin map format export |
| **SEMI G85** | Wafer map format | CP/WAT map interchange |

---

## 14. Deployment Architecture

### 14.1 Kubernetes Cluster Design

```mermaid
graph TB
    subgraph K8S["Kubernetes Production Cluster"]
        subgraph NS_PROD["Namespace: semfab-prod"]
            subgraph CORE_PODS["Core Service Pods"]
                P1[yield-svc\n3 replicas HPA]
                P2[spc-fdc-svc\n3 replicas HPA]
                P3[wat-analytics-svc\n3 replicas]
                P4[defect-svc\n2 replicas]
                P5[ai-inference-svc\n4 replicas GPU]
            end

            subgraph AI_PODS["AI Service Pods"]
                AP1[agent-svc\n2 replicas]
                AP2[llm-svc\n2 replicas A100 GPU]
                AP3[robot-ctrl-svc\n2 replicas]
                AP4[adc-svc\n2 replicas GPU]
            end
        end

        subgraph NS_INFRA["Namespace: semfab-infra"]
            I1[Kafka Cluster\n3 broker pods]
            I2[Redis Cluster\n6 pods]
            I3[Elasticsearch\n3 pods log]
            I4[Prometheus + Grafana]
            I5[Jaeger Tracing]
        end

        subgraph INGRESS["Ingress Layer"]
            ING[Nginx Ingress Controller]
            CERT[cert-manager TLS]
        end
    end

    subgraph EXTERNAL["External Services"]
        GP_EXT[(Greenplum\nDedicated Cluster)]
        ORA_EXT[(Oracle DB\nRAC Cluster)]
        CAS_EXT[SAS Viya\nManaged Service]
        TRITON[Triton Inference\nServer]
    end

    ING --> NS_PROD
    NS_PROD --> NS_INFRA
    NS_PROD --> EXTERNAL
```

### 14.2 Observability Stack

```mermaid
graph LR
    subgraph OBS["Observability — Full Three Pillars"]
        subgraph METRICS2["Metrics — Prometheus + Grafana"]
            M1[Service latency p50/p95/p99]
            M2[ML inference throughput]
            M3[Kafka consumer lag]
            M4[DB query performance]
            M5[Agent action success rate]
        end

        subgraph LOGS["Logging — ELK Stack"]
            L1[Structured JSON logs\nall services]
            L2[Audit log stream\nimmutable S3]
            L3[Error aggregation\nalert on anomaly]
            L4[Robot action log\nfull command trace]
        end

        subgraph TRACE["Tracing — Jaeger / OpenTelemetry"]
            T1[Distributed trace\ncross-service requests]
            T2[LLM reasoning trace\ntool call attribution]
            T3[Agent decision trace\nfull thought chain]
        end

        subgraph ALERTS2["Alerting — PagerDuty"]
            AL1[SLA breach\nlatency > threshold]
            AL2[Service down\nhealth check fail]
            AL3[Data pipeline lag\nKafka > 5 min]
            AL4[AI drift alert\nmodel accuracy drop]
        end
    end
```

---

## 15. API Design Reference

### 15.1 Core API Endpoints

```mermaid
graph TB
    subgraph API["REST API Surface — v1"]
        subgraph YIELD_API["Yield Service /api/v1/yield"]
            YA1[GET /summary\n?lot_id&wafer_id&step]
            YA2[GET /trend\n?product&node&days]
            YA3[GET /excursions\n?severity&status]
            YA4[POST /rca-drill\nbody: lot_id + symptom]
            YA5[GET /compare\n?baseline_lot&target_lot]
        end

        subgraph SPC_API["SPC Service /api/v1/spc"]
            SA1[GET /charts\n?parameter&tool&period]
            SA2[GET /violations\n?rule&severity&date_range]
            SA3[GET /capability\n?parameter&lot_range]
            SA4[POST /update-limits\nbody: parameter + new_limits]
            SA5[GET /virtual-metro\n?equipment&next_lot]
        end

        subgraph AGENT_API["Agent Service /api/v1/agent"]
            AA1[POST /query\nbody: question + context]
            AA2[GET /stream/{session_id}\nSSE stream]
            AA3[POST /approve-action\nbody: action_id]
            AA4[POST /reject-action\nbody: action_id + reason]
            AA5[GET /knowledge-search\n?symptom&category]
            AA6[GET /history\n?limit&offset]
        end

        subgraph ROBOT_API["Robot Control /api/v1/robot"]
            RA1[POST /lot-hold\nbody: lot_id + reason]
            RA2[POST /recipe-adjust\nbody: equipment + delta]
            RA3[POST /pm-schedule\nbody: equipment + urgency]
            RA4[GET /action-queue\nPending robot actions]
            RA5[GET /action-log\nCompleted action history]
        end
    end
```

### 15.2 WebSocket Events

| Event Name | Direction | Payload | Description |
|-----------|-----------|---------|-------------|
| `alarm.critical` | Server→Client | `{equipment_id, alarm_code, severity, lot_id}` | Real-time critical alarm push |
| `yield.excursion` | Server→Client | `{lot_id, current_yield, baseline, delta_pct}` | Yield drop alert |
| `agent.thinking` | Server→Client | `{session_id, step, content}` | Streaming agent reasoning |
| `spc.violation` | Server→Client | `{parameter, rule, value, timestamp}` | SPC rule breach |
| `equipment.status` | Server→Client | `{equipment_id, status, health_score}` | Equipment status update |
| `robot.action` | Server→Client | `{action_type, target, status, result}` | Robot action execution update |
| `chat.message` | Client→Server | `{session_id, message, context}` | User sends agent query |

---

## 16. Data Schema Design

### 16.1 Knowledge Graph Schema — Neo4j

```mermaid
graph TB
    subgraph NEO4J["Knowledge Graph — Nodes and Relationships"]
        subgraph NODES["Node Types"]
            N1["(:Equipment)\nequipment_id, type, chamber\nhealth_score, pm_interval"]
            N2["(:Parameter)\nparam_id, name, unit\nspec_high, spec_low, criticality"]
            N3["(:ProcessStep)\nstep_id, layer, tool_type\nnominal_values"]
            N4["(:DefectPattern)\npattern_id, spatial_class\nprocess_correlation"]
            N5["(:RootCause)\ncause_id, category, mechanism\nconfidence, occurrence_count"]
            N6["(:CorrectiveAction)\naction_id, type, description\nsuccess_rate, effort_level"]
            N7["(:Product)\nproduct_id, node, type\ntarget_yield"]
            N8["(:LotEvent)\nevent_id, lot_id, symptom\nconfirmed_cause, outcome"]
        end

        subgraph RELS["Relationship Types"]
            R1["(:Equipment)-[:PROCESSES]->(:ProcessStep)"]
            R2["(:ProcessStep)-[:MEASURES]->(:Parameter)"]
            R3["(:Parameter)-[:CAUSES_WHEN_OOC]->(:RootCause)"]
            R4["(:RootCause)-[:FIXED_BY]->(:CorrectiveAction)"]
            R5["(:DefectPattern)-[:INDICATES]->(:RootCause)"]
            R6["(:LotEvent)-[:RESOLVED_BY]->(:CorrectiveAction)"]
            R7["(:Equipment)-[:HEALTH_AFFECTS]->(:Parameter)"]
            R8["(:RootCause)-[:SIMILAR_TO]->(:RootCause)"]
        end
    end
```

---

## 17. Implementation Roadmap

### 17.1 Phased Delivery Plan

```mermaid
gantt
    title SEMFAB·IQ Implementation Roadmap — 24 Month Plan
    dateFormat  YYYY-MM
    axisFormat  %Y-%m

    section Phase 1 — Foundation (M1-M6)
    Data Infrastructure Setup     :p1a, 2025-01, 2M
    ETL Pipeline (WAT/CP/Inline)  :p1b, 2025-02, 2M
    Auth + API Gateway            :p1c, 2025-01, 1M
    React Shell + Core UI         :p1d, 2025-02, 2M
    YMS Dashboard v1              :p1e, 2025-03, 3M

    section Phase 2 — Analytics Core (M4-M10)
    SAS Viya SPC Engine           :p2a, 2025-04, 2M
    WAT Analytics Service         :p2b, 2025-04, 3M
    CP Analytics + BinMap         :p2c, 2025-05, 2M
    FDC Engine                    :p2d, 2025-06, 3M
    DE-G General Analytics        :p2e, 2025-07, 2M
    Defect DMS + ADC              :p2f, 2025-08, 3M

    section Phase 3 — Intelligence (M8-M16)
    ML Model Suite                :p3a, 2025-08, 3M
    INF-TPC Trace Anomaly         :p3b, 2025-09, 2M
    DFM Suite (Layout+CMP)        :p3c, 2025-10, 3M
    DFT QuanTest + YAD            :p3d, 2025-11, 3M
    LLM Wisdom Engine v1          :p3e, 2025-12, 4M

    section Phase 4 — Agentic AI (M14-M20)
    LangGraph Agent Orchestrator  :p4a, 2026-02, 3M
    Knowledge Graph (Neo4j)       :p4b, 2026-02, 2M
    SemiMind++ NL Interface       :p4c, 2026-04, 2M
    SW Robot MES/EAP Integration  :p4d, 2026-05, 3M

    section Phase 5 — Autonomous FAB (M18-M24)
    HW Robot AMHS Integration     :p5a, 2026-06, 3M
    APC Run-to-Run Controller     :p5b, 2026-07, 2M
    Full Autonomous Loop          :p5c, 2026-09, 3M
    Production Certification      :p5d, 2026-11, 2M
```

### 17.2 Team Structure

```mermaid
graph TB
    subgraph TEAM["Development Team Structure"]
        subgraph LEAD["Engineering Leadership"]
            CTO[Chief Architect\nSystem Design + AI Strategy]
            TL1[Backend Lead\nFlask + Microservices]
            TL2[Frontend Lead\nReact + Vite]
            TL3[Data Engineering Lead\nGreenplum + Oracle + SAS]
            TL4[AI / ML Lead\nML + LLM + Agent]
            TL5[FAB Integration Lead\nGEM300 + Robot APIs]
        end

        subgraph DEVS["Development Teams"]
            BE[Backend Team × 6\nFlask Microservices]
            FE[Frontend Team × 4\nReact + Vite]
            DE[Data Team × 4\nETL + DW + SAS]
            AI[AI Team × 5\nML + LLM + Agent]
            FAB[FAB Integration × 3\nGEM300 + Robots]
            QA[QA / DevOps × 4\nK8s + CI/CD + Test]
        end
    end
```

---

## 18. Commercial Licensing Model

### 18.1 Product SKUs

```mermaid
graph TB
    subgraph COMMERCIAL["SEMFAB·IQ — Commercial Licensing Tiers"]
        subgraph STARTER["Starter — Analytics Foundation"]
            ST_F1[DE-G General Analytics equivalent]
            ST_F2[WAT / CP data ingestion]
            ST_F3[SPC monitoring — 200 parameters]
            ST_F4[Basic yield dashboards]
            ST_F5[Standard reports]
            ST_P[USD 80K/year\nup to 2 product lines]
        end

        subgraph PRO["Professional — Full Analytics Suite"]
            PR_F1[All Starter features]
            PR_F2[DE-YMS full yield management]
            PR_F3[DE-FDC + DE-DMS]
            PR_F4[ML anomaly detection]
            PR_F5[DFM lite suite]
            PR_F6[INF-ADC defect classification]
            PR_P[USD 250K/year\nup to 10 product lines]
        end

        subgraph ENT["Enterprise — AI Intelligence"]
            EN_F1[All Professional features]
            EN_F2[LLM Wisdom Engine]
            EN_F3[Agentic AI RCA]
            EN_F4[DFT QuanTest+YAD equivalent]
            EN_F5[Full DFM suite]
            EN_F6[SemiMind++ NL interface]
            EN_F7[SW Robot MES/EAP integration]
            EN_P[USD 800K/year\nunlimited products]
        end

        subgraph ULTIMATE["Autonomous FAB — Full Robot Suite"]
            UL_F1[All Enterprise features]
            UL_F2[HW Robot AMHS integration]
            UL_F3[Full autonomous loop]
            UL_F4[Multi-fab multi-tenant]
            UL_F5[Custom LLM fine-tuning]
            UL_F6[Dedicated SRE support]
            UL_P[USD 2M+/year\nCustom negotiation]
        end
    end
```

### 18.2 Revenue Model

| Stream | Description | Target |
|--------|-------------|--------|
| **SaaS License** | Annual subscription by tier | 60% of revenue |
| **Implementation** | Professional services for onboarding | 20% of revenue |
| **Training** | Engineer certification programs | 10% of revenue |
| **Custom AI** | Bespoke LLM fine-tuning + knowledge base | 10% of revenue |

---

## Appendix A — Technology Stack Summary

| Layer | Component | Technology | Rationale |
|-------|-----------|------------|-----------|
| Frontend | SPA Application | React 18 + Vite | Fast HMR, code splitting, established team stack |
| Frontend | State Management | Zustand | Lightweight, no boilerplate, fab data store |
| Frontend | Charts | Recharts + D3 | Recharts for standard, D3 for custom (wafer maps) |
| Frontend | Wafer Map | Canvas API | 684K die bitmap-blit at ~1.6ms |
| Backend | API Framework | Python Flask | Lightweight, blueprint-modular, SWAT compatible |
| Backend | Async Tasks | Celery + Redis | Distributed task queue for analytics |
| Backend | ORM | SQLAlchemy | Oracle + Greenplum dual adapter |
| Backend | WebSocket | Flask-SocketIO | Real-time alarm push |
| Data Warehouse | Historical DW | Greenplum | MPP columnar analytics, pg-compatible |
| Real-time DB | OLTP | Oracle RAC | Sub-second alarm, WIP, R2R control |
| Analytics Engine | Statistical | SAS Viya + CAS | Industry-certified SPC, ANOVA, regression |
| ML Training | Framework | PyTorch + scikit-learn | CNN/ViT defect, XGBoost yield, LSTM FDC |
| ML Serving | Inference | NVIDIA Triton | Multi-model serving, A100 GPU |
| ML Ops | Tracking | MLflow + SAS Model Mgr | Experiment + certified governance |
| Causal AI | Framework | DoWhy + SHAP | Causal graphs, feature attribution |
| LLM | Base Model | Llama-3 70B / Qwen2.5 72B | Open-weight, fine-tunable, on-premise |
| LLM Fine-Tuning | Method | LoRA / QLoRA + RLHF | Parameter-efficient, fab domain adaptation |
| Agent Framework | Orchestration | LangGraph + MCP | State machine agents with certified tool calls |
| Knowledge Graph | Database | Neo4j Enterprise | Graph relationships for RCA knowledge |
| Vector Store | Embedding | pgvector + ChromaDB | RAG retrieval for LLM context |
| Messaging | Event Bus | Apache Kafka | High-throughput fab data streaming |
| Cache | Hot Data | Redis Cluster | 5-min SPC results, session, feature store |
| Object Storage | Raw Files | MinIO | STDF archive, GDS files, SEM images |
| API Gateway | Gateway | Kong Enterprise | OAuth2, rate limiting, routing |
| Container | Orchestration | Kubernetes | Production-grade microservice management |
| Observability | Full Stack | Prometheus + Grafana + Jaeger + ELK | Three pillars: metrics, logs, traces |
| CI/CD | Pipeline | GitLab CI + ArgoCD | GitOps deployment |
| FAB Interface | Protocol | SEMI GEM300 / SECS-II | Industry standard equipment communication |
| Security | Auth | OAuth2 / OIDC / JWT + MFA | Enterprise identity standard |

---

## Appendix B — Key Performance Targets

| KPI | Target | Measurement Method |
|-----|--------|--------------------|
| Wafer map render (684K die) | < 2ms | Canvas benchmark |
| API response P95 latency | < 200ms | Prometheus histogram |
| SPC alarm to notification | < 30 seconds | End-to-end trace |
| LLM RCA response time | < 30 seconds | Agent session timer |
| Autonomous RCA accuracy | > 90% | vs engineer gold standard |
| INF-TPC anomaly detection | > 95% accuracy | FAB benchmark |
| Greenplum query (1B row) | < 5 seconds | Execution plan |
| System availability | 99.95% (< 4h/year) | Uptime monitor |
| Data ingestion throughput | > 100K events/second | Kafka consumer lag |
| ML inference throughput | > 1000 predictions/second | Triton server metrics |

---

*Document End — SEMFAB·IQ Comprehensive System Architecture & Product Design Report v1.0*

*© 2025 SEMFAB·IQ Engineering Team. All rights reserved. Commercial Confidential.*
