# SEMFAB·IQ — Comprehensive Mermaid Architecture Diagrams
## Part 1: Full System Architecture Collection

This document provides the complete, production-grade Mermaid architecture diagrams for the SEMFAB·IQ platform, detailing the macro-level topology, microservice interactions, data pipelines, and AI agent workflows.

---

### 1. Macro System Topology & Network Architecture

This diagram illustrates the complete physical and logical network separation across the DMZ, Kubernetes Application Tier, Data Tier, and the isolated FAB equipment VLAN.

```mermaid
graph TB
    subgraph EXTERNAL["External / User Access"]
        ENG[Process Engineers]
        MGR[Fab Management]
        API_CLIENT[External Systems]
    end

    subgraph DMZ["DMZ / API Gateway Layer"]
        LB[Nginx L4 Load Balancer]
        KONG[Kong API Gateway\nOAuth2 / Rate Limit / WAF]
        WSS[WebSocket Server\nReal-time SSE/WS Push]
    end

    subgraph K8S_APP["Kubernetes Application Tier (Flask Microservices)"]
        subgraph CORE_ANALYTICS["Core Analytics Services"]
            YIELD[yield-service :8002]
            WAT[wat-analytics :8003]
            SPC[spc-fdc-service :8005]
            DEFECT[defect-service :8006]
        end

        subgraph AI_AGENTS["AI & Agentic Services"]
            INFER[inference-service :8020\nTriton ML Proxy]
            AGENT[agent-service :8030\nLangGraph Orchestrator]
            LLM[llm-service :8031\nWisdom RAG Engine]
        end

        subgraph INFRA_SVCS["Infrastructure Services"]
            AUTH[auth-service :8001]
            ALARM[alarm-service :8009]
            ROBOT[robot-ctrl :8040]
        end
    end

    subgraph DATA_TIER["Data Persistence & Compute Tier"]
        ORA[(Oracle RAC\nReal-time OLTP\nSub-second latency)]
        GP[(Greenplum MPP\nHistorical EDW\nPetabyte scale)]
        CAS[SAS Viya CAS\nIn-Memory Stats Engine]
        REDIS[(Redis Cluster\nHot Cache & Session)]
        KAFKA[Apache Kafka\nEvent Streaming Bus]
        MINIO[(MinIO S3\nRaw Files & Images)]
        NEO4J[(Neo4j Graph\nRCA Knowledge Base)]
    end

    subgraph FAB_VLAN["FAB Equipment Network (Isolated VLAN)"]
        TESTER[WAT Testers\nSemitronix / Keysight]
        INLINE[Inline Metrology\nKLA / AMAT]
        MES[MES / EAP Systems\nApplied Materials]
        HW_ROBOT[AMHS / Wafer Transport]
    end

    %% Connections
    EXTERNAL --> LB
    LB --> KONG
    LB --> WSS
    KONG --> K8S_APP
    
    K8S_APP <--> REDIS
    K8S_APP <--> ORA
    K8S_APP <--> GP
    K8S_APP <--> CAS
    K8S_APP <--> NEO4J
    
    FAB_VLAN -- "STDF / SECS-II / GEM300" --> KAFKA
    KAFKA -- "Spark Structured Streaming" --> ORA
    KAFKA -- "Spark Structured Streaming" --> GP
    KAFKA -- "Raw Files" --> MINIO
    
    ROBOT -- "Control APIs" --> MES
    ROBOT -- "Control APIs" --> HW_ROBOT
```

---

### 2. High-Throughput Data Ingestion Pipeline

To handle >100K events/second from FAB equipment, the ingestion pipeline utilizes Kafka, Spark Structured Streaming, and parallel bulk loading into Greenplum and Oracle.

```mermaid
flowchart LR
    subgraph FAB_SOURCES["FAB Data Sources"]
        S1[WAT Testers\nSTDF Files]
        S2[Inline Metro\nXML Reports]
        S3[FDC Sensors\nHigh-freq Traces]
        S4[Defect Tools\nKLARF + Images]
    end

    subgraph STREAMING_BUS["Event Streaming (Kafka)"]
        K1[Topic: wat.raw]
        K2[Topic: inline.raw]
        K3[Topic: fdc.trace]
        K4[Topic: defect.raw]
    end

    subgraph ETL_SPARK["Spark Structured Streaming (ETL)"]
        E1[Parse & Validate\nGreat Expectations]
        E2[Enrichment\nJoin Lot/Equipment Context]
        E3[Data Quality\nNull/Outlier Check]
    end

    subgraph DATA_SINKS["Parallel Data Sinks"]
        ORA[(Oracle\nLive Alarms/WIP\nJDBC Batch)]
        GP[(Greenplum\nHistorical Facts\ngpfdist Bulk Load)]
        MINIO[(MinIO\nRaw Files/Images\nS3 API)]
    end

    S1 --> K1
    S2 --> K2
    S3 --> K3
    S4 --> K4
    
    K1 & K2 & K3 & K4 --> E1
    E1 --> E2 --> E3
    
    E3 -->|Sub-second| ORA
    E3 -->|10s Microbatch| GP
    E3 -->|Blob Storage| MINIO
```

---

### 3. Agentic AI & Hardware Robot Orchestration Loop

This diagram details how the LLM Agent acts as a Software Robot, detecting anomalies, reasoning through root causes, and executing physical actions via FAB Hardware Robots.

```mermaid
sequenceDiagram
    autonumber
    participant EQUIP as FAB Equipment
    participant ORA as Oracle ODS
    participant SPC as spc-fdc-service
    participant AGENT as agent-service (LangGraph)
    participant SAS as SAS Viya Engine
    participant LLM as llm-service (RAG)
    participant ENG as Process Engineer
    participant ROBOT as robot-ctrl-service

    EQUIP->>ORA: Stream real-time sensor data (FDC)
    ORA->>SPC: Trigger SPC rule evaluation
    SPC->>AGENT: Event: Critical SPC Violation (Rule 1)
    
    rect rgb(40, 44, 52)
        Note over AGENT,LLM: Autonomous Reasoning Phase
        AGENT->>SAS: Request multi-variate ANOVA & correlation
        SAS-->>AGENT: Return top correlated factors (e.g., Gas Flow MFC)
        AGENT->>LLM: Query Knowledge Graph: "SPC violation + MFC anomaly"
        LLM-->>AGENT: Return historical RCA: "MFC Drift requiring recalibration"
    end
    
    AGENT->>ENG: Push RCA Hypothesis & Action Plan (Confidence: 92%)
    
    alt Confidence > 95% (Full Autonomy)
        AGENT->>ROBOT: Auto-execute action plan
    else Confidence 80-95% (Human-in-the-Loop)
        ENG->>AGENT: Approve Action Plan via UI
        AGENT->>ROBOT: Execute approved action
    end
    
    rect rgb(30, 50, 40)
        Note over ROBOT,EQUIP: Physical Execution Phase
        ROBOT->>EQUIP: EAP Command: Pause Equipment Processing
        ROBOT->>EQUIP: MES Command: Put Lot on Hold
        ROBOT->>EQUIP: CMMS Command: Schedule MFC Recalibration PM
    end
    
    ROBOT-->>AGENT: Execution confirmed
    AGENT->>LLM: Update Knowledge Graph with successful RCA & Action
```

---

### 4. Microservice Internal Architecture (Flask Pattern)

This diagram shows the internal architecture of a standard Flask microservice within the platform, using `yield-service` as the example.

```mermaid
graph TB
    subgraph FLASK_SVC["yield-service Internal Architecture"]
        subgraph ROUTER["API Route Layer (Blueprints)"]
            R1[GET /api/v1/yield/summary]
            R2[GET /api/v1/yield/trend]
            R3[POST /api/v1/yield/compare]
        end

        subgraph SERVICE["Business Logic Layer"]
            S1[YieldCalculatorService]
            S2[ExcursionDetectorService]
            S3[LotComparatorService]
        end

        subgraph REPO["Data Repository Layer"]
            GP_REPO[GreenplumRepo\nSQLAlchemy + asyncpg]
            ORA_REPO[OracleRepo\ncx_Oracle]
            REDIS_REPO[RedisCache\nredis-py]
        end

        subgraph ASYNC_TASKS["Celery Background Tasks"]
            C1[Task: compute_daily_rollups]
            C2[Task: detect_excursions]
        end
    end

    R1 --> S1
    R2 --> S1
    R3 --> S3
    
    S1 --> REDIS_REPO
    REDIS_REPO -.->|Cache Miss| GP_REPO
    S2 --> ORA_REPO
    
    C1 --> S1
    C2 --> S2
```
