# SEMFAB·IQ — Comprehensive Data Schema Design
## DataMart Architecture for Semiconductor Engineering Analytics
### Production-Grade · Multi-Domain · Interactive Analysis Ready

---

> **Document Classification:** Data Architecture Specification  
> **Database Engines:** Greenplum (Analytical DW) · Oracle (OLTP Real-time) · SAS Viya CAS (In-memory) · Neo4j (Knowledge Graph) · Redis (Cache/Hot)  
> **Schema Philosophy:** DataMart per Analysis Domain, Star/Snowflake hybrid, Columnar storage for analytical workloads  
> **Coverage:** MES · Process Route · WAT · CP · SPC · FDC · APC · Metrology · Defect · Equipment · Material · Yield · Reliability

---

## Schema Naming Convention

```
{domain}_{entity}_{type}
│         │       └─ DIM = Dimension | FACT = Fact | BRIDGE = Bridge | AGG = Aggregate | SRC = Source Staging
│         └─ entity name (snake_case)
└─ domain prefix: MES / WAT / CP / SPC / FDC / APC / MTR / DEF / EQP / MAT / YLD / REL / AGT
```

**Distribution Keys** (Greenplum): All FACT tables distributed by `lot_id`  
**Partition Strategy**: Range partition by `event_date` (monthly for FACT, quarterly for AGG)  
**Columnar Storage**: All FACT tables use Append-Optimized Columnar (AOCO)  
**Index Strategy**: BRIN indexes on time columns, B-tree on natural keys

---

# DOMAIN 1 — MES (Manufacturing Execution System) DataMart

> **Purpose:** Process route tracking, WIP management, lot traceability, operation history, step-level timing, queue time analysis, cycle time analysis

## MES_DIM_LOT — Lot Master Dimension

```sql
CREATE TABLE mes_dim_lot (
    -- Surrogate Key
    lot_sk              BIGSERIAL       PRIMARY KEY,
    
    -- Natural Keys
    lot_id              VARCHAR(32)     NOT NULL,           -- e.g. M900123
    lot_alias           VARCHAR(64),                        -- internal alias/customer ref
    
    -- Lot Classification
    lot_type            VARCHAR(20)     NOT NULL,           -- PRODUCTION / ENGINEERING / QUALIFICATION / MONITOR / REWORK
    lot_subtype         VARCHAR(20),                        -- HOT_LOT / PRIORITY / STANDARD / HOLD
    lot_priority        SMALLINT        DEFAULT 5,          -- 1=highest, 10=lowest
    is_split_lot        BOOLEAN         DEFAULT FALSE,
    parent_lot_id       VARCHAR(32),                        -- for split lots
    split_sequence      SMALLINT        DEFAULT 1,
    
    -- Product Linkage
    product_id          VARCHAR(32)     NOT NULL,
    product_revision    VARCHAR(8),
    device_family       VARCHAR(32),
    customer_id         VARCHAR(32),
    customer_order_id   VARCHAR(64),
    
    -- Technology
    process_node        VARCHAR(16),                        -- N5 / N3 / N7 / 28nm
    technology_id       VARCHAR(32),                        -- e.g. N5P
    mask_set_id         VARCHAR(32),
    mask_revision       VARCHAR(8),
    
    -- Lot Lifecycle
    lot_status          VARCHAR(24)     NOT NULL,           -- ACTIVE / HOLD / COMPLETED / SCRAPPED / SHIPPED
    hold_code           VARCHAR(16),
    hold_reason         TEXT,
    
    -- Wafer Info
    wafer_count_start   SMALLINT,
    wafer_count_current SMALLINT,
    wafer_size_mm       SMALLINT        DEFAULT 300,
    substrate_type      VARCHAR(16)     DEFAULT 'Si',       -- Si / SOI / GaN / SiC
    
    -- Dates
    lot_start_date      TIMESTAMP WITH TIME ZONE,
    lot_target_date     TIMESTAMP WITH TIME ZONE,
    lot_complete_date   TIMESTAMP WITH TIME ZONE,
    lot_ship_date       TIMESTAMP WITH TIME ZONE,
    
    -- Yield Targets
    target_yield_pct    NUMERIC(6,3),
    syl_pct             NUMERIC(6,3),                       -- Soft Yield Limit
    sbl_pct             NUMERIC(6,3),                       -- Soft Bin Limit
    
    -- SCD Type 2 Tracking
    effective_from      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    effective_to        TIMESTAMP WITH TIME ZONE,
    is_current          BOOLEAN DEFAULT TRUE,
    
    -- Audit
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    source_system       VARCHAR(32)
) WITH (appendonly=true, compresslevel=5)
DISTRIBUTED BY (lot_id);

CREATE INDEX idx_mes_lot_lot_id ON mes_dim_lot(lot_id) WHERE is_current=TRUE;
CREATE INDEX idx_mes_lot_product ON mes_dim_lot(product_id, process_node);
CREATE INDEX idx_mes_lot_status ON mes_dim_lot(lot_status, lot_type);
```

## MES_DIM_WAFER — Wafer Master Dimension

```sql
CREATE TABLE mes_dim_wafer (
    wafer_sk            BIGSERIAL       PRIMARY KEY,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,           -- lot_id + slot
    slot_number         SMALLINT        NOT NULL,           -- 1–25
    wafer_sequence      SMALLINT,
    
    -- Physical
    wafer_diameter_mm   SMALLINT        DEFAULT 300,
    wafer_thickness_um  NUMERIC(8,2),
    notch_orientation   SMALLINT        DEFAULT 0,          -- degrees
    edge_exclusion_mm   NUMERIC(4,2)    DEFAULT 3.0,
    
    -- Die Info
    die_size_x_um       NUMERIC(10,3),
    die_size_y_um       NUMERIC(10,3),
    die_per_wafer       INTEGER,
    die_count_good      INTEGER,
    die_count_bad       INTEGER,
    
    -- Status
    wafer_status        VARCHAR(20),                        -- ACTIVE / SCRAPPED / COMPLETED / ON_HOLD
    scrap_reason        VARCHAR(64),
    scrap_step_id       VARCHAR(32),
    
    -- Barcode / Traceability
    wafer_barcode       VARCHAR(64),
    substrate_lot_id    VARCHAR(32),                        -- silicon supplier lot
    
    -- Yield Summary (updated after each test)
    cp_yield_pct        NUMERIC(6,3),
    wat_status          VARCHAR(16),
    final_disposition   VARCHAR(24),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (lot_id, slot_number)
) WITH (appendonly=true)
DISTRIBUTED BY (lot_id);
```

## MES_DIM_PROCESS_ROUTE — Process Route & Flow

```sql
CREATE TABLE mes_dim_process_route (
    route_sk            BIGSERIAL       PRIMARY KEY,
    route_id            VARCHAR(32)     NOT NULL UNIQUE,    -- e.g. N5_LOGIC_R04
    route_name          VARCHAR(128),
    route_version       VARCHAR(8),
    route_type          VARCHAR(20),                        -- STANDARD / QUALIFICATION / SHORT_LOOP
    technology_id       VARCHAR(32),
    process_node        VARCHAR(16),
    total_steps         INTEGER,
    total_layers        SMALLINT,
    is_active           BOOLEAN DEFAULT TRUE,
    effective_date      DATE,
    obsolete_date       DATE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (route_id);

-- Route Step Detail
CREATE TABLE mes_dim_route_step (
    step_sk             BIGSERIAL       PRIMARY KEY,
    route_id            VARCHAR(32)     NOT NULL,
    step_id             VARCHAR(32)     NOT NULL,           -- e.g. LI-3041
    step_sequence       INTEGER         NOT NULL,           -- absolute order
    step_name           VARCHAR(128),
    step_type           VARCHAR(24),                        -- PROCESS / METROLOGY / INSPECTION / TEST / HOLD_POINT
    
    -- Process Classification
    process_area        VARCHAR(32),                        -- PHOTO / ETCH / CVD / CMP / IMP / DIFF / WET / INSP
    process_module      VARCHAR(32),                        -- e.g. GATE_OX / M1 / STI / NBL
    layer_name          VARCHAR(32),                        -- e.g. AA / PO / M1 / VIA1
    layer_number        SMALLINT,
    front_end_backend   VARCHAR(8),                         -- FEOL / MEOL / BEOL
    
    -- Step Properties
    is_optional         BOOLEAN DEFAULT FALSE,
    is_monitor_step     BOOLEAN DEFAULT FALSE,
    is_cp_step          BOOLEAN DEFAULT FALSE,
    is_wat_step         BOOLEAN DEFAULT FALSE,
    is_hold_point       BOOLEAN DEFAULT FALSE,
    requires_approval   BOOLEAN DEFAULT FALSE,
    
    -- Tool Requirements
    tool_type_required  VARCHAR(32),
    chamber_required    VARCHAR(32),
    
    -- Time Standards
    nominal_duration_min NUMERIC(8,2),
    max_queue_time_hr   NUMERIC(8,2),
    
    route_id_fk         VARCHAR(32),
    step_version        VARCHAR(8),
    UNIQUE (route_id, step_id)
) WITH (appendonly=true)
DISTRIBUTED BY (route_id);

CREATE INDEX idx_route_step_area ON mes_dim_route_step(process_area, process_module);
CREATE INDEX idx_route_step_layer ON mes_dim_route_step(layer_name, layer_number);
```

## MES_FACT_LOT_OPERATION — Core WIP & Operation Tracking

```sql
CREATE TABLE mes_fact_lot_operation (
    operation_sk        BIGSERIAL,
    
    -- Keys
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40),                        -- NULL = lot-level, populated = wafer-level
    route_id            VARCHAR(32)     NOT NULL,
    step_id             VARCHAR(32)     NOT NULL,
    step_sequence       INTEGER,
    
    -- Equipment
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    operator_id         VARCHAR(32),
    shift               VARCHAR(8),                         -- DAY / EVE / NIGHT
    
    -- Recipe
    recipe_id           VARCHAR(64),
    recipe_version      VARCHAR(8),
    recipe_parameter_set VARCHAR(32),
    
    -- Timing (critical for cycle time analysis)
    queue_start_time    TIMESTAMP WITH TIME ZONE,           -- when lot arrived at step
    process_start_time  TIMESTAMP WITH TIME ZONE,           -- when processing began
    process_end_time    TIMESTAMP WITH TIME ZONE,           -- when processing ended
    queue_end_time      TIMESTAMP WITH TIME ZONE,           -- when lot left step queue
    
    -- Derived Timing (pre-computed for fast reporting)
    queue_time_hr       NUMERIC(10,4),                      -- time waiting before process
    process_time_min    NUMERIC(10,4),                      -- actual process duration
    cycle_time_hr       NUMERIC(10,4),                      -- total = queue + process + queue_out
    
    -- Operation Result
    operation_status    VARCHAR(20)     NOT NULL,           -- COMPLETE / ABORTED / FAILED / SKIPPED
    abort_code          VARCHAR(16),
    abort_reason        TEXT,
    wafer_count_in      SMALLINT,
    wafer_count_out     SMALLINT,
    wafer_count_scrapped SMALLINT       DEFAULT 0,
    
    -- Lot Status at this Step
    lot_disposition     VARCHAR(20),                        -- PASS / FAIL / HOLD / REWORK
    hold_triggered      BOOLEAN DEFAULT FALSE,
    hold_code           VARCHAR(16),
    hold_source         VARCHAR(32),                        -- MANUAL / SPC / FDC / YIELD / AGENT
    
    -- MRB Flags
    mrb_required        BOOLEAN DEFAULT FALSE,
    mrb_decision        VARCHAR(20),                        -- PASS / SCRAP / REWORK / CONDITIONAL
    
    -- Process Parameters Snapshot (JSON for flexibility)
    process_params_json TEXT,                               -- key process setpoints at time of run
    
    -- Event Tracking
    event_date          DATE NOT NULL,
    event_timestamp     TIMESTAMP WITH TIME ZONE,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2023-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);

CREATE INDEX idx_mes_op_lot_step ON mes_fact_lot_operation(lot_id, step_id);
CREATE INDEX idx_mes_op_equipment ON mes_fact_lot_operation(equipment_id, event_date);
CREATE INDEX idx_mes_op_status ON mes_fact_lot_operation(operation_status, event_date);
```

## MES_FACT_CYCLE_TIME — Cycle Time Analytics Fact

```sql
CREATE TABLE mes_fact_cycle_time (
    ct_sk               BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    route_id            VARCHAR(32),
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    lot_type            VARCHAR(20),
    
    -- Dates
    lot_start_date      DATE,
    lot_complete_date   DATE,
    
    -- Total Cycle Time Breakdown
    total_ct_days       NUMERIC(10,4),
    process_time_days   NUMERIC(10,4),                      -- time actually in equipment
    queue_time_days     NUMERIC(10,4),                      -- time waiting
    hold_time_days      NUMERIC(10,4),                      -- time on hold
    transport_time_days NUMERIC(10,4),
    
    -- By Process Area
    feol_ct_days        NUMERIC(10,4),
    meol_ct_days        NUMERIC(10,4),
    beol_ct_days        NUMERIC(10,4),
    
    -- Efficiency Metrics
    process_efficiency_pct NUMERIC(6,3),                    -- process_time / total_ct
    queue_ratio_pct     NUMERIC(6,3),
    hold_ratio_pct      NUMERIC(6,3),
    
    -- MRB / Hold Events
    hold_count          SMALLINT        DEFAULT 0,
    mrb_count           SMALLINT        DEFAULT 0,
    rework_count        SMALLINT        DEFAULT 0,
    
    event_date          DATE NOT NULL,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2023-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

## MES_FACT_MATERIAL_CONSUMPTION — Material & Chemical EBOM

```sql
CREATE TABLE mes_fact_material_consumption (
    consumption_sk      BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    step_id             VARCHAR(32)     NOT NULL,
    equipment_id        VARCHAR(32),
    event_date          DATE NOT NULL,
    
    -- Material
    material_id         VARCHAR(32)     NOT NULL,
    material_name       VARCHAR(128),
    material_group      VARCHAR(32),                        -- Chemical / Gas / Pad_Disk / PhotoResist / Slurry / Target
    material_module     VARCHAR(32),                        -- CMP / CVD / Litho / WET / PVD
    ebom_lot_id         VARCHAR(32),                        -- material supplier lot
    
    -- Consumption
    consumption_unit    VARCHAR(16),                        -- L / ST / KG / ml
    consumption_actual  NUMERIC(14,6),
    consumption_plan    NUMERIC(14,6),
    consumption_p1k     NUMERIC(14,6),                      -- per 1000 wafers moved
    ebom_all            NUMERIC(14,6),
    
    -- Classification
    ebom_lot_type       VARCHAR(20),                        -- Engineer / Production
    p_all_pct           NUMERIC(8,4),                       -- actual/plan %
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2023-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

---

# DOMAIN 2 — WAT (Wafer Acceptance Test) DataMart

> **Purpose:** Parametric electrical test on monitor structures; SPC, correlation, DOE, equipment factor analysis, yield prediction features

## WAT_DIM_PARAMETER — Parameter Master

```sql
CREATE TABLE wat_dim_parameter (
    parameter_sk        BIGSERIAL       PRIMARY KEY,
    parameter_id        VARCHAR(64)     NOT NULL UNIQUE,    -- canonical ID
    parameter_name      VARCHAR(128)    NOT NULL,
    parameter_alias     VARCHAR(128),                       -- alternate names
    
    -- Classification
    parameter_group     VARCHAR(32),                        -- IDSAT / VT / LEAKAGE / RESISTANCE / CAPACITANCE / BVJ / ...
    device_type         VARCHAR(32),                        -- NMOS / PMOS / RESISTOR / CAPACITOR / DIODE / BJT
    mos_type            VARCHAR(8),                         -- N / P
    test_structure      VARCHAR(32),                        -- PCM structure type
    
    -- Electrical Type
    parameter_type      VARCHAR(24),                        -- DC / CV / AC / RF / RELIABILITY
    measurement_mode    VARCHAR(24),                        -- FORCED_V / FORCED_I / SWEEP
    
    -- Units & Scale
    unit                VARCHAR(16),                        -- A / V / Ω / F / S / Hz
    unit_prefix         VARCHAR(8),                         -- n / µ / m / k / M
    display_unit        VARCHAR(16),                        -- combined: mA, µV, pF
    scale_factor        NUMERIC(20,10)  DEFAULT 1.0,
    
    -- Spec Limits (nominal - recipe/product specific limits in WAT_DIM_SPEC)
    nominal_value       NUMERIC(20,10),
    
    -- SPC Configuration
    is_spc_monitored    BOOLEAN DEFAULT FALSE,
    spc_chart_type      VARCHAR(16),                        -- XBAR_R / XBAR_S / IMR / P
    spc_subgroup_size   SMALLINT DEFAULT 1,
    
    -- DOE / Analysis
    is_dof_parameter    BOOLEAN DEFAULT FALSE,              -- use in DOE analysis
    criticality_rank    SMALLINT,                           -- 1=most critical
    
    -- Process Layer
    layer_name          VARCHAR(32),
    process_module      VARCHAR(32),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (parameter_id);
```

## WAT_DIM_SPEC — Product-Parameter Specification

```sql
CREATE TABLE wat_dim_spec (
    spec_sk             BIGSERIAL       PRIMARY KEY,
    product_id          VARCHAR(32)     NOT NULL,
    technology_id       VARCHAR(32)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    recipe_id           VARCHAR(64),                        -- NULL = all recipes
    
    -- Test Conditions
    vcc                 NUMERIC(8,4),                       -- supply voltage
    temp_c              NUMERIC(8,3),                       -- temperature °C
    freq_hz             NUMERIC(16,4),                      -- frequency for AC/RF
    bias_v              NUMERIC(8,4),
    
    -- Specification Limits
    usl                 NUMERIC(20,10),                     -- Upper Spec Limit
    lsl                 NUMERIC(20,10),                     -- Lower Spec Limit
    target              NUMERIC(20,10),
    usl_tight           NUMERIC(20,10),                     -- tighter engineering limit
    lsl_tight           NUMERIC(20,10),
    
    -- SPC Limits (separate from spec, set by Phase I analysis)
    spc_ucl             NUMERIC(20,10),
    spc_lcl             NUMERIC(20,10),
    spc_cl              NUMERIC(20,10),                     -- center line / mean
    spc_usl_2sigma      NUMERIC(20,10),
    spc_lsl_2sigma      NUMERIC(20,10),
    spc_sigma           NUMERIC(20,10),
    
    -- Limit Source
    limit_source        VARCHAR(24),                        -- CUSTOMER / ENGINEERING / FOUNDRY / MONITOR
    limit_version       VARCHAR(8),
    effective_date      DATE,
    obsolete_date       DATE,
    
    UNIQUE (product_id, technology_id, parameter_id, vcc, temp_c)
) DISTRIBUTED BY (product_id);
```

## WAT_FACT_RESULT — Core WAT Measurement Fact

```sql
CREATE TABLE wat_fact_result (
    result_sk           BIGSERIAL,
    
    -- Lot / Wafer / Site
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    site_id             SMALLINT        NOT NULL,           -- 1–25 for 25-site maps
    site_x              NUMERIC(8,4),                       -- X coordinate mm
    site_y              NUMERIC(8,4),                       -- Y coordinate mm
    site_zone           VARCHAR(8),                         -- CENTER / EDGE / RING_70 / CORNER
    
    -- Parameter
    parameter_id        VARCHAR(64)     NOT NULL,
    parameter_group     VARCHAR(32),
    
    -- Test Conditions
    vcc                 NUMERIC(8,4),
    temp_c              NUMERIC(8,3),
    freq_hz             NUMERIC(16,4),
    
    -- Measurement
    measured_value      NUMERIC(20,10)  NOT NULL,
    raw_value           NUMERIC(20,10),                     -- before unit scaling
    
    -- Spec References (denormalized for fast analysis)
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    target_value        NUMERIC(20,10),
    
    -- Pass/Fail
    pass_fail           CHAR(1),                            -- P / F / M (marginal)
    fail_code           VARCHAR(16),
    sigma_deviation     NUMERIC(10,6),                      -- (value - mean) / sigma vs fleet
    cpk_contribution    NUMERIC(10,6),
    
    -- Equipment Context (at time of measurement)
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    tester_id           VARCHAR(32),
    prober_id           VARCHAR(32),
    probe_card_id       VARCHAR(32),
    
    -- Process Context
    route_id            VARCHAR(32),
    step_id             VARCHAR(32),
    process_node        VARCHAR(16),
    product_id          VARCHAR(32),
    
    -- Outlier Flags
    is_outlier_mad      BOOLEAN DEFAULT FALSE,              -- Modified Z-score outlier
    is_outlier_grubbs   BOOLEAN DEFAULT FALSE,              -- Grubbs test outlier
    is_outlier_iqr      BOOLEAN DEFAULT FALSE,
    outlier_z_score     NUMERIC(10,6),
    
    -- AI Feature Flags
    is_anomaly_ml       BOOLEAN DEFAULT FALSE,              -- ML-detected anomaly
    anomaly_score       NUMERIC(6,4),
    
    -- Event
    test_time           TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    lot_sequence        INTEGER,                            -- chronological lot order
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);

CREATE INDEX idx_wat_result_param ON wat_fact_result(parameter_id, event_date);
CREATE INDEX idx_wat_result_equipment ON wat_fact_result(equipment_id, parameter_id);
CREATE INDEX idx_wat_result_lot_wafer ON wat_fact_result(lot_id, wafer_id, site_id);
```

## WAT_AGG_LOT_SUMMARY — Pre-computed Lot-Level Aggregates

```sql
CREATE TABLE wat_agg_lot_summary (
    summary_sk          BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    vcc                 NUMERIC(8,4),
    temp_c              NUMERIC(8,3),
    product_id          VARCHAR(32),
    equipment_id        VARCHAR(32),
    event_date          DATE NOT NULL,
    
    -- Descriptive Statistics
    n_sites             SMALLINT,
    mean_value          NUMERIC(20,10),
    median_value        NUMERIC(20,10),
    std_dev             NUMERIC(20,10),
    variance            NUMERIC(20,10),
    min_value           NUMERIC(20,10),
    max_value           NUMERIC(20,10),
    range_value         NUMERIC(20,10),
    p5_value            NUMERIC(20,10),
    p25_value           NUMERIC(20,10),
    p75_value           NUMERIC(20,10),
    p95_value           NUMERIC(20,10),
    skewness            NUMERIC(10,6),
    kurtosis            NUMERIC(10,6),
    
    -- Process Capability
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    cp                  NUMERIC(10,6),
    cpk                 NUMERIC(10,6),
    cpm                 NUMERIC(10,6),
    pp                  NUMERIC(10,6),
    ppk                 NUMERIC(10,6),
    
    -- Normality
    shapiro_wilk_p      NUMERIC(10,8),
    is_normal_dist      BOOLEAN,
    dist_fit_type       VARCHAR(20),                        -- NORMAL / LOGNORMAL / BIMODAL
    
    -- Pass/Fail
    n_pass              SMALLINT,
    n_fail              SMALLINT,
    pass_rate_pct       NUMERIC(6,3),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (lot_id, wafer_id, parameter_id, vcc, temp_c)
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id);
```

## WAT_FACT_CORRELATION — Pre-computed Parameter Correlation Matrix

```sql
CREATE TABLE wat_fact_correlation (
    corr_sk             BIGSERIAL,
    
    -- Scope
    product_id          VARCHAR(32)     NOT NULL,
    process_node        VARCHAR(16),
    date_range_start    DATE,
    date_range_end      DATE,
    lot_count           INTEGER,
    n_observations      INTEGER,
    
    -- Parameter Pair
    param_x_id          VARCHAR(64)     NOT NULL,
    param_y_id          VARCHAR(64)     NOT NULL,
    
    -- Correlation Results
    pearson_r           NUMERIC(10,8),
    pearson_p_value     NUMERIC(12,10),
    spearman_r          NUMERIC(10,8),
    spearman_p_value    NUMERIC(12,10),
    
    -- Regression (Y ~ X)
    ols_slope           NUMERIC(20,10),
    ols_intercept       NUMERIC(20,10),
    ols_r_squared       NUMERIC(10,8),
    ols_adj_r_squared   NUMERIC(10,8),
    ols_f_stat          NUMERIC(16,6),
    ols_f_p_value       NUMERIC(12,10),
    
    -- Significance
    is_significant_05   BOOLEAN,                            -- p < 0.05
    is_significant_01   BOOLEAN,                            -- p < 0.01
    
    computed_at         TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    computation_id      UUID
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (product_id);
```

## WAT_FACT_ANOVA_EQUIPMENT — Equipment Factor Analysis (Eta-Squared)

```sql
CREATE TABLE wat_fact_anova_equipment (
    anova_sk            BIGSERIAL,
    
    -- Scope
    parameter_id        VARCHAR(64)     NOT NULL,
    product_id          VARCHAR(32)     NOT NULL,
    process_node        VARCHAR(16),
    date_range_start    DATE,
    date_range_end      DATE,
    lot_count           INTEGER,
    n_observations      INTEGER,
    
    -- ANOVA Factor
    factor_type         VARCHAR(24)     NOT NULL,           -- EQPID / CHAMBER / RECIPE / OPERATOR / SHIFT
    factor_value        VARCHAR(64)     NOT NULL,           -- equipment_id, chamber_id, etc.
    
    -- ANOVA Results
    ss_between          NUMERIC(20,10),                     -- Sum of Squares between groups
    ss_within           NUMERIC(20,10),
    ss_total            NUMERIC(20,10),
    ms_between          NUMERIC(20,10),
    ms_within           NUMERIC(20,10),
    df_between          INTEGER,
    df_within           INTEGER,
    f_statistic         NUMERIC(16,6),
    p_value             NUMERIC(12,10),
    
    -- Effect Size
    eta_squared         NUMERIC(10,8),                      -- η² = SS_between / SS_total
    eta_squared_adj     NUMERIC(10,8),                      -- adjusted
    omega_squared       NUMERIC(10,8),                      -- more conservative
    
    -- Group Statistics
    group_mean          NUMERIC(20,10),
    group_std           NUMERIC(20,10),
    group_n             INTEGER,
    fleet_mean          NUMERIC(20,10),
    fleet_std           NUMERIC(20,10),
    
    -- Health Score Components (composite equipment health)
    z_score_component   NUMERIC(10,6),                      -- |group_mean - fleet_mean| / fleet_std
    gof_component       NUMERIC(10,6),                      -- KS test p-value (inverted)
    cv_stability        NUMERIC(10,6),                      -- CV trend slope
    volume_component    NUMERIC(10,6),                      -- throughput consistency
    composite_health_score NUMERIC(6,2),                    -- 0-100
    health_tier         VARCHAR(16),                        -- HEALTHY / WATCH / DEGRADED / CRITICAL
    
    computed_at         TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (product_id);
```

---

# DOMAIN 3 — CP (Circuit Probe / Die Sort) DataMart

> **Purpose:** Die-level electrical test, bin analysis, wafer map patterns, spatial clustering, tray traceability, touchdowns, smart sampling

## CP_DIM_TEST_PROGRAM — Test Program Registry

```sql
CREATE TABLE cp_dim_test_program (
    program_sk          BIGSERIAL       PRIMARY KEY,
    program_id          VARCHAR(64)     NOT NULL UNIQUE,
    program_name        VARCHAR(128),
    program_version     VARCHAR(16),
    program_type        VARCHAR(20),                        -- CP / FT / WLR / BURN_IN
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    -- Test Items
    total_test_items    INTEGER,
    total_pass_bins     SMALLINT,
    total_fail_bins     SMALLINT,
    
    -- Timing
    avg_touch_time_ms   NUMERIC(10,4),
    avg_test_time_sec   NUMERIC(10,4),
    
    -- Smart Sampling
    smart_sampling_enabled BOOLEAN DEFAULT FALSE,
    sampling_algorithm  VARCHAR(32),                        -- SPATIAL / YIELD_PREDICT / CLUSTER_SKIP
    
    effective_date      DATE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (program_id);
```

## CP_DIM_BIN — Bin Definition

```sql
CREATE TABLE cp_dim_bin (
    bin_sk              BIGSERIAL       PRIMARY KEY,
    program_id          VARCHAR(64)     NOT NULL,
    bin_code            SMALLINT        NOT NULL,           -- bin number
    bin_type            VARCHAR(8)      NOT NULL,           -- HARD / SOFT
    bin_name            VARCHAR(64),
    bin_category        VARCHAR(20),                        -- PASS / FAIL / UNTESTED / SKIP
    is_pass_bin         BOOLEAN         NOT NULL,
    
    -- Failure Classification
    fail_category       VARCHAR(32),                        -- FUNCTIONAL / PARAMETRIC / LEAKAGE / SPEED / STUCK_AT
    fail_mechanism      VARCHAR(64),
    fail_test_name      VARCHAR(128),
    
    -- Priority (for bin pareto)
    priority_rank       SMALLINT,
    yield_impact_est    NUMERIC(6,3),
    
    UNIQUE (program_id, bin_code)
) DISTRIBUTED BY (program_id);
```

## CP_FACT_DIE_RESULT — Die-Level Test Result Fact

```sql
CREATE TABLE cp_fact_die_result (
    die_sk              BIGSERIAL,
    
    -- Lot / Wafer / Die
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    die_x               SMALLINT        NOT NULL,           -- die X coordinate
    die_y               SMALLINT        NOT NULL,           -- die Y coordinate
    die_index           INTEGER,                            -- linearized index
    
    -- Test
    program_id          VARCHAR(64)     NOT NULL,
    tester_id           VARCHAR(32),
    load_board_id       VARCHAR(32),
    probe_card_id       VARCHAR(32),
    site_number         SMALLINT,
    
    -- Bin Result
    hard_bin            SMALLINT        NOT NULL,
    soft_bin            SMALLINT,
    is_pass             BOOLEAN         NOT NULL,
    
    -- Test Count (retests)
    test_count          SMALLINT        DEFAULT 1,
    retest_hard_bin     SMALLINT,                           -- bin after retest
    
    -- Parametric Test Results (key items only; full in CP_FACT_PARAMETRIC)
    test_time_ms        NUMERIC(10,4),
    
    -- Touch Info
    touchdown_number    SMALLINT,                           -- which touchdown this die was on
    touch_x             NUMERIC(8,4),
    touch_y             NUMERIC(8,4),
    
    -- Smart Sampling
    was_tested          BOOLEAN DEFAULT TRUE,
    skip_reason         VARCHAR(24),                        -- SPATIAL_SKIP / CLUSTER_SKIP / ASSUMED_PASS
    
    -- Spatial Analysis Flags
    is_edge_die         BOOLEAN DEFAULT FALSE,
    edge_zone           VARCHAR(16),                        -- EDGE_1MM / EDGE_3MM / NOTCH_ZONE
    
    -- AI/ML Flags
    is_inkout_candidate BOOLEAN DEFAULT FALSE,
    is_spatial_cluster  BOOLEAN DEFAULT FALSE,
    cluster_id          INTEGER,
    
    -- Event
    test_time           TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);

CREATE INDEX idx_cp_die_wafer ON cp_fact_die_result(lot_id, wafer_id, die_x, die_y);
CREATE INDEX idx_cp_die_bin ON cp_fact_die_result(hard_bin, event_date);
CREATE INDEX idx_cp_die_tester ON cp_fact_die_result(tester_id, event_date);
```

## CP_FACT_PARAMETRIC — Die-Level Parametric Test Items

```sql
CREATE TABLE cp_fact_parametric (
    param_sk            BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    die_x               SMALLINT        NOT NULL,
    die_y               SMALLINT        NOT NULL,
    program_id          VARCHAR(64),
    test_number         INTEGER         NOT NULL,
    test_name           VARCHAR(128),
    
    -- Result
    measured_value      NUMERIC(20,10),
    low_limit           NUMERIC(20,10),
    high_limit          NUMERIC(20,10),
    pass_fail           CHAR(1),
    units               VARCHAR(16),
    
    -- Conditions
    vcc_v               NUMERIC(8,4),
    temp_c              NUMERIC(8,3),
    
    event_date          DATE NOT NULL,
    test_time           TIMESTAMP WITH TIME ZONE
) WITH (appendonly=true, orientation=column, compresslevel=7)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

## CP_FACT_WAFER_SUMMARY — Wafer-Level Yield Summary

```sql
CREATE TABLE cp_fact_wafer_summary (
    summary_sk          BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    program_id          VARCHAR(64),
    tester_id           VARCHAR(32),
    step_id             VARCHAR(32),
    
    -- Yield
    total_die           INTEGER,
    pass_die            INTEGER,
    fail_die            INTEGER,
    skip_die            INTEGER,
    edge_die_excluded   INTEGER,
    gross_yield_pct     NUMERIC(7,4),
    net_yield_pct       NUMERIC(7,4),
    
    -- Bin Breakdown (JSON for full flexibility)
    bin_counts_json     TEXT,                               -- {"1":8500,"2":200,...}
    
    -- First Pass / Retest
    first_pass_yield    NUMERIC(7,4),
    retest_count        INTEGER         DEFAULT 0,
    retest_pass_count   INTEGER         DEFAULT 0,
    offline_retest_rate NUMERIC(7,4),
    
    -- Site-to-Site Yield
    site_yields_json    TEXT,                               -- per-site yield %
    
    -- Spatial Pattern
    pattern_class_generic  VARCHAR(32),                     -- NORMAL / CENTER / EDGE / DONUT / SCRATCH / CLUSTER
    pattern_class_primary  VARCHAR(32),
    pattern_class_secondary VARCHAR(32),
    pattern_confidence  NUMERIC(6,4),
    
    -- Edge Analysis
    edge_yield_pct      NUMERIC(7,4),
    center_yield_pct    NUMERIC(7,4),
    edge_center_delta   NUMERIC(7,4),
    
    -- Defect Correlation
    defect_density_cm2  NUMERIC(12,6),
    predicted_yield_pct NUMERIC(7,4),                      -- from Virtual Yield model
    
    -- Flags
    is_partial_wafer    BOOLEAN DEFAULT FALSE,
    is_split_wafer      BOOLEAN DEFAULT FALSE,
    syl_flag            BOOLEAN DEFAULT FALSE,              -- below Soft Yield Limit
    sbl_flag            BOOLEAN DEFAULT FALSE,              -- below Soft Bin Limit
    mrb_required        BOOLEAN DEFAULT FALSE,
    mrb_result          VARCHAR(16),                        -- GOOD_WAFER / BAD_WAFER
    
    -- Tray Traceability
    tray_id             VARCHAR(32),
    tray_slot           SMALLINT,
    
    event_date          DATE NOT NULL,
    test_time           TIMESTAMP WITH TIME ZONE,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (lot_id, wafer_id, program_id, step_id)
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

## CP_FACT_TOUCHDOWN — Prober Touchdown Analysis

```sql
CREATE TABLE cp_fact_touchdown (
    td_sk               BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    program_id          VARCHAR(64),
    prober_id           VARCHAR(32),
    probe_card_id       VARCHAR(32),
    
    -- Touchdown Info
    touchdown_number    SMALLINT        NOT NULL,
    die_per_touchdown   SMALLINT,
    touchdown_x         NUMERIC(10,6),
    touchdown_y         NUMERIC(10,6),
    
    -- Yield per Touchdown
    pass_count          SMALLINT,
    fail_count          SMALLINT,
    skip_count          SMALLINT,
    yield_pct           NUMERIC(7,4),
    
    -- Probe Health
    probe_force_mg      NUMERIC(10,4),
    contact_resistance  NUMERIC(12,6),
    
    event_date          DATE NOT NULL,
    test_time           TIMESTAMP WITH TIME ZONE
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

## CP_FACT_TRAY_MAP — Package Tray Traceability

```sql
CREATE TABLE cp_fact_tray_map (
    tray_sk             BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    die_x               SMALLINT,
    die_y               SMALLINT,
    
    -- Tray Location
    tray_id             VARCHAR(32)     NOT NULL,
    tray_slot_row       SMALLINT,
    tray_slot_col       SMALLINT,
    
    -- Die Status in Tray
    bin_code            SMALLINT,
    bin_yield_pct       NUMERIC(7,4),
    final_disposition   VARCHAR(20),                        -- FINAL_PASS / SINGULATE_FAIL / FINAL_FAIL / UNKNOWN
    
    -- FT Result Link
    ft_lot_id           VARCHAR(32),
    ft_test_result      VARCHAR(16),
    
    event_date          DATE NOT NULL,
    UNIQUE (tray_id, tray_slot_row, tray_slot_col)
) WITH (appendonly=true)
DISTRIBUTED BY (lot_id);
```
---

# DOMAIN 4 — SPC (Statistical Process Control) DataMart

> **Purpose:** Real-time process monitoring, Western Electric rules, capability analysis, virtual metrology, alarm management, cross-parameter correlation monitoring

## SPC_DIM_PARAMETER_CONFIG — SPC Monitor Configuration

```sql
CREATE TABLE spc_dim_parameter_config (
    config_sk           BIGSERIAL       PRIMARY KEY,
    config_id           VARCHAR(64)     NOT NULL UNIQUE,
    
    -- Parameter Identity
    parameter_id        VARCHAR(64)     NOT NULL,           -- references WAT or Inline parameter
    parameter_source    VARCHAR(20)     NOT NULL,           -- WAT / INLINE / CP / FDC_DERIVED / VIRTUAL
    
    -- Scope
    product_id          VARCHAR(32),                        -- NULL = all products
    technology_id       VARCHAR(32),
    equipment_id        VARCHAR(32),                        -- NULL = all tools
    chamber_id          VARCHAR(16),                        -- NULL = all chambers
    recipe_id           VARCHAR(64),                        -- NULL = all recipes
    step_id             VARCHAR(32),
    
    -- Chart Configuration
    chart_type          VARCHAR(16)     NOT NULL,           -- XBAR_R / XBAR_S / IMR / P / NP / C / U
    subgroup_size       SMALLINT        DEFAULT 1,
    subgroup_method     VARCHAR(24),                        -- TIME_WINDOW / WAFER_COUNT / LOT_BASED
    
    -- Control Limits (Phase II)
    ucl                 NUMERIC(20,10),
    cl                  NUMERIC(20,10),
    lcl                 NUMERIC(20,10),
    ucl_2sigma          NUMERIC(20,10),
    lcl_2sigma          NUMERIC(20,10),
    ucl_1sigma          NUMERIC(20,10),
    lcl_1sigma          NUMERIC(20,10),
    sigma_estimate      NUMERIC(20,10),
    
    -- Spec Limits
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    target              NUMERIC(20,10),
    
    -- Phase I Basis
    phase1_lot_count    INTEGER,
    phase1_start_date   DATE,
    phase1_end_date     DATE,
    phase1_method       VARCHAR(24),                        -- RBAR / SBAR / MR / HISTORICAL
    
    -- Rule Configuration (bitmask or JSON)
    enabled_rules       SMALLINT        DEFAULT 255,        -- bitmask: bit1=R1, bit2=R2,...bit8=R8
    custom_rules_json   TEXT,                               -- user-defined rule expressions
    
    -- Response Actions
    alarm_mode          VARCHAR(16),                        -- EMAIL / SMS / MES_HOLD / AUTO_HOLD / AGENT
    alarm_severity      VARCHAR(16),                        -- CRITICAL / MAJOR / MINOR / INFO
    
    -- Virtual Metrology
    is_virtual          BOOLEAN DEFAULT FALSE,
    vm_model_id         VARCHAR(64),
    vm_feature_list     TEXT,                               -- JSON list of FDC features used
    vm_r_squared        NUMERIC(10,8),
    
    -- Status
    is_active           BOOLEAN DEFAULT TRUE,
    limit_version       INTEGER DEFAULT 1,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by          VARCHAR(64)
) DISTRIBUTED BY (config_id);
```

## SPC_FACT_MEASUREMENT — SPC Data Stream Fact

```sql
CREATE TABLE spc_fact_measurement (
    measurement_sk      BIGSERIAL,
    
    -- Reference
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    
    -- Lot / Wafer
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    slot_number         SMALLINT,
    
    -- Equipment Context
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    operator_id         VARCHAR(32),
    shift               VARCHAR(8),
    
    -- Subgroup
    subgroup_id         VARCHAR(64),                        -- unique subgroup identifier
    subgroup_index      INTEGER,                            -- sequential subgroup number
    
    -- Measurement
    measured_value      NUMERIC(20,10)  NOT NULL,
    subgroup_mean       NUMERIC(20,10),                     -- for Xbar charts
    subgroup_range      NUMERIC(20,10),                     -- for R charts
    subgroup_std        NUMERIC(20,10),                     -- for S charts
    moving_range        NUMERIC(20,10),                     -- for IMR charts
    
    -- Limits at Time of Measurement
    ucl_at_time         NUMERIC(20,10),
    cl_at_time          NUMERIC(20,10),
    lcl_at_time         NUMERIC(20,10),
    usl_at_time         NUMERIC(20,10),
    lsl_at_time         NUMERIC(20,10),
    
    -- Derived Stats
    sigma_score         NUMERIC(10,6),                      -- (value - cl) / sigma
    
    -- Violation Flags (8 Western Electric Rules)
    violation_rule_1    BOOLEAN DEFAULT FALSE,              -- 1pt > 3σ
    violation_rule_2    BOOLEAN DEFAULT FALSE,              -- 9 pts same side
    violation_rule_3    BOOLEAN DEFAULT FALSE,              -- 6 pts trend
    violation_rule_4    BOOLEAN DEFAULT FALSE,              -- 14 alternating
    violation_rule_5    BOOLEAN DEFAULT FALSE,              -- 2/3 pts > 2σ same side
    violation_rule_6    BOOLEAN DEFAULT FALSE,              -- 4/5 pts > 1σ same side
    violation_rule_7    BOOLEAN DEFAULT FALSE,              -- 15 pts within 1σ
    violation_rule_8    BOOLEAN DEFAULT FALSE,              -- 8 pts > 1σ both sides
    any_violation       BOOLEAN DEFAULT FALSE,              -- OR of all rules
    violation_rules_list VARCHAR(32),                       -- comma-list: "1,5"
    
    -- Alarm Generated
    alarm_triggered     BOOLEAN DEFAULT FALSE,
    alarm_id            VARCHAR(64),
    alarm_severity      VARCHAR(16),
    
    -- Virtual Metrology
    is_virtual          BOOLEAN DEFAULT FALSE,
    vm_predicted_value  NUMERIC(20,10),
    vm_ci_lower         NUMERIC(20,10),
    vm_ci_upper         NUMERIC(20,10),
    vm_prediction_error NUMERIC(20,10),
    
    -- Event
    measurement_time    TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (config_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);

CREATE INDEX idx_spc_meas_config ON spc_fact_measurement(config_id, event_date);
CREATE INDEX idx_spc_meas_equip ON spc_fact_measurement(equipment_id, parameter_id, event_date);
CREATE INDEX idx_spc_meas_violation ON spc_fact_measurement(any_violation, event_date) WHERE any_violation=TRUE;
```

## SPC_FACT_VIOLATION — SPC Violation Event Fact

```sql
CREATE TABLE spc_fact_violation (
    violation_sk        BIGSERIAL,
    
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    
    -- Violation Details
    rule_number         SMALLINT        NOT NULL,           -- 1–8
    rule_description    VARCHAR(256),
    rule_severity       VARCHAR(16),                        -- CRITICAL / MAJOR / MINOR
    
    -- Triggering Measurement
    triggering_measurement_sk BIGSERIAL,
    trigger_value       NUMERIC(20,10),
    trigger_lot_id      VARCHAR(32),
    trigger_wafer_id    VARCHAR(40),
    
    -- Context (the N measurements that triggered the rule)
    evidence_measurements_json TEXT,                        -- [{sk, value, lot_id, time}, ...]
    
    -- Statistical Context
    sigma_deviation     NUMERIC(10,6),
    cl_at_violation     NUMERIC(20,10),
    ucl_at_violation    NUMERIC(20,10),
    lcl_at_violation    NUMERIC(20,10),
    
    -- Disposition
    acknowledged_by     VARCHAR(64),
    acknowledged_at     TIMESTAMP WITH TIME ZONE,
    resolution_code     VARCHAR(32),                        -- PROCESS_ADJUST / MEAS_ERROR / SPEC_CHANGE / FALSE_ALARM
    resolution_note     TEXT,
    
    -- Downstream Impact
    lots_affected_count INTEGER,
    lots_on_hold_count  INTEGER,
    yield_impact_pct    NUMERIC(6,3),
    
    -- AI Investigation
    agent_rca_session_id VARCHAR(64),
    agent_rca_summary   TEXT,
    
    violation_time      TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (config_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

## SPC_AGG_CAPABILITY — Process Capability Aggregate

```sql
CREATE TABLE spc_agg_capability (
    capability_sk       BIGSERIAL,
    config_id           VARCHAR(64)     NOT NULL,
    parameter_id        VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32),
    product_id          VARCHAR(32),
    
    -- Period
    period_type         VARCHAR(16),                        -- DAILY / WEEKLY / MONTHLY
    period_start        DATE NOT NULL,
    period_end          DATE NOT NULL,
    n_observations      INTEGER,
    n_subgroups         INTEGER,
    
    -- Capability Indices
    cp                  NUMERIC(10,6),
    cpk                 NUMERIC(10,6),
    cpm                 NUMERIC(10,6),
    cpl                 NUMERIC(10,6),
    cpu                 NUMERIC(10,6),
    pp                  NUMERIC(10,6),
    ppk                 NUMERIC(10,6),
    
    -- Distribution
    mean_value          NUMERIC(20,10),
    std_dev_within      NUMERIC(20,10),
    std_dev_overall     NUMERIC(20,10),
    
    -- Violation Summary
    total_violations    INTEGER,
    violations_r1       SMALLINT,
    violations_r2       SMALLINT,
    violations_r3       SMALLINT,
    violations_r4       SMALLINT,
    violations_r5       SMALLINT,
    violations_r6       SMALLINT,
    violations_r7       SMALLINT,
    violations_r8       SMALLINT,
    
    computed_at         TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (config_id, period_type, period_start, equipment_id)
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (config_id);
```

---

# DOMAIN 5 — FDC (Fault Detection & Classification) DataMart

> **Purpose:** Equipment sensor trace analysis, anomaly detection, PM event tracking, alarm classification, equipment qualification (baseline vs qualification), trace feature extraction

## EQP_DIM_EQUIPMENT — Equipment Master Dimension

```sql
CREATE TABLE eqp_dim_equipment (
    equipment_sk        BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL UNIQUE,    -- e.g. ULKCVD-01
    equipment_name      VARCHAR(128),
    equipment_alias     VARCHAR(64),
    
    -- Classification
    equipment_type      VARCHAR(32)     NOT NULL,           -- CVD / ETCH / CMP / LITHO / IMP / DIFF / WET / INSP / WAT / CP
    equipment_subtype   VARCHAR(32),                        -- PECVD / LPCVD / ALD / HDPCVD
    oem_vendor          VARCHAR(32),                        -- AMAT / LAM / TEL / ASML / KLA
    oem_model           VARCHAR(64),
    oem_serial          VARCHAR(64),
    
    -- Location
    fab_id              VARCHAR(16),
    bay_id              VARCHAR(16),
    area_id             VARCHAR(32),
    
    -- Chamber Structure
    chamber_count       SMALLINT DEFAULT 1,
    is_multi_chamber    BOOLEAN DEFAULT FALSE,
    
    -- Capability
    wafer_size_mm       SMALLINT DEFAULT 300,
    process_capability  TEXT[],                             -- array of capable recipe types
    
    -- Status
    equipment_status    VARCHAR(24),                        -- PRODUCTION / MAINTENANCE / QUALIFICATION / IDLE / DOWN
    is_golden_tool      BOOLEAN DEFAULT FALSE,              -- reference tool for matching
    commissioning_date  DATE,
    
    -- Health (updated by FDC engine)
    health_score        NUMERIC(5,2)    DEFAULT 100.0,      -- 0-100
    health_tier         VARCHAR(16),                        -- HEALTHY / WATCH / DEGRADED / CRITICAL
    health_updated_at   TIMESTAMP WITH TIME ZONE,
    
    -- Composite Health Components
    z_score_component   NUMERIC(5,3),
    gof_component       NUMERIC(5,3),
    cv_stability_component NUMERIC(5,3),
    volume_component    NUMERIC(5,3),
    
    -- PM Schedule
    last_pm_date        DATE,
    next_pm_date        DATE,
    pm_interval_days    INTEGER,
    pm_wafer_count      INTEGER,
    
    -- SCD Type 2
    effective_from      DATE DEFAULT CURRENT_DATE,
    effective_to        DATE,
    is_current          BOOLEAN DEFAULT TRUE,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (equipment_id);
```

## EQP_DIM_CHAMBER — Chamber Master Dimension

```sql
CREATE TABLE eqp_dim_chamber (
    chamber_sk          BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16)     NOT NULL,           -- A / B / C / PM1 / PM2 / PM3 / PM4
    chamber_name        VARCHAR(64),
    
    -- Classification
    chamber_type        VARCHAR(32),
    chamber_index       SMALLINT,
    
    -- Status
    chamber_status      VARCHAR(24),
    health_score        NUMERIC(5,2),
    last_clean_date     DATE,
    last_pm_date        DATE,
    run_since_pm        INTEGER,                            -- wafer count since last PM
    
    -- Matching Reference
    is_reference_chamber BOOLEAN DEFAULT FALSE,
    matching_target_chamber VARCHAR(16),
    
    UNIQUE (equipment_id, chamber_id)
) DISTRIBUTED BY (equipment_id);
```

## FDC_DIM_SENSOR — Sensor / Trace Channel Registry

```sql
CREATE TABLE fdc_dim_sensor (
    sensor_sk           BIGSERIAL       PRIMARY KEY,
    equipment_id        VARCHAR(32)     NOT NULL,
    sensor_alias        VARCHAR(128)    NOT NULL,           -- e.g. DAQ275HPPumpCurrentR
    sensor_full_name    VARCHAR(256),
    
    -- Classification
    sensor_type         VARCHAR(32),                        -- PRESSURE / TEMP / FLOW / POWER / CURRENT / VOLTAGE / POSITION / ENDPOINT
    measurement_units   VARCHAR(32),
    module_id           VARCHAR(16),
    module_name         VARCHAR(64),
    
    -- Sampling
    sampling_rate_hz    NUMERIC(10,4),
    is_time_series      BOOLEAN DEFAULT TRUE,
    
    -- SPC Config
    is_spc_monitored    BOOLEAN DEFAULT FALSE,
    spc_config_id       VARCHAR(64),
    
    -- FDC Config
    is_fdc_monitored    BOOLEAN DEFAULT TRUE,
    fdc_alarm_enabled   BOOLEAN DEFAULT TRUE,
    baseline_sigma_limit NUMERIC(6,2)   DEFAULT 6.0,
    
    UNIQUE (equipment_id, sensor_alias)
) DISTRIBUTED BY (equipment_id);
```

## FDC_DIM_INDICATOR — FDC Indicator / Feature Definition

```sql
CREATE TABLE fdc_dim_indicator (
    indicator_sk        BIGSERIAL       PRIMARY KEY,
    indicator_id        VARCHAR(128)    NOT NULL UNIQUE,    -- e.g. BPOFG-F040-B4_BiasMatch_Shape
    indicator_name      VARCHAR(256),
    
    -- Source
    equipment_id        VARCHAR(32),
    recipe_id           VARCHAR(64),
    sensor_alias        VARCHAR(128),
    
    -- Feature Type
    feature_type        VARCHAR(24),                        -- SHAPE / MAX / MIN / MEAN / AREA / SLOPE / ENDPOINT / CUSTOM
    step_segment        VARCHAR(32),                        -- which recipe step this applies to
    
    -- SPC / Alarm Config
    alarm_mode          VARCHAR(16),                        -- NoSPC / EMAIL / SMS / MES_HOLD
    ucl                 NUMERIC(20,10),
    lcl                 NUMERIC(20,10),
    cl                  NUMERIC(20,10),
    
    -- Capability
    ca                  NUMERIC(10,6),                      -- accuracy index
    cp                  NUMERIC(10,6),
    cpk                 NUMERIC(10,6),
    cpk_threshold       NUMERIC(10,6)   DEFAULT 1.33,
    
    -- Alarm History
    total_runs          INTEGER DEFAULT 0,
    total_alarms        INTEGER DEFAULT 0,
    alarm_rate_pct      NUMERIC(8,4),
    last_alarm_time     TIMESTAMP WITH TIME ZONE,
    
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (equipment_id);
```

## FDC_FACT_TRACE_RUN — Equipment Run / Job Fact

```sql
CREATE TABLE fdc_fact_trace_run (
    run_sk              BIGSERIAL,
    
    -- Identity
    run_id              VARCHAR(64)     NOT NULL UNIQUE,    -- unique run identifier
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    slot_number         SMALLINT,
    
    -- Equipment
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    recipe_version      VARCHAR(8),
    
    -- Process Context
    step_id             VARCHAR(32),
    route_id            VARCHAR(32),
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    -- Run Timing
    run_start_time      TIMESTAMP WITH TIME ZONE NOT NULL,
    run_end_time        TIMESTAMP WITH TIME ZONE,
    run_duration_sec    NUMERIC(12,4),
    
    -- Process Timeline Steps (JSON array of step events)
    process_steps_json  TEXT,                               -- [{step, event, elapsed_sec, timestamp}, ...]
    
    -- FDC Result
    run_result          VARCHAR(16),                        -- PASS / ALARM / ABORT
    alarm_count         SMALLINT        DEFAULT 0,
    alarm_sensor_list   TEXT,                               -- comma-sep sensor aliases that alarmed
    
    -- Anomaly Scores (per detection type)
    interval_anomaly_score  NUMERIC(8,6),
    pm_anomaly_score        NUMERIC(8,6),
    amplitude_anomaly_score NUMERIC(8,6),
    shape_anomaly_score     NUMERIC(8,6),
    composite_anomaly_score NUMERIC(8,6),                   -- weighted fusion
    
    -- Classification
    anomaly_class       VARCHAR(32),                        -- NORMAL / INTERVAL / PM_SHIFT / AMPLITUDE / SHAPE / MULTI
    is_anomaly          BOOLEAN DEFAULT FALSE,
    
    -- Post-PM Flag
    is_post_pm          BOOLEAN DEFAULT FALSE,
    pm_wafer_count      INTEGER,                            -- runs since last PM
    
    -- Qualification
    is_qualification_run BOOLEAN DEFAULT FALSE,
    baseline_run_id     VARCHAR(64),                        -- comparison baseline run
    qual_match_score    NUMERIC(8,6),                       -- how well qual matches baseline
    
    event_date          DATE NOT NULL,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (equipment_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

## FDC_FACT_TRACE_DATA — Raw Sensor Trace Storage

```sql
-- Note: Large volume table - keep compressed, partition aggressively
CREATE TABLE fdc_fact_trace_data (
    trace_sk            BIGSERIAL,
    run_id              VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    sensor_alias        VARCHAR(128)    NOT NULL,
    
    -- Trace Metadata
    trace_type          VARCHAR(16),                        -- BASELINE / QUALIFICATION / PRODUCTION
    recipe_step         VARCHAR(32),
    
    -- Time Series (stored as arrays for efficiency)
    time_points_json    TEXT NOT NULL,                      -- [0.0, 0.1, 0.2, ...] seconds
    values_json         TEXT NOT NULL,                      -- [5.2, 5.21, 5.19, ...]
    n_points            INTEGER,
    
    -- Pre-computed Stats per Trace
    trace_mean          NUMERIC(16,8),
    trace_std           NUMERIC(16,8),
    trace_min           NUMERIC(16,8),
    trace_max           NUMERIC(16,8),
    trace_range         NUMERIC(16,8),
    trace_area          NUMERIC(20,10),
    trace_slope         NUMERIC(16,10),
    
    -- Anomaly per Trace
    dtw_distance        NUMERIC(16,8),                      -- DTW from baseline template
    reconstruction_error NUMERIC(16,8),                     -- LSTM Autoencoder error
    pct_out_of_band     NUMERIC(8,6),                       -- fraction outside [p5, p95]
    
    -- Storage
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=9)
DISTRIBUTED BY (run_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

## FDC_FACT_INDICATOR_RESULT — Indicator-Level FDC Results

```sql
CREATE TABLE fdc_fact_indicator_result (
    ind_result_sk       BIGSERIAL,
    run_id              VARCHAR(64)     NOT NULL,
    indicator_id        VARCHAR(128)    NOT NULL,
    equipment_id        VARCHAR(32),
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    step_id             VARCHAR(32),
    
    -- Feature Value
    feature_value       NUMERIC(20,10),
    feature_type        VARCHAR(24),
    
    -- Limits
    ucl                 NUMERIC(20,10),
    lcl                 NUMERIC(20,10),
    cl                  NUMERIC(20,10),
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    
    -- Result
    pass_fail           CHAR(1),                            -- P / F
    sigma_deviation     NUMERIC(10,6),
    alarm_triggered     BOOLEAN DEFAULT FALSE,
    alarm_mode          VARCHAR(16),
    
    -- Process Staging
    dc_context          VARCHAR(64),                        -- context identifier
    
    measurement_time    TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (equipment_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

## FDC_FACT_PM_EVENT — Preventive Maintenance Event Fact

```sql
CREATE TABLE fdc_fact_pm_event (
    pm_sk               BIGSERIAL,
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    
    -- PM Classification
    pm_type             VARCHAR(32),                        -- SCHEDULED / PREDICTIVE / CORRECTIVE / EMERGENCY
    pm_subtype          VARCHAR(32),                        -- PAD_REPLACE / CLEAN / CALIBRATE / REPLACE_PART
    pm_code             VARCHAR(16),
    
    -- Timing
    pm_start_time       TIMESTAMP WITH TIME ZONE NOT NULL,
    pm_end_time         TIMESTAMP WITH TIME ZONE,
    pm_duration_hr      NUMERIC(8,3),
    
    -- Trigger
    trigger_source      VARCHAR(24),                        -- SCHEDULE / HEALTH_SCORE / AGENT / MANUAL / ALARM
    trigger_health_score NUMERIC(5,2),
    trigger_alarm_id    VARCHAR(64),
    
    -- Performed By
    performed_by        VARCHAR(64),
    oem_support         BOOLEAN DEFAULT FALSE,
    
    -- Parts Used
    parts_json          TEXT,                               -- [{part_id, qty, description}, ...]
    
    -- Pre/Post Qualification
    pre_pm_health_score NUMERIC(5,2),
    post_pm_health_score NUMERIC(5,2),
    health_improvement  NUMERIC(5,2),
    qualification_passed BOOLEAN,
    qual_run_id         VARCHAR(64),
    
    -- WIP Impact
    wafers_impacted     INTEGER DEFAULT 0,
    lots_on_hold        INTEGER DEFAULT 0,
    
    -- CMMS Reference
    cmms_work_order_id  VARCHAR(32),
    
    event_date          DATE NOT NULL,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true)
DISTRIBUTED BY (equipment_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 year')
);
```

---

# DOMAIN 6 — MTR (Inline Metrology) DataMart

> **Purpose:** CD, overlay, film thickness, after-etch, chemical mechanical planarization measurements; virtual metrology correlation; within-wafer uniformity; tool-to-tool matching

## MTR_DIM_RECIPE_STEP — Metrology Recipe & Step Config

```sql
CREATE TABLE mtr_dim_recipe_step (
    recipe_step_sk      BIGSERIAL       PRIMARY KEY,
    mtr_recipe_id       VARCHAR(64)     NOT NULL,
    mtr_step_id         VARCHAR(32)     NOT NULL,
    
    -- What is being measured
    measurement_type    VARCHAR(32),                        -- CD / OVERLAY / FILM_THICKNESS / ROUGHNESS / HEIGHT
    measurement_subtype VARCHAR(32),                        -- AA_CD / PO_CD / M1_THICKNESS / ...
    layer_name          VARCHAR(32),
    after_step_id       VARCHAR(32),                        -- which process step this measures after
    
    -- Site Pattern
    site_count          SMALLINT,
    site_pattern        VARCHAR(32),                        -- 5PT / 9PT / 25PT / 49PT / CUSTOM
    site_map_json       TEXT,                               -- [{site, x_mm, y_mm}, ...]
    
    -- Equipment
    tool_type           VARCHAR(32),                        -- SEM / OCD / ELLIPS / AFM / XRF / BF_OPT
    
    UNIQUE (mtr_recipe_id, mtr_step_id)
) DISTRIBUTED BY (mtr_recipe_id);
```

## MTR_FACT_MEASUREMENT — Inline Metrology Measurement Fact

```sql
CREATE TABLE mtr_fact_measurement (
    mtr_sk              BIGSERIAL,
    
    -- Keys
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    site_id             SMALLINT        NOT NULL,
    site_x              NUMERIC(8,4),
    site_y              NUMERIC(8,4),
    site_zone           VARCHAR(16),
    
    -- Measurement Identity
    mtr_recipe_id       VARCHAR(64),
    mtr_step_id         VARCHAR(32),
    measurement_type    VARCHAR(32)     NOT NULL,
    measurement_subtype VARCHAR(32),
    layer_name          VARCHAR(32),
    
    -- Equipment
    equipment_id        VARCHAR(32),
    recipe_id           VARCHAR(64),
    
    -- After Which Process Step
    after_step_id       VARCHAR(32),
    after_equipment_id  VARCHAR(32),
    after_recipe_id     VARCHAR(64),
    
    -- Measurement Value
    measured_value      NUMERIC(20,10)  NOT NULL,
    unit                VARCHAR(16),
    
    -- Reference Values
    target_value        NUMERIC(20,10),
    nominal_value       NUMERIC(20,10),
    usl                 NUMERIC(20,10),
    lsl                 NUMERIC(20,10),
    
    -- Pass/Fail
    pass_fail           CHAR(1),
    deviation_from_target NUMERIC(20,10),
    pct_deviation       NUMERIC(12,8),
    
    -- SPC at time of measurement
    spc_cl              NUMERIC(20,10),
    spc_ucl             NUMERIC(20,10),
    spc_lcl             NUMERIC(20,10),
    sigma_deviation     NUMERIC(10,6),
    any_spc_violation   BOOLEAN DEFAULT FALSE,
    
    -- Virtual Metrology Comparison
    vm_predicted        NUMERIC(20,10),
    vm_error            NUMERIC(20,10),
    vm_within_ci        BOOLEAN,
    
    -- APC Feed-Forward Context
    apc_recipe_adjusted BOOLEAN DEFAULT FALSE,
    apc_adjustment_delta NUMERIC(20,10),
    
    measurement_time    TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);
```

---

# DOMAIN 7 — APC (Advanced Process Control) DataMart

> **Purpose:** Run-to-run control models, setpoint adjustments, feed-forward/feedback loops, R2R model performance, process drift correction

## APC_DIM_MODEL — APC Model Registry

```sql
CREATE TABLE apc_dim_model (
    model_sk            BIGSERIAL       PRIMARY KEY,
    model_id            VARCHAR(64)     NOT NULL UNIQUE,
    model_name          VARCHAR(128),
    model_version       VARCHAR(8),
    
    -- Scope
    equipment_id        VARCHAR(32),
    recipe_id           VARCHAR(64),
    step_id             VARCHAR(32),
    product_id          VARCHAR(32),
    
    -- Model Type
    model_type          VARCHAR(24),                        -- EWMA / DOUBLE_EWMA / LINEAR / PLS / MPC / NEURAL
    control_type        VARCHAR(24),                        -- RUN_TO_RUN / WAFER_TO_WAFER / WITHIN_WAFER
    
    -- Control Variable (what is adjusted)
    manipulated_var_id  VARCHAR(64),                        -- recipe parameter being adjusted
    manipulated_var_name VARCHAR(128),
    manipulated_var_unit VARCHAR(16),
    mv_min              NUMERIC(16,8),                      -- lower bound for adjustment
    mv_max              NUMERIC(16,8),                      -- upper bound for adjustment
    mv_step_max         NUMERIC(16,8),                      -- max change per run (safety)
    
    -- Controlled Variable (what is targeted)
    controlled_var_id   VARCHAR(64),                        -- metrology or WAT parameter
    controlled_var_target NUMERIC(20,10),
    
    -- EWMA Parameters
    ewma_lambda         NUMERIC(6,4)    DEFAULT 0.4,        -- forgetting factor
    ewma_discount       NUMERIC(6,4),
    
    -- Performance
    model_r_squared     NUMERIC(10,8),
    model_rmse          NUMERIC(20,10),
    
    -- Status
    is_active           BOOLEAN DEFAULT TRUE,
    training_start_date DATE,
    training_end_date   DATE,
    last_retrain_date   DATE,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (equipment_id);
```

## APC_FACT_CONTROL_ACTION — R2R Control Action Fact

```sql
CREATE TABLE apc_fact_control_action (
    action_sk           BIGSERIAL,
    
    model_id            VARCHAR(64)     NOT NULL,
    equipment_id        VARCHAR(32)     NOT NULL,
    chamber_id          VARCHAR(16),
    recipe_id           VARCHAR(64),
    
    -- Lot Context
    lot_id              VARCHAR(32),
    wafer_id            VARCHAR(40),
    run_number          INTEGER,
    
    -- Timing
    action_time         TIMESTAMP WITH TIME ZONE NOT NULL,
    applied_to_run_id   VARCHAR(64),
    
    -- Feedback
    measured_output     NUMERIC(20,10),                     -- from previous run measurement
    target_output       NUMERIC(20,10),
    error_from_target   NUMERIC(20,10),
    
    -- Control Action
    previous_setpoint   NUMERIC(20,10),
    predicted_output    NUMERIC(20,10),                     -- model prediction
    setpoint_adjustment NUMERIC(20,10),                     -- delta applied
    new_setpoint        NUMERIC(20,10),
    
    -- Feed-Forward
    ff_measurement_value NUMERIC(20,10),                    -- incoming metro used for FF
    ff_correction       NUMERIC(20,10),
    
    -- Model State
    ewma_state          NUMERIC(20,10),                     -- EWMA model state at time of action
    model_r2_current    NUMERIC(10,8),
    
    -- Validation
    was_applied         BOOLEAN DEFAULT TRUE,
    override_reason     VARCHAR(64),
    
    -- Post-run Verification
    actual_output       NUMERIC(20,10),                     -- measured after this run
    actual_error        NUMERIC(20,10),
    control_effective   BOOLEAN,
    
    event_date          DATE NOT NULL
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (equipment_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

---

# DOMAIN 8 — DEF (Defect) DataMart

> **Purpose:** Inline inspection defect management, ADC classification, wafer pattern analysis, SEM image management, defect-to-yield correlation, killer defect identification

## DEF_FACT_DEFECT — Defect Point Fact

```sql
CREATE TABLE def_fact_defect (
    defect_sk           BIGSERIAL,
    
    -- Lot / Wafer
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    slot_number         SMALLINT,
    
    -- Inspection
    inspection_tool_id  VARCHAR(32)     NOT NULL,           -- KLA-1234 / AMAT-XYZ
    inspection_recipe   VARCHAR(64),
    inspection_layer    VARCHAR(32),
    inspection_step_id  VARCHAR(32),
    
    -- Defect Location
    defect_x_um         NUMERIC(12,4),                      -- X coordinate in µm
    defect_y_um         NUMERIC(12,4),                      -- Y coordinate in µm
    die_x               SMALLINT,
    die_y               SMALLINT,
    
    -- Defect Physical Properties
    defect_size_nm      NUMERIC(12,4),                      -- long axis
    defect_size_y_nm    NUMERIC(12,4),                      -- short axis
    defect_area_nm2     NUMERIC(16,4),
    defect_roughness    NUMERIC(10,6),
    defect_finition     VARCHAR(16),
    
    -- Classification
    rough_class         VARCHAR(32),                        -- from inspection tool (rough classification)
    adc_class           VARCHAR(32),                        -- ADC refined classification
    adc_confidence      NUMERIC(6,4),
    is_adc_auto         BOOLEAN DEFAULT FALSE,              -- auto-classified vs human-reviewed
    human_class         VARCHAR(32),                        -- human correction (if any)
    final_class         VARCHAR(32),                        -- final accepted classification
    
    -- Class Categories (from wafer images)
    class_category      VARCHAR(32),                        -- Particle / Scratch / Crystal / Bridge / Pit / Film / Unknown
    class_subcategory   VARCHAR(32),
    
    -- Kill Probability
    die_size_x_nm       NUMERIC(12,4),
    die_size_y_nm       NUMERIC(12,4),
    is_killer           BOOLEAN,                            -- overlaps with critical area
    kill_probability    NUMERIC(8,6),                       -- based on critical area model
    
    -- SEM Review
    sem_reviewed        BOOLEAN DEFAULT FALSE,
    sem_image_path      VARCHAR(256),                       -- MinIO path
    sem_image_id        UUID,
    
    -- Flags
    is_nuisance         BOOLEAN DEFAULT FALSE,
    
    -- Event
    inspection_time     TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column, compresslevel=5)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 month')
);

CREATE INDEX idx_def_defect_class ON def_fact_defect(final_class, event_date);
CREATE INDEX idx_def_defect_tool ON def_fact_defect(inspection_tool_id, event_date);
```

## DEF_FACT_WAFER_DEFECT_SUMMARY — Per-Wafer Defect Summary

```sql
CREATE TABLE def_fact_wafer_defect_summary (
    def_summary_sk      BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    inspection_tool_id  VARCHAR(32),
    inspection_step_id  VARCHAR(32),
    inspection_layer    VARCHAR(32),
    
    -- Counts
    total_defects       INTEGER         DEFAULT 0,
    killer_defects      INTEGER         DEFAULT 0,
    nuisance_defects    INTEGER         DEFAULT 0,
    
    -- Density
    inspection_area_cm2 NUMERIC(12,6),
    defect_density_cm2  NUMERIC(14,8),
    killer_density_cm2  NUMERIC(14,8),
    
    -- Class Breakdown (JSON for full bin spectrum)
    class_counts_json   TEXT,                               -- {"Particle":120,"Scratch":15,...}
    
    -- Spatial Pattern
    pattern_class       VARCHAR(32),                        -- NORMAL / CLUSTER / EDGE / RING / SCRATCH / LINEAR
    pattern_confidence  NUMERIC(6,4),
    pattern_center_x    NUMERIC(12,4),
    pattern_center_y    NUMERIC(12,4),
    pattern_radius_mm   NUMERIC(8,4),
    
    -- Process Step Hypothesis (from pattern-to-process mapping)
    suspected_step_id   VARCHAR(32),
    suspected_equipment_id VARCHAR(32),
    hypothesis_confidence NUMERIC(6,4),
    
    -- Yield Impact
    predicted_yield_loss_pct NUMERIC(7,4),
    
    inspection_time     TIMESTAMP WITH TIME ZONE,
    event_date          DATE NOT NULL,
    UNIQUE (lot_id, wafer_id, inspection_tool_id, inspection_step_id)
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

---

# DOMAIN 9 — YLD (Yield) DataMart

> **Purpose:** Cross-domain yield aggregation, excursion detection, RCA knowledge, prediction, virtual yield, yield learning curves, MRB consolidation

## YLD_FACT_EXCURSION — Yield Excursion Event Fact

```sql
CREATE TABLE yld_fact_excursion (
    excursion_sk        BIGSERIAL,
    excursion_id        VARCHAR(64)     NOT NULL UNIQUE,    -- UUID
    
    -- Scope
    excursion_type      VARCHAR(24)     NOT NULL,           -- YIELD / BIN_SHIFT / WAT / SPC / FDC / DEFECT
    excursion_source    VARCHAR(24),                        -- SYSTEM / AGENT / ENGINEER / SPC_RULE / FDC_ALARM
    severity            VARCHAR(16)     NOT NULL,           -- CRITICAL / MAJOR / MINOR
    
    -- Affected Lots
    trigger_lot_id      VARCHAR(32),
    affected_lot_ids    TEXT,                               -- comma-sep or JSON array
    affected_lot_count  INTEGER,
    affected_wafer_count INTEGER,
    
    -- Product Context
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    step_id             VARCHAR(32),
    equipment_id        VARCHAR(32),
    
    -- Yield Impact
    baseline_yield_pct  NUMERIC(7,4),
    excursion_yield_pct NUMERIC(7,4),
    yield_delta_pct     NUMERIC(7,4),
    estimated_revenue_impact_usd NUMERIC(14,2),
    
    -- Detection
    detected_at         TIMESTAMP WITH TIME ZONE NOT NULL,
    detection_method    VARCHAR(32),                        -- SHEWHART_3SIGMA / BIN_CHISQ / ML_ANOMALY / MANUAL
    
    -- Resolution
    status              VARCHAR(20)     DEFAULT 'OPEN',     -- OPEN / INVESTIGATING / RESOLVED / CLOSED / FALSE_ALARM
    resolved_at         TIMESTAMP WITH TIME ZONE,
    resolution_days     NUMERIC(8,4),
    
    -- RCA Link
    rca_session_id      VARCHAR(64),
    confirmed_root_cause VARCHAR(256),
    root_cause_category VARCHAR(32),
    corrective_action   TEXT,
    preventive_action   TEXT,
    
    -- Agent Investigation
    agent_investigated  BOOLEAN DEFAULT FALSE,
    agent_confidence    NUMERIC(6,4),
    agent_rca_summary   TEXT,
    
    event_date          DATE NOT NULL,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true)
DISTRIBUTED BY (product_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '6 months')
);
```

## YLD_FACT_PREDICTION — ML Yield Prediction Fact

```sql
CREATE TABLE yld_fact_prediction (
    prediction_sk       BIGSERIAL,
    prediction_id       UUID            DEFAULT gen_random_uuid(),
    
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40),
    
    -- Prediction Metadata
    model_id            VARCHAR(64),
    model_version       VARCHAR(16),
    prediction_type     VARCHAR(24),                        -- EARLY_WARNING / PRE_CP / LOT_LEVEL
    prediction_step_id  VARCHAR(32),                        -- which process step prediction made at
    
    -- Prediction
    predicted_yield_pct NUMERIC(7,4),
    predicted_ci_lower  NUMERIC(7,4),
    predicted_ci_upper  NUMERIC(7,4),
    prediction_uncertainty NUMERIC(7,4),
    
    -- Model Components
    xgboost_prediction  NUMERIC(7,4),
    lstm_prediction     NUMERIC(7,4),
    xgboost_weight      NUMERIC(4,3)    DEFAULT 0.7,
    lstm_weight         NUMERIC(4,3)    DEFAULT 0.3,
    
    -- SHAP Attribution
    top_factor_1_name   VARCHAR(64),
    top_factor_1_shap   NUMERIC(14,8),
    top_factor_2_name   VARCHAR(64),
    top_factor_2_shap   NUMERIC(14,8),
    top_factor_3_name   VARCHAR(64),
    top_factor_3_shap   NUMERIC(14,8),
    shap_values_json    TEXT,                               -- full SHAP vector
    
    -- Actual (filled in after CP test completes)
    actual_yield_pct    NUMERIC(7,4),
    prediction_error    NUMERIC(7,4),
    prediction_within_ci BOOLEAN,
    
    -- Risk Flags
    is_high_risk        BOOLEAN DEFAULT FALSE,              -- below target threshold
    risk_alert_sent     BOOLEAN DEFAULT FALSE,
    
    prediction_time     TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '3 months')
);
```

## YLD_FACT_RCA_KNOWLEDGE — RCA Knowledge Base (also mirrored to Neo4j)

```sql
CREATE TABLE yld_fact_rca_knowledge (
    rca_sk              BIGSERIAL,
    rca_id              UUID            DEFAULT gen_random_uuid() UNIQUE,
    
    -- Symptom Signature
    symptom_category    VARCHAR(32),                        -- YIELD_DROP / WAT_SHIFT / BIN_CHANGE / SPATIAL_PATTERN / FDC_ALARM
    symptom_description TEXT,
    symptom_signature_hash VARCHAR(64),                     -- hash for similarity matching
    
    -- Context
    product_id          VARCHAR(32),
    process_node        VARCHAR(16),
    step_id             VARCHAR(32),
    equipment_type      VARCHAR(32),
    layer_name          VARCHAR(32),
    
    -- Root Cause
    root_cause_category VARCHAR(32),                        -- EQUIPMENT / PROCESS / MATERIAL / DESIGN / MEASUREMENT / HUMAN
    root_cause_subcategory VARCHAR(64),
    root_cause_description TEXT,
    
    -- Physical Mechanism
    physical_mechanism  TEXT,                               -- process physics explanation
    
    -- Evidence (what data supported this RCA)
    evidence_json       TEXT,                               -- [{type, parameter, value, significance}, ...]
    
    -- Actions
    corrective_action   TEXT,
    preventive_action   TEXT,
    verification_steps  TEXT,
    
    -- Outcome
    yield_recovered_pct NUMERIC(7,4),
    time_to_resolution_hr NUMERIC(10,4),
    
    -- Confidence & Usage
    confidence_score    NUMERIC(6,4)    DEFAULT 0.5,
    occurrence_count    INTEGER         DEFAULT 1,
    validation_count    INTEGER         DEFAULT 0,
    last_validated_by   VARCHAR(64),
    last_validated_at   TIMESTAMP WITH TIME ZONE,
    
    -- AI Attribution
    discovered_by       VARCHAR(24),                        -- ENGINEER / AGENT / ML_MODEL
    agent_session_id    VARCHAR(64),
    
    -- Embedding (for vector similarity search)
    symptom_embedding   TEXT,                               -- JSON float array, 1536-dim
    
    -- Dates
    first_seen          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true)
DISTRIBUTED BY (root_cause_category);

CREATE INDEX idx_rca_symptom_hash ON yld_fact_rca_knowledge(symptom_signature_hash);
CREATE INDEX idx_rca_category ON yld_fact_rca_knowledge(root_cause_category, product_id);
```

---

# DOMAIN 10 — MSC (Measurement System Comparison / R&R) DataMart

> **Purpose:** Measurement system analysis, tester-to-tester matching, R&R, GR&R, tester qualification, CP/FT method comparison

## MSC_FACT_RR_RESULT — R&R Measurement Comparison Fact

```sql
CREATE TABLE msc_fact_rr_result (
    rr_sk               BIGSERIAL,
    study_id            VARCHAR(64)     NOT NULL,
    study_type          VARCHAR(24),                        -- GAUGE_RR / MSC / ANOVA_GRR / LINEARITY
    
    test_number         INTEGER,
    test_name           VARCHAR(128),
    unit                VARCHAR(16),
    
    -- System 1
    system1_id          VARCHAR(32),                        -- tester_id / equipment_id
    system1_values_json TEXT,                               -- measurement array
    system1_mean        NUMERIC(20,10),
    system1_std         NUMERIC(20,10),
    system1_median      NUMERIC(20,10),
    system1_cpk         NUMERIC(10,6),
    
    -- System 2
    system2_id          VARCHAR(32),
    system2_values_json TEXT,
    system2_mean        NUMERIC(20,10),
    system2_std         NUMERIC(20,10),
    system2_median      NUMERIC(20,10),
    system2_cpk         NUMERIC(10,6),
    
    -- R&R Metrics
    rr_pct              NUMERIC(8,4),                       -- R&R %
    reproducibility_pct NUMERIC(8,4),
    repeatability_sys1  NUMERIC(8,4),
    repeatability_sys2  NUMERIC(8,4),
    
    -- Specification
    lpl                 NUMERIC(20,10),                     -- Lower Performance Limit
    upl                 NUMERIC(20,10),                     -- Upper Performance Limit
    q2                  NUMERIC(20,10),                     -- median (Q2)
    
    -- Tests
    t_test_stat         NUMERIC(12,6),
    t_test_p_value      NUMERIC(12,10),
    f_test_stat         NUMERIC(12,6),
    f_test_p_value      NUMERIC(12,10),
    
    -- Delta
    mean_delta          NUMERIC(20,10),
    delta_significant   BOOLEAN,
    
    -- Pass/Fail Threshold
    rr_threshold        NUMERIC(8,4)    DEFAULT 10.0,       -- flag if R&R% > threshold
    is_acceptable       BOOLEAN,
    
    -- Derived
    diff_sys1           NUMERIC(20,10),
    diff_sys2           NUMERIC(20,10),
    
    study_date          DATE NOT NULL,
    event_date          DATE NOT NULL,
    product_id          VARCHAR(32),
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (study_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 year')
);
```

---

# DOMAIN 11 — REL (Reliability / WLR) DataMart

> **Purpose:** Wafer-level reliability tests (TDDB, HCI, NBTI, EM), lifetime prediction, burn-in data, DPPM fallout models

## REL_FACT_WLR_RESULT — Wafer Level Reliability Test Fact

```sql
CREATE TABLE rel_fact_wlr_result (
    wlr_sk              BIGSERIAL,
    lot_id              VARCHAR(32)     NOT NULL,
    wafer_id            VARCHAR(40)     NOT NULL,
    site_id             SMALLINT,
    
    -- Test
    test_id             VARCHAR(64),
    test_type           VARCHAR(24),                        -- TDDB / HCI / NBTI / PBTI / EM
    stress_type         VARCHAR(24),                        -- VOLTAGE / CURRENT / TEMP / COMBINED
    
    -- Stress Conditions
    stress_voltage_v    NUMERIC(10,6),
    stress_current_a    NUMERIC(14,10),
    stress_temp_c       NUMERIC(8,3),
    stress_time_sec     NUMERIC(16,4),
    
    -- Result
    measured_value      NUMERIC(20,10),
    fail_criterion      NUMERIC(20,10),
    is_fail             BOOLEAN,
    time_to_fail_sec    NUMERIC(16,4),
    
    -- Lifetime Projection
    projected_lifetime_hr NUMERIC(16,4),
    lifetime_ci_lower   NUMERIC(16,4),
    lifetime_ci_upper   NUMERIC(16,4),
    
    tester_id           VARCHAR(32),
    test_time           TIMESTAMP WITH TIME ZONE,
    event_date          DATE NOT NULL
) WITH (appendonly=true, orientation=column)
DISTRIBUTED BY (lot_id)
PARTITION BY RANGE (event_date) (
    START ('2022-01-01') END ('2027-01-01') EVERY (INTERVAL '1 year')
);
```

## REL_FACT_DPPM_MODEL — DPPM / Burn-in Model Results

```sql
CREATE TABLE rel_fact_dppm_model (
    dppm_sk             BIGSERIAL,
    model_id            VARCHAR(64),
    product_id          VARCHAR(32)     NOT NULL,
    technology_id       VARCHAR(32),
    model_type          VARCHAR(16),                        -- BEST / AVERAGE / WORST
    
    -- Burn-in Sweep Points
    burnin_pct          NUMERIC(6,3),                       -- % of chips sent to burn-in
    dppm_value          NUMERIC(12,6),                      -- fallout in DPPM
    
    -- Model Parameters
    model_a             NUMERIC(16,8),                      -- exponential decay A
    model_b             NUMERIC(16,8),                      -- exponential decay B
    model_r_squared     NUMERIC(10,8),
    
    -- Outcome Metrics
    yield_gain_pct      NUMERIC(6,3),
    excursion_reduction_pct NUMERIC(6,3),
    lr_increase_pct     NUMERIC(6,3),                       -- learning rate increase
    
    computed_date       DATE NOT NULL,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) DISTRIBUTED BY (product_id);
```

---

# DOMAIN 12 — AGT (Agent / AI) DataMart

> **Purpose:** Agentic AI session tracking, tool call audit, robot action audit, LLM inference log, knowledge update log

## AGT_FACT_SESSION — Agent Session Fact

```sql
CREATE TABLE agt_fact_session (
    session_sk          BIGSERIAL,
    session_id          UUID            NOT NULL UNIQUE,
    
    -- Initiator
    initiated_by        VARCHAR(24),                        -- ENGINEER / SCHEDULER / ALARM / AGENT_CHAIN
    user_id             VARCHAR(64),
    question_text       TEXT,
    
    -- Context
    context_lot_ids     TEXT,
    context_equipment_ids TEXT,
    context_excursion_id VARCHAR(64),
    
    -- State Machine
    final_state         VARCHAR(24),                        -- COMPLETE / ESCALATED / FAILED / TIMEOUT
    states_visited      TEXT,                               -- JSON array of state names
    iteration_count     SMALLINT,
    
    -- Result
    rca_generated       BOOLEAN DEFAULT FALSE,
    confidence_score    NUMERIC(6,4),
    action_plan_json    TEXT,
    
    -- Actions Taken
    total_tool_calls    SMALLINT,
    auto_actions_taken  SMALLINT,
    human_approvals_needed SMALLINT,
    human_approvals_given SMALLINT,
    
    -- Performance
    total_duration_sec  NUMERIC(10,4),
    llm_tokens_in       INTEGER,
    llm_tokens_out      INTEGER,
    
    -- Outcome
    engineer_feedback   VARCHAR(16),                        -- CORRECT / PARTIALLY_CORRECT / INCORRECT
    knowledge_updated   BOOLEAN DEFAULT FALSE,
    rca_id_created      UUID,
    
    session_start       TIMESTAMP WITH TIME ZONE NOT NULL,
    session_end         TIMESTAMP WITH TIME ZONE,
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) WITH (appendonly=true)
DISTRIBUTED BY (session_id)
PARTITION BY RANGE (event_date) (
    START ('2024-01-01') END ('2028-01-01') EVERY (INTERVAL '6 months')
);
```

## AGT_FACT_ROBOT_ACTION — Robot Action Audit Fact

```sql
CREATE TABLE agt_fact_robot_action (
    action_sk           BIGSERIAL,
    action_id           UUID            NOT NULL UNIQUE,
    session_id          UUID,
    
    -- Action Classification
    action_type         VARCHAR(32)     NOT NULL,           -- LOT_HOLD / LOT_RELEASE / RECIPE_ADJUST / PM_SCHEDULE / TRANSPORT / NOTIFY
    action_target_type  VARCHAR(24),                        -- LOT / EQUIPMENT / CHAMBER / RECIPE
    action_target_id    VARCHAR(64),
    
    -- Parameters
    action_params_json  TEXT,                               -- all parameters passed
    
    -- Confidence & Authorization
    confidence_score    NUMERIC(6,4),
    authorization_level VARCHAR(24),                        -- AUTO / ENGINEER_APPROVED / SENIOR_APPROVED
    approved_by         VARCHAR(64),
    approved_at         TIMESTAMP WITH TIME ZONE,
    
    -- Execution
    execution_status    VARCHAR(20),                        -- PENDING / EXECUTING / COMPLETE / FAILED / CANCELLED
    system_called       VARCHAR(32),                        -- MES / EAP / CMMS / AMHS / NOTIF
    api_endpoint        VARCHAR(256),
    api_response_code   SMALLINT,
    api_response_json   TEXT,
    
    -- Outcome
    action_result       VARCHAR(20),                        -- SUCCESS / FAILURE / PARTIAL
    error_message       TEXT,
    
    -- Business Impact
    lots_affected       INTEGER,
    wafers_saved        INTEGER,
    estimated_value_usd NUMERIC(14,2),
    
    -- Immutable Audit
    action_time         TIMESTAMP WITH TIME ZONE NOT NULL,
    event_date          DATE NOT NULL,
    
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    -- NOTE: No UPDATE allowed on this table - fully immutable audit trail
) WITH (appendonly=true)
DISTRIBUTED BY (action_type)
PARTITION BY RANGE (event_date) (
    START ('2024-01-01') END ('2028-01-01') EVERY (INTERVAL '6 months')
);
```


---

# CROSS-DOMAIN VIEWS & ANALYTICAL LAYERS

> **Purpose:** Pre-joined, denormalized views optimized for each analysis scenario — these are what SEMFAB·IQ microservices and SAS Viya actually query

## VIEW: v_yield_dashboard — YMS Dashboard Unified View

```sql
CREATE MATERIALIZED VIEW v_yield_dashboard AS
SELECT
    -- Lot Identifiers
    l.lot_id,
    l.lot_type,
    l.lot_priority,
    l.product_id,
    l.process_node,
    l.customer_id,
    l.lot_status,
    l.syl_pct,
    l.sbl_pct,
    
    -- Latest CP Summary (most recent program run)
    ws.gross_yield_pct,
    ws.net_yield_pct,
    ws.first_pass_yield,
    ws.total_die,
    ws.pass_die,
    ws.fail_die,
    ws.bin_counts_json,
    ws.pattern_class_generic,
    ws.pattern_class_primary,
    ws.syl_flag,
    ws.sbl_flag,
    ws.mrb_required,
    ws.mrb_result,
    
    -- Yield vs Baseline Delta
    (ws.gross_yield_pct - l.target_yield_pct) AS yield_delta_pct,
    
    -- Risk Flags
    CASE WHEN ws.syl_flag THEN 'SYL_BREACH'
         WHEN ws.sbl_flag THEN 'SBL_BREACH'
         WHEN ws.gross_yield_pct < l.sbl_pct THEN 'CRITICAL'
         WHEN ws.gross_yield_pct < l.syl_pct THEN 'WARNING'
         ELSE 'NORMAL' END AS risk_level,
    
    -- Latest WAT Snapshot
    wss.parameter_id   AS top_wat_parameter,
    wss.cpk            AS top_wat_cpk,
    wss.mean_value     AS top_wat_mean,
    
    -- Active Alarm Count
    (SELECT COUNT(*) FROM spc_fact_violation v
     WHERE v.trigger_lot_id = l.lot_id
       AND v.violation_time >= NOW() - INTERVAL '24 hours') AS spc_violations_24h,
    
    -- Latest ML Prediction
    yp.predicted_yield_pct,
    yp.prediction_uncertainty,
    yp.is_high_risk    AS ml_high_risk,
    yp.top_factor_1_name AS top_risk_factor,
    
    -- Process Position
    mo.step_id         AS current_step_id,
    mo.equipment_id    AS current_equipment_id,
    mo.process_start_time AS step_start_time,
    
    l.lot_start_date,
    l.lot_target_date,
    ws.event_date      AS last_test_date,
    ws.test_time       AS last_test_time

FROM mes_dim_lot l
LEFT JOIN LATERAL (
    SELECT * FROM cp_fact_wafer_summary cws
    WHERE cws.lot_id = l.lot_id
    ORDER BY cws.test_time DESC
    LIMIT 1
) ws ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM wat_agg_lot_summary wss
    WHERE wss.lot_id = l.lot_id
    ORDER BY wss.event_date DESC
    LIMIT 1
) wss ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM yld_fact_prediction yp
    WHERE yp.lot_id = l.lot_id
    ORDER BY yp.prediction_time DESC
    LIMIT 1
) yp ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM mes_fact_lot_operation mo
    WHERE mo.lot_id = l.lot_id
      AND mo.operation_status IN ('IN_PROCESS', 'QUEUED')
    ORDER BY mo.step_sequence DESC
    LIMIT 1
) mo ON TRUE
WHERE l.is_current = TRUE
  AND l.lot_status IN ('ACTIVE', 'HOLD')
DISTRIBUTED BY (lot_id);

-- Refresh: every 5 minutes via Celery task
```

## VIEW: v_wat_analytical — WAT Analytical Workbench Flat View

```sql
CREATE VIEW v_wat_analytical AS
SELECT
    r.lot_id,
    r.wafer_id,
    r.slot_number,
    r.site_id,
    r.site_x,
    r.site_y,
    r.site_zone,
    r.parameter_id,
    p.parameter_group,
    p.device_type,
    p.mos_type,
    p.unit,
    p.display_unit,
    p.layer_name,
    p.process_module,
    r.vcc,
    r.temp_c,
    r.measured_value,
    r.usl,
    r.lsl,
    r.target_value,
    r.pass_fail,
    r.sigma_deviation,
    r.is_outlier_mad,
    r.is_outlier_grubbs,
    r.anomaly_score,
    r.equipment_id,
    r.chamber_id,
    r.recipe_id,
    r.step_id,
    r.route_id,
    r.process_node,
    r.product_id,
    r.test_time,
    r.event_date,
    r.lot_sequence,
    -- Lot context
    l.lot_type,
    l.lot_priority,
    l.customer_id,
    -- Equipment context
    e.equipment_type,
    e.oem_vendor,
    e.health_score AS equipment_health_score,
    e.health_tier  AS equipment_health_tier
FROM wat_fact_result r
LEFT JOIN wat_dim_parameter p ON p.parameter_id = r.parameter_id
LEFT JOIN mes_dim_lot l ON l.lot_id = r.lot_id AND l.is_current = TRUE
LEFT JOIN eqp_dim_equipment e ON e.equipment_id = r.equipment_id AND e.is_current = TRUE;
```

## VIEW: v_spc_chart_data — SPC Chart Rendering View

```sql
CREATE VIEW v_spc_chart_data AS
SELECT
    m.config_id,
    m.parameter_id,
    m.equipment_id,
    m.chamber_id,
    m.recipe_id,
    m.lot_id,
    m.wafer_id,
    m.subgroup_index,
    m.measured_value,
    m.subgroup_mean,
    m.subgroup_range,
    m.subgroup_std,
    m.moving_range,
    -- Limits
    m.ucl_at_time,
    m.cl_at_time,
    m.lcl_at_time,
    m.usl_at_time,
    m.lsl_at_time,
    m.sigma_score,
    -- Violation flags (all 8 rules)
    m.violation_rule_1, m.violation_rule_2, m.violation_rule_3, m.violation_rule_4,
    m.violation_rule_5, m.violation_rule_6, m.violation_rule_7, m.violation_rule_8,
    m.any_violation,
    m.violation_rules_list,
    m.alarm_triggered,
    m.alarm_severity,
    -- Virtual metrology
    m.is_virtual,
    m.vm_predicted_value,
    m.vm_ci_lower,
    m.vm_ci_upper,
    -- Annotation events (PM, recipe changes)
    pm.pm_type AS annotation_type,
    pm.pm_start_time AS annotation_time,
    -- Config details
    c.chart_type,
    c.subgroup_size,
    c.ucl,
    c.lcl,
    c.usl,
    c.lsl,
    c.target,
    c.alarm_severity AS config_alarm_severity,
    m.measurement_time,
    m.event_date
FROM spc_fact_measurement m
LEFT JOIN spc_dim_parameter_config c ON c.config_id = m.config_id
LEFT JOIN LATERAL (
    SELECT * FROM fdc_fact_pm_event pm
    WHERE pm.equipment_id = m.equipment_id
      AND pm.pm_start_time BETWEEN m.measurement_time - INTERVAL '1 day'
      AND m.measurement_time + INTERVAL '1 day'
    LIMIT 1
) pm ON TRUE;
```

## VIEW: v_fdc_trace_anomaly — FDC Trace Anomaly Dashboard View

```sql
CREATE VIEW v_fdc_trace_anomaly AS
SELECT
    r.run_id,
    r.lot_id,
    r.wafer_id,
    r.equipment_id,
    e.equipment_type,
    e.bay_id,
    r.chamber_id,
    c.chamber_type,
    r.recipe_id,
    r.step_id,
    r.run_start_time,
    r.run_end_time,
    r.run_duration_sec,
    r.run_result,
    r.alarm_count,
    r.alarm_sensor_list,
    -- Anomaly Scores
    r.interval_anomaly_score,
    r.pm_anomaly_score,
    r.amplitude_anomaly_score,
    r.shape_anomaly_score,
    r.composite_anomaly_score,
    r.anomaly_class,
    r.is_anomaly,
    r.is_post_pm,
    r.pm_wafer_count,
    -- PM Context
    pm.pm_type        AS last_pm_type,
    pm.pm_end_time    AS last_pm_time,
    pm.post_pm_health_score,
    -- Equipment Health
    e.health_score    AS equipment_health_score,
    e.health_tier,
    e.last_pm_date,
    e.next_pm_date,
    r.event_date
FROM fdc_fact_trace_run r
LEFT JOIN eqp_dim_equipment e ON e.equipment_id = r.equipment_id AND e.is_current = TRUE
LEFT JOIN eqp_dim_chamber c ON c.equipment_id = r.equipment_id AND c.chamber_id = r.chamber_id
LEFT JOIN LATERAL (
    SELECT * FROM fdc_fact_pm_event pm
    WHERE pm.equipment_id = r.equipment_id
      AND pm.pm_end_time < r.run_start_time
    ORDER BY pm.pm_end_time DESC
    LIMIT 1
) pm ON TRUE;
```

## VIEW: v_cp_bin_analysis — CP Bin Map & Pareto Analysis View

```sql
CREATE VIEW v_cp_bin_analysis AS
SELECT
    ws.lot_id,
    ws.wafer_id,
    ws.slot_number,
    ws.program_id,
    tp.program_name,
    tp.program_type,
    ws.tester_id,
    ws.step_id,
    ws.total_die,
    ws.pass_die,
    ws.fail_die,
    ws.gross_yield_pct,
    ws.net_yield_pct,
    ws.first_pass_yield,
    ws.retest_count,
    ws.offline_retest_rate,
    ws.bin_counts_json,
    ws.site_yields_json,
    -- Spatial Pattern
    ws.pattern_class_generic,
    ws.pattern_class_primary,
    ws.pattern_class_secondary,
    ws.pattern_confidence,
    -- Edge Analysis
    ws.edge_yield_pct,
    ws.center_yield_pct,
    ws.edge_center_delta,
    -- MRB
    ws.syl_flag,
    ws.sbl_flag,
    ws.mrb_required,
    ws.mrb_result,
    -- Lot context
    l.product_id,
    l.process_node,
    l.lot_type,
    l.customer_id,
    l.target_yield_pct,
    l.syl_pct,
    l.sbl_pct,
    -- Defect correlation
    ds.defect_density_cm2,
    ds.killer_density_cm2,
    ds.pattern_class AS defect_pattern_class,
    ws.predicted_yield_pct,
    ws.event_date,
    ws.test_time
FROM cp_fact_wafer_summary ws
LEFT JOIN cp_dim_test_program tp ON tp.program_id = ws.program_id
LEFT JOIN mes_dim_lot l ON l.lot_id = ws.lot_id AND l.is_current = TRUE
LEFT JOIN LATERAL (
    SELECT * FROM def_fact_wafer_defect_summary ds
    WHERE ds.lot_id = ws.lot_id AND ds.wafer_id = ws.wafer_id
    ORDER BY ds.inspection_time DESC
    LIMIT 1
) ds ON TRUE;
```

## VIEW: v_mrb_consolidation — MRB Decision View

```sql
CREATE VIEW v_mrb_consolidation AS
SELECT
    ws.lot_id,
    ws.wafer_id,
    ws.slot_number,
    l.product_id,
    l.process_node,
    -- MRB Decision Flags
    ws.is_partial_wafer                             AS partial_wafer,
    (ws.pattern_confidence > 0.85 
     AND ws.pattern_class_generic != 'NORMAL')      AS wafer_cluster,
    (ws.pattern_class_generic NOT IN ('NORMAL'))    AS wafer_pattern,
    ws.syl_flag                                     AS wf_syl,
    ws.sbl_flag                                     AS wf_sbl,
    (ws.first_pass_yield < l.sbl_pct)               AS wf_sbl_breach,
    -- PCM Violation (from WAT data)
    (EXISTS (
        SELECT 1 FROM wat_fact_result wr
        WHERE wr.lot_id = ws.lot_id AND wr.wafer_id = ws.wafer_id
          AND wr.pass_fail = 'F'
          AND wr.event_date = ws.event_date
    ))                                              AS pcm_violate,
    -- Final MRB Result
    CASE
        WHEN ws.sbl_flag = TRUE THEN 'BadWafer'
        WHEN ws.syl_flag = TRUE AND ws.mrb_required = TRUE THEN 'BadWafer'
        WHEN ws.is_partial_wafer = TRUE THEN 'BadWafer'
        WHEN ws.pattern_class_generic NOT IN ('NORMAL') 
         AND ws.pattern_confidence > 0.85 THEN 'BadWafer'
        ELSE 'GoodWafer'
    END                                             AS mrb_result,
    ws.gross_yield_pct,
    ws.net_yield_pct,
    ws.bin_counts_json,
    ws.pattern_class_generic,
    ws.pattern_class_primary,
    ws.event_date,
    ws.test_time
FROM cp_fact_wafer_summary ws
LEFT JOIN mes_dim_lot l ON l.lot_id = ws.lot_id AND l.is_current = TRUE
WHERE ws.mrb_required = TRUE OR ws.syl_flag = TRUE;
```

---

# ORACLE RT (Real-Time OLTP) Schema

> High-speed, sub-second operations: live alarms, WIP status, R2R control, equipment status

```sql
-- Oracle 19c RAC Schema for Real-Time Operations

CREATE TABLE rt_live_alarm (
    alarm_id        NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    alarm_uuid      VARCHAR2(36)    DEFAULT SYS_GUID() NOT NULL,
    
    -- Source
    alarm_source    VARCHAR2(20)    NOT NULL,   -- FDC / SPC / YIELD / AGENT / MANUAL / MES
    alarm_type      VARCHAR2(32)    NOT NULL,   -- TRACE_ANOMALY / SPC_VIOLATION / YIELD_DROP / PM_DUE
    
    -- Scope
    equipment_id    VARCHAR2(32),
    chamber_id      VARCHAR2(16),
    lot_id          VARCHAR2(32),
    wafer_id        VARCHAR2(40),
    step_id         VARCHAR2(32),
    parameter_id    VARCHAR2(64),
    indicator_id    VARCHAR2(128),
    
    -- Alarm Content
    severity        VARCHAR2(16)    NOT NULL,   -- CRITICAL / MAJOR / MINOR / INFO
    alarm_code      VARCHAR2(32),
    alarm_message   VARCHAR2(512),
    alarm_detail    CLOB,
    
    -- Statistical Context
    measured_value  NUMBER,
    threshold_value NUMBER,
    sigma_deviation NUMBER,
    
    -- Status
    status          VARCHAR2(20)    DEFAULT 'OPEN',
    acknowledged_by VARCHAR2(64),
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    resolved_at     TIMESTAMP WITH TIME ZONE,
    resolution_code VARCHAR2(32),
    
    -- Agent
    agent_session_id VARCHAR2(36),
    agent_rca_summary VARCHAR2(2000),
    auto_action_taken VARCHAR2(256),
    
    alarm_time      TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT chk_severity CHECK (severity IN ('CRITICAL','MAJOR','MINOR','INFO')),
    CONSTRAINT chk_status CHECK (status IN ('OPEN','ACK','INVESTIGATING','RESOLVED','FALSE_ALARM'))
);

CREATE INDEX idx_rt_alarm_time ON rt_live_alarm(alarm_time DESC);
CREATE INDEX idx_rt_alarm_equip ON rt_live_alarm(equipment_id, status, alarm_time DESC);
CREATE INDEX idx_rt_alarm_lot ON rt_live_alarm(lot_id, status);
CREATE INDEX idx_rt_alarm_sev ON rt_live_alarm(severity, status, alarm_time DESC);

-- Trigger: Auto-update EQUIPMENT_STATUS on alarm insert
CREATE OR REPLACE TRIGGER trg_alarm_update_equip_status
AFTER INSERT ON rt_live_alarm
FOR EACH ROW
WHEN (NEW.equipment_id IS NOT NULL)
BEGIN
    UPDATE rt_equipment_status
    SET    alarm_count_24h = alarm_count_24h + 1,
           last_alarm_time = :NEW.alarm_time,
           last_alarm_severity = :NEW.severity
    WHERE  equipment_id = :NEW.equipment_id;
END;
/

CREATE TABLE rt_wip_tracking (
    wip_id          NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    lot_id          VARCHAR2(32)    NOT NULL,
    wafer_id        VARCHAR2(40),
    
    -- Current Position
    current_step_id VARCHAR2(32),
    current_step_seq INTEGER,
    equipment_id    VARCHAR2(32),
    chamber_id      VARCHAR2(16),
    
    -- Status
    wip_status      VARCHAR2(24)    NOT NULL,   -- QUEUED / IN_PROCESS / COMPLETE / HOLD / SCRAPPED
    hold_code       VARCHAR2(16),
    hold_reason     VARCHAR2(512),
    hold_source     VARCHAR2(32),   -- MANUAL / SPC / FDC / YIELD / AGENT / MRB
    
    -- Priority
    priority        NUMBER          DEFAULT 5,
    is_hot_lot      NUMBER(1)       DEFAULT 0,
    hot_lot_reason  VARCHAR2(128),
    
    -- Timing
    step_start_time TIMESTAMP WITH TIME ZONE,
    step_due_time   TIMESTAMP WITH TIME ZONE,
    
    -- Commitment Tracking
    customer_commit_date DATE,
    is_at_risk      NUMBER(1)       DEFAULT 0,
    
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP,
    CONSTRAINT uq_wip_lot_step UNIQUE (lot_id, current_step_id)
);

CREATE INDEX idx_wip_step ON rt_wip_tracking(current_step_id, wip_status);
CREATE INDEX idx_wip_equip ON rt_wip_tracking(equipment_id, wip_status);
CREATE INDEX idx_wip_priority ON rt_wip_tracking(priority ASC, is_hot_lot DESC);

CREATE TABLE rt_equipment_status (
    equipment_id        VARCHAR2(32)    PRIMARY KEY,
    equipment_type      VARCHAR2(32),
    bay_id              VARCHAR2(16),
    
    -- Current State
    status              VARCHAR2(24)    NOT NULL,   -- PRODUCTION / MAINTENANCE / IDLE / DOWN / QUALIFICATION
    current_recipe_id   VARCHAR2(64),
    current_lot_id      VARCHAR2(32),
    current_wafer_id    VARCHAR2(40),
    
    -- Performance
    utilization_pct     NUMBER,
    throughput_wph      NUMBER,         -- wafers per hour
    
    -- Health
    health_score        NUMBER,
    health_tier         VARCHAR2(16),
    
    -- Alarms
    alarm_count_24h     NUMBER          DEFAULT 0,
    last_alarm_time     TIMESTAMP WITH TIME ZONE,
    last_alarm_severity VARCHAR2(16),
    
    -- PM
    run_since_pm        INTEGER         DEFAULT 0,
    last_pm_date        DATE,
    next_pm_date        DATE,
    
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP,
    CONSTRAINT chk_equip_status CHECK (status IN ('PRODUCTION','MAINTENANCE','IDLE','DOWN','QUALIFICATION','HOLD'))
);

CREATE TABLE rt_run_to_run_control (
    ctrl_id         NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    model_id        VARCHAR2(64)    NOT NULL,
    equipment_id    VARCHAR2(32)    NOT NULL,
    chamber_id      VARCHAR2(16),
    recipe_id       VARCHAR2(64),
    lot_id          VARCHAR2(32),
    run_number      INTEGER,
    
    -- Control Action
    parameter_name  VARCHAR2(128),
    previous_setpoint NUMBER,
    setpoint_adjustment NUMBER,
    new_setpoint    NUMBER,
    predicted_output NUMBER,
    measured_feedback NUMBER,
    ewma_state      NUMBER,
    
    -- Status
    was_applied     NUMBER(1)       DEFAULT 1,
    override_reason VARCHAR2(128),
    
    ctrl_time       TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL
);

CREATE INDEX idx_r2r_equip ON rt_run_to_run_control(equipment_id, ctrl_time DESC);
CREATE INDEX idx_r2r_lot ON rt_run_to_run_control(lot_id);
```

---

# SAS VIYA CAS — In-Memory Analytical Tables

> Loaded from Greenplum for live analytics sessions; auto-refreshed by scheduled SWAT jobs

```python
# Python SWAT session management — CAS table loading patterns

CAS_TABLE_DEFINITIONS = {
    # Hot tables: refreshed every 5 minutes
    "WAT_CURRENT": {
        "source_query": """
            SELECT * FROM v_wat_analytical
            WHERE event_date >= CURRENT_DATE - INTERVAL '90 days'
        """,
        "refresh_interval_min": 5,
        "partition_by": "parameter_group",
        "compress": True
    },
    "SPC_CHARTS_ACTIVE": {
        "source_query": """
            SELECT * FROM v_spc_chart_data
            WHERE event_date >= CURRENT_DATE - INTERVAL '30 days'
              AND config_id IN (SELECT config_id FROM spc_dim_parameter_config WHERE is_active=TRUE)
        """,
        "refresh_interval_min": 5
    },
    "CP_WAFER_CURRENT": {
        "source_query": """
            SELECT * FROM v_cp_bin_analysis
            WHERE event_date >= CURRENT_DATE - INTERVAL '60 days'
        """,
        "refresh_interval_min": 10
    },
    # Warm tables: refreshed hourly
    "YIELD_TREND_90D": {
        "source_query": """
            SELECT * FROM v_yield_dashboard
        """,
        "refresh_interval_min": 60
    },
    "ANOVA_EQUIPMENT_CURRENT": {
        "source_query": """
            SELECT * FROM wat_fact_anova_equipment
            WHERE date_range_end >= CURRENT_DATE - INTERVAL '90 days'
        """,
        "refresh_interval_min": 60
    },
    "FDC_TRACE_SUMMARY": {
        "source_query": """
            SELECT * FROM v_fdc_trace_anomaly
            WHERE event_date >= CURRENT_DATE - INTERVAL '30 days'
        """,
        "refresh_interval_min": 30
    },
    # Cold tables: refreshed daily
    "CORRELATION_MATRIX": {
        "source_query": "SELECT * FROM wat_fact_correlation",
        "refresh_interval_min": 1440
    },
    "RCA_KNOWLEDGE": {
        "source_query": "SELECT * FROM yld_fact_rca_knowledge",
        "refresh_interval_min": 360
    }
}

# SAS Viya Analytical Procedure Calls (via SWAT)
SAS_PROC_MAP = {
    "distribution_fit":     "PROC UNIVARIATE",
    "capability":           "PROC CAPABILITY",
    "spc_chart":            "PROC SHEWHART",
    "correlation":          "PROC CORR",
    "anova":                "PROC GLM",
    "factor_screening":     "PROC GLMSELECT",
    "pca":                  "PROC FACTOR",
    "regression":           "PROC REG",
    "mixed_effects":        "PROC MIXED",
    "time_series":          "PROC TSMODEL",
    "causal_discovery":     "PROC CAUSL",
    "random_forest":        "PROC HPFOREST",
    "gradient_boosting":    "PROC GRADBOOST",
    "neural_network":       "PROC NNET",
    "logistic_regression":  "PROC LOGISTIC",
    "survival_analysis":    "PROC LIFETEST",
    "cluster_analysis":     "PROC CLUSTER",
    "chi_square":           "PROC FREQ"
}
```

---

# Redis Cache Key Schema

> Sub-millisecond hot data access; all keys use namespace:domain:entity:id pattern

```
# Cache Key Design
# TTL: seconds

# ── Dashboard Hot Cache ──
semfab:yms:dashboard:snapshot                       TTL=300     # 5-min
semfab:yms:alarm_count:active                       TTL=30      # 30-sec
semfab:yms:wip_count:{step_id}                      TTL=60      # 1-min
semfab:yms:fab_yield_today:{product_id}             TTL=300     # 5-min

# ── SPC Chart Cache ──
semfab:spc:chart_data:{config_id}:{days}            TTL=300     # 5-min
semfab:spc:limits:{config_id}                       TTL=3600    # 1-hr
semfab:spc:violations:recent:{equipment_id}         TTL=60      # 1-min

# ── WAT Analytics Cache ──
semfab:wat:lot_summary:{lot_id}:{parameter_id}      TTL=3600    # 1-hr
semfab:wat:correlation:{product_id}:{date_hash}     TTL=7200    # 2-hr
semfab:wat:anova:{product_id}:{parameter_id}        TTL=3600    # 1-hr
semfab:wat:equipment_health:{equipment_id}          TTL=1800    # 30-min

# ── CP Analytics Cache ──
semfab:cp:wafer_map:{lot_id}:{wafer_id}             TTL=3600    # 1-hr (compressed JSON)
semfab:cp:bin_pareto:{lot_id}                       TTL=3600    # 1-hr
semfab:cp:yield_summary:{lot_id}                    TTL=1800    # 30-min

# ── FDC Cache ──
semfab:fdc:trace_anomaly:{run_id}                   TTL=86400   # 24-hr
semfab:fdc:equipment_health:{equipment_id}          TTL=300     # 5-min
semfab:fdc:active_alarms:{equipment_id}             TTL=30      # 30-sec

# ── Agent Session Cache ──
semfab:agent:session:{session_id}                   TTL=1800    # 30-min
semfab:agent:pending_actions:{user_id}              TTL=3600    # 1-hr
semfab:agent:streaming:{session_id}                 TTL=300     # 5-min

# ── Auth Cache ──
semfab:auth:token:{jti}                             TTL=900     # 15-min (match JWT expiry)
semfab:auth:blacklist:{jti}                         TTL=86400   # 24-hr
semfab:auth:user_perms:{user_id}                    TTL=1800    # 30-min
semfab:auth:lockout:{username}                      TTL=900     # 15-min

# ── Report Cache ──
semfab:report:weekly_yield:{week_key}               TTL=86400   # 24-hr
semfab:report:capability:{config_id}:{month}        TTL=86400   # 24-hr
```

---

# Neo4j Knowledge Graph Schema

> Equipment-Parameter-RootCause-CorrectiveAction graph for agent RAG and pattern matching

```cypher
// ── Node Types ──

// Equipment nodes
CREATE CONSTRAINT equip_id FOR (e:Equipment) REQUIRE e.equipment_id IS UNIQUE;
CREATE (:Equipment {
    equipment_id: 'CVD-01',
    equipment_type: 'CVD',
    oem_vendor: 'AMAT',
    process_node: 'N5',
    health_score: 88.4,
    health_tier: 'HEALTHY'
});

// Parameter nodes
CREATE CONSTRAINT param_id FOR (p:Parameter) REQUIRE p.parameter_id IS UNIQUE;
CREATE (:Parameter {
    parameter_id: 'GATE_OX_THICKNESS',
    parameter_group: 'CAPACITANCE',
    layer_name: 'GO',
    criticality_rank: 1
});

// Process Step nodes
CREATE CONSTRAINT step_id FOR (s:ProcessStep) REQUIRE s.step_id IS UNIQUE;
CREATE (:ProcessStep {
    step_id: 'LI-3041',
    step_name: 'Gate Oxidation',
    process_area: 'DIFF',
    process_module: 'GATE_OX',
    layer_name: 'GO'
});

// Root Cause nodes
CREATE CONSTRAINT rca_id FOR (r:RootCause) REQUIRE r.rca_id IS UNIQUE;
CREATE (:RootCause {
    rca_id: 'RC-2024-001',
    symptom_category: 'WAT_SHIFT',
    root_cause_category: 'EQUIPMENT',
    root_cause_description: 'NBL Drive-in furnace temperature zone 3 drift',
    confidence_score: 0.94,
    occurrence_count: 7,
    physical_mechanism: 'Temperature non-uniformity causes radial BVJ junction depth variation'
});

// Corrective Action nodes
CREATE CONSTRAINT action_id FOR (a:CorrectiveAction) REQUIRE a.action_id IS UNIQUE;
CREATE (:CorrectiveAction {
    action_id: 'CA-2024-001',
    action_type: 'RECIPE_ADJUST',
    description: 'Adjust NBL furnace zone 3 setpoint +2.5°C',
    success_rate: 0.92,
    effort_level: 'LOW',
    time_to_effect_hr: 2
});

// DefectPattern nodes
CREATE (:DefectPattern {
    pattern_id: 'DP-RING-001',
    spatial_class: 'RING',
    radius_ratio: 0.7,
    process_correlation: 'CMP_PAD_WEAR'
});

// Product nodes
CREATE (:Product {
    product_id: 'PROD-N5-001',
    process_node: 'N5',
    device_family: 'LOGIC',
    target_yield_pct: 95.0
});

// ── Relationship Types ──

// Equipment → ProcessStep
MATCH (e:Equipment {equipment_id:'CVD-01'}), (s:ProcessStep {step_id:'LI-3041'})
CREATE (e)-[:PROCESSES {since:'2023-01-01', run_count:45000}]->(s);

// ProcessStep → Parameter (MEASURES)
MATCH (s:ProcessStep {step_id:'LI-3041'}), (p:Parameter {parameter_id:'GATE_OX_THICKNESS'})
CREATE (s)-[:MEASURES {criticality:'HIGH', spc_monitored:true}]->(p);

// Parameter → RootCause (CAUSES_WHEN_OOC)
MATCH (p:Parameter {parameter_id:'GATE_OX_THICKNESS'}), (r:RootCause {rca_id:'RC-2024-001'})
CREATE (p)-[:CAUSES_WHEN_OOC {
    ooc_direction: 'HIGH',
    min_sigma_deviation: 2.5,
    yield_impact_pct: 3.2
}]->(r);

// RootCause → CorrectiveAction (FIXED_BY)
MATCH (r:RootCause {rca_id:'RC-2024-001'}), (a:CorrectiveAction {action_id:'CA-2024-001'})
CREATE (r)-[:FIXED_BY {
    historical_success_rate: 0.92,
    avg_yield_recovery_pct: 2.8,
    last_used: '2024-06-15'
}]->(a);

// DefectPattern → RootCause (INDICATES)
MATCH (d:DefectPattern {pattern_id:'DP-RING-001'}), (r:RootCause {rca_id:'RC-2024-001'})
CREATE (d)-[:INDICATES {confidence: 0.85}]->(r);

// RootCause → RootCause (SIMILAR_TO — for knowledge graph traversal)
MATCH (r1:RootCause {rca_id:'RC-2024-001'}), (r2:RootCause {rca_id:'RC-2023-045'})
CREATE (r1)-[:SIMILAR_TO {cosine_similarity: 0.87, same_mechanism: true}]->(r2);

// Equipment → Equipment (MATCHED_TO — for tool matching)
MATCH (e1:Equipment {equipment_id:'CVD-01'}), (e2:Equipment {equipment_id:'CVD-02'})
CREATE (e1)-[:MATCHED_TO {
    matching_score: 0.96,
    matching_date: '2024-01-15',
    parameter_count: 47,
    deviation_pct: 0.8
}]->(e2);

// ── Key Queries for Agent RAG ──

// Find similar root causes by symptom
MATCH (r:RootCause)
WHERE r.symptom_category = 'WAT_SHIFT'
  AND r.confidence_score > 0.7
RETURN r ORDER BY r.confidence_score DESC, r.occurrence_count DESC LIMIT 5;

// Full RCA chain: Parameter → RootCause → CorrectiveAction
MATCH (p:Parameter {parameter_id: $param_id})
      -[:CAUSES_WHEN_OOC]->(r:RootCause)
      -[:FIXED_BY]->(a:CorrectiveAction)
WHERE r.confidence_score > 0.6
RETURN p, r, a ORDER BY r.confidence_score DESC;

// Equipment influence on yield through process steps
MATCH (e:Equipment {equipment_id: $equip_id})
      -[:PROCESSES]->(s:ProcessStep)
      -[:MEASURES]->(p:Parameter)
      -[:CAUSES_WHEN_OOC]->(r:RootCause)
RETURN e, s, p, r;
```

---

# DataMart Summary Matrix

| DataMart Domain | Primary FACT Tables | Key Dimensions | Analysis Scenarios | Interactive Features |
|----------------|--------------------|-----------------|--------------------|---------------------|
| **MES** | lot_operation, cycle_time, material_consumption | lot, wafer, route_step | WIP tracking, CT analysis, EBOM | Route step filter, shift selector, lot type toggle |
| **WAT** | result, correlation, anova_equipment | parameter, spec | Parametric trend, ANOVA, DOE, PSA | Parameter selector, vcc/temp condition filter, site zone filter, equipment group-by |
| **CP** | die_result, parametric, wafer_summary, touchdown | test_program, bin | Bin map, pareto, spatial analysis, tray trace | Bin filter, die click drill-down, site-to-site view, mark/hide bins |
| **SPC** | measurement, violation, capability | parameter_config | Control charts, capability, virtual metro | Rule toggle, limit edit, compare baseline, zoom/brush |
| **FDC** | trace_run, trace_data, indicator_result, pm_event | sensor, indicator, equipment | Trace overlay, anomaly detection, qualification | Sensor multi-select, baseline vs qual overlay, anomaly threshold slider |
| **MTR** | measurement | recipe_step | Inline trend, within-wafer map, tool matching | Site heatmap, overlay multiple tools, CD/overlay toggle |
| **APC** | control_action | model | R2R setpoint history, correction trend, feed-forward | Recipe parameter selector, EWMA lambda edit, lot range brush |
| **DEF** | defect, wafer_defect_summary | inspection_tool | Defect pareto, pattern analysis, SEM gallery, kill prob | Class filter, size range slider, cluster highlight, SEM zoom |
| **YLD** | excursion, prediction, rca_knowledge | excursion | Excursion timeline, yield prediction, RCA knowledge | Severity filter, lot group selection, confidence threshold |
| **MSC** | rr_result | study | R&R comparison, tester matching, delta plot | System 1/2 selector, test item multi-select, cycle group-by |
| **REL** | wlr_result, dppm_model | test_type | Lifetime projection, DPPM curve, burn-in optimizer | Stress condition selector, model type toggle (best/avg/worst) |
| **AGT** | session, robot_action | — | Agent audit, action history, confidence tracking | Date range, action type filter, approval status |

---

*Document End — SEMFAB·IQ Comprehensive Data Schema v1.0*  
*12 DataMart Domains · 50+ Tables · 15+ Pre-joined Views · Oracle RT · Redis Cache · Neo4j Knowledge Graph*  
*© 2025 SEMFAB·IQ Engineering Team. All rights reserved.*
