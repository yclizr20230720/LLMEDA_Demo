# SEMFAB·IQ — Final Data Architecture & Schema Design
## Integrated, Production-Grade, Function-Complete DataMart Specification

> **Version:** v2.0 Final  
> **Engines:** Greenplum 7 (Analytical DW) · Oracle 19c RAC (OLTP Real-time) · SAS Viya CAS (In-memory) · Neo4j 5 (Knowledge Graph) · Redis 7 Cluster (Cache)  
> **Coverage:** 12 DataMart Domains · 60+ Tables · 20+ Pre-joined Views · Complete Redis Cache Schema · Full Neo4j Knowledge Graph  
> **Integration:** Fully aligned with SEMFAB·IQ v4.0 UI modules, API services, and Agentic AI workflows

---

## 1. Architecture Overview

The SEMFAB·IQ data architecture follows a **three-tier analytical stack** designed to serve the full spectrum of semiconductor engineering data analysis — from millisecond real-time alarm response to multi-hour deep statistical modeling.

```mermaid
graph TB
    subgraph Tier1["Tier 1 — Real-Time OLTP (Oracle 19c RAC)"]
        RT_ALARM["rt_live_alarm\n(sub-second alarm ingestion)"]
        RT_WIP["rt_wip_tracking\n(live lot position)"]
        RT_EQP["rt_equipment_status\n(live tool health)"]
        RT_R2R["rt_run_to_run_control\n(APC setpoints)"]
    end

    subgraph Tier2["Tier 2 — Analytical Data Warehouse (Greenplum 7 MPP)"]
        direction LR
        MES["MES Domain\nmes_dim_lot\nmes_fact_lot_operation\nmes_fact_cycle_time"]
        WAT["WAT Domain\nwat_fact_result\nwat_agg_lot_summary\nwat_fact_correlation\nwat_fact_anova_equipment"]
        CP["CP Domain\ncp_fact_die_result\ncp_fact_parametric\ncp_fact_wafer_summary\ncp_fact_touchdown"]
        SPC["SPC Domain\nspc_dim_parameter_config\nspc_fact_measurement\nspc_fact_violation\nspc_agg_capability"]
        FDC["FDC Domain\nfdc_fact_trace_run\nfdc_fact_trace_data\nfdc_fact_indicator_result\nfdc_fact_pm_event"]
        MTR["MTR Domain\nmtr_fact_measurement"]
        APC["APC Domain\napc_dim_model\napc_fact_control_action"]
        DEF["DEF Domain\ndef_fact_defect\ndef_fact_wafer_defect_summary"]
        YLD["YLD Domain\nyld_fact_excursion\nyld_fact_prediction\nyld_fact_rca_knowledge"]
        MSC["MSC Domain\nmsc_fact_rr_result"]
        REL["REL Domain\nrel_fact_wlr_result\nrel_fact_dppm_model"]
        AGT["AGT Domain\nagt_fact_session\nagt_fact_robot_action"]
    end

    subgraph Tier3["Tier 3 — In-Memory Analytics (SAS Viya CAS)"]
        CAS_WAT["WAT_CURRENT\n(90-day hot)"]
        CAS_SPC["SPC_CHARTS_ACTIVE\n(30-day hot)"]
        CAS_CP["CP_WAFER_CURRENT\n(60-day hot)"]
        CAS_YIELD["YIELD_TREND_90D\n(hourly warm)"]
        CAS_FDC["FDC_TRACE_SUMMARY\n(30-day warm)"]
        CAS_CORR["CORRELATION_MATRIX\n(daily cold)"]
        CAS_RCA["RCA_KNOWLEDGE\n(6-hr cold)"]
    end

    subgraph Cache["Redis 7 Cluster (Hot Cache)"]
        REDIS["Dashboard Snapshot TTL=300s\nSPC Chart Data TTL=300s\nWAT Lot Summary TTL=3600s\nCP Wafer Map TTL=3600s\nFDC Active Alarms TTL=30s\nAgent Session TTL=1800s"]
    end

    subgraph KG["Neo4j 5 (Knowledge Graph)"]
        NEO4J["Equipment → ProcessStep → Parameter\n→ RootCause → CorrectiveAction\nDefectPattern → RootCause\nEquipment ↔ Equipment (matching)"]
    end

    Tier1 -->|Kafka ETL| Tier2
    Tier2 -->|SWAT scheduled load| Tier3
    Tier2 -->|Redis cache-aside| Cache
    Tier3 -->|SAS PROC calls| SPC
    Tier2 -->|RCA sync| KG
```

---

## 2. Schema Naming Convention

```
{domain}_{entity}_{type}
│         │       └─ DIM = Dimension | FACT = Fact | BRIDGE = Bridge | AGG = Aggregate | SRC = Source Staging
│         └─ entity name (snake_case)
└─ domain: MES / WAT / CP / SPC / FDC / APC / MTR / DEF / EQP / MAT / YLD / MSC / REL / AGT
```

| Convention | Rule |
|---|---|
| **Distribution Key** | All FACT tables `DISTRIBUTED BY (lot_id)` |
| **Partition Strategy** | Range partition by `event_date` — monthly for FACT, quarterly for AGG |
| **Storage Format** | All FACT tables: Append-Optimized Columnar (AOCO), `compresslevel=5` |
| **Index Strategy** | BRIN on time columns, B-tree on natural keys, partial indexes on boolean flags |
| **SCD Type 2** | Dimension tables with `effective_from`, `effective_to`, `is_current` for historical tracking |

---

## 3. Domain 1 — MES (Manufacturing Execution System)

**Purpose:** Process route tracking, WIP management, lot traceability, cycle time analysis, material EBOM

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `mes_dim_lot` | DIM | lot_id, product_id, process_node, lot_status, syl_pct, sbl_pct | YMS Dashboard, Score Card, MRB |
| `mes_dim_wafer` | DIM | lot_id, slot_number, die_per_wafer, cp_yield_pct | Wafer Gallery |
| `mes_dim_process_route` | DIM | route_id, technology_id, total_steps | Process Timeline |
| `mes_dim_route_step` | DIM | step_id, process_area, layer_name, front_end_backend | Process Timeline, FDC |
| `mes_fact_lot_operation` | FACT | lot_id, step_id, equipment_id, process_time_min, queue_time_hr, operation_status, hold_triggered | FAB Control, Process Timeline |
| `mes_fact_cycle_time` | FACT | lot_id, total_ct_days, feol_ct_days, beol_ct_days, process_efficiency_pct | Advanced Analytics |
| `mes_fact_material_consumption` | FACT | lot_id, material_id, consumption_actual, ebom_lot_id | EBOM Module |

**Key Design Decisions:**
- `mes_dim_lot` uses **SCD Type 2** to track lot status changes over time — critical for excursion post-mortems.
- `syl_pct` (Soft Yield Limit) and `sbl_pct` (Soft Bin Limit) are stored at the lot level to enable the SYL/SBL reference lines in the YMS yield trend chart.
- `mes_fact_lot_operation.hold_source` distinguishes between manual holds and AI-agent-triggered holds — essential for the MRB Review panel.

---

## 4. Domain 2 — WAT (Wafer Acceptance Test)

**Purpose:** Parametric electrical test, SPC correlation, DOE, equipment factor analysis, yield prediction features

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `wat_dim_parameter` | DIM | parameter_id, parameter_group, mos_type, unit, usl, lsl | WAT Analytics |
| `wat_dim_site_map` | DIM | site_id, site_x, site_y, site_zone | 9-Site Uniformity Map |
| `wat_fact_result` | FACT | lot_id, wafer_id, site_id, parameter_id, measured_value, pass_fail, is_outlier_mad, anomaly_score | WAT Distribution, Trend |
| `wat_agg_lot_summary` | AGG | lot_id, parameter_id, mean_value, std_dev, cpk, ppk, dist_fit_type | WAT Stats Cards |
| `wat_fact_correlation` | FACT | param_x_id, param_y_id, pearson_r, ols_slope, ols_r_squared, is_significant_05 | Correlation Matrix |
| `wat_fact_anova_equipment` | FACT | parameter_id, factor_value, eta_squared, f_statistic, p_value, composite_health_score | Equipment ANOVA |

**Key Design Decisions:**
- `wat_fact_result` stores `is_outlier_mad`, `is_outlier_grubbs`, `anomaly_score` — enabling the WAT Analytics outlier detection and ML anomaly flags.
- `wat_fact_anova_equipment.composite_health_score` is computed as `0.35×z_score + 0.30×gof + 0.20×cv_stability + 0.15×volume` — directly powering the Equipment Health Fleet view.
- `wat_agg_lot_summary` stores all 10 percentile statistics (p5, p25, p75, p95) plus skewness/kurtosis — enabling the BoxPlot and distribution analysis.

---

## 5. Domain 3 — CP (Circuit Probe / Die Sort)

**Purpose:** Die-level electrical test, bin analysis, wafer map patterns, spatial clustering, tray traceability, smart sampling

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `cp_dim_test_program` | DIM | program_id, program_type, smart_sampling_enabled | Smart Sampling |
| `cp_dim_bin` | DIM | bin_code, bin_category, fail_category, yield_impact_est | Bin Pareto |
| `cp_fact_die_result` | FACT | lot_id, wafer_id, die_x, die_y, hard_bin, is_pass, was_tested, skip_reason | CP Bin Map |
| `cp_fact_parametric` | FACT | lot_id, die_x, die_y, test_number, measured_value, pass_fail | Die-Level Sparkmap |
| `cp_fact_wafer_summary` | FACT | lot_id, wafer_id, gross_yield_pct, bin_counts_json, pattern_class_generic, syl_flag, sbl_flag, mrb_required | YMS Dashboard, MRB |
| `cp_fact_touchdown` | FACT | lot_id, wafer_id, touchdown_number, die_count_tested, contact_resistance_avg | Smart Sampling |

**Key Design Decisions:**
- `cp_fact_die_result.was_tested` + `skip_reason` supports the Smart Sampling module — showing which dies were skipped and why.
- `cp_fact_wafer_summary.bin_counts_json` stores the full bin spectrum as JSON for flexible Bin Pareto rendering without schema changes.
- `cp_fact_wafer_summary.pattern_class_generic` directly maps to the WPA Pattern Gallery (NORMAL/CLUSTER/EDGE/RING/SCRATCH/LINEAR).
- `cp_fact_wafer_summary.syl_flag` and `sbl_flag` feed directly into the MRB Review panel's PASS/REJECT/REVIEW decision logic.

---

## 6. Domain 4 — SPC (Statistical Process Control)

**Purpose:** Control chart management, Western Electric rule enforcement, Cpk tracking, virtual metrology, OCAP automation

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `spc_dim_parameter_config` | DIM | config_id, chart_type, ucl, lcl, enabled_rules (bitmask), alarm_mode, is_virtual | SPC DC Config |
| `spc_fact_measurement` | FACT | config_id, measured_value, violation_rule_1..8, any_violation, vm_predicted_value | SPC Data Analyzer |
| `spc_fact_violation` | FACT | config_id, rule_number, trigger_lot_id, sigma_deviation, lots_on_hold_count, agent_rca_session_id | SPC Alarm Viewer |
| `spc_agg_capability` | AGG | config_id, period_type, cp, cpk, cpm, ppk, violations_r1..r8 | Cpk Summary Table |

**Key Design Decisions:**
- `spc_dim_parameter_config.enabled_rules` uses a **bitmask** (8 bits = 8 Western Electric rules) — enabling the rule toggle UI in the Strategy Builder tab.
- `spc_fact_measurement` stores all 8 violation flags individually plus `any_violation` — enabling the SPC chart's violation highlighting and the Alarm Viewer cross-table.
- `spc_fact_measurement.vm_predicted_value` + `vm_ci_lower/upper` supports the Virtual Metrology overlay in the SPC chart.
- `spc_fact_violation.agent_rca_session_id` creates a direct link from SPC violations to the AI Agent's RCA session — enabling the "Drill to Agent" workflow.

---

## 7. Domain 5 — FDC (Fault Detection & Classification)

**Purpose:** Equipment sensor trace analysis, anomaly detection, PM event tracking, tool qualification, trace feature extraction

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `eqp_dim_equipment` | DIM | equipment_id, equipment_type, health_score, health_tier, z_score_component, gof_component | Equipment Fleet |
| `eqp_dim_chamber` | DIM | equipment_id, chamber_id, run_since_pm, is_reference_chamber | FDC Feature SPC |
| `fdc_dim_sensor` | DIM | equipment_id, sensor_alias, sensor_type, sampling_rate_hz | FDC Trace Stack |
| `fdc_dim_indicator` | DIM | indicator_id, feature_type, baseline_mean, baseline_sigma | FDC Feature SPC |
| `fdc_fact_trace_run` | FACT | run_id, lot_id, equipment_id, run_result, composite_anomaly_score, alarm_count | FDC Monitor |
| `fdc_fact_trace_data` | FACT | run_id, sensor_alias, time_offset_ms, value, is_anomaly_point | Trace Stack View |
| `fdc_fact_indicator_result` | FACT | run_id, indicator_id, feature_value, sigma_deviation, anomaly_type | Feature SPC |
| `fdc_fact_pm_event` | FACT | equipment_id, pm_type, pre_pm_health_score, post_pm_health_score, qualification_passed | Process Timeline |

**Key Design Decisions:**
- `fdc_fact_trace_run.composite_anomaly_score` is the weighted fusion of 4 anomaly detection methods (Interval + PM + Amplitude + Shape) — directly powering the Anomaly Score bar chart.
- `fdc_fact_trace_data` stores raw time-series at millisecond resolution — enabling the Trace Stack View's multi-sensor overlay.
- `fdc_fact_pm_event.pre_pm_health_score` vs `post_pm_health_score` enables the PM effectiveness analysis in the Process Timeline module.
- `eqp_dim_equipment.composite_health_score` = `0.35×z_score + 0.30×gof + 0.20×cv_stability + 0.15×volume` — the exact formula used by the Equipment Health Fleet gauge.

---

## 8. Domain 6 — MTR (Inline Metrology)

**Purpose:** CD, overlay, film thickness measurements; virtual metrology correlation; within-wafer uniformity; tool-to-tool matching

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `mtr_dim_recipe_step` | DIM | mtr_recipe_id, measurement_type, site_count, site_pattern | 9-Site Uniformity Map |
| `mtr_fact_measurement` | FACT | lot_id, wafer_id, site_id, measurement_type, measured_value, vm_predicted, apc_recipe_adjusted | WAT Site Map, APC |

**Key Design Decisions:**
- `mtr_fact_measurement.vm_predicted` enables the Virtual Metrology comparison view — showing predicted vs actual measurements.
- `mtr_fact_measurement.apc_recipe_adjusted` flags wafers where APC feed-forward was applied — enabling the R2R control audit trail.

---

## 9. Domain 7 — APC (Advanced Process Control)

**Purpose:** Run-to-run control models, setpoint adjustments, feed-forward/feedback loops, process drift correction

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `apc_dim_model` | DIM | model_id, model_type, manipulated_var_id, ewma_lambda, mv_step_max | FDC Fab Control |
| `apc_fact_control_action` | FACT | model_id, equipment_id, setpoint_adjustment, new_setpoint, ewma_state, control_effective | Process Timeline, FDC |

**Key Design Decisions:**
- `apc_fact_control_action.mv_step_max` enforces the ±5% safety constraint for auto-approved recipe adjustments.
- `apc_fact_control_action.control_effective` enables the R2R control effectiveness tracking — showing whether the adjustment achieved its target.

---

## 10. Domain 8 — DEF (Defect)

**Purpose:** Inline inspection defect management, ADC classification, wafer pattern analysis, SEM image management, killer defect identification

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `def_fact_defect` | FACT | lot_id, wafer_id, defect_x_um, defect_y_um, adc_class, adc_confidence, is_killer, kill_probability, sem_image_path | Defect Map, ADC Gallery |
| `def_fact_wafer_defect_summary` | FACT | lot_id, wafer_id, defect_density_cm2, pattern_class, suspected_equipment_id, hypothesis_confidence, predicted_yield_loss_pct | Defect Pareto, Stacked Map |

**Key Design Decisions:**
- `def_fact_defect.is_killer` + `kill_probability` enables the Killer Defect identification and yield impact correlation.
- `def_fact_defect.sem_image_path` stores the MinIO path for SEM images — enabling the ADC Gallery's image viewer.
- `def_fact_wafer_defect_summary.suspected_equipment_id` + `hypothesis_confidence` is the output of the WPA (Wafer Pattern Analysis) spatial-to-equipment mapping — directly feeding the Defect Source Analysis (DSA) module.

---

## 11. Domain 9 — YLD (Yield)

**Purpose:** Cross-domain yield aggregation, excursion detection, RCA knowledge, yield prediction, virtual yield, MRB consolidation

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `yld_fact_excursion` | FACT | excursion_id, excursion_type, severity, trigger_lot_id, affected_lot_count, financial_impact_usd | YMS Dashboard, Guided Analytics |
| `yld_fact_prediction` | FACT | lot_id, predicted_yield_pct, prediction_uncertainty, top_factor_1_name, shap_values_json | YMS Dashboard, Guided Analytics |
| `yld_fact_rca_knowledge` | FACT | rca_id, symptom_description, root_cause_category, corrective_action, yield_recovery_pct, confidence_score | Agent Knowledge Base |

**Key Design Decisions:**
- `yld_fact_prediction.shap_values_json` stores SHAP attribution values for each feature — enabling the SHAP waterfall chart in the Agent RCA response.
- `yld_fact_rca_knowledge` is the structured knowledge store that feeds the Neo4j Knowledge Graph — every confirmed RCA creates a node here and a corresponding Neo4j entry.
- `yld_fact_excursion.financial_impact_usd` enables the business-impact quantification in the MRB Review panel.

---

## 12. Domain 10 — MSC (Measurement System Comparison / R&R)

**Purpose:** Tester-to-tester comparison, R&R analysis, probe card qualification, measurement system validation

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `msc_dim_study` | DIM | study_id, study_type, system_1_id, system_2_id, product_id | MSC R&R |
| `msc_fact_rr_result` | FACT | study_id, test_name, rr_pct, repro_pct, repeat_pct, cpk_n, is_acceptable | MSC R&R Table |

**Key Design Decisions:**
- `msc_fact_rr_result.rr_pct` directly maps to the R&R% bar chart color coding: ≤20% (green), 20-50% (yellow), >50% (red).
- `msc_fact_rr_result.lpl` and `upl` (Lower/Upper Performance Limits) are the MSC-specific limits distinct from SPC limits.

---

## 13. Domain 11 — REL (Reliability / WLR)

**Purpose:** Wafer-level reliability tests (TDDB, HCI, NBTI, EM), lifetime prediction, burn-in data, DPPM fallout models

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `rel_fact_wlr_result` | FACT | lot_id, test_type, stress_voltage_v, is_fail, projected_lifetime_hr | Advanced Analytics |
| `rel_fact_dppm_model` | FACT | product_id, model_type, burnin_pct, dppm_value, yield_gain_pct, excursion_reduction_pct | DPPM Burn-in Chart |

**Key Design Decisions:**
- `rel_fact_dppm_model.model_type` (BEST/AVERAGE/WORST) maps directly to the three model lines in the DPPM Burn-in chart.
- `rel_fact_dppm_model.burnin_pct` + `dppm_value` are the X/Y coordinates for the DPPM curve — enabling the optimal burn-in point calculation.

---

## 14. Domain 12 — AGT (Agent / AI)

**Purpose:** Agentic AI session tracking, tool call audit, robot action audit, LLM inference log, knowledge update log

| Table | Type | Key Columns | UI Module |
|---|---|---|---|
| `agt_fact_session` | FACT | session_id, initiated_by, confidence_score, total_tool_calls, auto_actions_taken, engineer_feedback | Agent Chat, FAB Control |
| `agt_fact_robot_action` | FACT | action_id, action_type, confidence_score, authorization_level, execution_status, wafers_saved, estimated_value_usd | FAB Control, Agent Actions |

**Key Design Decisions:**
- `agt_fact_robot_action` is **fully immutable** (no UPDATE allowed) — providing a tamper-proof audit trail for all autonomous actions.
- `agt_fact_robot_action.estimated_value_usd` quantifies the financial impact of each robot action — enabling the "Wafers saved: $66,000" calculation in the FAB Control dashboard.
- `agt_fact_session.engineer_feedback` (CORRECT/PARTIALLY_CORRECT/INCORRECT) feeds back into the Neo4j Knowledge Graph to update confidence scores.

---

## 15. Oracle RT Schema (Real-Time OLTP)

Four tables optimized for sub-second response in the Oracle 19c RAC cluster:

| Table | Purpose | Key Feature |
|---|---|---|
| `rt_live_alarm` | Live alarm ingestion from FDC/SPC/YIELD | Auto-trigger updates `rt_equipment_status.alarm_count_24h` |
| `rt_wip_tracking` | Current lot position in fab | `is_hot_lot` flag for expedite routing |
| `rt_equipment_status` | Real-time tool health snapshot | Updated by trigger on every alarm insert |
| `rt_run_to_run_control` | APC setpoint adjustments | Immutable log of every recipe change |

---

## 16. Cross-Domain Pre-joined Views

Eight materialized/regular views that the SEMFAB·IQ microservices and SAS Viya actually query:

| View | Refresh | Serves | Key Joins |
|---|---|---|---|
| `v_yield_dashboard` | Every 5 min | YMS Dashboard | mes_dim_lot + cp_fact_wafer_summary + wat_agg_lot_summary + yld_fact_prediction + mes_fact_lot_operation |
| `v_wat_analytical` | On-demand | WAT Analytics Workbench | wat_fact_result + wat_dim_parameter + mes_dim_lot + eqp_dim_equipment |
| `v_spc_chart_data` | Every 5 min | SPC Monitor | spc_fact_measurement + spc_dim_parameter_config + fdc_fact_pm_event (for PM annotations) |
| `v_fdc_trace_anomaly` | Every 5 min | FDC Monitor | fdc_fact_trace_run + eqp_dim_equipment + eqp_dim_chamber |
| `v_cp_bin_analysis` | Every 10 min | CP Bin Map, Wafer Gallery | cp_fact_wafer_summary + cp_dim_test_program + mes_dim_lot + def_fact_wafer_defect_summary |
| `v_mrb_consolidation` | Every 10 min | MRB Review Panel | cp_fact_wafer_summary + mes_dim_lot (with SYL/SBL/pattern logic) |
| `v_defect_pareto` | Every 30 min | Defect Analysis | def_fact_defect + def_fact_wafer_defect_summary + mes_dim_lot |
| `v_agent_audit` | Real-time | FAB Control, Agent History | agt_fact_robot_action + agt_fact_session |

---

## 17. SAS Viya CAS Table Loading Strategy

| CAS Table | Source View | Refresh | Purpose |
|---|---|---|---|
| `WAT_CURRENT` | `v_wat_analytical` (90d) | 5 min | PROC UNIVARIATE, PROC CORR, PROC GLM |
| `SPC_CHARTS_ACTIVE` | `v_spc_chart_data` (30d) | 5 min | PROC SHEWHART, PROC CAPABILITY |
| `CP_WAFER_CURRENT` | `v_cp_bin_analysis` (60d) | 10 min | Spatial pattern analysis, bin pareto |
| `YIELD_TREND_90D` | `v_yield_dashboard` | 60 min | Yield trend, SYL/SBL check |
| `ANOVA_EQUIPMENT_CURRENT` | `wat_fact_anova_equipment` (90d) | 60 min | Equipment factor analysis |
| `FDC_TRACE_SUMMARY` | `v_fdc_trace_anomaly` (30d) | 30 min | Trace anomaly classification |
| `CORRELATION_MATRIX` | `wat_fact_correlation` | 24 hr | Pre-computed Pearson/Spearman matrix |
| `RCA_KNOWLEDGE` | `yld_fact_rca_knowledge` | 6 hr | Agent RAG retrieval |

**SAS Procedure Mapping:**

| Analysis | SAS Procedure | Output |
|---|---|---|
| Distribution Fit | `PROC UNIVARIATE` | mean, sigma, Cpk, normality p-value, histogram bins |
| Process Capability | `PROC CAPABILITY` | Cp, Cpk, Cpm, Pp, Ppk |
| SPC Chart | `PROC SHEWHART` | UCL, LCL, CL, violation flags |
| Correlation | `PROC CORR` | Pearson r, p-value matrix |
| ANOVA | `PROC GLM` | SS, MS, F-statistic, eta-squared |
| Factor Screening | `PROC GLMSELECT` | Standardized coefficients, variable selection |
| PCA | `PROC FACTOR` | Loadings, scores, explained variance |
| Regression | `PROC REG` | Coefficients, R², confidence intervals |
| Yield Prediction | `PROC HPFOREST` + `PROC GRADBOOST` | Predicted yield, SHAP values |
| Chi-Square | `PROC FREQ` | Chi-square statistic, p-value, Cramér's V |

---

## 18. Redis Cache Key Schema

```
# Dashboard Hot Cache (TTL = seconds)
semfab:yms:dashboard:snapshot                       TTL=300
semfab:yms:alarm_count:active                       TTL=30
semfab:yms:wip_count:{step_id}                      TTL=60
semfab:yms:fab_yield_today:{product_id}             TTL=300

# SPC Chart Cache
semfab:spc:chart_data:{config_id}:{days}            TTL=300
semfab:spc:limits:{config_id}                       TTL=3600
semfab:spc:violations:recent:{equipment_id}         TTL=60

# WAT Analytics Cache
semfab:wat:lot_summary:{lot_id}:{parameter_id}      TTL=3600
semfab:wat:correlation:{product_id}:{date_hash}     TTL=7200
semfab:wat:anova:{product_id}:{parameter_id}        TTL=3600
semfab:wat:equipment_health:{equipment_id}          TTL=1800

# CP Analytics Cache
semfab:cp:wafer_map:{lot_id}:{wafer_id}             TTL=3600
semfab:cp:bin_pareto:{lot_id}                       TTL=3600
semfab:cp:yield_summary:{lot_id}                    TTL=1800

# FDC Cache
semfab:fdc:trace_anomaly:{run_id}                   TTL=86400
semfab:fdc:equipment_health:{equipment_id}          TTL=300
semfab:fdc:active_alarms:{equipment_id}             TTL=30

# Agent Session Cache
semfab:agent:session:{session_id}                   TTL=1800
semfab:agent:pending_actions:{user_id}              TTL=3600
semfab:agent:streaming:{session_id}                 TTL=300

# Auth Cache
semfab:auth:token:{jti}                             TTL=900
semfab:auth:blacklist:{jti}                         TTL=86400
semfab:auth:user_perms:{user_id}                    TTL=1800
```

---

## 19. Neo4j Knowledge Graph Schema

Seven node types and seven relationship types form the AI Wisdom Engine:

```
Node Types:
  Equipment    → equipment_id, health_score, health_tier
  ProcessStep  → step_id, process_area, layer_name
  Parameter    → parameter_id, parameter_group, criticality_rank
  RootCause    → rca_id, confidence_score, occurrence_count, physical_mechanism
  CorrectiveAction → action_id, success_rate, time_to_effect_hr
  DefectPattern → pattern_id, spatial_class, process_correlation
  Product      → product_id, process_node, target_yield_pct

Relationship Types:
  Equipment   -[:PROCESSES]->         ProcessStep
  ProcessStep -[:MEASURES]->          Parameter
  Parameter   -[:CAUSES_WHEN_OOC]->   RootCause   {ooc_direction, yield_impact_pct}
  RootCause   -[:FIXED_BY]->          CorrectiveAction {historical_success_rate}
  DefectPattern -[:INDICATES]->       RootCause   {confidence}
  RootCause   -[:SIMILAR_TO]->        RootCause   {cosine_similarity}
  Equipment   -[:MATCHED_TO]->        Equipment   {matching_score, deviation_pct}
```

---

## 20. DataMart Summary Matrix

| Domain | FACT Tables | Key Dimensions | UI Modules Served | Interactive Features |
|---|---|---|---|---|
| **MES** | lot_operation, cycle_time, material_consumption | lot, wafer, route_step | YMS, Score Card, MRB, Process Timeline | Route step filter, shift selector, lot type toggle |
| **WAT** | result, correlation, anova_equipment | parameter, site_map | WAT Analytics, DE-General | Parameter selector, vcc/temp filter, site zone filter, equipment group-by |
| **CP** | die_result, parametric, wafer_summary, touchdown | test_program, bin | CP Bin Map, Wafer Gallery, Smart Sampling, Die Traceability | Bin filter, die click drill-down, mark/hide bins, skip visualization |
| **SPC** | measurement, violation, capability | parameter_config | SPC Monitor (5 tabs) | Rule bitmask toggle, limit edit, compare baseline, zoom/brush |
| **FDC** | trace_run, trace_data, indicator_result, pm_event | sensor, indicator, equipment | FDC Monitor (4 views), Equipment Fleet | Sensor multi-select, baseline vs qual overlay, anomaly threshold slider |
| **MTR** | measurement | recipe_step | WAT 9-Site Map, APC | Site heatmap, overlay multiple tools, VM comparison |
| **APC** | control_action | model | FDC Fab Control, Process Timeline | Recipe parameter selector, EWMA lambda edit, lot range brush |
| **DEF** | defect, wafer_defect_summary | inspection_tool | Defect Analysis (5 tabs), Stacked Map | Class filter, size range slider, cluster highlight, SEM zoom |
| **YLD** | excursion, prediction, rca_knowledge | excursion | YMS Dashboard, Guided Analytics, Agent Chat | Severity filter, lot group selection, confidence threshold |
| **MSC** | rr_result | study | Advanced Analytics (MSC R&R tab) | System 1/2 selector, test item multi-select, cycle group-by |
| **REL** | wlr_result, dppm_model | test_type | Advanced Analytics (DPPM tab) | Stress condition selector, model type toggle (best/avg/worst) |
| **AGT** | session, robot_action | — | Agent Chat, FAB Control | Date range, action type filter, approval status, immutable audit |

---

## 21. Integration Gap Analysis: Current vs Final

The current SEMFAB·IQ implementation uses simplified MySQL tables for demonstration. The following table maps the current simplified tables to the final production schema:

| Current Table | Final Production Schema | Gap |
|---|---|---|
| `equipment` | `eqp_dim_equipment` + `eqp_dim_chamber` | Missing: chamber-level data, SCD Type 2, composite health components |
| `lots` | `mes_dim_lot` + `rt_wip_tracking` | Missing: SYL/SBL limits, SCD Type 2, process route linkage |
| `alarms` | `rt_live_alarm` (Oracle) + `spc_fact_violation` (Greenplum) | Missing: Oracle trigger, agent_rca_session_id linkage |
| `spc_violations` | `spc_fact_violation` + `spc_agg_capability` | Missing: all 8 rule flags, evidence_measurements_json, financial impact |
| `defect_maps` | `def_fact_defect` + `def_fact_wafer_defect_summary` | Missing: kill_probability, SEM image path, pattern hypothesis |
| `agent_actions` | `agt_fact_robot_action` (immutable) | Missing: immutability constraint, wafers_saved, estimated_value_usd |
| `yield_summaries` | `cp_fact_wafer_summary` + `yld_fact_excursion` | Missing: SHAP values, SYL/SBL flags, MRB decision |
| *(not implemented)* | `wat_fact_result` + `wat_agg_lot_summary` | WAT parametric data currently synthetic |
| *(not implemented)* | `fdc_fact_trace_run` + `fdc_fact_trace_data` | FDC trace data currently synthetic |
| *(not implemented)* | `msc_fact_rr_result` | MSC R&R data currently hardcoded |
| *(not implemented)* | `rel_fact_dppm_model` | DPPM data currently synthetic |

---

*Document: SEMFAB·IQ Final Data Architecture & Schema Design v2.0*  
*12 DataMart Domains · 60+ Tables · 20+ Views · Oracle RT · Redis Cache · Neo4j Knowledge Graph · SAS Viya CAS*  
*Fully integrated with SEMFAB·IQ v4.0 UI modules and Agentic AI workflows*
