/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'bg-void':    '#060A12',
        'bg-base':    '#0A0F1C',
        'bg-surface': '#0F1626',
        'bg-card':    '#131B2E',
        'bg-elevated':'#192035',
        teal:  '#00E5C4',
        coral: '#FF4F6A',
        violet:'#8B5CF6',
        amber: '#F59E0B',
        sky:   '#38BDF8',
        lime:  '#84CC16',
        pass:  '#10B981',
        fail:  '#EF4444',
        warn:  '#F59E0B',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
        body:    ['Inter', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', '"Fira Code"', 'monospace'],
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.25s cubic-bezier(0.23,1,0.32,1) both',
        'pulse-teal': 'pulseTeal 2s infinite',
        'alarm-glow': 'alarmGlow 2s infinite',
      },
      keyframes: {
        fadeInUp: {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to:   { opacity: '1', transform: 'translateY(0)' }
        },
        pulseTeal: {
          '0%,100%': { boxShadow: '0 0 0 0 rgba(0,229,196,0.4)' },
          '50%':     { boxShadow: '0 0 0 6px rgba(0,229,196,0)' }
        },
        alarmGlow: {
          '0%,100%': { boxShadow: '0 0 0 0 rgba(255,79,106,0.15)' },
          '50%':     { boxShadow: '0 0 0 4px rgba(255,79,106,0)' }
        }
      }
    }
  },
  plugins: []
}
