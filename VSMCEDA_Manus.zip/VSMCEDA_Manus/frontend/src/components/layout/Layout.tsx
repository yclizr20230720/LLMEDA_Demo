/**
 * SEMFAB·IQ — Main Layout with Sidebar Navigation
 */
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { dashboardAPI } from '../../services/api'
import { useAuthStore } from '../../store/authStore'
import {
  LayoutDashboard, FlaskConical, Activity, Bug, Bot, Factory,
  Cpu, ChevronLeft, ChevronRight, User, Zap, AlertTriangle,
  BarChart2, Radio, Compass, Target, LogOut
} from 'lucide-react'
import toast from 'react-hot-toast'

const NAV_GROUPS = [
  {
    label: 'Yield Intelligence',
    items: [
      { path: '/yms', label: 'YMS Dashboard', icon: LayoutDashboard, desc: 'Fab-wide yield' },
      { path: '/guided', label: 'Guided Analytics', icon: Compass, desc: 'Step-by-step RCA', badge: 'GA' },
      { path: '/advanced', label: 'Score Card / MRB', icon: Target, desc: 'MSC · DPPM · Timeline', badge: 'NEW' },
    ]
  },
  {
    label: 'Data Analytics',
    items: [
      { path: '/wat', label: 'WAT Analytics', icon: FlaskConical, desc: 'Parametric analysis' },
      { path: '/fdc', label: 'FDC Engine', icon: Zap, desc: 'Fault detection' },
    ]
  },
  {
    label: 'Process Control',
    items: [
      { path: '/spc', label: 'SPC Monitor', icon: Activity, desc: 'Statistical control' },
    ]
  },
  {
    label: 'Quality & Defect',
    items: [
      { path: '/defect', label: 'Defect DMS', icon: Bug, desc: 'ADC + WPA + Pareto' },
    ]
  },
  {
    label: 'AI / Agent',
    items: [
      { path: '/agent', label: 'SemiMind++ AI', icon: Bot, desc: 'AI Agent chat', badge: 'AI' },
    ]
  },
  {
    label: 'FAB Operations',
    items: [
      { path: '/fab-control', label: 'FAB Control', icon: Factory, desc: 'Robot dashboard' },
      { path: '/equipment', label: 'Equipment Fleet', icon: Cpu, desc: 'Tool health' },
    ]
  }
]

const BADGE_STYLES: Record<string, { bg: string; color: string }> = {
  'GA':  { bg: 'rgba(0,229,196,0.15)',  color: '#00E5C4' },
  'AI':  { bg: 'rgba(139,92,246,0.15)', color: '#8B5CF6' },
  'NEW': { bg: 'rgba(245,158,11,0.15)', color: '#F59E0B' },
}

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false)
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const { data: kpis } = useQuery({
    queryKey: ['kpis'],
    queryFn: () => dashboardAPI.kpis().then(r => r.data),
    refetchInterval: 30000
  })

  const { data: alarms } = useQuery({
    queryKey: ['alarms-count'],
    queryFn: () => dashboardAPI.alarms(5, 'CRITICAL').then(r => r.data),
    refetchInterval: 30000
  })

  const criticalCount = (alarms || []).filter((a: any) => a.severity === 'CRITICAL' && a.status === 'OPEN').length

  const handleLogout = () => {
    logout()
    navigate('/login')
    toast.success('Logged out successfully')
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-void)' }}>
      {/* Sidebar */}
      <aside style={{
        width: collapsed ? '52px' : '210px',
        flexShrink: 0,
        height: '100vh',
        position: 'sticky',
        top: 0,
        background: 'var(--bg-base)',
        borderRight: '1px solid var(--border)',
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.3s cubic-bezier(0.23,1,0.32,1)',
        zIndex: 20,
        overflow: 'hidden'
      }}>
        {/* Logo */}
        <div style={{ padding: '14px 12px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
          <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'var(--teal-dim)', border: '1px solid var(--border-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Zap size={14} color="var(--teal)" />
          </div>
          {!collapsed && (
            <div style={{ minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', fontWeight: 700, background: 'linear-gradient(135deg, var(--teal), var(--violet))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>SEMFAB·IQ</div>
              <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>EDA PLATFORM v2.0</div>
            </div>
          )}
        </div>

        {/* FAB Status Strip */}
        {!collapsed && kpis && (
          <div style={{ padding: '8px 12px', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
            <div style={{ borderRadius: '6px', padding: '6px 8px', background: 'var(--teal-dim)', border: '1px solid var(--border-accent)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                <span style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>FAB YIELD</span>
                <span style={{ fontSize: '11px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--teal)' }}>{kpis.fabYield}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>OEE</span>
                <span style={{ fontSize: '11px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--text-primary)' }}>{kpis.oee}%</span>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav style={{ flex: 1, overflowY: 'auto', padding: '8px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {NAV_GROUPS.map(group => (
            <div key={group.label}>
              {!collapsed && (
                <div style={{ fontSize: '9px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', padding: '0 6px', marginBottom: '4px' }}>
                  {group.label}
                </div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
                {group.items.map(item => {
                  const Icon = item.icon
                  const badgeStyle = item.badge ? BADGE_STYLES[item.badge] : null
                  return (
                    <NavLink key={item.path} to={item.path} style={({ isActive }) => ({
                      display: 'flex', alignItems: 'center', gap: '8px',
                      padding: '7px 8px', borderRadius: '6px', cursor: 'pointer',
                      transition: 'all 0.15s', textDecoration: 'none',
                      background: isActive ? 'var(--teal-dim)' : 'transparent',
                      border: `1px solid ${isActive ? 'var(--border-accent)' : 'transparent'}`,
                      color: isActive ? 'var(--teal)' : 'var(--text-secondary)',
                      position: 'relative'
                    })}>
                      {({ isActive }) => (
                        <>
                          {isActive && <div style={{ position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)', width: '2px', height: '16px', borderRadius: '0 2px 2px 0', background: 'var(--teal)' }} />}
                          <Icon size={14} style={{ flexShrink: 0 }} />
                          {!collapsed && (
                            <div style={{ minWidth: 0, flex: 1 }}>
                              <div style={{ fontSize: '11px', fontWeight: 500, lineHeight: '1.2', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                {item.label}
                                {item.badge && badgeStyle && (
                                  <span style={{ fontSize: '8px', padding: '1px 4px', borderRadius: '3px', fontWeight: 700, background: badgeStyle.bg, color: badgeStyle.color }}>
                                    {item.badge}
                                  </span>
                                )}
                              </div>
                              <div style={{ fontSize: '9px', opacity: 0.55, lineHeight: '1.2', marginTop: '1px' }}>{item.desc}</div>
                            </div>
                          )}
                        </>
                      )}
                    </NavLink>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Bottom: Alarms + User */}
        <div style={{ borderTop: '1px solid var(--border)', padding: '8px', flexShrink: 0 }}>
          {criticalCount > 0 && !collapsed && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 8px', borderRadius: '6px', marginBottom: '4px', background: 'var(--coral-dim)', border: '1px solid rgba(255,79,106,0.3)', color: 'var(--coral)', fontSize: '10px', fontFamily: 'var(--font-mono)', animation: 'alarmGlow 2s infinite' }}>
              <AlertTriangle size={12} />
              <span>{criticalCount} Critical Alarm{criticalCount > 1 ? 's' : ''}</span>
            </div>
          )}
          {!collapsed && user && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 8px', borderRadius: '6px', background: 'var(--bg-surface)' }}>
              <div style={{ width: '22px', height: '22px', borderRadius: '50%', background: 'var(--teal-dim)', border: '1px solid var(--border-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <User size={11} color="var(--teal)" />
              </div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: '10px', color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.full_name}</div>
                <div style={{ fontSize: '8px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{user.role}</div>
              </div>
              <button onClick={handleLogout} title="Logout" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '2px' }}>
                <LogOut size={12} />
              </button>
            </div>
          )}
        </div>

        {/* Collapse Toggle */}
        <button onClick={() => setCollapsed(!collapsed)} style={{
          position: 'absolute', right: '-12px', top: '56px',
          width: '24px', height: '24px', borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'var(--bg-base)', border: '1px solid var(--border-accent)',
          color: 'var(--teal)', cursor: 'pointer', transition: 'all 0.2s', zIndex: 30
        }}>
          {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>
      </aside>

      {/* Main Content */}
      <main style={{ flex: 1, minWidth: 0, overflow: 'auto' }}>
        <Outlet />
      </main>
    </div>
  )
}
