/**
 * SEMFAB·IQ — YMS Dashboard Page
 * 6-KPI Strip · Yield Trend · Score Card · MRB Review · Alarm Feed · Wafer Gallery
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { dashboardAPI, lotsAPI } from '../services/api'
import { useState, useMemo, useRef, useEffect } from 'react'
import {
  ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Brush, Legend, BarChart, Bar, Cell
} from 'recharts'
import {
  TrendingUp, AlertTriangle, Package, Gauge, Bot, Activity,
  Filter, Download, RefreshCw, Eye, EyeOff, ChevronDown, ChevronUp,
  ArrowUpDown, Search, X, Zap, CheckCircle2, XCircle
} from 'lucide-react'
import toast from 'react-hot-toast'

// ── Canvas Wafer Map ──────────────────────────────────────
function WaferCanvas({ waferId, yieldPct, pattern, size = 80 }: { waferId: string; yieldPct: number | null; pattern: string; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const BIN_COLORS: Record<number, string> = { 1: '#00E5C4', 2: '#EF4444', 3: '#F97316', 4: '#F59E0B', 5: '#8B5CF6', 6: '#475569' }
  useEffect(() => {
    const c = ref.current; if (!c) return
    const ctx = c.getContext('2d'); if (!ctx) return
    ctx.clearRect(0, 0, size, size)
    const cx = size / 2, cy = size / 2, r = size / 2 - 4
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2)
    ctx.fillStyle = 'rgba(255,255,255,0.02)'; ctx.fill()
    ctx.strokeStyle = 'rgba(0,229,196,0.2)'; ctx.lineWidth = 1; ctx.stroke()
    const ds = size < 80 ? 4 : 5, passRate = yieldPct ? yieldPct / 100 : 0.94
    for (let x = -r + 2; x < r - 2; x += ds + 1) {
      for (let y = -r + 2; y < r - 2; y += ds + 1) {
        if (x * x + y * y > (r - 3) * (r - 3)) continue
        const isEdge = x * x + y * y > (r - 10) * (r - 10)
        let bin = 1
        const rnd = Math.random()
        if (isEdge && pattern === 'EDGE') bin = rnd < 0.6 ? 2 : 1
        else if (pattern === 'RING' && x * x + y * y > (r - 20) * (r - 20) && x * x + y * y < (r - 8) * (r - 8)) bin = rnd < 0.5 ? 2 : 1
        else bin = rnd < passRate ? 1 : rnd < passRate + 0.03 ? 3 : rnd < passRate + 0.05 ? 4 : 2
        ctx.fillStyle = BIN_COLORS[bin] || '#475569'
        ctx.globalAlpha = bin === 1 ? 0.7 : 0.9
        ctx.fillRect(cx + x, cy + y, ds, ds)
      }
    }
    ctx.globalAlpha = 1
    ctx.beginPath(); ctx.arc(cx, cy + r - 1, 3, 0, Math.PI * 2)
    ctx.fillStyle = '#060A12'; ctx.fill()
  }, [yieldPct, pattern, size])
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}>
      <canvas ref={ref} width={size} height={size} style={{ cursor: 'pointer' }} />
      <div style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{waferId.split('_').pop()}</div>
      {yieldPct && <div style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', fontWeight: 700, color: yieldPct > 92 ? 'var(--pass)' : yieldPct > 88 ? 'var(--warn)' : 'var(--fail)' }}>{yieldPct.toFixed(1)}%</div>}
    </div>
  )
}

// ── KPI Card ──────────────────────────────────────────────
function KpiCard({ label, value, unit, colorClass, delta, deltaUp, progress, Icon, onClick }: any) {
  return (
    <div className={`kpi-card ${colorClass}`} onClick={onClick}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '8px' }}>
        <div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500 }}>{label}</div>
        <Icon size={14} style={{ color: `var(--${colorClass})`, opacity: 0.7 }} />
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '26px', fontWeight: 700, color: `var(--${colorClass})`, textShadow: `0 0 20px var(--${colorClass})40`, lineHeight: 1 }}>
        {value}<span style={{ fontSize: '14px', fontWeight: 400, color: 'var(--text-muted)', marginLeft: '3px' }}>{unit}</span>
      </div>
      {delta && (
        <div style={{ fontSize: '11px', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)' }}>
          <span style={{ color: deltaUp ? 'var(--pass)' : 'var(--fail)' }}>{deltaUp ? '▲' : '▼'}</span>
          <span style={{ color: deltaUp ? 'var(--pass)' : 'var(--fail)' }}>{delta}</span>
        </div>
      )}
      {progress !== undefined && (
        <div style={{ width: '100%', height: '3px', background: 'var(--bg-elevated)', borderRadius: '2px', overflow: 'hidden', marginTop: '8px' }}>
          <div style={{ height: '100%', borderRadius: '2px', width: `${progress}%`, background: `var(--${colorClass})`, transition: 'width 1s ease' }} />
        </div>
      )}
    </div>
  )
}

// ── Main Dashboard ────────────────────────────────────────
export default function YMSDashboard() {
  const qc = useQueryClient()
  const [activeTab, setActiveTab] = useState<'gallery' | 'scorecard' | 'mrb'>('gallery')
  const [filterCollapsed, setFilterCollapsed] = useState(true)
  const [filters, setFilters] = useState<Record<string, string>>({ product: 'ALL', node: 'ALL', priority: 'ALL', status: 'ALL' })
  const [showSYL, setShowSYL] = useState(true)
  const [showSBL, setShowSBL] = useState(true)
  const [compareMode, setCompareMode] = useState(false)
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState('event_date')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [selectedLots, setSelectedLots] = useState<Set<string>>(new Set())
  const [clock, setClock] = useState(new Date().toLocaleTimeString())

  useEffect(() => { const t = setInterval(() => setClock(new Date().toLocaleTimeString()), 1000); return () => clearInterval(t) }, [])

  const { data: kpis, refetch: refetchKpis } = useQuery({ queryKey: ['kpis'], queryFn: () => dashboardAPI.kpis().then(r => r.data), refetchInterval: 30000 })
  const { data: trend } = useQuery({ queryKey: ['yield-trend'], queryFn: () => dashboardAPI.yieldTrend(30).then(r => r.data) })
  const { data: alarms, refetch: refetchAlarms } = useQuery({ queryKey: ['alarms'], queryFn: () => dashboardAPI.alarms(20).then(r => r.data), refetchInterval: 15000 })
  const { data: gallery } = useQuery({ queryKey: ['wafer-gallery'], queryFn: () => dashboardAPI.waferGallery().then(r => r.data) })
  const { data: scoreCard } = useQuery({ queryKey: ['score-card'], queryFn: () => dashboardAPI.scoreCard().then(r => r.data) })
  const { data: lots } = useQuery({ queryKey: ['lots'], queryFn: () => lotsAPI.list().then(r => r.data) })

  const ackMutation = useMutation({ mutationFn: (id: number) => dashboardAPI.ackAlarm(id), onSuccess: () => { refetchAlarms(); toast.success('Alarm acknowledged') } })

  const chartData = useMemo(() => {
    if (!trend) return []
    return (trend as any[]).map((d: any) => ({ ...d, yieldPrev: d.yield - (Math.random() - 0.5) * 4 }))
  }, [trend])

  const filteredScore = useMemo(() => {
    if (!scoreCard) return []
    return (scoreCard as any[]).filter((l: any) => {
      if (search && !l.lot_id?.toLowerCase().includes(search.toLowerCase()) && !l.product_id?.toLowerCase().includes(search.toLowerCase())) return false
      if (filters.product !== 'ALL' && l.product_id !== filters.product) return false
      return true
    }).sort((a: any, b: any) => {
      const av = a[sortKey], bv = b[sortKey]
      if (av == null) return 1; if (bv == null) return -1
      return sortDir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1)
    })
  }, [scoreCard, search, filters, sortKey, sortDir])

  const getYieldBadge = (y: number | null) => {
    if (y == null) return <span style={{ color: 'var(--text-muted)' }}>—</span>
    const cls = y >= 95 ? 'cell-pass' : y >= 90 ? 'cell-warn' : 'cell-fail'
    return <span className={cls}>{Number(y).toFixed(2)}%</span>
  }

  return (
    <div className="circuit-bg" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px', minHeight: '100vh' }}>
      {/* Header */}
      <div className="animate-fade-in-up" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Zap size={20} color="var(--teal)" /> Yield Management System
          </h1>
          <p style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>FAB-12 · N5/N3 Production · Real-time · {clock}</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--teal)', animation: 'pulseTeal 2s infinite' }} />
            <span style={{ fontSize: '11px', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>LIVE</span>
          </div>
          <button onClick={() => { refetchKpis(); refetchAlarms(); toast.success('Refreshed') }} style={{ width: '28px', height: '28px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--teal-dim)', border: '1px solid var(--border-accent)', color: 'var(--teal)', cursor: 'pointer' }}>
            <RefreshCw size={14} />
          </button>
        </div>
      </div>

      {/* 6-KPI Strip */}
      <div className="animate-fade-in-up stagger-1" style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '12px' }}>
        <KpiCard label="FAB Yield Today" value={kpis?.fabYield || '—'} unit="%" colorClass="teal" Icon={TrendingUp} delta={`${kpis?.fabYield ? (Number(kpis.fabYield) - 94.1).toFixed(1) : '0.0'}% vs 7d`} deltaUp={Number(kpis?.fabYield || 94) >= 94.1} progress={Number(kpis?.fabYield || 94)} />
        <KpiCard label="Active Alarms" value={kpis?.activeAlarms || 0} colorClass="coral" Icon={AlertTriangle} delta={`${Math.floor((kpis?.activeAlarms || 0) * 0.4)} Critical`} deltaUp={false} progress={(kpis?.activeAlarms || 0) * 10} />
        <KpiCard label="Lots In Process" value={kpis?.activeLots || 0} colorClass="amber" Icon={Package} delta="+8 vs yesterday" deltaUp={true} progress={78} />
        <KpiCard label="Equipment OEE" value={kpis?.oee || '—'} unit="%" colorClass="sky" Icon={Gauge} delta="+1.2% vs target" deltaUp={true} progress={Number(kpis?.oee || 88)} />
        <KpiCard label="Agent Actions 24h" value={kpis?.agentActions24h || 12} colorClass="violet" Icon={Bot} delta="11 auto · 1 pending" deltaUp={true} progress={92} />
        <KpiCard label="DPPM Fallout" value={kpis?.dppmFallout || '4.2'} colorClass="lime" Icon={Activity} delta="−0.8 best model" deltaUp={true} progress={42} />
      </div>

      {/* Row 1: Yield Trend + Alarm Feed */}
      <div className="animate-fade-in-up stagger-2" style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px' }}>
        {/* Yield Trend */}
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title"><div className="panel-accent" />Product Yield Trend & SYL/SBL Check</div>
            <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
              {[{ key: 'syl', label: 'SYL', state: showSYL, setter: setShowSYL, color: 'var(--amber)' }, { key: 'sbl', label: 'SBL', state: showSBL, setter: setShowSBL, color: 'var(--coral)' }].map(c => (
                <button key={c.key} onClick={() => c.setter(!c.state)} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '4px', fontSize: '10px', fontFamily: 'var(--font-mono)', cursor: 'pointer', background: c.state ? `${c.color}15` : 'var(--bg-elevated)', color: c.state ? c.color : 'var(--text-muted)', border: `1px solid ${c.state ? c.color + '30' : 'var(--border)'}`, opacity: c.state ? 1 : 0.5 }}>
                  {c.state ? <Eye size={10} /> : <EyeOff size={10} />} {c.label}
                </button>
              ))}
              <button onClick={() => setCompareMode(!compareMode)} style={{ padding: '3px 8px', borderRadius: '4px', fontSize: '10px', fontFamily: 'var(--font-mono)', cursor: 'pointer', background: compareMode ? 'var(--violet-dim)' : 'var(--bg-elevated)', color: compareMode ? 'var(--violet)' : 'var(--text-muted)', border: `1px solid ${compareMode ? 'rgba(139,92,246,0.3)' : 'var(--border)'}` }}>
                Compare
              </button>
              <button onClick={() => toast.success('Trend exported')} style={{ width: '24px', height: '24px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <Download size={12} />
              </button>
            </div>
          </div>
          <div className="panel-body">
            <ResponsiveContainer width="100%" height={160}>
              <ComposedChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="date" tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} tickFormatter={v => v?.slice(5)} />
                <YAxis domain={[82, 100]} tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} tickFormatter={v => `${v}%`} />
                <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                <Brush dataKey="date" height={12} stroke="rgba(0,229,196,0.3)" fill="rgba(0,229,196,0.05)" travellerWidth={5} tickFormatter={v => v?.slice(5)} />
                {showSYL && <ReferenceLine y={90.0} stroke="rgba(245,158,11,0.6)" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'SYL 90%', fill: 'var(--amber)', fontSize: 9, position: 'right' }} />}
                {showSBL && <ReferenceLine y={85.0} stroke="rgba(255,79,106,0.6)" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'SBL 85%', fill: 'var(--coral)', fontSize: 9, position: 'right' }} />}
                <Area type="monotone" dataKey="yield" stroke="var(--teal)" fill="rgba(0,229,196,0.06)" strokeWidth={2} name="Current"
                  dot={(props: any) => {
                    const { cx, cy, payload } = props
                    if (payload.yield < 90) return <circle key={cx} cx={cx} cy={cy} r={4} fill="var(--fail)" stroke="var(--fail)" style={{ filter: 'drop-shadow(0 0 4px var(--fail))' }} />
                    return <circle key={cx} cx={cx} cy={cy} r={2} fill="var(--teal)" stroke="none" />
                  }}
                />
                {compareMode && <Line type="monotone" dataKey="yieldPrev" stroke="var(--violet)" strokeWidth={1.5} strokeDasharray="4 2" name="Previous" dot={false} />}
                {compareMode && <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'var(--font-mono)' }} />}
              </ComposedChart>
            </ResponsiveContainer>
            {/* Inline stats */}
            <div style={{ display: 'flex', gap: '16px', marginTop: '12px', flexWrap: 'wrap' }}>
              {[
                { val: `${kpis?.fabYield || '95.1'}%`, lbl: 'Current', color: 'var(--teal)' },
                { val: '94.4%', lbl: '7d Avg', color: 'var(--text-primary)' },
                { val: '93.9%', lbl: '30d Avg', color: 'var(--text-primary)' },
                { val: '90.0%', lbl: 'SYL', color: 'var(--amber)' },
                { val: '85.0%', lbl: 'SBL', color: 'var(--coral)' },
                { val: '1.42', lbl: 'Cpk', color: 'var(--pass)' },
              ].map(s => (
                <div key={s.lbl} style={{ textAlign: 'center' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '15px', fontWeight: 600, color: s.color }}>{s.val}</div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{s.lbl}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Alarm Feed */}
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title"><div className="panel-accent coral" />Live Alarm Feed</div>
            <span className="chip coral">{(alarms || []).filter((a: any) => a.status === 'OPEN').length} Active</span>
          </div>
          <div className="panel-body" style={{ padding: '12px', maxHeight: '320px', overflowY: 'auto' }}>
            {(alarms || []).length === 0 ? (
              <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: '12px' }}>
                <CheckCircle2 size={32} style={{ margin: '0 auto 8px', color: 'var(--pass)' }} />
                All Clear
              </div>
            ) : (alarms || []).map((alarm: any) => {
              const sev = alarm.severity?.toLowerCase()
              const cls = sev === 'critical' ? 'critical' : sev === 'major' ? 'warning' : 'info'
              const icon = sev === 'critical' ? '🔴' : sev === 'major' ? '🟡' : '🔵'
              return (
                <div key={alarm.alarm_id} className={`alarm-item ${cls}`} onClick={() => ackMutation.mutate(alarm.alarm_id)}>
                  <span style={{ fontSize: '14px', marginTop: '1px' }}>{icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--text-primary)' }}>{alarm.alarm_message?.slice(0, 55)}</div>
                    <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '2px', fontFamily: 'var(--font-mono)' }}>{alarm.equipment_id} · {alarm.lot_id || '—'}</div>
                  </div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap' }}>
                    {new Date(alarm.alarm_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Row 2: Tabbed Panel */}
      <div className="panel animate-fade-in-up stagger-3">
        <div className="panel-header">
          <div style={{ display: 'flex', gap: '4px' }}>
            {[{ id: 'gallery', label: '🗺️ Wafer Gallery' }, { id: 'scorecard', label: '📋 Score Card' }, { id: 'mrb', label: '🚦 MRB Review' }].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} style={{ padding: '4px 10px', fontSize: '11px', fontWeight: 500, borderRadius: '4px', cursor: 'pointer', color: activeTab === tab.id ? 'var(--teal)' : 'var(--text-muted)', background: activeTab === tab.id ? 'var(--teal-dim)' : 'transparent', border: `1px solid ${activeTab === tab.id ? 'var(--border-accent)' : 'transparent'}`, transition: 'all 0.15s' }}>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        <div className="panel-body">
          {activeTab === 'gallery' && (
            <div style={{ overflowX: 'auto' }}>
              <div style={{ display: 'flex', gap: '12px', paddingBottom: '8px' }}>
                {(gallery || []).map((lot: any) => (
                  <div key={lot.lot_id} style={{ flexShrink: 0, minWidth: '160px', padding: '12px', borderRadius: '10px', background: 'var(--bg-surface)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--teal)', fontWeight: 600 }}>{lot.lot_id}</span>
                      {lot.priority === 'HOT' && <span className="chip coral" style={{ fontSize: '8px', padding: '1px 5px' }}>HOT</span>}
                    </div>
                    <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>{lot.product_id} · {lot.process_node}</div>
                    <div style={{ display: 'flex', gap: '3px', flexWrap: 'wrap' }}>
                      {(lot.wafers || []).slice(0, 6).map((w: any) => <WaferCanvas key={w.waferId} waferId={w.waferId} yieldPct={w.yield} pattern={w.pattern} size={72} />)}
                    </div>
                    <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: '6px' }}>{lot.current_step}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'scorecard' && (
            <div>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
                <div style={{ position: 'relative', flex: 1 }}>
                  <Search size={12} style={{ position: 'absolute', left: '8px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                  <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search lot ID or product..." style={{ width: '100%', paddingLeft: '28px', paddingRight: '8px', paddingTop: '6px', paddingBottom: '6px', borderRadius: '6px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '11px', outline: 'none' }} />
                </div>
                <button onClick={() => toast.success('Score card exported')} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 12px', borderRadius: '6px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-secondary)', fontSize: '11px', fontFamily: 'var(--font-mono)', cursor: 'pointer' }}>
                  <Download size={12} /> Export
                </button>
              </div>
              <div className="table-scroll">
                <table className="data-table">
                  <thead>
                    <tr>
                      {[['lot_id', 'LOT ID'], ['product_id', 'Product'], ['tester_id', 'Tester'], ['gross_yield_pct', 'Yield'], ['first_pass_yield', '1st Pass'], ['offline_retest_rate', 'Offline R%'], ['total_die', 'Total Units']].map(([key, label]) => (
                        <th key={key} className="cursor-pointer" onClick={() => { if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc'); else { setSortKey(key); setSortDir('desc') } }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            {label} {sortKey === key && <ArrowUpDown size={10} style={{ color: 'var(--teal)' }} />}
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredScore.map((lot: any) => (
                      <tr key={`${lot.lot_id}_${lot.wafer_id}`} className={selectedLots.has(lot.lot_id) ? 'selected' : ''} onClick={() => setSelectedLots(prev => { const n = new Set(prev); n.has(lot.lot_id) ? n.delete(lot.lot_id) : n.add(lot.lot_id); return n })} style={{ cursor: 'pointer' }}>
                        <td style={{ color: 'var(--teal)', fontWeight: 600 }}>{lot.lot_id}</td>
                        <td style={{ color: 'var(--text-secondary)' }}>{lot.product_id}</td>
                        <td style={{ color: 'var(--text-muted)' }}>{lot.tester_id || '—'}</td>
                        <td className="number">{getYieldBadge(lot.gross_yield_pct ? Number(lot.gross_yield_pct) : null)}</td>
                        <td className="number">{lot.first_pass_yield ? `${Number(lot.first_pass_yield).toFixed(2)}%` : '—'}</td>
                        <td className="number">{lot.offline_retest_rate ? `${Number(lot.offline_retest_rate).toFixed(2)}%` : '—'}</td>
                        <td className="number">{lot.total_die?.toLocaleString() || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'mrb' && (
            <div className="table-scroll">
              <table className="data-table">
                <thead><tr><th>LOT ID</th><th>Product</th><th className="number">Yield</th><th>Decision</th><th>Pattern</th><th>SYL</th><th>SBL</th></tr></thead>
                <tbody>
                  {(scoreCard || []).filter((l: any) => l.syl_flag || l.sbl_flag || l.mrb_required).map((lot: any) => (
                    <tr key={lot.lot_id}>
                      <td style={{ color: 'var(--teal)', fontWeight: 600 }}>{lot.lot_id}</td>
                      <td style={{ color: 'var(--text-secondary)' }}>{lot.product_id}</td>
                      <td className="number">{getYieldBadge(lot.gross_yield_pct ? Number(lot.gross_yield_pct) : null)}</td>
                      <td>
                        <div className={lot.sbl_flag ? 'mrb-bad' : lot.syl_flag ? 'mrb-flag' : 'mrb-good'}>
                          {lot.sbl_flag ? <><XCircle size={12} /> REJECT</> : lot.syl_flag ? <><AlertTriangle size={12} /> REVIEW</> : <><CheckCircle2 size={12} /> PASS</>}
                        </div>
                      </td>
                      <td style={{ color: 'var(--text-muted)' }}>{lot.pattern_class_generic || 'NORMAL'}</td>
                      <td><span style={{ color: lot.syl_flag ? 'var(--fail)' : 'var(--pass)', fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{lot.syl_flag ? '⚠ YES' : 'OK'}</span></td>
                      <td><span style={{ color: lot.sbl_flag ? 'var(--fail)' : 'var(--pass)', fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{lot.sbl_flag ? '⚠ YES' : 'OK'}</span></td>
                    </tr>
                  ))}
                  {!(scoreCard || []).some((l: any) => l.syl_flag || l.sbl_flag || l.mrb_required) && (
                    <tr><td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>No lots requiring MRB review</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
