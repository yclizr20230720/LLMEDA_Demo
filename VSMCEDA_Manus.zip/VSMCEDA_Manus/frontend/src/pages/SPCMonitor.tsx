/**
 * SEMFAB·IQ — SPC Monitor Page
 */
import { useQuery } from '@tanstack/react-query'
import { spcAPI } from '../services/api'
import { useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Brush, BarChart, Bar, Cell } from 'recharts'
import { Activity, Eye, EyeOff, Download } from 'lucide-react'
import toast from 'react-hot-toast'

const PARAMS = ['NMOS_VT','PMOS_VT','GATOX_THK','POLY_CD','CMP_RATE']
const TABS = [{ id: 'analyzer', label: '📈 Data Analyzer' }, { id: 'capability', label: '📊 Cpk Summary' }, { id: 'alarms', label: '🔔 Alarm Viewer' }, { id: 'config', label: '⚙️ DC Config' }]

export default function SPCMonitor() {
  const [activeTab, setActiveTab] = useState('analyzer')
  const [selectedParam, setSelectedParam] = useState('GATOX_THK')
  const [showUCL, setShowUCL] = useState(true)
  const [showVirtual, setShowVirtual] = useState(false)

  const { data: chart } = useQuery({ queryKey: ['spc-chart', selectedParam], queryFn: () => spcAPI.chartData(selectedParam).then(r => r.data) })
  const { data: capability } = useQuery({ queryKey: ['spc-cap'], queryFn: () => spcAPI.capability().then(r => r.data) })
  const { data: alarmSummary } = useQuery({ queryKey: ['spc-alarms'], queryFn: () => spcAPI.alarmSummary().then(r => r.data) })

  const cpkColor = (v: number) => v >= 1.67 ? 'var(--pass)' : v >= 1.33 ? 'var(--warn)' : 'var(--fail)'

  return (
    <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Activity size={20} color="var(--teal)" /> SPC / FDC Process Control
        </h1>
        <select value={selectedParam} onChange={e => setSelectedParam(e.target.value)} style={{ padding: '6px 12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '12px', outline: 'none' }}>
          {PARAMS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ padding: '7px 14px', fontSize: '11px', fontWeight: 500, borderRadius: '6px', cursor: 'pointer', color: activeTab === tab.id ? 'var(--teal)' : 'var(--text-muted)', background: activeTab === tab.id ? 'var(--teal-dim)' : 'var(--bg-surface)', border: `1px solid ${activeTab === tab.id ? 'var(--border-accent)' : 'var(--border)'}`, transition: 'all 0.15s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'analyzer' && chart && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Capability Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
            {[['Cpk', chart.cpk, cpkColor(chart.cpk)], ['Cp', chart.cp, 'var(--text-primary)'], ['Ppk', chart.ppk, 'var(--text-primary)'], ['Violations', chart.violations, chart.violations > 0 ? 'var(--fail)' : 'var(--pass)']].map(([label, val, color]) => (
              <div key={label as string} className="panel" style={{ padding: '12px', textAlign: 'center' }}>
                <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', marginBottom: '4px' }}>{label}</div>
                <div style={{ fontSize: '22px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: color as string }}>{typeof val === 'number' ? val.toFixed(3) : val}</div>
              </div>
            ))}
          </div>
          {/* Xbar Chart */}
          <div className="panel">
            <div className="panel-header">
              <div className="panel-title"><div className="panel-accent" />Xbar Control Chart — {selectedParam}</div>
              <div style={{ display: 'flex', gap: '6px' }}>
                <button onClick={() => setShowUCL(!showUCL)} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '4px', fontSize: '10px', fontFamily: 'var(--font-mono)', cursor: 'pointer', background: showUCL ? 'rgba(255,79,106,0.15)' : 'var(--bg-elevated)', color: showUCL ? 'var(--coral)' : 'var(--text-muted)', border: `1px solid ${showUCL ? 'rgba(255,79,106,0.3)' : 'var(--border)'}` }}>
                  {showUCL ? <Eye size={10} /> : <EyeOff size={10} />} UCL/LCL
                </button>
                <button onClick={() => toast.success('Chart exported')} style={{ width: '24px', height: '24px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', cursor: 'pointer' }}><Download size={12} /></button>
              </div>
            </div>
            <div className="panel-body">
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={chart.points} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="index" tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                  <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                  <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                  <Brush dataKey="index" height={14} stroke="rgba(0,229,196,0.3)" fill="rgba(0,229,196,0.05)" travellerWidth={5} />
                  {showUCL && <ReferenceLine y={chart.ucl} stroke="rgba(255,79,106,0.5)" strokeDasharray="4 4" label={{ value: 'UCL', fill: 'var(--coral)', fontSize: 9, position: 'right' }} />}
                  {showUCL && <ReferenceLine y={chart.lcl} stroke="rgba(255,79,106,0.5)" strokeDasharray="4 4" label={{ value: 'LCL', fill: 'var(--coral)', fontSize: 9, position: 'right' }} />}
                  <ReferenceLine y={chart.cl} stroke="rgba(0,229,196,0.3)" strokeDasharray="2 4" label={{ value: 'CL', fill: 'var(--teal)', fontSize: 9, position: 'right' }} />
                  <Line type="monotone" dataKey="value" stroke="var(--teal)" strokeWidth={1.5}
                    dot={(props: any) => {
                      const { cx, cy, payload } = props
                      if (payload.violation) return <circle key={cx} cx={cx} cy={cy} r={5} fill="var(--fail)" stroke="var(--fail)" style={{ filter: 'drop-shadow(0 0 5px var(--fail))' }} />
                      return <circle key={cx} cx={cx} cy={cy} r={2} fill="var(--teal)" stroke="none" />
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'capability' && capability && (
        <div className="panel">
          <div className="panel-header"><div className="panel-title"><div className="panel-accent amber" />Cpk Summary Table</div></div>
          <div className="table-scroll">
            <table className="data-table">
              <thead><tr><th>Parameter</th><th className="number">Target</th><th className="number">USL</th><th className="number">LSL</th><th className="number">Mean</th><th className="number">Cp</th><th className="number">Cpk</th><th className="number">Ppk</th><th className="number">N</th></tr></thead>
              <tbody>
                {(capability as any[]).map((row: any) => (
                  <tr key={row.parameter_id}>
                    <td style={{ color: 'var(--teal)', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>{row.parameter_id}</td>
                    <td className="number">{Number(row.target || 0).toFixed(4)}</td>
                    <td className="number">{Number(row.usl || 0).toFixed(4)}</td>
                    <td className="number">{Number(row.lsl || 0).toFixed(4)}</td>
                    <td className="number">{Number(row.mean_value || 0).toFixed(4)}</td>
                    <td className="number"><span style={{ color: cpkColor(Number(row.cp)), fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{Number(row.cp || 0).toFixed(3)}</span></td>
                    <td className="number"><span style={{ color: cpkColor(Number(row.cpk)), fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: 700 }}>{Number(row.cpk || 0).toFixed(3)}</span></td>
                    <td className="number"><span style={{ color: cpkColor(Number(row.ppk)), fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{Number(row.ppk || 0).toFixed(3)}</span></td>
                    <td className="number">{row.n_observations || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'alarms' && alarmSummary && (
        <div className="panel">
          <div className="panel-header"><div className="panel-title"><div className="panel-accent coral" />Weekly Alarm Summary by Area</div></div>
          <div className="panel-body">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={alarmSummary.weekly_data} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="week" tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                {(alarmSummary.areas || []).map((area: string, i: number) => {
                  const colors = ['var(--teal)', 'var(--coral)', 'var(--amber)', 'var(--sky)', 'var(--violet)']
                  return <Bar key={area} dataKey={area} stackId="a" fill={colors[i % colors.length]} opacity={0.8} />
                })}
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {activeTab === 'config' && (
        <div className="panel">
          <div className="panel-header"><div className="panel-title"><div className="panel-accent sky" />DC Config — Parameter Spec Templates</div></div>
          <div className="panel-body" style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>
            <p>Configure SPC strategies, control limits, and rule sets for each parameter.</p>
            <p style={{ marginTop: '8px', color: 'var(--text-secondary)' }}>Select a parameter from the dropdown above to view and edit its SPC configuration.</p>
          </div>
        </div>
      )}
    </div>
  )
}
