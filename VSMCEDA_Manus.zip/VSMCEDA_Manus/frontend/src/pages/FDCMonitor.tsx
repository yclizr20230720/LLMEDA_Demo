/**
 * SEMFAB·IQ — FDC Monitor Page
 */
import { useQuery } from '@tanstack/react-query'
import { fdcAPI, equipmentAPI } from '../services/api'
import { useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, AreaChart, Area } from 'recharts'
import { Zap } from 'lucide-react'

const TABS = [{ id: 'feature-spc', label: '📊 Feature SPC' }, { id: 'trace-stack', label: '📡 Trace Stack' }, { id: 'virtual-sensor', label: '🔮 Virtual Sensor' }, { id: 'trace-link', label: '🔗 Trace Link' }]

export default function FDCMonitor() {
  const [activeTab, setActiveTab] = useState('feature-spc')
  const [selectedEquip, setSelectedEquip] = useState('ETCH-01')

  const { data: equipment } = useQuery({ queryKey: ['equipment'], queryFn: () => equipmentAPI.list().then(r => r.data) })
  const { data: anomalyScore } = useQuery({ queryKey: ['anomaly-score', selectedEquip], queryFn: () => fdcAPI.anomalyScore(selectedEquip).then(r => r.data), refetchInterval: 10000 })
  const { data: featureSpc } = useQuery({ queryKey: ['feature-spc', selectedEquip], queryFn: () => fdcAPI.featureSpc(selectedEquip).then(r => r.data) })
  const { data: pmEvents } = useQuery({ queryKey: ['pm-events', selectedEquip], queryFn: () => fdcAPI.pmEvents(selectedEquip).then(r => r.data) })

  const maxScore = Math.max(...((anomalyScore?.data || []).map((d: any) => d.score)))
  const isCritical = maxScore >= 0.95

  return (
    <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Zap size={20} color="var(--teal)" /> FDC — Fault Detection & Classification
          {isCritical && <span className="chip coral" style={{ animation: 'alarmGlow 2s infinite' }}>CRITICAL</span>}
        </h1>
        <select value={selectedEquip} onChange={e => setSelectedEquip(e.target.value)} style={{ padding: '6px 12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '12px', outline: 'none' }}>
          {(equipment || []).map((e: any) => <option key={e.equipment_id} value={e.equipment_id}>{e.equipment_id} — {e.equipment_name}</option>)}
        </select>
      </div>

      {/* Anomaly Score */}
      {anomalyScore && (
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title"><div className="panel-accent coral" />Composite Anomaly Score — {selectedEquip}</div>
            <span className="chip" style={{ color: isCritical ? 'var(--coral)' : 'var(--pass)', background: isCritical ? 'var(--coral-dim)' : 'rgba(16,185,129,0.1)', borderColor: isCritical ? 'rgba(255,79,106,0.3)' : 'rgba(16,185,129,0.2)' }}>
              Max: {maxScore.toFixed(3)}
            </span>
          </div>
          <div className="panel-body">
            <ResponsiveContainer width="100%" height={80}>
              <AreaChart data={anomalyScore.data} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="index" tick={{ fill: 'var(--text-muted)', fontSize: 8, fontFamily: 'var(--font-mono)' }} />
                <YAxis domain={[0, 1]} tick={{ fill: 'var(--text-muted)', fontSize: 8, fontFamily: 'var(--font-mono)' }} />
                <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                <ReferenceLine y={0.95} stroke="rgba(255,79,106,0.6)" strokeDasharray="4 4" label={{ value: 'Critical', fill: 'var(--coral)', fontSize: 9 }} />
                <Area type="monotone" dataKey="score" stroke="var(--teal)" fill="rgba(0,229,196,0.1)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ padding: '7px 14px', fontSize: '11px', fontWeight: 500, borderRadius: '6px', cursor: 'pointer', color: activeTab === tab.id ? 'var(--teal)' : 'var(--text-muted)', background: activeTab === tab.id ? 'var(--teal-dim)' : 'var(--bg-surface)', border: `1px solid ${activeTab === tab.id ? 'var(--border-accent)' : 'var(--border)'}`, transition: 'all 0.15s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'feature-spc' && featureSpc && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {(featureSpc as any[]).map((ind: any) => (
            <div key={ind.indicator_id} className="panel">
              <div className="panel-header">
                <div className="panel-title">
                  <div className={`panel-accent ${ind.priority === 'HIGH' ? 'coral' : ind.priority === 'MEDIUM' ? 'amber' : ''}`} />
                  {ind.indicator_id}
                  <span className={`chip ${ind.priority === 'HIGH' ? 'coral' : ind.priority === 'MEDIUM' ? 'amber' : ''}`} style={{ fontSize: '9px', padding: '1px 6px' }}>{ind.priority}</span>
                  {ind.alarm_count > 0 && <span className="chip coral" style={{ fontSize: '9px', padding: '1px 6px' }}>{ind.alarm_count} alarms</span>}
                </div>
                <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>CL: {ind.cl?.toFixed(2)} | UCL: {ind.ucl?.toFixed(2)} | LCL: {ind.lcl?.toFixed(2)}</div>
              </div>
              <div style={{ padding: '8px 16px' }}>
                <ResponsiveContainer width="100%" height={80}>
                  <LineChart data={ind.points} margin={{ top: 2, right: 2, bottom: 2, left: 0 }}>
                    <XAxis dataKey="index" hide />
                    <YAxis hide />
                    <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '9px', fontFamily: 'var(--font-mono)' }} />
                    <ReferenceLine y={ind.ucl} stroke="rgba(255,79,106,0.4)" strokeDasharray="3 3" />
                    <ReferenceLine y={ind.lcl} stroke="rgba(255,79,106,0.4)" strokeDasharray="3 3" />
                    <ReferenceLine y={ind.cl} stroke="rgba(0,229,196,0.3)" strokeDasharray="2 3" />
                    <Line type="monotone" dataKey="value" stroke="var(--teal)" strokeWidth={1.5}
                      dot={(props: any) => {
                        const { cx, cy, payload } = props
                        if (payload.violation) return <circle key={cx} cx={cx} cy={cy} r={4} fill="var(--fail)" stroke="var(--fail)" />
                        return <circle key={cx} cx={cx} cy={cy} r={1.5} fill="var(--teal)" stroke="none" />
                      }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab !== 'feature-spc' && (
        <div className="panel">
          <div className="panel-body" style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>
            📡 {TABS.find(t => t.id === activeTab)?.label} — Select a run from the equipment list to view trace data.
          </div>
        </div>
      )}

      {/* ML-Based Fab Control */}
      <div className="panel">
        <div className="panel-header"><div className="panel-title"><div className="panel-accent lime" />Fab Control (ML-Based)</div></div>
        <div className="panel-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
          {[
            { label: 'Yield Source Identified', value: 'CMP-03', color: 'var(--coral)', sub: 'Chamber pressure anomaly — edge-ring defect' },
            { label: 'Preventive Alarm', value: 'ACTIVE', color: 'var(--amber)', sub: 'ML model: FDC vs yield correlation 0.94' },
            { label: 'Virtual Metrology', value: '28.3 Å', color: 'var(--teal)', sub: 'Predicted GATOX_THK (±0.4Å CI)' },
            { label: 'R2R Control', value: 'ENABLED', color: 'var(--pass)', sub: 'APC setpoint adjusted -1.8°C on CVD-02' },
          ].map(c => (
            <div key={c.label} style={{ padding: '12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', marginBottom: '4px' }}>{c.label}</div>
              <div style={{ fontSize: '18px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: c.color, marginBottom: '4px' }}>{c.value}</div>
              <div style={{ fontSize: '10px', color: 'var(--text-muted)' }}>{c.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
