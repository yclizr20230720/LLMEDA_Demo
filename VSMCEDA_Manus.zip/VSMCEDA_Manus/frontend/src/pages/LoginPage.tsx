/**
 * SEMFAB·IQ — Login Page
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import { Zap, Eye, EyeOff, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [error, setError] = useState('')
  const { login, isLoading } = useAuthStore()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      await login(username, password)
      toast.success('Welcome to SEMFAB·IQ')
      navigate('/yms')
    } catch (err: any) {
      setError(err.response?.data?.error || 'Login failed. Please check credentials.')
    }
  }

  const demoLogin = async (role: string) => {
    const creds: Record<string, [string, string]> = {
      admin: ['admin', 'Admin@2025'],
      engineer: ['chen_wei', 'Admin@2025'],
      operator: ['fab_op1', 'Admin@2025']
    }
    const [u, p] = creds[role] || creds.engineer
    setUsername(u)
    setPassword(p)
    try {
      await login(u, p)
      toast.success(`Logged in as ${u}`)
      navigate('/yms')
    } catch {
      toast.error('Demo login failed — ensure backend is running')
    }
  }

  return (
    <div className="circuit-bg" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-void)' }}>
      <div className="animate-fade-in-up" style={{ width: '100%', maxWidth: '420px', padding: '0 16px' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{ width: '72px', height: '72px', margin: '0 auto 16px', borderRadius: '16px', background: 'var(--teal-dim)', border: '1px solid var(--border-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', animation: 'pulseTeal 2s infinite' }}>
            <Zap size={36} color="var(--teal)" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 700, background: 'linear-gradient(135deg, var(--teal), var(--violet))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: '4px' }}>
            SEMFAB·IQ
          </h1>
          <p style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>
            SEMICONDUCTOR ENGINEERING DATA ANALYTICS
          </p>
        </div>

        {/* Login Form */}
        <div className="panel" style={{ padding: '28px' }}>
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '6px' }}>
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
                style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '13px', outline: 'none', transition: 'border-color 0.2s' }}
                onFocus={e => e.target.style.borderColor = 'var(--teal)'}
                onBlur={e => e.target.style.borderColor = 'var(--border)'}
              />
            </div>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '6px' }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPwd ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  style={{ width: '100%', padding: '10px 40px 10px 12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '13px', outline: 'none', transition: 'border-color 0.2s' }}
                  onFocus={e => e.target.style.borderColor = 'var(--teal)'}
                  onBlur={e => e.target.style.borderColor = 'var(--border)'}
                />
                <button type="button" onClick={() => setShowPwd(!showPwd)} style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', borderRadius: '8px', background: 'var(--coral-dim)', border: '1px solid rgba(255,79,106,0.3)', color: 'var(--coral)', fontSize: '12px', marginBottom: '16px' }}>
                <AlertCircle size={14} />
                {error}
              </div>
            )}

            <button type="submit" disabled={isLoading} className="btn btn-primary" style={{ width: '100%', padding: '11px', fontSize: '13px', fontWeight: 600 }}>
              {isLoading ? 'Authenticating...' : 'Sign In to SEMFAB·IQ'}
            </button>
          </form>

          {/* Demo Accounts */}
          <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid var(--border)' }}>
            <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '10px', textAlign: 'center' }}>
              Quick Demo Access
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              {[
                { role: 'admin', label: 'Admin', color: 'var(--coral)' },
                { role: 'engineer', label: 'Engineer', color: 'var(--teal)' },
                { role: 'operator', label: 'Operator', color: 'var(--sky)' },
              ].map(d => (
                <button key={d.role} onClick={() => demoLogin(d.role)} style={{ padding: '7px', borderRadius: '6px', background: 'var(--bg-surface)', border: `1px solid ${d.color}30`, color: d.color, fontSize: '11px', fontFamily: 'var(--font-mono)', cursor: 'pointer', transition: 'all 0.15s' }}>
                  {d.label}
                </button>
              ))}
            </div>
            <div style={{ marginTop: '10px', fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textAlign: 'center' }}>
              Default password: Admin@2025
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '20px', textAlign: 'center', fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', display: 'flex', justifyContent: 'center', gap: '16px' }}>
          {['GEM300 · SEMI E10', 'SAS Viya · Greenplum', 'Agentic AI v2.0'].map(t => (
            <span key={t} style={{ padding: '3px 8px', borderRadius: '4px', background: 'var(--teal-dim)', color: 'var(--teal)', border: '1px solid var(--border-accent)' }}>{t}</span>
          ))}
        </div>
      </div>
    </div>
  )
}
