/**
 * SEMFAB·IQ — WAT Analytics Workbench
 * Full interactive parametric analysis with 5 tabs
 */
import { useQuery } from '@tanstack/react-query'
import { watAPI } from '../services/api'
import { useState, useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, ScatterChart, Scatter, LineChart, Line, Cell, Brush } from 'recharts'
import { FlaskConical, Filter, Download, Eye, EyeOff, ArrowLeftRight, ChevronDown, ChevronUp } from 'lucide-react'
import toast from 'react-hot-toast'

const PARAMS = ['NMOS_VT','PMOS_VT','NMOS_IDSAT','GATOX_THK','POLY_CD','CMP_RATE','CONTACT_R','METAL_R']
const TABS = [
  { id: 'distribution', label: '📊 Distribution' },
  { id: 'scatter', label: '🔵 Scatter Plot' },
  { id: 'correlation', label: '🔗 Correlation' },
  { id: 'anova', label: '🧪 Equipment ANOVA' },
  { id: 'trend', label: '📈 Trend' },
]

export default function WATAnalytics() {
  const [activeTab, setActiveTab] = useState('distribution')
  const [selectedParam, setSelectedParam] = useState('NMOS_VT')
  const [xParam, setXParam] = useState('NMOS_VT')
  const [yParam, setYParam] = useState('NMOS_IDSAT')
  const [showSpec, setShowSpec] = useState(true)
  const [showUCL, setShowUCL] = useState(true)
  const [filterOpen, setFilterOpen] = useState(false)

  const { data: dist } = useQuery({ queryKey: ['wat-dist', selectedParam], queryFn: () => watAPI.distribution(selectedParam).then(r => r.data) })
  const { data: anova } = useQuery({ queryKey: ['wat-anova', selectedParam], queryFn: () => watAPI.equipmentAnova(selectedParam).then(r => r.data) })
  const { data: trend } = useQuery({ queryKey: ['wat-trend', selectedParam], queryFn: () => watAPI.trend(selectedParam).then(r => r.data) })
  const { data: corr } = useQuery({ queryKey: ['wat-corr'], queryFn: () => watAPI.correlationMatrix().then(r => r.data) })
  const { data: siteMap } = useQuery({ queryKey: ['wat-site', selectedParam], queryFn: () => watAPI.siteMap(selectedParam).then(r => r.data) })

  const cpkColor = dist?.cpk >= 1.67 ? 'var(--pass)' : dist?.cpk >= 1.33 ? 'var(--warn)' : 'var(--fail)'

  return (
    <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FlaskConical size={20} color="var(--teal)" /> WAT Analytics Workbench
          </h1>
          <p style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>Interactive Parametric Analysis · SAS Viya Powered</p>
        </div>
        <select value={selectedParam} onChange={e => setSelectedParam(e.target.value)} style={{ padding: '6px 12px', borderRadius: '8px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '12px', outline: 'none' }}>
          {PARAMS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {/* Filter Panel */}
      <div className="panel" style={{ overflow: 'hidden' }}>
        <div className="panel-header" style={{ cursor: 'pointer' }} onClick={() => setFilterOpen(!filterOpen)}>
          <div className="panel-title"><Filter size={14} color="var(--teal)" /> Filter & Context</div>
          {filterOpen ? <ChevronUp size={14} color="var(--text-muted)" /> : <ChevronDown size={14} color="var(--text-muted)" />}
        </div>
        {filterOpen && (
          <div className="panel-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
            {[['Lot ID', ['ALL', 'M900001', 'M900002', 'M900003']], ['Equipment', ['ALL', 'CVD-01', 'CVD-02', 'ETCH-01']], ['Process Node', ['ALL', 'N5', 'N3', '16nm', '28nm']], ['Wafer Range', ['ALL', 'W01-W05', 'W06-W10', 'W11-W15']]].map(([label, opts]) => (
              <div key={label as string}>
                <label style={{ display: 'block', fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '4px' }}>{label}</label>
                <select style={{ width: '100%', padding: '5px 8px', borderRadius: '6px', background: 'var(--bg-surface)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)', fontSize: '10px', outline: 'none' }}>
                  {(opts as string[]).map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px', borderBottom: '1px solid var(--border)', paddingBottom: '0' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ padding: '8px 14px', fontSize: '11px', fontWeight: 500, borderRadius: '6px 6px 0 0', cursor: 'pointer', color: activeTab === tab.id ? 'var(--teal)' : 'var(--text-muted)', background: activeTab === tab.id ? 'var(--teal-dim)' : 'transparent', border: `1px solid ${activeTab === tab.id ? 'var(--border-accent)' : 'transparent'}`, borderBottom: 'none', transition: 'all 0.15s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'distribution' && dist && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '8px' }}>
            {[['Mean', dist.mean?.toFixed(4), 'var(--text-primary)'], ['Sigma', dist.sigma?.toFixed(4), 'var(--text-primary)'], ['Cpk', dist.cpk?.toFixed(2), cpkColor], ['Cp', dist.cp?.toFixed(2), 'var(--text-primary)'], ['N', dist.n, 'var(--text-primary)'], ['Unit', dist.unit, 'var(--text-muted)']].map(([label, val, color]) => (
              <div key={label as string} className="panel" style={{ padding: '10px', textAlign: 'center' }}>
                <div style={{ fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase', marginBottom: '4px' }}>{label}</div>
                <div style={{ fontSize: '16px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: color as string }}>{val}</div>
              </div>
            ))}
          </div>
          {/* Histogram */}
          <div className="panel">
            <div className="panel-header">
              <div className="panel-title"><div className="panel-accent" />Distribution — {selectedParam}</div>
              <div style={{ display: 'flex', gap: '6px' }}>
                <button onClick={() => setShowSpec(!showSpec)} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '4px', fontSize: '10px', fontFamily: 'var(--font-mono)', cursor: 'pointer', background: showSpec ? 'rgba(255,79,106,0.15)' : 'var(--bg-elevated)', color: showSpec ? 'var(--coral)' : 'var(--text-muted)', border: `1px solid ${showSpec ? 'rgba(255,79,106,0.3)' : 'var(--border)'}` }}>
                  {showSpec ? <Eye size={10} /> : <EyeOff size={10} />} Spec
                </button>
                <button onClick={() => toast.success('Distribution exported')} style={{ width: '24px', height: '24px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', cursor: 'pointer' }}><Download size={12} /></button>
              </div>
            </div>
            <div className="panel-body">
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={dist.histogram} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="x" tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} tickFormatter={v => Number(v).toFixed(3)} />
                  <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                  <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                  <Brush dataKey="x" height={14} stroke="rgba(0,229,196,0.3)" fill="rgba(0,229,196,0.05)" travellerWidth={5} />
                  {showSpec && <ReferenceLine x={dist.spec_high} stroke="rgba(255,79,106,0.6)" strokeDasharray="4 4" label={{ value: 'USL', fill: 'var(--coral)', fontSize: 9 }} />}
                  {showSpec && <ReferenceLine x={dist.spec_low} stroke="rgba(255,79,106,0.6)" strokeDasharray="4 4" label={{ value: 'LSL', fill: 'var(--coral)', fontSize: 9 }} />}
                  <ReferenceLine x={dist.mean} stroke="rgba(0,229,196,0.4)" strokeDasharray="2 4" label={{ value: 'μ', fill: 'var(--teal)', fontSize: 9 }} />
                  <Bar dataKey="count" fill="var(--teal)" opacity={0.7} radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
              <div style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginTop: '8px' }}>💡 Drag the brush to zoom · Click bars for details</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'anova' && anova && (
        <div className="panel">
          <div className="panel-header"><div className="panel-title"><div className="panel-accent violet" />Equipment Factor Analysis (ANOVA / η²)</div></div>
          <div className="panel-body" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {(anova as any[]).map((eq: any) => {
              const isFlagged = eq.eta_squared >= 0.15
              const color = isFlagged ? (eq.eta_squared > 0.25 ? 'var(--fail)' : 'var(--warn)') : 'var(--pass)'
              const pct = (eq.eta_squared / Math.max(...(anova as any[]).map((d: any) => d.eta_squared))) * 100
              return (
                <div key={eq.equipment_id} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '8px', borderRadius: '6px', background: 'var(--bg-surface)', border: '1px solid var(--border)' }}>
                  <div style={{ width: '80px', fontSize: '10px', fontFamily: 'var(--font-mono)', color, flexShrink: 0 }}>{eq.equipment_id} {isFlagged && '⚠'}</div>
                  <div style={{ flex: 1, height: '16px', borderRadius: '4px', overflow: 'hidden', background: 'var(--bg-elevated)' }}>
                    <div style={{ height: '100%', borderRadius: '4px', width: `${pct}%`, background: `${color}30`, border: `1px solid ${color}40`, display: 'flex', alignItems: 'center', paddingLeft: '4px' }}>
                      <span style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', color }}>{(eq.eta_squared * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                  <div style={{ width: '60px', textAlign: 'right', fontSize: '9px', fontFamily: 'var(--font-mono)', color }}>η²={eq.eta_squared?.toFixed(3)}</div>
                  <div style={{ width: '40px', textAlign: 'right', fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>n={eq.group_n || eq.n_wafers}</div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {activeTab === 'trend' && trend && (
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title"><div className="panel-accent" />Parameter Trend — {selectedParam}</div>
            <div style={{ display: 'flex', gap: '6px' }}>
              <button onClick={() => setShowUCL(!showUCL)} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '4px', fontSize: '10px', fontFamily: 'var(--font-mono)', cursor: 'pointer', background: showUCL ? 'rgba(255,79,106,0.15)' : 'var(--bg-elevated)', color: showUCL ? 'var(--coral)' : 'var(--text-muted)', border: `1px solid ${showUCL ? 'rgba(255,79,106,0.3)' : 'var(--border)'}` }}>
                {showUCL ? <Eye size={10} /> : <EyeOff size={10} />} UCL/LCL
              </button>
            </div>
          </div>
          <div className="panel-body">
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={trend.points} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="index" tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)' }} />
                <Tooltip contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-accent)', borderRadius: '8px', fontSize: '10px', fontFamily: 'var(--font-mono)' }} />
                <Brush dataKey="index" height={14} stroke="rgba(0,229,196,0.3)" fill="rgba(0,229,196,0.05)" travellerWidth={5} />
                {showUCL && <ReferenceLine y={trend.ucl} stroke="rgba(255,79,106,0.5)" strokeDasharray="4 4" label={{ value: 'UCL', fill: 'var(--coral)', fontSize: 9, position: 'right' }} />}
                {showUCL && <ReferenceLine y={trend.lcl} stroke="rgba(255,79,106,0.5)" strokeDasharray="4 4" label={{ value: 'LCL', fill: 'var(--coral)', fontSize: 9, position: 'right' }} />}
                <ReferenceLine y={trend.cl} stroke="rgba(0,229,196,0.3)" strokeDasharray="2 4" label={{ value: 'CL', fill: 'var(--teal)', fontSize: 9, position: 'right' }} />
                <Line type="monotone" dataKey="value" stroke="var(--teal)" strokeWidth={1.5}
                  dot={(props: any) => {
                    const { cx, cy, payload } = props
                    if (payload.violation) return <circle key={cx} cx={cx} cy={cy} r={4} fill="var(--fail)" stroke="var(--fail)" style={{ filter: 'drop-shadow(0 0 4px var(--fail))' }} />
                    return <circle key={cx} cx={cx} cy={cy} r={2} fill="var(--teal)" stroke="none" />
                  }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {activeTab === 'correlation' && corr && (
        <div className="panel">
          <div className="panel-header"><div className="panel-title"><div className="panel-accent" />Parameter Correlation Matrix (Pearson r)</div></div>
          <div className="panel-body" style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th style={{ width: '80px' }} />
                  {corr.params.map((p: string) => <th key={p} style={{ textAlign: 'center', minWidth: '64px' }}>{p.split('_')[0]}</th>)}
                </tr>
              </thead>
              <tbody>
                {corr.params.map((p1: string, i: number) => (
                  <tr key={p1}>
                    <td style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', fontSize: '10px' }}>{p1}</td>
                    {corr.matrix[i].map((v: number, j: number) => {
                      const abs = Math.abs(v)
                      const c = abs >= 0.7 ? 'var(--teal)' : abs >= 0.4 ? 'var(--sky)' : abs >= 0.2 ? 'var(--text-muted)' : 'var(--text-muted)'
                      const bg = abs >= 0.7 ? 'rgba(0,229,196,0.15)' : abs >= 0.4 ? 'rgba(56,189,248,0.1)' : 'transparent'
                      return (
                        <td key={j} style={{ textAlign: 'center', padding: '4px' }}>
                          <div style={{ padding: '4px 6px', borderRadius: '4px', background: bg, color: c, fontFamily: 'var(--font-mono)', fontSize: '10px', fontWeight: abs >= 0.5 ? 600 : 400 }}>
                            {v.toFixed(2)}
                          </div>
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'scatter' && (
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title"><div className="panel-accent" />Scatter Plot — {xParam} vs {yParam}</div>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <select value={xParam} onChange={e => setXParam(e.target.value)} style={{ padding: '4px 8px', borderRadius: '6px', background: 'rgba(0,229,196,0.05)', border: '1px solid var(--border-accent)', color: 'var(--teal)', fontFamily: 'var(--font-mono)', fontSize: '10px', outline: 'none' }}>
                {PARAMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
              <button onClick={() => { setXParam(yParam); setYParam(xParam) }} style={{ width: '24px', height: '24px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)', color: 'var(--violet)', cursor: 'pointer' }}>
                <ArrowLeftRight size={12} />
              </button>
              <select value={yParam} onChange={e => setYParam(e.target.value)} style={{ padding: '4px 8px', borderRadius: '6px', background: 'rgba(255,107,53,0.05)', border: '1px solid rgba(255,107,53,0.2)', color: '#FF6B35', fontFamily: 'var(--font-mono)', fontSize: '10px', outline: 'none' }}>
                {PARAMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div className="panel-body">
            <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-muted)', fontSize: '12px', fontFamily: 'var(--font-mono)' }}>
              📊 Scatter plot data loading... Select X/Y parameters above to visualize correlation.
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
