/**
 * SEMFAB·IQ — Main Application Router
 */
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from 'react-hot-toast'
import { useEffect } from 'react'
import { useAuthStore } from './store/authStore'

// Layout
import Layout from './components/layout/Layout'

// Pages
import LoginPage from './pages/LoginPage'
import YMSDashboard from './pages/YMSDashboard'
import WATAnalytics from './pages/WATAnalytics'
import SPCMonitor from './pages/SPCMonitor'
import FDCMonitor from './pages/FDCMonitor'
import DefectAnalysis from './pages/DefectAnalysis'
import EquipmentFleet from './pages/EquipmentFleet'
import AgentChat from './pages/AgentChat'
import FabControl from './pages/FabControl'
import AdvancedAnalytics from './pages/AdvancedAnalytics'
import GuidedAnalytics from './pages/GuidedAnalytics'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30000,
      refetchOnWindowFocus: false
    }
  }
})

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore()
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

function App() {
  const { fetchMe, isAuthenticated } = useAuthStore()

  useEffect(() => {
    if (localStorage.getItem('access_token')) {
      fetchMe()
    }
  }, [])

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: 'var(--bg-elevated)',
              color: 'var(--text-primary)',
              border: '1px solid var(--border-accent)',
              fontFamily: 'var(--font-mono)',
              fontSize: '12px'
            }
          }}
        />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route index element={<Navigate to="/yms" replace />} />
            <Route path="yms" element={<YMSDashboard />} />
            <Route path="wat" element={<WATAnalytics />} />
            <Route path="spc" element={<SPCMonitor />} />
            <Route path="fdc" element={<FDCMonitor />} />
            <Route path="defect" element={<DefectAnalysis />} />
            <Route path="equipment" element={<EquipmentFleet />} />
            <Route path="agent" element={<AgentChat />} />
            <Route path="fab-control" element={<FabControl />} />
            <Route path="advanced" element={<AdvancedAnalytics />} />
            <Route path="guided" element={<GuidedAnalytics />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}

export default App
