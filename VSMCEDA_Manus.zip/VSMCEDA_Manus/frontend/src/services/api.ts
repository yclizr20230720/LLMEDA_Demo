/**
 * SEMFAB·IQ API Service Layer
 * Axios-based HTTP client with JWT interceptors
 */
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: `${BASE_URL}/api`,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

// Request interceptor — attach JWT token
apiClient.interceptors.request.use(config => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Response interceptor — handle 401
apiClient.interceptors.response.use(
  res => res,
  async err => {
    if (err.response?.status === 401) {
      const refreshToken = localStorage.getItem('refresh_token')
      if (refreshToken) {
        try {
          const res = await axios.post(`${BASE_URL}/api/auth/refresh`, {}, {
            headers: { Authorization: `Bearer ${refreshToken}` }
          })
          localStorage.setItem('access_token', res.data.access_token)
          err.config.headers.Authorization = `Bearer ${res.data.access_token}`
          return apiClient(err.config)
        } catch {
          localStorage.removeItem('access_token')
          localStorage.removeItem('refresh_token')
          window.location.href = '/login'
        }
      }
    }
    return Promise.reject(err)
  }
)

// ── Auth ──────────────────────────────────────────────────
export const authAPI = {
  login: (username: string, password: string) =>
    apiClient.post('/auth/login', { username, password }),
  me: () => apiClient.get('/auth/me'),
  logout: () => apiClient.post('/auth/logout'),
  refresh: () => apiClient.post('/auth/refresh'),
}

// ── Dashboard ─────────────────────────────────────────────
export const dashboardAPI = {
  kpis: () => apiClient.get('/dashboard/kpis'),
  yieldTrend: (days = 30, productId?: string) =>
    apiClient.get('/dashboard/yield-trend', { params: { days, product_id: productId } }),
  alarms: (limit = 20, severity?: string) =>
    apiClient.get('/dashboard/alarms', { params: { limit, severity } }),
  ackAlarm: (id: number) => apiClient.post(`/dashboard/alarms/${id}/ack`),
  waferGallery: () => apiClient.get('/dashboard/wafer-gallery'),
  scoreCard: (productId?: string, limit = 20) =>
    apiClient.get('/dashboard/score-card', { params: { product_id: productId, limit } }),
}

// ── Lots ──────────────────────────────────────────────────
export const lotsAPI = {
  list: (params?: Record<string, string | number>) => apiClient.get('/lots/', { params }),
  detail: (lotId: string) => apiClient.get(`/lots/${lotId}`),
  hold: (lotId: string, data: object) => apiClient.post(`/lots/${lotId}/hold`, data),
  release: (lotId: string) => apiClient.post(`/lots/${lotId}/release`),
}

// ── Equipment ─────────────────────────────────────────────
export const equipmentAPI = {
  list: () => apiClient.get('/equipment/'),
  detail: (id: string) => apiClient.get(`/equipment/${id}`),
}

// ── WAT ───────────────────────────────────────────────────
export const watAPI = {
  parameters: () => apiClient.get('/wat/parameters'),
  distribution: (parameterId: string, params?: object) =>
    apiClient.get('/wat/distribution', { params: { parameterId, ...params } }),
  correlationMatrix: (paramIds?: string[]) =>
    apiClient.get('/wat/correlation-matrix', { params: paramIds ? { params: paramIds } : {} }),
  equipmentAnova: (parameterId: string) =>
    apiClient.get('/wat/equipment-anova', { params: { parameterId } }),
  trend: (parameterId: string, params?: object) =>
    apiClient.get('/wat/trend', { params: { parameterId, ...params } }),
  siteMap: (parameterId: string) =>
    apiClient.get('/wat/site-map', { params: { parameterId } }),
  psaSummary: (yParam: string) =>
    apiClient.get('/wat/psa-summary', { params: { y_param: yParam } }),
}

// ── SPC ───────────────────────────────────────────────────
export const spcAPI = {
  configs: () => apiClient.get('/spc/configs'),
  chartData: (parameterId: string, params?: object) =>
    apiClient.get('/spc/chart-data', { params: { parameterId, ...params } }),
  capability: () => apiClient.get('/spc/capability'),
  alarmSummary: () => apiClient.get('/spc/alarm-summary'),
  violations: (limit = 20) => apiClient.get('/spc/violations', { params: { limit } }),
}

// ── FDC ───────────────────────────────────────────────────
export const fdcAPI = {
  runs: (equipmentId: string, limit = 20) =>
    apiClient.get(`/fdc/equipment/${equipmentId}/runs`, { params: { limit } }),
  trace: (runId: string, sensors?: string[]) =>
    apiClient.get(`/fdc/runs/${runId}/trace`, { params: sensors ? { sensors } : {} }),
  anomalyScore: (equipmentId: string) =>
    apiClient.get(`/fdc/equipment/${equipmentId}/anomaly-score`),
  featureSpc: (equipmentId: string) =>
    apiClient.get(`/fdc/equipment/${equipmentId}/feature-spc`),
  pmEvents: (equipmentId: string) =>
    apiClient.get(`/fdc/equipment/${equipmentId}/pm-events`),
}

// ── Defect ────────────────────────────────────────────────
export const defectAPI = {
  pareto: (limit = 20) => apiClient.get('/defect/pareto', { params: { limit } }),
  waferMap: (lotId: string, waferId: string, pattern?: string) =>
    apiClient.get('/defect/wafer-map', { params: { lot_id: lotId, wafer_id: waferId, pattern } }),
  adcGallery: () => apiClient.get('/defect/adc-gallery'),
  wpaPatterns: () => apiClient.get('/defect/wpa-patterns'),
}

// ── Agent ─────────────────────────────────────────────────
export const agentAPI = {
  chat: (message: string, messages: object[]) =>
    `${BASE_URL}/api/agent/chat`,  // SSE endpoint URL
  actions: (status = 'PENDING') => apiClient.get('/agent/actions', { params: { status } }),
  approveAction: (id: string) => apiClient.post(`/agent/actions/${id}/approve`),
  rejectAction: (id: string) => apiClient.post(`/agent/actions/${id}/reject`),
  rcaKnowledge: () => apiClient.get('/agent/rca-knowledge'),
}

// ── Advanced ──────────────────────────────────────────────
export const advancedAPI = {
  mscRR: (studyId?: string) => apiClient.get('/advanced/msc-rr', { params: { study_id: studyId } }),
  dppm: (productId?: string) => apiClient.get('/advanced/dppm', { params: { product_id: productId } }),
  processTimeline: (equipmentType?: string) =>
    apiClient.get('/advanced/process-timeline', { params: { equipment_type: equipmentType } }),
  smartSampling: (productId?: string) =>
    apiClient.get('/advanced/smart-sampling', { params: { product_id: productId } }),
  anomalyTraces: (equipmentId?: string, sensor?: string) =>
    apiClient.get('/advanced/anomaly-traces', { params: { equipment_id: equipmentId, sensor } }),
}

export default apiClient
