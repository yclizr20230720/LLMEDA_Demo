## Reality check

Your spec describes a multi-million-dollar enterprise platform: Greenplum MPP warehouse, Oracle 19c RAC, SAS Viya CAS, Neo4j, Redis Cluster, Python microservices, 60+ tables, 624 functions across a pnpm monorepo. **Lovable cannot deliver that** — Lovable builds a React/TanStack Start frontend with an optional Lovable Cloud (Postgres) backend running on Cloudflare Workers. There is no Greenplum, no Oracle, no SAS, no Neo4j, no Python services here.

What Lovable *can* deliver, and what will look and feel like the real system, is a **complete frontend implementation of all 13 UI modules** driven by realistic mock data shaped after your schema. That's the plan below.

## Scope

A single TanStack Start app implementing all 13 modules from the function list, styled with the dark teal/violet design system from `SEMFAB_IQ_Visual_Analytics_Platform.html`. Data layer is a typed mock-data service shaped after the DataMart schema (MES, WAT, CP, SPC, FDC, APC, MTR, DEF, YLD, REL, MSC, AGT) so it can be swapped to a real backend later.

No Lovable Cloud in this pass — adding Postgres for mock data would slow things down and the schema is too large to model meaningfully without a real ETL source. We can wire selected tables to Cloud later, module by module.

## Modules implemented

1. **YMS Dashboard** — KPI strip (FAB Yield %, Active Alarms, Lots In Process, OEE), 30-day yield trend with UCL/LCL/CL, live alarm feed, active-lot wafer gallery (canvas wafer maps).
2. **Guided Analytics (GA-MA)** — 6-step wizard: yield impact ranking → parameter drill → equipment commonality → SPC/FDC overlay → RCA hypothesis → action.
3. **SPC Workbench** — parameter tree, X-bar/R + I-MR charts, Western Electric rule violations, Cpk panel, capability heatmap.
4. **FDC Trace Viewer** — recipe/step picker, multi-trace overlay, indicator table, PM event markers.
5. **WAT Analyzer** — site map, parameter trends, lot/wafer scatter, ANOVA-by-equipment, correlation matrix.
6. **CP Analyzer** — wafer bin map, bin Pareto, parametric distributions, touchdown stats, stacked wafer overlay.
7. **Defect Review** — wafer defect map, defect Pareto, classifier confusion view, signature gallery.
8. **APC Console** — model list, R2R control action timeline, setpoint vs measured, model health.
9. **Metrology** — measurement trend, gauge R&R summary, tool-to-tool matching.
10. **Reliability (WLR/DPPM)** — WLR result tables, DPPM model viewer, lifetime projection chart.
11. **Equipment Health** — tool list with OEE/MTBF/MTTR, status timeline, PM schedule, live status board.
12. **Lot Genealogy** — lot search, route history, split-lot tree, queue/cycle-time breakdown.
13. **Agent Console (AGT)** — agent session list, robot action log, RCA knowledge browser, ask-the-agent panel (chat UI, static responses for now).

Plus a persistent shell: top nav, left module rail, global lot/date/product filter bar, command palette (⌘K), notification drawer.

## Design

Adopt the uploaded HTML's tokens directly into `src/styles.css`:
- bg ramp `#060A12 → #1E2840`, teal `#00E5C4`, violet `#8B5CF6`, amber `#F59E0B`, coral `#FF4F6A`
- Space Grotesk (display), Inter (body), JetBrains Mono (numeric/code) via `<link>` in `__root.tsx`
- Glass surfaces, 1px hairline borders, teal accent glow on active states
- Pass/Fail/Warn semantic colors for wafer bins and SPC violations

## Technical architecture

```
src/
  routes/
    __root.tsx                  // shell: top nav, command palette, providers
    index.tsx                   // YMS dashboard
    guided.tsx                  // GA-MA wizard
    spc.tsx, spc.$param.tsx
    fdc.tsx
    wat.tsx
    cp.tsx
    defect.tsx
    apc.tsx
    metrology.tsx
    reliability.tsx
    equipment.tsx, equipment.$toolId.tsx
    lots.tsx, lots.$lotId.tsx
    agent.tsx
  components/
    shell/         TopNav, ModuleRail, GlobalFilters, CommandPalette
    charts/        YieldTrend, SpcChart, TraceChart, ParetoBar, ScatterMatrix, AnovaBox, CorrelationHeatmap
    wafer/         WaferMap (canvas), WaferGallery, BinLegend
    kpi/           KpiCard, DeltaBadge, Sparkline
    tables/        DataTable (sortable, virtualized)
    common/        StatusDot, SeverityBadge, GlassCard, SectionHeader
  data/
    schema.ts             // TS types matching DataMart tables
    mock/
      lots.ts, wat.ts, cp.ts, spc.ts, fdc.ts, alarms.ts, equipment.ts, defect.ts, apc.ts, mtr.ts, yld.ts, rel.ts, agt.ts
      generators.ts       // seeded RNG, time-series, wafer-map generation
    queries.ts            // TanStack Query options keyed by domain
  lib/
    spc.ts                // Western Electric rules, Cpk calc
    stats.ts              // mean/std/quantiles, simple ANOVA, Pearson
    format.ts             // numeric, percent, duration formatters
```

Charts use **Recharts** (already in shadcn chart). Wafer maps use **HTML Canvas** with bitmap-blit (per spec). State + caching via **TanStack Query** with mock async fetchers (200–400ms simulated latency, so loading states are real).

## What "workable" means in this delivery

- Every route renders, every module is navigable.
- Every chart, table, KPI, and wafer map renders real numbers from the mock layer with believable distributions (lot IDs follow `M9xxxxx`, wafers 1–25, bins 1/2/3, Cpk 0.8–1.6, yield 88–98%).
- SPC rule detection, Cpk, ANOVA, Pareto, correlation actually compute from the mock data — not hardcoded.
- Filters, sorting, drill-downs work across the session.
- Refresh intervals (30s KPIs, 15s alarms) tick against the mock layer.
- Design matches the uploaded HTML closely.

## What is explicitly NOT in this delivery

- No real Greenplum/Oracle/SAS/Neo4j/Redis connections.
- No Python services, tRPC, or Node backend.
- No authentication, RBAC, or multi-tenant.
- No real ML models — RCA suggestions and yield predictions are pre-scripted plausible outputs.
- No real-time WebSocket — polling against mock data.
- Reliability projections, agent chat responses, and APC model health are deterministic mock outputs, not computed.

Any of these can be added later, one module at a time, by swapping a `data/*` file for a Lovable Cloud query or external API call.

## Build order (single pass)

1. Design tokens, fonts, shell (top nav + module rail + global filters).
2. Mock data generators + schema types + TanStack Query wiring.
3. Shared chart/table/wafer/KPI components.
4. Module 1 YMS → 2 GA-MA → 3 SPC → 4 FDC → 5 WAT → 6 CP → 7 Defect → 8 APC → 9 MTR → 10 REL → 11 EQP → 12 Lots → 13 AGT.
5. Command palette, notification drawer, polish pass.

This is a large build — expect several hundred files. After approval I'll execute it in one go.