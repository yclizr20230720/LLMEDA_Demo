export function mean(xs: number[]): number {
  if (!xs.length) return 0;
  let s = 0;
  for (const x of xs) s += x;
  return s / xs.length;
}

export function stddev(xs: number[]): number {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  let s = 0;
  for (const x of xs) s += (x - m) ** 2;
  return Math.sqrt(s / (xs.length - 1));
}

export function quantile(xs: number[], q: number): number {
  if (!xs.length) return 0;
  const sorted = [...xs].sort((a, b) => a - b);
  const idx = q * (sorted.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sorted[lo]!;
  return sorted[lo]! + (sorted[hi]! - sorted[lo]!) * (idx - lo);
}

export function cpk(xs: number[], lsl: number, usl: number): number {
  const m = mean(xs);
  const s = stddev(xs);
  if (s === 0) return 0;
  return Math.min((usl - m) / (3 * s), (m - lsl) / (3 * s));
}

export function cp(xs: number[], lsl: number, usl: number): number {
  const s = stddev(xs);
  if (s === 0) return 0;
  return (usl - lsl) / (6 * s);
}

export function pearson(xs: number[], ys: number[]): number {
  const n = Math.min(xs.length, ys.length);
  if (n < 2) return 0;
  const mx = mean(xs.slice(0, n));
  const my = mean(ys.slice(0, n));
  let num = 0, dx = 0, dy = 0;
  for (let i = 0; i < n; i++) {
    const a = xs[i]! - mx;
    const b = ys[i]! - my;
    num += a * b;
    dx += a * a;
    dy += b * b;
  }
  if (dx === 0 || dy === 0) return 0;
  return num / Math.sqrt(dx * dy);
}

// One-way ANOVA F-statistic across groups
export function anovaF(groups: number[][]): { F: number; dfB: number; dfW: number; pseudoP: number } {
  const k = groups.length;
  const all = groups.flat();
  const N = all.length;
  if (k < 2 || N < k + 1) return { F: 0, dfB: 0, dfW: 0, pseudoP: 1 };
  const grand = mean(all);
  let ssb = 0, ssw = 0;
  for (const g of groups) {
    const m = mean(g);
    ssb += g.length * (m - grand) ** 2;
    for (const x of g) ssw += (x - m) ** 2;
  }
  const dfB = k - 1;
  const dfW = N - k;
  const msB = ssb / dfB;
  const msW = ssw / dfW || 1e-9;
  const F = msB / msW;
  // crude pseudo-p (not statistically rigorous; for visual coloring)
  const pseudoP = Math.exp(-F / 3);
  return { F, dfB, dfW, pseudoP: Math.min(1, pseudoP) };
}
