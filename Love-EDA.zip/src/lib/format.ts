// Deterministic UTC formatters to avoid SSR/client hydration mismatch.
export const fmtPct = (v: number, d = 2) => `${v.toFixed(d)}%`;
export const fmtNum = (v: number, d = 2) => v.toFixed(d);
export const fmtInt = (v: number) => Math.round(v).toString();
export const fmtDelta = (v: number, d = 2) => `${v >= 0 ? "+" : ""}${v.toFixed(d)}`;
export const fmtDur = (ms: number) => {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
};
const pad = (n: number) => String(n).padStart(2, "0");
export const fmtDate = (d: Date | string | number) => {
  const dt = new Date(d);
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
};
export const fmtTime = (d: Date | string | number) => {
  const dt = new Date(d);
  return `${pad(dt.getUTCHours())}:${pad(dt.getUTCMinutes())}:${pad(dt.getUTCSeconds())}`;
};
export const fmtDateTime = (d: Date | string | number) => `${fmtDate(d)} ${fmtTime(d)}`;
