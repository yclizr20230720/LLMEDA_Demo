import { mean, stddev } from "./stats";

export type SpcViolation = { index: number; rule: string; severity: "minor" | "major" | "critical" };

// Western Electric Rules — simplified set
export function westernElectric(values: number[], cl: number, ucl: number, lcl: number): SpcViolation[] {
  const out: SpcViolation[] = [];
  const sigma = (ucl - cl) / 3;
  const z1u = cl + sigma, z1l = cl - sigma;
  const z2u = cl + 2 * sigma, z2l = cl - 2 * sigma;

  for (let i = 0; i < values.length; i++) {
    const v = values[i]!;
    // Rule 1: 1 point beyond 3σ
    if (v > ucl || v < lcl) out.push({ index: i, rule: "WE-1: Point beyond 3σ", severity: "critical" });
    // Rule 2: 9 points same side of CL
    if (i >= 8) {
      const slice = values.slice(i - 8, i + 1);
      if (slice.every((x) => x > cl)) out.push({ index: i, rule: "WE-2: 9 pts above CL", severity: "major" });
      else if (slice.every((x) => x < cl)) out.push({ index: i, rule: "WE-2: 9 pts below CL", severity: "major" });
    }
    // Rule 3: 6 points trending
    if (i >= 5) {
      const slice = values.slice(i - 5, i + 1);
      let inc = true, dec = true;
      for (let j = 1; j < slice.length; j++) {
        if (slice[j]! <= slice[j - 1]!) inc = false;
        if (slice[j]! >= slice[j - 1]!) dec = false;
      }
      if (inc) out.push({ index: i, rule: "WE-3: 6 pts trending up", severity: "minor" });
      if (dec) out.push({ index: i, rule: "WE-3: 6 pts trending down", severity: "minor" });
    }
    // Rule 4: 2 of 3 beyond 2σ same side
    if (i >= 2) {
      const slice = values.slice(i - 2, i + 1);
      const above = slice.filter((x) => x > z2u).length;
      const below = slice.filter((x) => x < z2l).length;
      if (above >= 2) out.push({ index: i, rule: "WE-4: 2/3 beyond 2σ (high)", severity: "major" });
      if (below >= 2) out.push({ index: i, rule: "WE-4: 2/3 beyond 2σ (low)", severity: "major" });
    }
    // Rule 5: 4 of 5 beyond 1σ same side
    if (i >= 4) {
      const slice = values.slice(i - 4, i + 1);
      const above = slice.filter((x) => x > z1u).length;
      const below = slice.filter((x) => x < z1l).length;
      if (above >= 4) out.push({ index: i, rule: "WE-5: 4/5 beyond 1σ (high)", severity: "minor" });
      if (below >= 4) out.push({ index: i, rule: "WE-5: 4/5 beyond 1σ (low)", severity: "minor" });
    }
  }
  return out;
}

export function controlLimits(values: number[]): { cl: number; ucl: number; lcl: number; sigma: number } {
  const cl = mean(values);
  const sigma = stddev(values);
  return { cl, ucl: cl + 3 * sigma, lcl: cl - 3 * sigma, sigma };
}
