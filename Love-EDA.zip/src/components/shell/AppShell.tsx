import { Link, useRouterState } from "@tanstack/react-router";
import {
  Activity, Workflow, LineChart, Waves, Microscope, CircuitBoard,
  Bug, Sliders, Ruler, ShieldCheck, Cpu, Boxes, Bot, Search,
} from "lucide-react";
import { cn } from "@/lib/utils";

const MODULES = [
  { to: "/", label: "YMS Dashboard", icon: Activity, code: "YMS" },
  { to: "/guided", label: "Guided Analytics", icon: Workflow, code: "GA-MA" },
  { to: "/spc", label: "SPC Workbench", icon: LineChart, code: "SPC" },
  { to: "/fdc", label: "FDC Trace Viewer", icon: Waves, code: "FDC" },
  { to: "/wat", label: "WAT Analyzer", icon: Microscope, code: "WAT" },
  { to: "/cp", label: "CP Analyzer", icon: CircuitBoard, code: "CP" },
  { to: "/defect", label: "Defect Review", icon: Bug, code: "DEF" },
  { to: "/apc", label: "APC Console", icon: Sliders, code: "APC" },
  { to: "/metrology", label: "Metrology", icon: Ruler, code: "MTR" },
  { to: "/reliability", label: "Reliability", icon: ShieldCheck, code: "REL" },
  { to: "/equipment", label: "Equipment Health", icon: Cpu, code: "EQP" },
  { to: "/lots", label: "Lot Genealogy", icon: Boxes, code: "LOT" },
  { to: "/agent", label: "Agent Console", icon: Bot, code: "AGT" },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const current = MODULES.find((m) => (m.to === "/" ? pathname === "/" : pathname.startsWith(m.to)));

  return (
    <div className="flex min-h-screen bg-bg-void text-text-primary">
      {/* Rail */}
      <aside className="w-[208px] shrink-0 border-r border-border bg-bg-base flex flex-col">
        <Link to="/" className="h-14 flex items-center px-5 border-b border-border">
          <div className="font-display font-bold text-lg text-gradient tracking-tight">SEMFAB·IQ</div>
        </Link>
        <nav className="flex-1 overflow-y-auto py-3">
          {MODULES.map((m) => {
            const active = m === current;
            const Icon = m.icon;
            return (
              <Link
                key={m.to}
                to={m.to}
                className={cn(
                  "flex items-center gap-3 px-4 py-2 mx-2 my-0.5 rounded-md text-sm transition-all",
                  "hover:bg-bg-elevated/60",
                  active && "bg-bg-elevated text-teal shadow-[inset_2px_0_0_0_var(--teal)]"
                )}
              >
                <Icon className={cn("h-4 w-4", active ? "text-teal" : "text-text-muted")} />
                <span className="flex-1">{m.label}</span>
                <span className="mono text-[10px] text-text-muted">{m.code}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border text-[11px] text-text-muted">
          <div className="mono">v4.0 · DEMO · MOCK DATA</div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border bg-bg-base/80 backdrop-blur sticky top-0 z-40 flex items-center px-6 gap-4">
          <div className="text-sm">
            <span className="text-text-muted">Module:</span>{" "}
            <span className="font-display font-semibold">{current?.label ?? "—"}</span>
          </div>
          <div className="flex-1" />
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md bg-bg-surface border border-border text-xs text-text-secondary w-72">
            <Search className="h-3.5 w-3.5" />
            <span>Search lot, eqp, param…</span>
            <span className="ml-auto mono text-[10px] text-text-muted">⌘K</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="h-2 w-2 rounded-full bg-pass animate-pulse" />
            <span className="text-text-secondary">Live · FAB-A</span>
          </div>
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-teal to-violet flex items-center justify-center text-[11px] font-bold text-bg-void">
            EN
          </div>
        </header>
        <main className="flex-1 p-6 overflow-x-hidden">{children}</main>
      </div>
    </div>
  );
}
