import { useEffect, useRef } from "react";
import type { Wafer } from "@/data/schema";
import { cn } from "@/lib/utils";

const BIN_COLOR: Record<number, string> = {
  1: "#00E5C4", 2: "#EF4444", 3: "#F59E0B", 4: "#FF4F6A", 5: "#8B5CF6", 6: "#38BDF8",
};

export function WaferMap({ wafer, size = 120, showLabel = true, className }: { wafer: Wafer; size?: number; showLabel?: boolean; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr; canvas.height = size * dpr;
    const ctx = canvas.getContext("2d")!;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, size, size);
    // background wafer disc
    ctx.fillStyle = "#0F1626";
    ctx.beginPath(); ctx.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.1)"; ctx.lineWidth = 1; ctx.stroke();
    // flat
    ctx.fillStyle = "#060A12";
    ctx.fillRect(size / 2 - size * 0.18, size - 4, size * 0.36, 4);

    const radius = 12; // matches generator
    const cell = (size - 8) / (radius * 2 + 1);
    for (const d of wafer.dies) {
      ctx.fillStyle = BIN_COLOR[d.bin] ?? "#475569";
      const px = size / 2 + d.x * cell - cell / 2;
      const py = size / 2 + d.y * cell - cell / 2;
      ctx.fillRect(px, py, cell - 0.5, cell - 0.5);
    }
  }, [wafer, size]);

  return (
    <div className={cn("inline-flex flex-col items-center gap-1", className)}>
      <canvas ref={ref} style={{ width: size, height: size }} />
      {showLabel && (
        <div className="text-[10px] mono text-text-secondary">
          W{String(wafer.wafer_no).padStart(2, "0")} · <span className="text-teal">{wafer.bin_yield}%</span>
        </div>
      )}
    </div>
  );
}

export function BinLegend() {
  const items = [
    [1, "Pass"], [2, "Open"], [3, "Marginal"], [4, "Short"], [5, "Param"], [6, "Other"],
  ] as const;
  return (
    <div className="flex flex-wrap gap-3 text-[10px] mono">
      {items.map(([b, l]) => (
        <span key={b} className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: BIN_COLOR[b as number] }} />
          <span className="text-text-secondary">B{b} {l}</span>
        </span>
      ))}
    </div>
  );
}
