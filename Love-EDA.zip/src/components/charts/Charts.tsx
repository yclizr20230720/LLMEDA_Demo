import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, ReferenceLine, CartesianGrid, AreaChart, Area, BarChart, Bar, ScatterChart, Scatter, Cell } from "recharts";

const TOOLTIP_STYLE = {
  contentStyle: { background: "#192035", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 },
  labelStyle: { color: "#94A3B8" },
  itemStyle: { color: "#E2E8F0" },
};

export function YieldTrendChart({ data }: { data: { date: string; yield_pct: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <defs>
          <linearGradient id="ygrad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#00E5C4" stopOpacity={0.4} />
            <stop offset="100%" stopColor="#00E5C4" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" />
        <XAxis dataKey="date" stroke="#475569" fontSize={10} tickFormatter={(d) => d.slice(5)} />
        <YAxis stroke="#475569" fontSize={10} domain={[85, 100]} />
        <Tooltip {...TOOLTIP_STYLE} />
        <ReferenceLine y={97.5} stroke="#10B981" strokeDasharray="3 3" label={{ value: "UCL", fontSize: 9, fill: "#10B981" }} />
        <ReferenceLine y={94.2} stroke="#00E5C4" strokeDasharray="2 2" label={{ value: "CL", fontSize: 9, fill: "#00E5C4" }} />
        <ReferenceLine y={90.0} stroke="#EF4444" strokeDasharray="3 3" label={{ value: "LCL", fontSize: 9, fill: "#EF4444" }} />
        <Area type="monotone" dataKey="yield_pct" stroke="#00E5C4" strokeWidth={2} fill="url(#ygrad)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function SpcChart({
  data, cl, ucl, lcl, target, violationIdx = [], height = 260,
}: {
  data: { ts: string; value: number }[];
  cl: number; ucl: number; lcl: number; target?: number;
  violationIdx?: number[];
  height?: number;
}) {
  const violationSet = new Set(violationIdx);
  const enriched = data.map((d, i) => ({ ...d, idx: i, violation: violationSet.has(i) ? d.value : null }));
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={enriched} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" />
        <XAxis dataKey="idx" stroke="#475569" fontSize={10} />
        <YAxis stroke="#475569" fontSize={10} domain={["auto", "auto"]} />
        <Tooltip {...TOOLTIP_STYLE} />
        <ReferenceLine y={ucl} stroke="#EF4444" strokeDasharray="3 3" label={{ value: `UCL ${ucl.toFixed(2)}`, fontSize: 9, fill: "#EF4444" }} />
        <ReferenceLine y={cl} stroke="#00E5C4" strokeDasharray="2 2" label={{ value: `CL ${cl.toFixed(2)}`, fontSize: 9, fill: "#00E5C4" }} />
        <ReferenceLine y={lcl} stroke="#EF4444" strokeDasharray="3 3" label={{ value: `LCL ${lcl.toFixed(2)}`, fontSize: 9, fill: "#EF4444" }} />
        {target !== undefined && <ReferenceLine y={target} stroke="#8B5CF6" strokeDasharray="1 3" />}
        <Line type="monotone" dataKey="value" stroke="#00E5C4" strokeWidth={1.5} dot={{ r: 2, fill: "#00E5C4" }} />
        <Line type="monotone" dataKey="violation" stroke="none" dot={{ r: 5, fill: "#EF4444", stroke: "#fff", strokeWidth: 1 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function TraceChart({ data, keys, height = 240 }: { data: any[]; keys: { key: string; color: string; name?: string }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" />
        <XAxis dataKey="t" stroke="#475569" fontSize={10} />
        <YAxis stroke="#475569" fontSize={10} />
        <Tooltip {...TOOLTIP_STYLE} />
        {keys.map((k) => (
          <Line key={k.key} type="monotone" dataKey={k.key} stroke={k.color} strokeWidth={1.5} dot={false} name={k.name ?? k.key} />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}

export function ParetoBar({ data, color = "#00E5C4", height = 240 }: { data: { label: string; value: number }[]; color?: string; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 30 }}>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" />
        <XAxis dataKey="label" stroke="#475569" fontSize={10} angle={-25} textAnchor="end" height={50} />
        <YAxis stroke="#475569" fontSize={10} />
        <Tooltip {...TOOLTIP_STYLE} />
        <Bar dataKey="value" fill={color} radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ScatterXY({ data, xKey = "x", yKey = "y", height = 260, color = "#00E5C4" }: { data: any[]; xKey?: string; yKey?: string; height?: number; color?: string }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ScatterChart margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid stroke="rgba(255,255,255,0.05)" />
        <XAxis type="number" dataKey={xKey} stroke="#475569" fontSize={10} />
        <YAxis type="number" dataKey={yKey} stroke="#475569" fontSize={10} />
        <Tooltip {...TOOLTIP_STYLE} />
        <Scatter data={data} fill={color}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.color ?? color} />
          ))}
        </Scatter>
      </ScatterChart>
    </ResponsiveContainer>
  );
}

export function CorrelationHeatmap({ matrix, labels, size = 24 }: { matrix: number[][]; labels: string[]; size?: number }) {
  return (
    <div className="overflow-auto">
      <div className="inline-block">
        <div className="flex">
          <div style={{ width: 90 }} />
          {labels.map((l) => (
            <div key={l} style={{ width: size }} className="text-[9px] mono text-text-muted -rotate-45 origin-bottom-left whitespace-nowrap pl-2">{l}</div>
          ))}
        </div>
        {matrix.map((row, i) => (
          <div key={i} className="flex items-center">
            <div style={{ width: 90 }} className="text-[10px] mono text-text-secondary text-right pr-2 truncate">{labels[i]}</div>
            {row.map((v, j) => {
              const abs = Math.abs(v);
              const hue = v >= 0 ? 175 : 0;
              return (
                <div
                  key={j}
                  title={`${labels[i]} ↔ ${labels[j]}: ${v.toFixed(2)}`}
                  style={{
                    width: size, height: size,
                    background: `hsla(${hue}, 80%, 50%, ${abs * 0.85 + 0.05})`,
                  }}
                  className="border border-bg-base text-[8px] mono text-text-primary flex items-center justify-center"
                >{v.toFixed(1)}</div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
