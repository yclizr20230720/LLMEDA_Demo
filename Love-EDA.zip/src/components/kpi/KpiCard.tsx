import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

export function KpiCard({
  label, value, unit, delta, deltaSuffix = "", tone = "teal", footnote,
}: {
  label: string;
  value: string | number;
  unit?: string;
  delta?: number;
  deltaSuffix?: string;
  tone?: "teal" | "violet" | "amber" | "coral";
  footnote?: string;
}) {
  const accent: Record<string, string> = {
    teal: "from-teal/20", violet: "from-violet/20", amber: "from-amber/20", coral: "from-coral/20",
  };
  const accentRing: Record<string, string> = {
    teal: "text-teal", violet: "text-violet", amber: "text-amber", coral: "text-coral",
  };
  return (
    <div className={cn("glass rounded-lg p-4 relative overflow-hidden bg-gradient-to-br to-transparent", accent[tone])}>
      <div className="text-[11px] uppercase tracking-widest text-text-muted mb-2">{label}</div>
      <div className="flex items-baseline gap-2">
        <div className={cn("font-display text-3xl font-bold mono", accentRing[tone])}>{value}</div>
        {unit && <div className="text-xs text-text-muted">{unit}</div>}
      </div>
      <div className="flex items-center justify-between mt-2 text-[11px]">
        {delta !== undefined ? (
          <span className={cn("flex items-center gap-1 mono", delta >= 0 ? "text-pass" : "text-fail")}>
            {delta >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {delta >= 0 ? "+" : ""}{delta.toFixed(2)}{deltaSuffix}
          </span>
        ) : <span />}
        {footnote && <span className="text-text-muted">{footnote}</span>}
      </div>
    </div>
  );
}
