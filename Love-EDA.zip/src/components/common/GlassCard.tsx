import { cn } from "@/lib/utils";

export function GlassCard({
  className, children, title, subtitle, action,
}: {
  className?: string;
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className={cn("glass rounded-lg p-4", className)}>
      {(title || action) && (
        <div className="flex items-center justify-between mb-3">
          <div>
            {title && <div className="font-display font-semibold text-sm">{title}</div>}
            {subtitle && <div className="text-xs text-text-muted mt-0.5">{subtitle}</div>}
          </div>
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

export function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-end justify-between mb-4">
      <div>
        <h1 className="font-display text-xl font-semibold tracking-tight">{title}</h1>
        {subtitle && <p className="text-xs text-text-secondary mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatusDot({ status }: { status: "RUN" | "IDLE" | "DOWN" | "PM" | "QUAL" | "OPEN" | "ACK" | "CLOSED" | string }) {
  const color: Record<string, string> = {
    RUN: "bg-pass", IDLE: "bg-neutral", DOWN: "bg-fail", PM: "bg-amber", QUAL: "bg-sky",
    OPEN: "bg-fail", ACK: "bg-amber", CLOSED: "bg-neutral",
  };
  return <span className={cn("inline-block h-2 w-2 rounded-full", color[status] ?? "bg-neutral")} />;
}

export function SeverityBadge({ severity }: { severity: "CRITICAL" | "MAJOR" | "MINOR" | string }) {
  const styles: Record<string, string> = {
    CRITICAL: "bg-fail/15 text-fail border-fail/30",
    MAJOR: "bg-amber/15 text-amber border-amber/30",
    MINOR: "bg-sky/15 text-sky border-sky/30",
  };
  return (
    <span className={cn("mono text-[10px] px-1.5 py-0.5 rounded border uppercase tracking-wider", styles[severity] ?? "bg-bg-elevated text-text-muted border-border")}>
      {severity}
    </span>
  );
}

export function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "teal" | "violet" | "amber" | "coral" | "neutral" | "pass" | "fail" }) {
  const t: Record<string, string> = {
    teal: "bg-teal/15 text-teal border-teal/30",
    violet: "bg-violet/15 text-violet border-violet/30",
    amber: "bg-amber/15 text-amber border-amber/30",
    coral: "bg-coral/15 text-coral border-coral/30",
    pass: "bg-pass/15 text-pass border-pass/30",
    fail: "bg-fail/15 text-fail border-fail/30",
    neutral: "bg-bg-elevated text-text-secondary border-border",
  };
  return <span className={cn("mono text-[10px] px-1.5 py-0.5 rounded border uppercase tracking-wide", t[tone])}>{children}</span>;
}
