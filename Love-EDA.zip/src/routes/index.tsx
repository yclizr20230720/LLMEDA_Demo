import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { kpiQuery, yieldTrendQuery, alarmsQuery, activeWafersQuery } from "@/data/queries";
import { KpiCard } from "@/components/kpi/KpiCard";
import { GlassCard, SectionHeader, SeverityBadge, StatusDot, Pill } from "@/components/common/GlassCard";
import { YieldTrendChart } from "@/components/charts/Charts";
import { WaferMap, BinLegend } from "@/components/wafer/WaferMap";
import { fmtTime } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "YMS Dashboard — SEMFAB·IQ" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(kpiQuery());
    context.queryClient.ensureQueryData(yieldTrendQuery());
    context.queryClient.ensureQueryData(alarmsQuery());
    context.queryClient.ensureQueryData(activeWafersQuery());
  },
  component: YmsDashboard,
});

function YmsDashboard() {
  const { data: kpi } = useSuspenseQuery(kpiQuery());
  const { data: yieldData } = useSuspenseQuery(yieldTrendQuery());
  const { data: alarms } = useSuspenseQuery(alarmsQuery());
  const { data: waferGroups } = useSuspenseQuery(activeWafersQuery());
  const openAlarms = alarms.filter((a) => a.status === "OPEN").slice(0, 12);

  return (
    <div className="space-y-6">
      <SectionHeader title="Yield Management — Fab Overview" subtitle="Real-time fab health · refreshes every 30s" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard label="FAB Yield" value={kpi.fab_yield} unit="%" delta={kpi.yield_delta} deltaSuffix="%" tone="teal" footnote="7-day baseline" />
        <KpiCard label="Active Alarms" value={kpi.active_alarms} delta={-kpi.critical_alarms} deltaSuffix=" crit" tone={kpi.critical_alarms > 0 ? "coral" : "amber"} footnote={`${kpi.critical_alarms} critical`} />
        <KpiCard label="Lots In Process" value={kpi.lots_in_process} tone="violet" footnote="WIP snapshot" />
        <KpiCard label="Avg Equipment OEE" value={kpi.avg_oee} unit="%" tone="amber" footnote="all tools" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <GlassCard className="lg:col-span-2" title="30-Day Yield Trend" subtitle="UCL 97.5% · CL 94.2% · LCL 90.0%">
          <YieldTrendChart data={yieldData} />
        </GlassCard>
        <GlassCard title="Live Alarm Feed" subtitle={`${openAlarms.length} open · refreshes every 15s`}>
          <div className="space-y-2 max-h-[260px] overflow-y-auto">
            {openAlarms.map((a) => (
              <div key={a.alarm_id} className="flex items-center gap-2 p-2 rounded bg-bg-surface/60 border border-border/50">
                <StatusDot status={a.status} />
                <SeverityBadge severity={a.severity} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs truncate">{a.message}</div>
                  <div className="text-[10px] mono text-text-muted">
                    {a.eqp_id} {a.lot_id ? `· ${a.lot_id}` : ""} · {fmtTime(a.ts)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      <GlassCard title="Active Lot Wafer Gallery" subtitle="8 lots × 6 wafers · canvas bitmap-blit" action={<BinLegend />}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {waferGroups.map(({ lot, wafers }) => (
            <div key={lot.lot_id} className="rounded-md bg-bg-surface/50 border border-border p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="mono text-xs font-semibold">{lot.lot_id}</div>
                {lot.is_hot && <Pill tone="coral">HOT</Pill>}
              </div>
              <div className="text-[10px] mono text-text-muted mb-2">
                {lot.product_id} · {lot.tech_node} · {lot.current_step}
              </div>
              <div className="grid grid-cols-3 gap-1">
                {wafers.map((w) => <WaferMap key={w.wafer_no} wafer={w} size={70} />)}
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
