import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { spcParametersQuery, equipmentQuery, fdcTracesQuery, spcSeriesQuery, rcaQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { SpcChart, TraceChart, ParetoBar } from "@/components/charts/Charts";
import { controlLimits, westernElectric } from "@/lib/spc";
import { ChevronRight, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/guided")({
  head: () => ({ meta: [{ title: "Guided Analytics — SEMFAB·IQ" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(spcParametersQuery());
    context.queryClient.ensureQueryData(equipmentQuery());
    context.queryClient.ensureQueryData(fdcTracesQuery());
    context.queryClient.ensureQueryData(rcaQuery());
  },
  component: Guided,
});

const STEPS = [
  "Yield Impact Ranking",
  "Parameter Drill-Down",
  "Equipment Commonality",
  "SPC / FDC Overlay",
  "RCA Hypothesis",
  "Recommended Action",
];

function Guided() {
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const { data: params } = useSuspenseQuery(spcParametersQuery());
  const { data: eqp } = useSuspenseQuery(equipmentQuery());
  const { data: fdc } = useSuspenseQuery(fdcTracesQuery());
  const { data: rca } = useSuspenseQuery(rcaQuery());
  const selectedParam = picked ?? params[0]!.param_id;
  const { data: series } = useSuspenseQuery(spcSeriesQuery(selectedParam));

  const ranked = params
    .map((p) => ({ ...p, impact: +(100 * (1 - Math.min(1, p.cpk / 1.67))).toFixed(2) }))
    .sort((a, b) => b.impact - a.impact);

  return (
    <div className="space-y-6">
      <SectionHeader title="Guided Analytics (GA-MA)" subtitle="Six-step structured root-cause investigation workflow" />

      <div className="flex items-center gap-1 overflow-x-auto pb-2">
        {STEPS.map((label, i) => (
          <button
            key={label}
            onClick={() => setStep(i)}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-md text-xs whitespace-nowrap border transition-all",
              i === step ? "bg-teal/15 text-teal border-teal/30"
                : i < step ? "bg-bg-elevated text-text-secondary border-border"
                : "text-text-muted border-border/50"
            )}
          >
            <span className="mono text-[10px]">{String(i + 1).padStart(2, "0")}</span>
            <span>{label}</span>
            {i < STEPS.length - 1 && <ChevronRight className="h-3 w-3 opacity-50" />}
          </button>
        ))}
      </div>

      {step === 0 && (
        <GlassCard title="Step 1 — Parameters Ranked by Yield Impact" subtitle="Click any row to drill down">
          <div className="space-y-1">
            {ranked.map((p) => (
              <button key={p.param_id} onClick={() => { setPicked(p.param_id); setStep(1); }}
                className="w-full flex items-center gap-3 p-3 rounded-md bg-bg-surface/50 hover:bg-bg-elevated/60 border border-border/50 text-left transition-all">
                <Pill tone={p.impact > 40 ? "coral" : p.impact > 20 ? "amber" : "teal"}>
                  {p.impact > 40 ? "Critical" : p.impact > 20 ? "Major" : "Minor"}
                </Pill>
                <div className="flex-1">
                  <div className="text-sm font-medium">{p.name}</div>
                  <div className="text-[10px] mono text-text-muted">{p.step} · {p.eqp_type}</div>
                </div>
                <div className="mono text-xs text-text-secondary">Cpk {p.cpk}</div>
                <div className="mono text-sm text-coral w-16 text-right">-{p.impact}%</div>
                <ChevronRight className="h-4 w-4 text-text-muted" />
              </button>
            ))}
          </div>
        </GlassCard>
      )}

      {step === 1 && (() => {
        const cl = controlLimits(series.map((s) => s.value));
        const vios = westernElectric(series.map((s) => s.value), cl.cl, cl.ucl, cl.lcl);
        const p = params.find((x) => x.param_id === selectedParam)!;
        return (
          <GlassCard title={`Step 2 — ${p.name} (${p.unit})`} subtitle={`Spec ${p.lsl}–${p.usl} · Target ${p.target}`}>
            <SpcChart data={series} cl={cl.cl} ucl={cl.ucl} lcl={cl.lcl} target={p.target} violationIdx={vios.map((v) => v.index)} />
            <div className="mt-3 text-xs text-text-secondary">
              {vios.length} Western Electric rule violations · {vios.filter((v) => v.severity === "critical").length} critical
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setStep(0)} className="px-3 py-1.5 text-xs rounded border border-border">Back</button>
              <button onClick={() => setStep(2)} className="px-3 py-1.5 text-xs rounded bg-teal/20 text-teal border border-teal/40">Next: Equipment Commonality</button>
            </div>
          </GlassCard>
        );
      })()}

      {step === 2 && (
        <GlassCard title="Step 3 — Equipment Commonality" subtitle="Tools most associated with parameter excursion">
          <ParetoBar
            data={eqp.filter((e) => e.type === (params.find((x) => x.param_id === selectedParam)?.eqp_type ?? "ETCH"))
              .slice(0, 8).map((e) => ({ label: e.eqp_id, value: +(100 - e.oee * 100).toFixed(1) }))}
            color="#FF4F6A"
          />
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => setStep(1)} className="px-3 py-1.5 text-xs rounded border border-border">Back</button>
            <button onClick={() => setStep(3)} className="px-3 py-1.5 text-xs rounded bg-teal/20 text-teal border border-teal/40">Next: Trace Overlay</button>
          </div>
        </GlassCard>
      )}

      {step === 3 && (
        <GlassCard title="Step 4 — SPC × FDC Overlay" subtitle="Process trace correlated with parameter excursion">
          <TraceChart
            data={fdc[0]!.trace}
            keys={[
              { key: "rf_power", color: "#00E5C4", name: "RF Power (W)" },
              { key: "pressure", color: "#8B5CF6", name: "Pressure (mTorr)" },
              { key: "temp", color: "#F59E0B", name: "Temp (°C)" },
            ]}
          />
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => setStep(2)} className="px-3 py-1.5 text-xs rounded border border-border">Back</button>
            <button onClick={() => setStep(4)} className="px-3 py-1.5 text-xs rounded bg-teal/20 text-teal border border-teal/40">Next: RCA Hypothesis</button>
          </div>
        </GlassCard>
      )}

      {step === 4 && (
        <GlassCard title="Step 5 — RCA Hypotheses (knowledge graph)" subtitle="Top matches from RCA knowledge base">
          <div className="space-y-2">
            {rca.slice(0, 4).map((r) => (
              <div key={r.rca_id} className="p-3 rounded-md bg-bg-surface/50 border border-border/50">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm font-medium">{r.symptom}</div>
                  <Pill tone={r.confidence > 0.85 ? "teal" : "amber"}>conf {(r.confidence * 100).toFixed(0)}%</Pill>
                </div>
                <div className="text-xs text-text-secondary">→ {r.root_cause}</div>
                <div className="text-[11px] text-text-muted mt-1">Historical cases: {r.cases}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => setStep(3)} className="px-3 py-1.5 text-xs rounded border border-border">Back</button>
            <button onClick={() => setStep(5)} className="px-3 py-1.5 text-xs rounded bg-teal/20 text-teal border border-teal/40">Next: Action</button>
          </div>
        </GlassCard>
      )}

      {step === 5 && (
        <GlassCard title="Step 6 — Recommended Action" subtitle="Highest-confidence fix">
          <div className="p-4 rounded-md bg-teal/10 border border-teal/30">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-teal mt-0.5" />
              <div>
                <div className="font-display font-semibold text-teal">{rca[0]!.fix}</div>
                <div className="text-xs text-text-secondary mt-1">Apply hold on affected lots, schedule re-qual after fix verification.</div>
              </div>
            </div>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => { setStep(0); setPicked(null); }} className="px-3 py-1.5 text-xs rounded border border-border">New Investigation</button>
            <button className="px-3 py-1.5 text-xs rounded bg-teal text-bg-void font-medium">Create Work Order</button>
          </div>
        </GlassCard>
      )}
    </div>
  );
}
