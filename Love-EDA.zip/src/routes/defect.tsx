import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { defectsQuery, lotsQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { ParetoBar, ScatterXY } from "@/components/charts/Charts";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/defect")({
  head: () => ({ meta: [{ title: "Defect Review — SEMFAB·IQ" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(lotsQuery());
    context.queryClient.ensureQueryData(defectsQuery());
  },
  component: Defect,
});

function Defect() {
  const { data: lots } = useSuspenseQuery(lotsQuery());
  const candidates = lots.slice(0, 12);
  const [lotId, setLotId] = useState(candidates[0]!.lot_id);
  const { data: defects } = useSuspenseQuery(defectsQuery(lotId));

  const byClass = useMemo(() => {
    const m = new Map<string, number>();
    for (const d of defects) m.set(d.class, (m.get(d.class) ?? 0) + 1);
    return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([label, value]) => ({ label, value }));
  }, [defects]);

  const wafer = useMemo(() => defects.map((d) => ({
    x: d.x, y: d.y, color: classColor(d.class),
  })), [defects]);

  return (
    <div className="space-y-6">
      <SectionHeader title="Defect Review" subtitle="Defect Pareto · wafer signature map · classifier review" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <GlassCard title="Lots" className="lg:col-span-1">
          <div className="space-y-1 max-h-[480px] overflow-y-auto">
            {candidates.map((l) => (
              <button key={l.lot_id} onClick={() => setLotId(l.lot_id)}
                className={cn("w-full text-left px-3 py-2 rounded text-xs border transition",
                  lotId === l.lot_id ? "bg-teal/15 border-teal/40" : "border-border/50 hover:bg-bg-elevated/40")}>
                <div className="mono font-medium">{l.lot_id}</div>
                <div className="text-[10px] text-text-muted">{l.product_id}</div>
              </button>
            ))}
          </div>
        </GlassCard>
        <div className="lg:col-span-3 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassCard title="Defect Pareto" subtitle={`${defects.length} defects total`}>
              <ParetoBar data={byClass} color="#FF4F6A" />
            </GlassCard>
            <GlassCard title="Wafer Signature">
              <ScatterXY data={wafer} height={260} />
            </GlassCard>
          </div>
          <GlassCard title="Defect List">
            <DataTable
              rows={defects.slice(0, 60)}
              rowKey={(d) => d.defect_id}
              dense
              columns={[
                { key: "id", header: "Defect", accessor: (d) => <span className="mono text-[10px]">{d.defect_id}</span> },
                { key: "wf", header: "Wafer", accessor: (d) => <span className="mono">W{d.wafer_no}</span>, sortValue: (d) => d.wafer_no },
                { key: "xy", header: "Position", accessor: (d) => <span className="mono">({d.x}, {d.y})</span> },
                { key: "size", header: "Size µm", accessor: (d) => <span className="mono">{d.size_um}</span>, align: "right", sortValue: (d) => d.size_um },
                { key: "cls", header: "Class", accessor: (d) => <Pill tone="violet">{d.class}</Pill>, sortValue: (d) => d.class },
                { key: "src", header: "Source", accessor: (d) => <span className="mono">{d.source_eqp}</span> },
                { key: "ts", header: "Time", accessor: (d) => <span className="mono text-[10px]">{fmtDateTime(d.ts)}</span> },
              ]}
            />
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

function classColor(c: string) {
  const map: Record<string, string> = {
    Particle: "#00E5C4", Scratch: "#FF4F6A", Residue: "#F59E0B", Void: "#8B5CF6",
    Bridge: "#38BDF8", Open: "#EF4444", Stain: "#84CC16", Pattern: "#E2E8F0",
  };
  return map[c] ?? "#94A3B8";
}
