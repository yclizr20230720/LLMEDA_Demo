import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { watResultsQuery, equipmentQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { ScatterXY, CorrelationHeatmap, ParetoBar } from "@/components/charts/Charts";
import { mean, stddev, pearson, anovaF } from "@/lib/stats";
import { DataTable } from "@/components/tables/DataTable";

export const Route = createFileRoute("/wat")({
  head: () => ({ meta: [{ title: "WAT Analyzer — SEMFAB·IQ" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(watResultsQuery());
    context.queryClient.ensureQueryData(equipmentQuery());
  },
  component: Wat,
});

function Wat() {
  const { data: wat } = useSuspenseQuery(watResultsQuery());
  const { data: eqp } = useSuspenseQuery(equipmentQuery());

  const paramNames = useMemo(() => Array.from(new Set(wat.map((r) => r.param))), [wat]);

  // by lot summary
  const lots = useMemo(() => {
    const m = new Map<string, { lot_id: string; n: number; pass: number; mean_vt: number; sd_vt: number }>();
    for (const r of wat) {
      const o = m.get(r.lot_id) ?? { lot_id: r.lot_id, n: 0, pass: 0, mean_vt: 0, sd_vt: 0 };
      o.n++;
      if (r.pass) o.pass++;
      m.set(r.lot_id, o);
    }
    const out = [...m.values()];
    for (const o of out) {
      const vt = wat.filter((r) => r.lot_id === o.lot_id && r.param === "Vt N-MOS").map((r) => r.value);
      o.mean_vt = +mean(vt).toFixed(4);
      o.sd_vt = +stddev(vt).toFixed(4);
    }
    return out;
  }, [wat]);

  // correlation matrix
  const corrMatrix = useMemo(() => {
    const byParam = paramNames.map((p) => wat.filter((r) => r.param === p).map((r) => r.value));
    return byParam.map((xs, i) => byParam.map((ys, j) => i === j ? 1 : +pearson(xs.slice(0, 80), ys.slice(0, 80)).toFixed(2)));
  }, [paramNames, wat]);

  // scatter Vt vs Idsat
  const scatter = useMemo(() => {
    const vt = wat.filter((r) => r.param === "Vt N-MOS");
    return vt.map((r) => {
      const id = wat.find((x) => x.param === "Idsat N-MOS" && x.lot_id === r.lot_id && x.wafer_no === r.wafer_no && x.site === r.site);
      return id ? { x: r.value, y: id.value, color: r.pass && id.pass ? "#00E5C4" : "#FF4F6A" } : null;
    }).filter(Boolean).slice(0, 200) as any[];
  }, [wat]);

  // ANOVA by equipment for Vt N-MOS — synthesise equipment grouping by lot
  const anova = useMemo(() => {
    const lotEqp = new Map<string, string>();
    wat.forEach((r) => { if (!lotEqp.has(r.lot_id)) lotEqp.set(r.lot_id, eqp[(r.lot_id.charCodeAt(3) + r.lot_id.charCodeAt(5)) % eqp.length]!.eqp_id); });
    const groups = new Map<string, number[]>();
    for (const r of wat.filter((x) => x.param === "Vt N-MOS")) {
      const e = lotEqp.get(r.lot_id)!;
      const a = groups.get(e) ?? [];
      a.push(r.value); groups.set(e, a);
    }
    const arr = [...groups.entries()].slice(0, 8);
    const f = anovaF(arr.map((g) => g[1]));
    return { groups: arr, f };
  }, [wat, eqp]);

  return (
    <div className="space-y-6">
      <SectionHeader title="WAT Analyzer" subtitle="Wafer Acceptance Test parametric analysis · ANOVA · correlation" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassCard title="Vt N-MOS vs Idsat N-MOS" subtitle="Per-site scatter · red = spec fail">
          <ScatterXY data={scatter} />
        </GlassCard>
        <GlassCard title="ANOVA by Equipment — Vt N-MOS" subtitle={`F = ${anova.f.F.toFixed(2)} · df ${anova.f.dfB}/${anova.f.dfW} · pseudo-p ${anova.f.pseudoP.toFixed(3)}`}>
          <ParetoBar
            data={anova.groups.map(([e, vs]) => ({ label: e, value: +mean(vs).toFixed(3) }))}
            color="#8B5CF6"
          />
        </GlassCard>
      </div>

      <GlassCard title="Parameter Correlation Matrix" subtitle="Pearson r across WAT parameters">
        <CorrelationHeatmap matrix={corrMatrix} labels={paramNames} size={36} />
      </GlassCard>

      <GlassCard title="Lot Summary">
        <DataTable
          rows={lots}
          rowKey={(l) => l.lot_id}
          columns={[
            { key: "lot", header: "Lot", accessor: (l) => <span className="mono">{l.lot_id}</span> },
            { key: "n", header: "Sites", accessor: (l) => l.n, align: "right", sortValue: (l) => l.n },
            { key: "pass", header: "Pass", accessor: (l) => <Pill tone={l.pass / l.n > 0.95 ? "teal" : "amber"}>{((l.pass / l.n) * 100).toFixed(1)}%</Pill>, sortValue: (l) => l.pass / l.n },
            { key: "vt", header: "Mean Vt", accessor: (l) => <span className="mono">{l.mean_vt.toFixed(3)}</span>, align: "right", sortValue: (l) => l.mean_vt },
            { key: "sd", header: "σ Vt", accessor: (l) => <span className="mono">{l.sd_vt.toFixed(4)}</span>, align: "right", sortValue: (l) => l.sd_vt },
          ]}
        />
      </GlassCard>
    </div>
  );
}
