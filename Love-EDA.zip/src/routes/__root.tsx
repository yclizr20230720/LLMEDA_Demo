import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { type ReactNode } from "react";

import appCss from "../styles.css?url";
import { AppShell } from "@/components/shell/AppShell";

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "SEMFAB·IQ — Semiconductor Engineering Analytics" },
      { name: "description", content: "Yield, SPC, FDC, WAT, CP, defect, APC, metrology, reliability, equipment, and agent analytics for advanced fabs." },
      { property: "og:title", content: "SEMFAB·IQ — Semiconductor Engineering Analytics" },
      { name: "twitter:title", content: "SEMFAB·IQ — Semiconductor Engineering Analytics" },
      { property: "og:description", content: "Yield, SPC, FDC, WAT, CP, defect, APC, metrology, reliability, equipment, and agent analytics for advanced fabs." },
      { name: "twitter:description", content: "Yield, SPC, FDC, WAT, CP, defect, APC, metrology, reliability, equipment, and agent analytics for advanced fabs." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/5e7110f1-22b5-43f7-bdd6-e2b83cc94855/id-preview-91d0815e--f72e6803-e0e3-414b-a946-a177230b5d66.lovable.app-1782552940283.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/5e7110f1-22b5-43f7-bdd6-e2b83cc94855/id-preview-91d0815e--f72e6803-e0e3-414b-a946-a177230b5d66.lovable.app-1782552940283.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFound,
  errorComponent: ErrorView,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AppShell><Outlet /></AppShell>
    </QueryClientProvider>
  );
}

function NotFound() {
  return (
    <div className="p-12 text-center">
      <div className="font-display text-4xl text-gradient mb-2">404</div>
      <div className="text-text-secondary">Module not found</div>
    </div>
  );
}

function ErrorView({ error }: { error: Error }) {
  return (
    <div className="p-12">
      <div className="font-display text-xl text-fail mb-2">Something failed</div>
      <pre className="mono text-xs text-text-muted whitespace-pre-wrap">{error.message}</pre>
    </div>
  );
}
