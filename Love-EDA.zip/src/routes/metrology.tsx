import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { mtrQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { ParetoBar } from "@/components/charts/Charts";
import { DataTable } from "@/components/tables/DataTable";
import { mean, stddev } from "@/lib/stats";
import { fmtDateTime } from "@/lib/format";

export const Route = createFileRoute("/metrology")({
  head: () => ({ meta: [{ title: "Metrology — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(mtrQuery()),
  component: Metrology,
});

function Metrology() {
  const { data: mtr } = useSuspenseQuery(mtrQuery());

  const byTool = useMemo(() => {
    const m = new Map<string, number[]>();
    for (const x of mtr) {
      const arr = m.get(x.tool) ?? [];
      arr.push(x.value); m.set(x.tool, arr);
    }
    return [...m.entries()].map(([tool, vs]) => ({
      tool, n: vs.length, mean: +mean(vs).toFixed(3), sd: +stddev(vs).toFixed(4),
    })).sort((a, b) => b.sd - a.sd);
  }, [mtr]);

  const grr = byTool.slice(0, 10).map((t) => ({
    label: t.tool, value: +(t.sd * 100).toFixed(2),
  }));

  return (
    <div className="space-y-6">
      <SectionHeader title="Metrology" subtitle="Measurement trend · gauge R&R · tool-to-tool matching" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassCard title="Tool-to-Tool σ Comparison" subtitle="Higher = worse matching">
          <ParetoBar data={grr} color="#8B5CF6" />
        </GlassCard>
        <GlassCard title="Tool R&R Summary">
          <DataTable
            rows={byTool}
            rowKey={(t) => t.tool}
            columns={[
              { key: "tool", header: "Tool", accessor: (t) => <span className="mono">{t.tool}</span> },
              { key: "n", header: "N", accessor: (t) => t.n, align: "right", sortValue: (t) => t.n },
              { key: "m", header: "Mean", accessor: (t) => <span className="mono">{t.mean}</span>, align: "right", sortValue: (t) => t.mean },
              { key: "sd", header: "σ", accessor: (t) => <span className="mono">{t.sd}</span>, align: "right", sortValue: (t) => t.sd },
              { key: "grr", header: "Status", accessor: (t) => <Pill tone={t.sd < 0.5 ? "teal" : t.sd < 1 ? "amber" : "coral"}>{t.sd < 0.5 ? "OK" : t.sd < 1 ? "WATCH" : "FAIL"}</Pill> },
            ]}
          />
        </GlassCard>
      </div>

      <GlassCard title="Recent Measurements">
        <DataTable
          rows={mtr.slice(0, 80)}
          rowKey={(m) => m.meas_id}
          dense
          columns={[
            { key: "id", header: "Meas", accessor: (m) => <span className="mono text-[10px]">{m.meas_id}</span> },
            { key: "ts", header: "Time", accessor: (m) => <span className="mono text-[10px]">{fmtDateTime(m.ts)}</span>, sortValue: (m) => m.ts },
            { key: "lot", header: "Lot", accessor: (m) => <span className="mono">{m.lot_id}</span> },
            { key: "w", header: "Wf", accessor: (m) => <span className="mono">W{m.wafer_no}</span>, align: "right" },
            { key: "p", header: "Param", accessor: (m) => m.param },
            { key: "tool", header: "Tool", accessor: (m) => <span className="mono">{m.tool}</span> },
            { key: "v", header: "Value", accessor: (m) => <span className="mono text-teal">{m.value}</span>, align: "right", sortValue: (m) => m.value },
          ]}
        />
      </GlassCard>
    </div>
  );
}
