import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { spcParametersQuery, spcSeriesQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { SpcChart } from "@/components/charts/Charts";
import { controlLimits, westernElectric } from "@/lib/spc";
import { cpk } from "@/lib/stats";
import { DataTable } from "@/components/tables/DataTable";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/spc")({
  head: () => ({ meta: [{ title: "SPC Workbench — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(spcParametersQuery()),
  component: Spc,
});

function Spc() {
  const { data: params } = useSuspenseQuery(spcParametersQuery());
  const [paramId, setParamId] = useState(params[0]!.param_id);
  const { data: series } = useSuspenseQuery(spcSeriesQuery(paramId));
  const param = params.find((p) => p.param_id === paramId)!;
  const values = series.map((s) => s.value);
  const cl = controlLimits(values);
  const vios = westernElectric(values, cl.cl, cl.ucl, cl.lcl);
  const cpkV = cpk(values, param.lsl, param.usl);

  return (
    <div className="space-y-6">
      <SectionHeader title="SPC Workbench" subtitle="Statistical process control with Western Electric rule detection" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <GlassCard title="Parameters" className="lg:col-span-1">
          <div className="space-y-1 max-h-[420px] overflow-y-auto">
            {params.map((p) => (
              <button key={p.param_id} onClick={() => setParamId(p.param_id)}
                className={cn("w-full text-left px-3 py-2 rounded text-xs border transition-all",
                  paramId === p.param_id ? "bg-teal/15 border-teal/40 text-teal" : "border-border/50 hover:bg-bg-elevated/40")}>
                <div className="font-medium">{p.name}</div>
                <div className="mono text-[10px] text-text-muted mt-0.5">{p.step} · Cpk {p.cpk}</div>
              </button>
            ))}
          </div>
        </GlassCard>

        <div className="lg:col-span-3 space-y-4">
          <div className="grid grid-cols-4 gap-3">
            <Stat label="Cpk" value={cpkV.toFixed(2)} tone={cpkV >= 1.33 ? "teal" : cpkV >= 1 ? "amber" : "coral"} />
            <Stat label="Mean" value={cl.cl.toFixed(3)} tone="violet" />
            <Stat label="σ" value={cl.sigma.toFixed(3)} tone="amber" />
            <Stat label="Violations" value={String(vios.length)} tone={vios.length ? "coral" : "teal"} />
          </div>

          <GlassCard title={`${param.name} — X̄ Control Chart`} subtitle={`Spec ${param.lsl}–${param.usl} ${param.unit}`}>
            <SpcChart data={series} cl={cl.cl} ucl={cl.ucl} lcl={cl.lcl} target={param.target} violationIdx={vios.map((v) => v.index)} />
          </GlassCard>

          <GlassCard title="Rule Violations">
            <DataTable
              rows={vios}
              rowKey={(v) => `${v.index}-${v.rule}`}
              columns={[
                { key: "idx", header: "Subgroup", accessor: (v) => <span className="mono">#{v.index}</span>, sortValue: (v) => v.index },
                { key: "rule", header: "Rule", accessor: (v) => v.rule },
                { key: "sev", header: "Severity", accessor: (v) => <Pill tone={v.severity === "critical" ? "coral" : v.severity === "major" ? "amber" : "neutral"}>{v.severity}</Pill> },
                { key: "val", header: "Value", accessor: (v) => <span className="mono">{series[v.index]?.value.toFixed(3)}</span>, align: "right" },
                { key: "lot", header: "Lot", accessor: (v) => <span className="mono">{series[v.index]?.lot_id}</span> },
              ]}
            />
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "teal" | "violet" | "amber" | "coral" }) {
  const c: Record<string, string> = { teal: "text-teal", violet: "text-violet", amber: "text-amber", coral: "text-coral" };
  return (
    <div className="glass rounded-md p-3">
      <div className="text-[10px] uppercase tracking-widest text-text-muted">{label}</div>
      <div className={cn("font-display mono text-2xl font-bold mt-1", c[tone])}>{value}</div>
    </div>
  );
}
