import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { relQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { ParetoBar, TraceChart } from "@/components/charts/Charts";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDate } from "@/lib/format";

export const Route = createFileRoute("/reliability")({
  head: () => ({ meta: [{ title: "Reliability — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(relQuery()),
  component: Reliability,
});

function Reliability() {
  const { data: rel } = useSuspenseQuery(relQuery());

  const byType = useMemo(() => {
    const m = new Map<string, { type: string; n: number; pass: number }>();
    for (const r of rel) {
      const o = m.get(r.test_type) ?? { type: r.test_type, n: 0, pass: 0 };
      o.n++; if (r.pass) o.pass++; m.set(r.test_type, o);
    }
    return [...m.values()];
  }, [rel]);

  const pareto = byType.map((b) => ({ label: b.type, value: +(100 * (1 - b.pass / b.n)).toFixed(2) }));

  // synthesised lifetime projection (Weibull-ish)
  const lifetime = Array.from({ length: 50 }, (_, i) => {
    const t = i * 200;
    const beta = 1.8, eta = 5000;
    const reliability = Math.exp(-Math.pow(t / eta, beta));
    return { t, reliability: +(reliability * 100).toFixed(2), dppm: +((1 - reliability) * 1e6).toFixed(0) };
  });

  return (
    <div className="space-y-6">
      <SectionHeader title="Reliability — WLR / DPPM" subtitle="Wafer-level reliability tests · lifetime projection" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassCard title="Failure Rate by Test Type">
          <ParetoBar data={pareto} color="#FF4F6A" />
        </GlassCard>
        <GlassCard title="DPPM Lifetime Projection" subtitle="Weibull β=1.8 · η=5000h">
          <TraceChart
            data={lifetime}
            keys={[
              { key: "reliability", color: "#00E5C4", name: "Reliability %" },
              { key: "dppm", color: "#FF4F6A", name: "DPPM" },
            ]}
          />
        </GlassCard>
      </div>

      <GlassCard title="WLR Result Log">
        <DataTable
          rows={rel}
          rowKey={(r) => r.test_id}
          columns={[
            { key: "id", header: "Test", accessor: (r) => <span className="mono text-[10px]">{r.test_id}</span> },
            { key: "lot", header: "Lot", accessor: (r) => <span className="mono">{r.lot_id}</span> },
            { key: "type", header: "Type", accessor: (r) => <Pill tone="violet">{r.test_type}</Pill> },
            { key: "v", header: "Value", accessor: (r) => <span className="mono">{r.value}</span>, align: "right", sortValue: (r) => r.value },
            { key: "spec", header: "Spec", accessor: (r) => <span className="mono">{r.spec}</span>, align: "right" },
            { key: "pass", header: "Result", accessor: (r) => <Pill tone={r.pass ? "pass" : "fail"}>{r.pass ? "PASS" : "FAIL"}</Pill> },
            { key: "d", header: "Date", accessor: (r) => <span className="mono text-[10px]">{fmtDate(r.date)}</span> },
          ]}
        />
      </GlassCard>
    </div>
  );
}
