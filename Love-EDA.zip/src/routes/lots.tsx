import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { lotsQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill, StatusDot } from "@/components/common/GlassCard";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDate } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/lots")({
  head: () => ({ meta: [{ title: "Lot Genealogy — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(lotsQuery()),
  component: Lots,
});

function Lots() {
  const { data: lots } = useSuspenseQuery(lotsQuery());
  const [sel, setSel] = useState(lots[0]!.lot_id);
  const lot = lots.find((l) => l.lot_id === sel)!;

  // synth route history
  const routeSteps = [
    "WAFER_START", "LITHO-A", "ETCH-A", "CVD-A", "PVD-A", "IMPL-A", "CMP-A",
    "LITHO-B", "ETCH-B", "DIFF-A", "WAT", "CP", "FINAL",
  ];
  const currentIdx = Math.max(0, routeSteps.indexOf(lot.current_step));

  return (
    <div className="space-y-6">
      <SectionHeader title="Lot Genealogy" subtitle="Route history · queue/cycle time · split-lot tree" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <GlassCard title="Lots" subtitle={`${lots.length} total`} className="lg:col-span-1">
          <div className="max-h-[520px] overflow-y-auto">
            <DataTable
              rows={lots}
              rowKey={(l) => l.lot_id}
              dense
              onRowClick={(l) => setSel(l.lot_id)}
              columns={[
                { key: "id", header: "Lot", accessor: (l) => <span className={cn("mono", sel === l.lot_id && "text-teal font-bold")}>{l.lot_id}</span> },
                { key: "p", header: "Product", accessor: (l) => <span className="text-[10px]">{l.product_id}</span> },
                { key: "s", header: "Status", accessor: (l) => <Pill tone={l.status === "IN_PROCESS" ? "teal" : l.status === "HOLD" ? "coral" : "neutral"}>{l.status}</Pill> },
              ]}
            />
          </div>
        </GlassCard>

        <div className="lg:col-span-2 space-y-4">
          <GlassCard title={lot.lot_id} subtitle={`${lot.product_id} · ${lot.tech_node} · ${lot.lot_type}`}>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <Field label="Status" value={lot.status} />
              <Field label="Wafers" value={String(lot.wafer_count)} />
              <Field label="Priority" value={String(lot.priority)} />
              <Field label="Hot" value={lot.is_hot ? "YES" : "no"} tone={lot.is_hot ? "coral" : "neutral"} />
              <Field label="Yield" value={lot.yield_pct != null ? `${lot.yield_pct}%` : "—"} tone="teal" />
              <Field label="Cycle Time" value={lot.cycle_time_h != null ? `${lot.cycle_time_h}h` : "—"} />
              <Field label="Current Step" value={lot.current_step} />
              <Field label="Current Eqp" value={lot.current_eqp} />
            </div>
            <div className="text-[11px] text-text-muted uppercase tracking-widest mb-2">Route Progress</div>
            <div className="flex items-center gap-1 overflow-x-auto">
              {routeSteps.map((s, i) => (
                <div key={s} className="flex items-center gap-1">
                  <div className={cn(
                    "px-2 py-1 rounded text-[10px] mono whitespace-nowrap border",
                    i < currentIdx ? "bg-pass/15 text-pass border-pass/30"
                    : i === currentIdx ? "bg-teal/20 text-teal border-teal/40"
                    : "border-border/50 text-text-muted"
                  )}>{s}</div>
                  {i < routeSteps.length - 1 && <span className="text-text-muted">→</span>}
                </div>
              ))}
            </div>
          </GlassCard>

          <GlassCard title="Queue & Cycle-Time Breakdown" subtitle="Synthesised per-step timing">
            <div className="space-y-1">
              {routeSteps.slice(1, currentIdx + 1).map((s, i) => {
                const q = 1 + (i * 7) % 12;
                const p = 2 + (i * 5) % 10;
                const total = q + p;
                return (
                  <div key={s} className="flex items-center gap-3 text-xs">
                    <div className="mono w-24 text-text-secondary">{s}</div>
                    <div className="flex-1 h-5 bg-bg-surface rounded overflow-hidden flex">
                      <div className="bg-amber/60 flex items-center justify-end pr-1 text-[9px] mono text-bg-void" style={{ width: `${(q / total) * 100}%` }}>q {q}h</div>
                      <div className="bg-teal/70 flex items-center justify-end pr-1 text-[9px] mono text-bg-void" style={{ width: `${(p / total) * 100}%` }}>p {p}h</div>
                    </div>
                    <div className="mono w-12 text-right text-text-secondary">{total}h</div>
                  </div>
                );
              })}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, tone = "neutral" }: { label: string; value: string; tone?: "teal" | "coral" | "neutral" }) {
  const c: Record<string, string> = { teal: "text-teal", coral: "text-coral", neutral: "text-text-primary" };
  return (
    <div className="bg-bg-surface/60 rounded p-2 border border-border/50">
      <div className="text-[10px] uppercase tracking-widest text-text-muted">{label}</div>
      <div className={cn("mono text-sm font-semibold mt-0.5", c[tone])}>{value}</div>
    </div>
  );
}
