import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { agentSessionsQuery, rcaQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDateTime, fmtDur } from "@/lib/format";
import { Bot, User, Send, Sparkles } from "lucide-react";

export const Route = createFileRoute("/agent")({
  head: () => ({ meta: [{ title: "Agent Console — SEMFAB·IQ" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(agentSessionsQuery());
    context.queryClient.ensureQueryData(rcaQuery());
  },
  component: Agent,
});

type Msg = { role: "user" | "agent"; text: string };

function Agent() {
  const { data: sessions } = useSuspenseQuery(agentSessionsQuery());
  const { data: rca } = useSuspenseQuery(rcaQuery());
  const [messages, setMessages] = useState<Msg[]>([
    { role: "agent", text: "I monitor SPC, FDC, WAT, CP, defect, and equipment streams. Ask me about a lot, a parameter, or a tool." },
  ]);
  const [input, setInput] = useState("");

  function send() {
    const q = input.trim();
    if (!q) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: q }]);
    setTimeout(() => {
      const reply = scriptedReply(q, rca);
      setMessages((m) => [...m, { role: "agent", text: reply }]);
    }, 600);
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Agent Console (AGT)" subtitle="Sessions · robot actions · RCA knowledge base · ask the agent" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <GlassCard title="Ask the Agent" className="lg:col-span-2">
          <div className="flex flex-col h-[500px]">
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {messages.map((m, i) => (
                <div key={i} className={`flex gap-2 ${m.role === "user" ? "justify-end" : ""}`}>
                  {m.role === "agent" && <div className="h-7 w-7 rounded-full bg-gradient-to-br from-teal to-violet flex items-center justify-center shrink-0"><Bot className="h-3.5 w-3.5 text-bg-void" /></div>}
                  <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${m.role === "user" ? "bg-teal text-bg-void" : "bg-bg-surface border border-border"}`}>{m.text}</div>
                  {m.role === "user" && <div className="h-7 w-7 rounded-full bg-bg-elevated flex items-center justify-center shrink-0"><User className="h-3.5 w-3.5" /></div>}
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-3">
              <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="e.g. why did lot M910023 yield drop?" 
                className="flex-1 px-3 py-2 rounded-md bg-bg-surface border border-border text-sm focus:outline-none focus:border-teal/50" />
              <button onClick={send} className="px-4 py-2 rounded-md bg-teal text-bg-void font-medium text-sm flex items-center gap-1.5">
                <Send className="h-3.5 w-3.5" /> Send
              </button>
            </div>
          </div>
        </GlassCard>

        <GlassCard title="RCA Knowledge" subtitle="Top patterns">
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {rca.map((r) => (
              <div key={r.rca_id} className="p-3 rounded bg-bg-surface/50 border border-border/50">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-xs font-medium flex items-center gap-1.5">
                    <Sparkles className="h-3 w-3 text-teal" />{r.symptom}
                  </div>
                  <Pill tone="teal">{(r.confidence * 100).toFixed(0)}%</Pill>
                </div>
                <div className="text-[11px] text-text-secondary">→ {r.root_cause}</div>
                <div className="text-[10px] text-text-muted mt-1">Fix: {r.fix} · {r.cases} cases</div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      <GlassCard title="Recent Agent Sessions">
        <DataTable
          rows={sessions}
          rowKey={(s) => s.session_id}
          columns={[
            { key: "id", header: "Session", accessor: (s) => <span className="mono text-[10px]">{s.session_id}</span> },
            { key: "ts", header: "Time", accessor: (s) => <span className="mono text-[10px]">{fmtDateTime(s.ts)}</span>, sortValue: (s) => s.ts },
            { key: "u", header: "User", accessor: (s) => <span className="mono">{s.user}</span> },
            { key: "intent", header: "Intent", accessor: (s) => s.intent },
            { key: "actions", header: "Actions", accessor: (s) => s.actions, align: "right", sortValue: (s) => s.actions },
            { key: "dur", header: "Duration", accessor: (s) => fmtDur(s.duration_s * 1000), align: "right", sortValue: (s) => s.duration_s },
            { key: "out", header: "Outcome", accessor: (s) => <Pill tone={s.outcome === "RESOLVED" ? "pass" : s.outcome === "ESCALATED" ? "coral" : "amber"}>{s.outcome}</Pill> },
          ]}
        />
      </GlassCard>
    </div>
  );
}

function scriptedReply(q: string, rca: any[]): string {
  const lower = q.toLowerCase();
  const match = rca.find((r) => lower.includes(r.symptom.toLowerCase().slice(0, 6)));
  if (match) return `Likely cause: ${match.root_cause}. Recommended fix: ${match.fix}. Confidence ${(match.confidence * 100).toFixed(0)}% across ${match.cases} historical cases.`;
  if (lower.includes("yield")) return "Pulling the last 30 days of yield data — fab average is 94.2%, last 3 lots show -1.2% drift driven by Vt N-MOS widening at WAT site 9. Recommend probe-card refurb (RCA-0007).";
  if (lower.includes("lot")) return "I can trace this lot's WAT, CP, defect, and FDC history. Top correlated tools: LITHO101, ETCH102. No critical alarms on its route.";
  if (lower.includes("alarm")) return "5 critical alarms open in the last 2 hours, all clustered on PVD103. Likely particle excursion — overdue PM. Recommend escalating to area lead.";
  return "I scanned SPC, FDC, and WAT streams for your query. No immediate excursion detected; refer to Guided Analytics for a structured drill-down.";
}
