import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { fdcTracesQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { TraceChart } from "@/components/charts/Charts";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/fdc")({
  head: () => ({ meta: [{ title: "FDC Trace Viewer — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(fdcTracesQuery()),
  component: Fdc,
});

function Fdc() {
  const { data: traces } = useSuspenseQuery(fdcTracesQuery());
  const [selected, setSelected] = useState<string[]>([traces[0]!.run_id]);
  const picked = traces.filter((t) => selected.includes(t.run_id));

  // overlay: merge by t
  const maxLen = Math.max(...picked.map((p) => p.trace.length));
  const overlay = Array.from({ length: maxLen }, (_, t) => {
    const row: any = { t };
    picked.forEach((p, i) => {
      if (p.trace[t]) {
        row[`run${i}_rf`] = p.trace[t]!.rf_power;
        row[`run${i}_pr`] = p.trace[t]!.pressure;
      }
    });
    return row;
  });
  const colors = ["#00E5C4", "#8B5CF6", "#F59E0B", "#FF4F6A", "#38BDF8"];

  return (
    <div className="space-y-6">
      <SectionHeader title="FDC Trace Viewer" subtitle="Fault detection & classification — multi-run overlay" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <GlassCard title="Runs" subtitle="Multi-select to overlay" className="lg:col-span-1">
          <div className="space-y-1 max-h-[420px] overflow-y-auto">
            {traces.map((t) => {
              const on = selected.includes(t.run_id);
              return (
                <button key={t.run_id} onClick={() =>
                  setSelected((s) => on ? s.filter((x) => x !== t.run_id) : [...s, t.run_id].slice(-5))
                }
                  className={cn("w-full text-left px-3 py-2 rounded text-xs border transition",
                    on ? "bg-teal/15 border-teal/40" : "border-border/50 hover:bg-bg-elevated/40")}>
                  <div className="mono font-medium">{t.run_id}</div>
                  <div className="text-[10px] text-text-muted mt-0.5">{t.recipe} · {t.eqp_id}</div>
                </button>
              );
            })}
          </div>
        </GlassCard>

        <div className="lg:col-span-3 space-y-4">
          <GlassCard title="RF Power (W) — overlay">
            <TraceChart data={overlay} keys={picked.map((p, i) => ({ key: `run${i}_rf`, color: colors[i]!, name: p.run_id }))} />
          </GlassCard>
          <GlassCard title="Pressure (mTorr) — overlay">
            <TraceChart data={overlay} keys={picked.map((p, i) => ({ key: `run${i}_pr`, color: colors[i]!, name: p.run_id }))} />
          </GlassCard>
          <GlassCard title="Indicators">
            <DataTable
              rows={picked}
              rowKey={(t) => t.run_id}
              columns={[
                { key: "run", header: "Run", accessor: (t) => <span className="mono">{t.run_id}</span> },
                { key: "lot", header: "Lot", accessor: (t) => <span className="mono">{t.lot_id}</span> },
                { key: "rcp", header: "Recipe", accessor: (t) => t.recipe },
                { key: "eqp", header: "Eqp", accessor: (t) => <span className="mono">{t.eqp_id}</span> },
                { key: "dur", header: "Duration", accessor: (t) => `${t.duration_s}s`, align: "right" },
                { key: "pwr", header: "Peak Power", accessor: (t) => <span className="mono">{t.indicators.peak_power}</span>, align: "right" },
                { key: "ep", header: "Endpoint t", accessor: (t) => <span className="mono">{t.indicators.endpoint_t}s</span>, align: "right" },
                { key: "ts", header: "Time", accessor: (t) => <span className="mono text-[10px]">{fmtDateTime(t.ts)}</span> },
              ]}
            />
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
