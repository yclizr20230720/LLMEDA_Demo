import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apcModelsQuery, apcActionsQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { TraceChart } from "@/components/charts/Charts";
import { DataTable } from "@/components/tables/DataTable";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/apc")({
  head: () => ({ meta: [{ title: "APC Console — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(apcModelsQuery()),
  component: Apc,
});

function Apc() {
  const { data: models } = useSuspenseQuery(apcModelsQuery());
  const [modelId, setModelId] = useState(models[0]!.model_id);
  const { data: actions } = useSuspenseQuery(apcActionsQuery(modelId));
  const model = models.find((m) => m.model_id === modelId)!;

  const setpointSeries = actions.slice().reverse().map((a, i) => ({
    t: i, setpoint: a.setpoint_new, measured: a.setpoint_new + (Math.sin(i) * 0.6),
  }));

  return (
    <div className="space-y-6">
      <SectionHeader title="APC Console" subtitle="Advanced Process Control · R2R model health · setpoint timeline" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <GlassCard title="R2R Models" className="lg:col-span-1">
          <div className="space-y-1">
            {models.map((m) => (
              <button key={m.model_id} onClick={() => setModelId(m.model_id)}
                className={cn("w-full text-left px-3 py-2 rounded text-xs border transition",
                  modelId === m.model_id ? "bg-teal/15 border-teal/40" : "border-border/50 hover:bg-bg-elevated/40")}>
                <div className="flex items-center justify-between">
                  <div className="font-medium">{m.name}</div>
                  <Pill tone={m.health > 0.85 ? "teal" : m.health > 0.7 ? "amber" : "coral"}>{(m.health * 100).toFixed(0)}</Pill>
                </div>
                <div className="text-[10px] mono text-text-muted">{m.step} · {m.actions_24h} actions/24h</div>
              </button>
            ))}
          </div>
        </GlassCard>

        <div className="lg:col-span-3 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Model Health" value={`${(model.health * 100).toFixed(1)}%`} tone={model.health > 0.85 ? "teal" : "amber"} />
            <Stat label="Actions / 24h" value={String(model.actions_24h)} tone="violet" />
            <Stat label="Last Update" value={fmtDateTime(model.last_update).slice(11)} tone="amber" />
          </div>
          <GlassCard title={`${model.name} — Setpoint vs Measured`}>
            <TraceChart
              data={setpointSeries}
              keys={[
                { key: "setpoint", color: "#00E5C4", name: "Setpoint" },
                { key: "measured", color: "#8B5CF6", name: "Measured" },
              ]}
            />
          </GlassCard>
          <GlassCard title="Control Actions">
            <DataTable
              rows={actions}
              rowKey={(a) => a.action_id}
              columns={[
                { key: "ts", header: "Time", accessor: (a) => <span className="mono text-[10px]">{fmtDateTime(a.ts)}</span>, sortValue: (a) => a.ts },
                { key: "lot", header: "Lot", accessor: (a) => <span className="mono">{a.lot_id}</span> },
                { key: "old", header: "Old SP", accessor: (a) => <span className="mono">{a.setpoint_old}</span>, align: "right" },
                { key: "new", header: "New SP", accessor: (a) => <span className="mono text-teal">{a.setpoint_new}</span>, align: "right" },
                { key: "delta", header: "Δ", accessor: (a) => <span className={cn("mono", a.setpoint_new - a.setpoint_old >= 0 ? "text-pass" : "text-fail")}>
                  {(a.setpoint_new - a.setpoint_old).toFixed(2)}</span>, align: "right" },
                { key: "reason", header: "Reason", accessor: (a) => a.reason },
              ]}
            />
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "teal" | "violet" | "amber" }) {
  const c: Record<string, string> = { teal: "text-teal", violet: "text-violet", amber: "text-amber" };
  return (
    <div className="glass rounded-md p-3">
      <div className="text-[10px] uppercase tracking-widest text-text-muted">{label}</div>
      <div className={cn("font-display mono text-2xl font-bold mt-1", c[tone])}>{value}</div>
    </div>
  );
}
