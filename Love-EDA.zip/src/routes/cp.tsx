import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { lotsQuery } from "@/data/queries";
import { generateWafer } from "@/data/mock";
import { GlassCard, SectionHeader, Pill } from "@/components/common/GlassCard";
import { WaferMap, BinLegend } from "@/components/wafer/WaferMap";
import { ParetoBar } from "@/components/charts/Charts";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/cp")({
  head: () => ({ meta: [{ title: "CP Analyzer — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(lotsQuery()),
  component: Cp,
});

function Cp() {
  const { data: lots } = useSuspenseQuery(lotsQuery());
  const candidates = lots.filter((l) => l.yield_pct != null).slice(0, 20);
  const [lotId, setLotId] = useState(candidates[0]!.lot_id);

  const wafers = useMemo(
    () => Array.from({ length: 25 }, (_, i) => generateWafer(lotId, i + 1, 0.9 + (i % 5) * 0.01)),
    [lotId]
  );

  // bin pareto
  const binCount = new Map<number, number>();
  for (const w of wafers) for (const d of w.dies) binCount.set(d.bin, (binCount.get(d.bin) ?? 0) + 1);
  const binData = [...binCount.entries()].sort((a, b) => b[1] - a[1])
    .map(([bin, count]) => ({ label: `B${bin}`, value: count }));

  const totalDies = wafers.reduce((s, w) => s + w.dies.length, 0);
  const passDies = wafers.reduce((s, w) => s + w.dies.filter((d) => d.pass).length, 0);
  const yieldPct = (100 * passDies / totalDies).toFixed(2);

  // stacked overlay (sum of fails per die location)
  const overlay = useMemo(() => {
    const failMap = new Map<string, number>();
    for (const w of wafers) for (const d of w.dies) {
      if (!d.pass) {
        const k = `${d.x},${d.y}`;
        failMap.set(k, (failMap.get(k) ?? 0) + 1);
      }
    }
    const dies = wafers[0]!.dies.map((d) => ({
      ...d,
      bin: (failMap.get(`${d.x},${d.y}`) ?? 0) > 5 ? 4 : (failMap.get(`${d.x},${d.y}`) ?? 0) > 2 ? 3 : 1,
      pass: (failMap.get(`${d.x},${d.y}`) ?? 0) <= 2,
    }));
    return { lot_id: lotId, wafer_no: 0, bin_yield: +yieldPct, dies };
  }, [wafers, lotId, yieldPct]);

  return (
    <div className="space-y-6">
      <SectionHeader title="CP Analyzer" subtitle="Chip Probe wafer maps · bin Pareto · stacked overlay" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <GlassCard title="Lot" className="lg:col-span-1">
          <div className="space-y-1 max-h-[420px] overflow-y-auto">
            {candidates.map((l) => (
              <button key={l.lot_id} onClick={() => setLotId(l.lot_id)}
                className={cn("w-full text-left px-3 py-2 rounded text-xs border transition",
                  lotId === l.lot_id ? "bg-teal/15 border-teal/40" : "border-border/50 hover:bg-bg-elevated/40")}>
                <div className="mono font-medium">{l.lot_id}</div>
                <div className="text-[10px] text-text-muted">{l.product_id} · {l.yield_pct}%</div>
              </button>
            ))}
          </div>
        </GlassCard>

        <div className="lg:col-span-3 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Lot Yield" value={`${yieldPct}%`} tone="teal" />
            <Stat label="Pass Dies" value={String(passDies)} tone="violet" />
            <Stat label="Fail Dies" value={String(totalDies - passDies)} tone="coral" />
          </div>
          <GlassCard title={`${lotId} — 25-Wafer Map`} action={<BinLegend />}>
            <div className="grid grid-cols-5 gap-3">
              {wafers.map((w) => <WaferMap key={w.wafer_no} wafer={w} size={96} />)}
            </div>
          </GlassCard>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassCard title="Bin Pareto">
              <ParetoBar data={binData} />
            </GlassCard>
            <GlassCard title="Stacked Wafer (fail-density overlay)">
              <div className="flex justify-center">
                <WaferMap wafer={overlay} size={220} showLabel={false} />
              </div>
              <div className="text-[10px] text-text-muted text-center mt-2 mono">
                bright = repeating-location failures across 25 wafers
              </div>
            </GlassCard>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "teal" | "violet" | "coral" }) {
  const c: Record<string, string> = { teal: "text-teal", violet: "text-violet", coral: "text-coral" };
  return (
    <div className="glass rounded-md p-3">
      <div className="text-[10px] uppercase tracking-widest text-text-muted">{label}</div>
      <div className={cn("font-display mono text-2xl font-bold mt-1", c[tone])}>{value}</div>
    </div>
  );
}
