import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { equipmentQuery } from "@/data/queries";
import { GlassCard, SectionHeader, Pill, StatusDot } from "@/components/common/GlassCard";
import { DataTable } from "@/components/tables/DataTable";
import { ParetoBar } from "@/components/charts/Charts";
import { fmtDate } from "@/lib/format";

export const Route = createFileRoute("/equipment")({
  head: () => ({ meta: [{ title: "Equipment Health — SEMFAB·IQ" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(equipmentQuery()),
  component: Eqp,
});

function Eqp() {
  const { data: eqp } = useSuspenseQuery(equipmentQuery());
  const counts = {
    RUN: eqp.filter((e) => e.status === "RUN").length,
    IDLE: eqp.filter((e) => e.status === "IDLE").length,
    DOWN: eqp.filter((e) => e.status === "DOWN").length,
    PM: eqp.filter((e) => e.status === "PM").length,
    QUAL: eqp.filter((e) => e.status === "QUAL").length,
  };
  const oeeData = eqp.slice().sort((a, b) => a.oee - b.oee).slice(0, 12)
    .map((e) => ({ label: e.eqp_id, value: +(e.oee * 100).toFixed(1) }));

  return (
    <div className="space-y-6">
      <SectionHeader title="Equipment Health" subtitle="OEE · MTBF · MTTR · PM schedule" />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {Object.entries(counts).map(([k, v]) => (
          <div key={k} className="glass rounded-md p-4 flex items-center gap-3">
            <StatusDot status={k as any} />
            <div>
              <div className="text-[10px] uppercase tracking-widest text-text-muted">{k}</div>
              <div className="font-display text-2xl font-bold mono">{v}</div>
            </div>
          </div>
        ))}
      </div>

      <GlassCard title="Bottom-12 OEE" subtitle="Tools needing attention">
        <ParetoBar data={oeeData} color="#FF4F6A" />
      </GlassCard>

      <GlassCard title="Equipment List">
        <DataTable
          rows={eqp}
          rowKey={(e) => e.eqp_id}
          columns={[
            { key: "id", header: "Tool", accessor: (e) => <span className="mono font-medium">{e.eqp_id}</span> },
            { key: "area", header: "Area", accessor: (e) => e.area, sortValue: (e) => e.area },
            { key: "type", header: "Type", accessor: (e) => <Pill tone="violet">{e.type}</Pill>, sortValue: (e) => e.type },
            { key: "vendor", header: "Vendor", accessor: (e) => e.vendor },
            { key: "status", header: "Status", accessor: (e) => <span className="inline-flex items-center gap-1.5"><StatusDot status={e.status} /><span className="mono">{e.status}</span></span> },
            { key: "oee", header: "OEE", accessor: (e) => <span className="mono">{(e.oee * 100).toFixed(1)}%</span>, align: "right", sortValue: (e) => e.oee },
            { key: "u", header: "Util", accessor: (e) => <span className="mono">{(e.utilization * 100).toFixed(1)}%</span>, align: "right", sortValue: (e) => e.utilization },
            { key: "mtbf", header: "MTBF (h)", accessor: (e) => <span className="mono">{e.mtbf_h}</span>, align: "right", sortValue: (e) => e.mtbf_h },
            { key: "mttr", header: "MTTR (h)", accessor: (e) => <span className="mono">{e.mttr_h}</span>, align: "right", sortValue: (e) => e.mttr_h },
            { key: "pm", header: "Next PM", accessor: (e) => <span className="mono text-[10px]">{fmtDate(e.next_pm)}</span> },
          ]}
        />
      </GlassCard>
    </div>
  );
}
