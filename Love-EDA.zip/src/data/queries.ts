import { queryOptions } from "@tanstack/react-query";
import * as mock from "./mock";

// simulated async latency so loading states are real
const delay = <T>(v: T, ms = 200) => new Promise<T>((r) => setTimeout(() => r(v), ms));

export const kpiQuery = () => queryOptions({
  queryKey: ["kpis"],
  queryFn: () => delay(mock.getKpis()),
  refetchInterval: 30000,
});
export const yieldTrendQuery = (days = 30) => queryOptions({
  queryKey: ["yield-trend", days],
  queryFn: () => delay(mock.getYieldTrend(days)),
});
export const alarmsQuery = () => queryOptions({
  queryKey: ["alarms"],
  queryFn: () => delay(mock.getAlarms()),
  refetchInterval: 15000,
});
export const activeWafersQuery = () => queryOptions({
  queryKey: ["active-wafers"],
  queryFn: () => delay(mock.getActiveWafers(), 300),
});
export const lotsQuery = () => queryOptions({
  queryKey: ["lots"],
  queryFn: () => delay(mock.getLots()),
});
export const equipmentQuery = () => queryOptions({
  queryKey: ["equipment"],
  queryFn: () => delay(mock.getEquipment()),
});
export const spcParametersQuery = () => queryOptions({
  queryKey: ["spc-params"],
  queryFn: () => delay(mock.getSpcParameters()),
});
export const spcSeriesQuery = (paramId: string) => queryOptions({
  queryKey: ["spc-series", paramId],
  queryFn: () => delay(mock.getSpcSeries(paramId)),
});
export const watResultsQuery = (lotId?: string) => queryOptions({
  queryKey: ["wat", lotId ?? "all"],
  queryFn: () => delay(mock.getWatResults(lotId), 350),
});
export const fdcTracesQuery = () => queryOptions({
  queryKey: ["fdc"],
  queryFn: () => delay(mock.getFdcTraces(), 300),
});
export const defectsQuery = (lotId?: string) => queryOptions({
  queryKey: ["defects", lotId ?? "all"],
  queryFn: () => delay(mock.getDefects(lotId)),
});
export const apcModelsQuery = () => queryOptions({
  queryKey: ["apc-models"],
  queryFn: () => delay(mock.getApcModels()),
});
export const apcActionsQuery = (modelId?: string) => queryOptions({
  queryKey: ["apc-actions", modelId ?? "all"],
  queryFn: () => delay(mock.getApcActions(modelId)),
});
export const mtrQuery = () => queryOptions({
  queryKey: ["mtr"],
  queryFn: () => delay(mock.getMtrMeasurements()),
});
export const relQuery = () => queryOptions({
  queryKey: ["rel"],
  queryFn: () => delay(mock.getRelResults()),
});
export const agentSessionsQuery = () => queryOptions({
  queryKey: ["agent-sessions"],
  queryFn: () => delay(mock.getAgentSessions()),
});
export const rcaQuery = () => queryOptions({
  queryKey: ["rca"],
  queryFn: () => delay(mock.getRcaKnowledge()),
});
