// SEMFAB·IQ — schema types (subset of DataMart, the parts the UI touches)

export type Severity = "CRITICAL" | "MAJOR" | "MINOR";
export type AlarmStatus = "OPEN" | "ACK" | "CLOSED";
export type LotStatus = "IN_PROCESS" | "HOLD" | "WAITING" | "DONE" | "SCRAP";
export type LotType = "PRODUCTION" | "ENGINEERING" | "QUALIFICATION" | "MONITOR" | "REWORK";

export interface Lot {
  lot_id: string;
  product_id: string;
  device_family: string;
  tech_node: string;
  lot_type: LotType;
  priority: number;
  is_hot: boolean;
  status: LotStatus;
  current_step: string;
  current_eqp: string;
  wafer_count: number;
  start_date: string;
  yield_pct: number | null;
  cycle_time_h: number | null;
}

export interface Equipment {
  eqp_id: string;
  area: string;
  type: string;
  vendor: string;
  status: "RUN" | "IDLE" | "DOWN" | "PM" | "QUAL";
  oee: number;
  mtbf_h: number;
  mttr_h: number;
  utilization: number;
  last_pm: string;
  next_pm: string;
}

export interface Alarm {
  alarm_id: string;
  ts: string;
  eqp_id: string;
  lot_id: string | null;
  code: string;
  message: string;
  severity: Severity;
  status: AlarmStatus;
}

export interface YieldPoint { date: string; yield_pct: number; lot_count: number; }

export interface WaferDie { x: number; y: number; bin: number; pass: boolean; }
export interface Wafer { lot_id: string; wafer_no: number; bin_yield: number; dies: WaferDie[]; }

export interface SpcParameter {
  param_id: string;
  name: string;
  step: string;
  eqp_type: string;
  unit: string;
  lsl: number;
  usl: number;
  target: number;
  cpk: number;
}

export interface SpcPoint { ts: string; value: number; lot_id: string; subgroup: number; }

export interface WatResult {
  lot_id: string;
  wafer_no: number;
  site: number;
  param: string;
  value: number;
  pass: boolean;
}

export interface FdcTrace {
  run_id: string;
  ts: string;
  lot_id: string;
  recipe: string;
  step: string;
  eqp_id: string;
  duration_s: number;
  indicators: Record<string, number>;
  trace: { t: number; [k: string]: number }[];
}

export interface DefectRecord {
  defect_id: string;
  lot_id: string;
  wafer_no: number;
  x: number;
  y: number;
  size_um: number;
  class: string;
  source_eqp: string;
  ts: string;
}

export interface ApcModel {
  model_id: string;
  name: string;
  param: string;
  step: string;
  health: number; // 0-1
  last_update: string;
  actions_24h: number;
}
export interface ApcAction {
  action_id: string;
  ts: string;
  model_id: string;
  lot_id: string;
  param: string;
  setpoint_old: number;
  setpoint_new: number;
  reason: string;
}

export interface MtrMeasurement {
  meas_id: string;
  ts: string;
  lot_id: string;
  wafer_no: number;
  param: string;
  value: number;
  tool: string;
}

export interface RelResult {
  test_id: string;
  lot_id: string;
  test_type: "WLR" | "HTOL" | "EM" | "TDDB" | "NBTI";
  param: string;
  value: number;
  spec: number;
  pass: boolean;
  date: string;
}

export interface AgentSession {
  session_id: string;
  ts: string;
  user: string;
  intent: string;
  outcome: "RESOLVED" | "ESCALATED" | "PENDING";
  duration_s: number;
  actions: number;
}

export interface RcaEntry {
  rca_id: string;
  symptom: string;
  root_cause: string;
  fix: string;
  confidence: number;
  cases: number;
}
