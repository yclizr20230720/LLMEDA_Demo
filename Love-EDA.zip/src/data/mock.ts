import { RNG } from "@/lib/rng";
import type {
  Lot, Equipment, Alarm, YieldPoint, Wafer, WaferDie,
  SpcParameter, SpcPoint, WatResult, FdcTrace, DefectRecord,
  ApcModel, ApcAction, MtrMeasurement, RelResult, AgentSession, RcaEntry,
} from "./schema";

const SEED = 42;
const NOW = new Date("2026-06-27T12:00:00Z").getTime();

const PRODUCTS = ["P-NAND-256", "P-LPDDR5", "P-CIS-50M", "P-RF-N5", "P-MCU-7", "P-PMIC-40"];
const FAMILIES = ["NAND", "DRAM", "CIS", "RF", "LOGIC", "PMIC"];
const NODES = ["7nm", "10nm", "14nm", "22nm", "28nm", "40nm"];
const STEPS = [
  "LITHO-A", "ETCH-A", "CVD-A", "PVD-A", "IMPL-A", "CMP-A",
  "LITHO-B", "ETCH-B", "DIFF-A", "WET-A", "MTL-1", "MTL-2",
];
const EQP_TYPES = ["LITHO", "ETCH", "CVD", "PVD", "IMPL", "CMP", "DIFF", "WET", "MET"];
const VENDORS = ["ASML", "AMAT", "TEL", "LAM", "KLA", "Hitachi"];
const AREAS = ["FEOL", "BEOL", "MTL", "DIFF", "PHOTO", "ETCH"];
const ALARM_CODES = [
  ["E101", "Gas flow deviation"],
  ["E203", "RF power out of range"],
  ["E305", "Chamber pressure excursion"],
  ["E412", "Wafer handler timeout"],
  ["E508", "Temperature setpoint violation"],
  ["E601", "Endpoint detection failed"],
  ["E704", "Particle count exceeded"],
  ["E812", "Robot collision warning"],
];
const SPC_PARAMS = [
  { name: "Gate CD", step: "LITHO-A", eqp: "LITHO", unit: "nm", target: 28, lsl: 25, usl: 31 },
  { name: "Etch Depth", step: "ETCH-A", eqp: "ETCH", unit: "nm", target: 120, lsl: 110, usl: 130 },
  { name: "Film Thickness", step: "CVD-A", eqp: "CVD", unit: "Å", target: 450, lsl: 420, usl: 480 },
  { name: "Resistivity", step: "PVD-A", eqp: "PVD", unit: "µΩ·cm", target: 2.4, lsl: 2.0, usl: 2.8 },
  { name: "Implant Dose", step: "IMPL-A", eqp: "IMPL", unit: "1e15/cm²", target: 5.0, lsl: 4.5, usl: 5.5 },
  { name: "Vt N-MOS", step: "WAT", eqp: "WAT", unit: "V", target: 0.45, lsl: 0.38, usl: 0.52 },
  { name: "Vt P-MOS", step: "WAT", eqp: "WAT", unit: "V", target: -0.45, lsl: -0.52, usl: -0.38 },
  { name: "Idsat N-MOS", step: "WAT", eqp: "WAT", unit: "µA/µm", target: 850, lsl: 780, usl: 920 },
  { name: "Sheet Rho", step: "WAT", eqp: "WAT", unit: "Ω/sq", target: 12, lsl: 10, usl: 14 },
];
const WAT_PARAMS = SPC_PARAMS.filter((p) => p.eqp === "WAT");
const DEFECT_CLASSES = ["Particle", "Scratch", "Residue", "Void", "Bridge", "Open", "Stain", "Pattern"];

// ========================= EQUIPMENT =========================
let _eqp: Equipment[] | null = null;
export function getEquipment(): Equipment[] {
  if (_eqp) return _eqp;
  const r = new RNG(SEED + 1);
  const out: Equipment[] = [];
  for (let i = 0; i < 48; i++) {
    const type = r.pick(EQP_TYPES);
    const area = r.pick(AREAS);
    const status = r.pick(["RUN", "RUN", "RUN", "RUN", "IDLE", "DOWN", "PM", "QUAL"] as const);
    out.push({
      eqp_id: `${type}${String(100 + i).padStart(3, "0")}`,
      area, type,
      vendor: r.pick(VENDORS),
      status,
      oee: +r.range(0.62, 0.95).toFixed(3),
      mtbf_h: +r.range(80, 800).toFixed(0),
      mttr_h: +r.range(0.5, 6).toFixed(2),
      utilization: +r.range(0.55, 0.92).toFixed(3),
      last_pm: new Date(NOW - r.int(1, 40) * 86400000).toISOString(),
      next_pm: new Date(NOW + r.int(2, 30) * 86400000).toISOString(),
    });
  }
  _eqp = out;
  return out;
}

// ========================= LOTS =========================
let _lots: Lot[] | null = null;
export function getLots(): Lot[] {
  if (_lots) return _lots;
  const r = new RNG(SEED + 2);
  const eqp = getEquipment();
  const out: Lot[] = [];
  for (let i = 0; i < 120; i++) {
    const status = r.pick(["IN_PROCESS", "IN_PROCESS", "IN_PROCESS", "HOLD", "WAITING", "DONE", "DONE"] as const);
    const fIdx = r.int(0, FAMILIES.length - 1);
    out.push({
      lot_id: `M9${String(10000 + i).padStart(5, "0")}`,
      product_id: PRODUCTS[fIdx]!,
      device_family: FAMILIES[fIdx]!,
      tech_node: r.pick(NODES),
      lot_type: r.pick(["PRODUCTION", "PRODUCTION", "PRODUCTION", "ENGINEERING", "QUALIFICATION", "MONITOR"] as const),
      priority: r.int(1, 10),
      is_hot: r.bool(0.12),
      status,
      current_step: r.pick(STEPS),
      current_eqp: r.pick(eqp).eqp_id,
      wafer_count: r.pick([25, 25, 25, 24, 12]),
      start_date: new Date(NOW - r.int(1, 30) * 86400000).toISOString(),
      yield_pct: status === "DONE" ? +r.range(86, 98.5).toFixed(2) : null,
      cycle_time_h: status === "DONE" ? +r.range(48, 240).toFixed(1) : null,
    });
  }
  _lots = out;
  return out;
}

// ========================= ALARMS =========================
let _alarms: Alarm[] | null = null;
export function getAlarms(): Alarm[] {
  if (_alarms) return _alarms;
  const r = new RNG(SEED + 3);
  const eqp = getEquipment();
  const lots = getLots();
  const out: Alarm[] = [];
  for (let i = 0; i < 80; i++) {
    const c = r.pick(ALARM_CODES);
    out.push({
      alarm_id: `A${String(50000 + i).padStart(6, "0")}`,
      ts: new Date(NOW - r.int(0, 7200) * 1000).toISOString(),
      eqp_id: r.pick(eqp).eqp_id,
      lot_id: r.bool(0.7) ? r.pick(lots).lot_id : null,
      code: c[0]!,
      message: c[1]!,
      severity: r.pick(["CRITICAL", "MAJOR", "MAJOR", "MINOR", "MINOR", "MINOR"] as const),
      status: r.pick(["OPEN", "OPEN", "OPEN", "ACK", "CLOSED"] as const),
    });
  }
  out.sort((a, b) => b.ts.localeCompare(a.ts));
  _alarms = out;
  return out;
}

// ========================= YIELD TREND =========================
export function getYieldTrend(days = 30): YieldPoint[] {
  const r = new RNG(SEED + 4);
  const out: YieldPoint[] = [];
  let base = 94.2;
  for (let i = days - 1; i >= 0; i--) {
    base += r.normal(0, 0.6);
    base = Math.max(86, Math.min(98, base));
    const excursion = r.bool(0.08) ? -r.range(2, 5) : 0;
    out.push({
      date: new Date(NOW - i * 86400000).toISOString().slice(0, 10),
      yield_pct: +(base + excursion).toFixed(2),
      lot_count: r.int(8, 22),
    });
  }
  return out;
}

// ========================= WAFER MAPS =========================
export function generateWafer(lotId: string, waferNo: number, targetYield = 0.94): Wafer {
  const seed = (lotId.charCodeAt(2) * 31 + lotId.charCodeAt(5) * 17 + waferNo * 7) & 0xfffffff;
  const r = new RNG(seed);
  const radius = 12;
  const dies: WaferDie[] = [];
  let pass = 0, total = 0;
  // edge-fail pattern, sometimes a cluster
  const clusterX = r.range(-radius, radius);
  const clusterY = r.range(-radius, radius);
  const hasCluster = r.bool(0.35);
  for (let y = -radius; y <= radius; y++) {
    for (let x = -radius; x <= radius; x++) {
      const dist = Math.sqrt(x * x + y * y);
      if (dist > radius) continue;
      total++;
      let failProb = 1 - targetYield;
      // edge zone
      if (dist > radius - 2) failProb += 0.25;
      // cluster
      if (hasCluster) {
        const cd = Math.sqrt((x - clusterX) ** 2 + (y - clusterY) ** 2);
        if (cd < 3) failProb += 0.5;
      }
      const isPass = r.next() > failProb;
      const bin = isPass ? 1 : r.pick([2, 3, 4, 5, 6]);
      if (isPass) pass++;
      dies.push({ x, y, bin, pass: isPass });
    }
  }
  return { lot_id: lotId, wafer_no: waferNo, bin_yield: +(100 * pass / total).toFixed(2), dies };
}

export function getActiveWafers(): { lot: Lot; wafers: Wafer[] }[] {
  const lots = getLots().filter((l) => l.status === "IN_PROCESS").slice(0, 8);
  return lots.map((l) => ({
    lot: l,
    wafers: Array.from({ length: 6 }, (_, i) => generateWafer(l.lot_id, i + 1, 0.88 + (i % 4) * 0.02)),
  }));
}

// ========================= SPC =========================
let _spcParams: SpcParameter[] | null = null;
export function getSpcParameters(): SpcParameter[] {
  if (_spcParams) return _spcParams;
  const r = new RNG(SEED + 5);
  _spcParams = SPC_PARAMS.map((p, i) => ({
    param_id: `SPC-${String(i + 1).padStart(3, "0")}`,
    name: p.name,
    step: p.step,
    eqp_type: p.eqp,
    unit: p.unit,
    lsl: p.lsl,
    usl: p.usl,
    target: p.target,
    cpk: +r.range(0.7, 1.8).toFixed(2),
  }));
  return _spcParams;
}

export function getSpcSeries(paramId: string, n = 60): SpcPoint[] {
  const p = getSpcParameters().find((x) => x.param_id === paramId) || getSpcParameters()[0]!;
  const r = new RNG(SEED + 10 + paramId.charCodeAt(paramId.length - 1));
  const sigma = (p.usl - p.lsl) / 8;
  const out: SpcPoint[] = [];
  const lots = getLots();
  let drift = 0;
  for (let i = 0; i < n; i++) {
    if (i > n * 0.7) drift += r.normal(0, sigma * 0.05);
    const v = p.target + r.normal(0, sigma) + drift;
    out.push({
      ts: new Date(NOW - (n - i) * 3600000).toISOString(),
      value: +v.toFixed(4),
      lot_id: r.pick(lots).lot_id,
      subgroup: i,
    });
  }
  return out;
}

// ========================= WAT =========================
export function getWatResults(lotId?: string): WatResult[] {
  const lots = lotId ? [getLots().find((l) => l.lot_id === lotId)!].filter(Boolean) : getLots().slice(0, 10);
  const out: WatResult[] = [];
  const r = new RNG(SEED + 6 + (lotId ? lotId.charCodeAt(3) : 0));
  for (const l of lots) {
    for (let w = 1; w <= 5; w++) {
      for (let s = 1; s <= 9; s++) {
        for (const p of WAT_PARAMS) {
          const v = p.target + r.normal(0, (p.usl - p.lsl) / 8);
          out.push({
            lot_id: l.lot_id, wafer_no: w, site: s, param: p.name,
            value: +v.toFixed(4), pass: v >= p.lsl && v <= p.usl,
          });
        }
      }
    }
  }
  return out;
}

// ========================= FDC =========================
export function getFdcTraces(n = 24): FdcTrace[] {
  const r = new RNG(SEED + 7);
  const lots = getLots();
  const eqp = getEquipment();
  const out: FdcTrace[] = [];
  for (let i = 0; i < n; i++) {
    const dur = r.int(60, 180);
    const trace: { t: number; pressure: number; rf_power: number; temp: number; gas_flow: number }[] = [];
    for (let t = 0; t < dur; t++) {
      const phase = t / dur;
      trace.push({
        t,
        pressure: 5 + Math.sin(phase * Math.PI * 2) * 0.3 + r.normal(0, 0.05),
        rf_power: 800 + (phase > 0.1 && phase < 0.9 ? 200 : 0) + r.normal(0, 8),
        temp: 250 + phase * 40 + r.normal(0, 1.5),
        gas_flow: 50 + r.normal(0, 1.2),
      });
    }
    out.push({
      run_id: `R${String(800000 + i).padStart(7, "0")}`,
      ts: new Date(NOW - i * 3600000).toISOString(),
      lot_id: r.pick(lots).lot_id,
      recipe: r.pick(["RCP-ETCH-01", "RCP-CVD-04", "RCP-PVD-02", "RCP-DIFF-03"]),
      step: r.pick(STEPS),
      eqp_id: r.pick(eqp).eqp_id,
      duration_s: dur,
      indicators: {
        avg_pressure: +(5 + r.normal(0, 0.1)).toFixed(3),
        peak_power: +(1000 + r.normal(0, 30)).toFixed(1),
        avg_temp: +(270 + r.normal(0, 3)).toFixed(2),
        endpoint_t: +(dur * 0.75 + r.normal(0, 3)).toFixed(1),
      },
      trace,
    });
  }
  return out;
}

// ========================= DEFECT =========================
export function getDefects(lotId?: string): DefectRecord[] {
  const lots = lotId ? [getLots().find((l) => l.lot_id === lotId)!].filter(Boolean) : getLots().slice(0, 6);
  const r = new RNG(SEED + 8);
  const eqp = getEquipment();
  const out: DefectRecord[] = [];
  for (const l of lots) {
    const count = r.int(20, 80);
    for (let i = 0; i < count; i++) {
      out.push({
        defect_id: `D${l.lot_id}-${i}`,
        lot_id: l.lot_id,
        wafer_no: r.int(1, 25),
        x: +r.range(-12, 12).toFixed(2),
        y: +r.range(-12, 12).toFixed(2),
        size_um: +r.range(0.1, 5).toFixed(2),
        class: r.pick(DEFECT_CLASSES),
        source_eqp: r.pick(eqp).eqp_id,
        ts: new Date(NOW - r.int(0, 7) * 86400000).toISOString(),
      });
    }
  }
  return out;
}

// ========================= APC =========================
let _apcModels: ApcModel[] | null = null;
export function getApcModels(): ApcModel[] {
  if (_apcModels) return _apcModels;
  const r = new RNG(SEED + 9);
  _apcModels = SPC_PARAMS.slice(0, 6).map((p, i) => ({
    model_id: `APC-M${String(i + 1).padStart(3, "0")}`,
    name: `R2R ${p.name}`,
    param: p.name, step: p.step,
    health: +r.range(0.55, 0.98).toFixed(3),
    last_update: new Date(NOW - r.int(0, 720) * 60000).toISOString(),
    actions_24h: r.int(2, 40),
  }));
  return _apcModels;
}

export function getApcActions(modelId?: string): ApcAction[] {
  const r = new RNG(SEED + 11 + (modelId ? modelId.charCodeAt(modelId.length - 1) : 0));
  const lots = getLots();
  const models = modelId ? getApcModels().filter((m) => m.model_id === modelId) : getApcModels();
  const out: ApcAction[] = [];
  let id = 0;
  for (const m of models) {
    for (let i = 0; i < 30; i++) {
      const oldSp = 100 + r.normal(0, 5);
      out.push({
        action_id: `ACT-${String(id++).padStart(5, "0")}`,
        ts: new Date(NOW - i * 1800000).toISOString(),
        model_id: m.model_id,
        lot_id: r.pick(lots).lot_id,
        param: m.param,
        setpoint_old: +oldSp.toFixed(3),
        setpoint_new: +(oldSp + r.normal(0, 1.5)).toFixed(3),
        reason: r.pick(["Drift correction", "Recipe tune", "Material lot change", "Tool-to-tool match"]),
      });
    }
  }
  return out;
}

// ========================= MTR =========================
export function getMtrMeasurements(): MtrMeasurement[] {
  const r = new RNG(SEED + 12);
  const lots = getLots().slice(0, 20);
  const out: MtrMeasurement[] = [];
  let id = 0;
  for (const l of lots) {
    for (const p of SPC_PARAMS.slice(0, 5)) {
      for (let w = 1; w <= 5; w++) {
        out.push({
          meas_id: `MTR-${String(id++).padStart(6, "0")}`,
          ts: new Date(NOW - r.int(0, 7) * 86400000).toISOString(),
          lot_id: l.lot_id,
          wafer_no: w,
          param: p.name,
          value: +(p.target + r.normal(0, (p.usl - p.lsl) / 8)).toFixed(4),
          tool: `${p.eqp}${String(100 + r.int(0, 5)).padStart(3, "0")}`,
        });
      }
    }
  }
  return out;
}

// ========================= REL =========================
export function getRelResults(): RelResult[] {
  const r = new RNG(SEED + 13);
  const lots = getLots().filter((l) => l.status === "DONE").slice(0, 15);
  const out: RelResult[] = [];
  let id = 0;
  for (const l of lots) {
    for (const t of ["WLR", "HTOL", "EM", "TDDB", "NBTI"] as const) {
      const spec = r.range(0.8, 1.2);
      const v = spec + r.normal(0, 0.15);
      out.push({
        test_id: `REL-${String(id++).padStart(5, "0")}`,
        lot_id: l.lot_id,
        test_type: t,
        param: `${t}_metric`,
        value: +v.toFixed(4),
        spec: +spec.toFixed(4),
        pass: v >= spec * 0.85,
        date: new Date(NOW - r.int(1, 60) * 86400000).toISOString(),
      });
    }
  }
  return out;
}

// ========================= AGT =========================
export function getAgentSessions(): AgentSession[] {
  const r = new RNG(SEED + 14);
  const intents = [
    "Yield excursion RCA", "SPC violation triage", "WAT outlier investigation",
    "FDC anomaly", "Defect signature match", "Equipment health check",
    "APC model retune", "Cycle time analysis",
  ];
  const users = ["a.chen", "m.park", "s.tanaka", "r.singh", "j.morales", "k.wright"];
  return Array.from({ length: 24 }, (_, i) => ({
    session_id: `SES-${String(900000 + i).padStart(7, "0")}`,
    ts: new Date(NOW - r.int(0, 72) * 3600000).toISOString(),
    user: r.pick(users),
    intent: r.pick(intents),
    outcome: r.pick(["RESOLVED", "RESOLVED", "RESOLVED", "ESCALATED", "PENDING"] as const),
    duration_s: r.int(45, 1800),
    actions: r.int(3, 28),
  }));
}

export function getRcaKnowledge(): RcaEntry[] {
  const r = new RNG(SEED + 15);
  const entries = [
    { sym: "Vt N-MOS drift high", root: "Implant dose mis-calibration on IMPL104", fix: "Recalibrate Faraday cup, re-qual lot" },
    { sym: "Edge-die yield loss", root: "CMP edge over-polish on CMP102", fix: "Adjust retainer ring pressure -8%" },
    { sym: "Gate CD widening", root: "Litho focus drift on LITHO101", fix: "Re-tune focus, refresh resist" },
    { sym: "Particle excursion", root: "PM overdue on PVD103 cathode liner", fix: "Schedule emergency PM" },
    { sym: "RF power instability", root: "Matching network drift on ETCH102", fix: "Replace matchbox capacitor bank" },
    { sym: "Sheet ρ low", root: "PVD target end-of-life", fix: "Swap target, re-qual" },
    { sym: "WAT site-9 fail", root: "Probe card site 9 contact resistance", fix: "Probe card refurb" },
    { sym: "Cycle time spike", root: "Queue at LITHO due to PM stack-up", fix: "Re-balance PM schedule" },
  ];
  return entries.map((e, i) => ({
    rca_id: `RCA-${String(i + 1).padStart(4, "0")}`,
    symptom: e.sym, root_cause: e.root, fix: e.fix,
    confidence: +r.range(0.65, 0.96).toFixed(2),
    cases: r.int(3, 42),
  }));
}

// ========================= KPIs =========================
export function getKpis() {
  const lots = getLots();
  const alarms = getAlarms();
  const eqp = getEquipment();
  const inProc = lots.filter((l) => l.status === "IN_PROCESS").length;
  const done = lots.filter((l) => l.yield_pct != null);
  const avgYield = done.reduce((s, l) => s + (l.yield_pct ?? 0), 0) / Math.max(1, done.length);
  const openAlarms = alarms.filter((a) => a.status === "OPEN").length;
  const criticalAlarms = alarms.filter((a) => a.status === "OPEN" && a.severity === "CRITICAL").length;
  const avgOee = eqp.reduce((s, e) => s + e.oee, 0) / eqp.length;
  return {
    fab_yield: +avgYield.toFixed(2),
    yield_delta: +(avgYield - 94.2).toFixed(2),
    active_alarms: openAlarms,
    critical_alarms: criticalAlarms,
    lots_in_process: inProc,
    avg_oee: +(avgOee * 100).toFixed(1),
  };
}
